# The Schedule FA calculation engine

This is where the exchange-rate engine, the market-data snapshot, the
reconstructed lots and the security master finally combine into the numbers
that go on the return. Everything before this step gathers and verifies data;
this step commits to figures.

## Every figure explains itself

Each reported money value is a `ComputedFigure` carrying the native amount,
the rate that converted it, the rupee result, the arithmetic as text, and a
sentence of prose. This is not presentation polish. A Schedule FA figure may
have to be defended years after filing, and `peak value 1,52,340` is
indefensible on its own, while "highest of 248 daily rupee valuations, reached
on 2025-12-29, 15.25 shares at USD 168.40 converted at the TT buying rate for
that date" is.

A figure that could not be computed is **not zero**. It holds no amount, a
status of `UNAVAILABLE`, and the reason. Writing zero into a field whose value
is unknown is the most dangerous thing this module could do, because zero is a
number a reader will believe. The tables distinguish four states:

| Status | Meaning |
| --- | --- |
| `COMPLETE` | Computed from confirmed rules and complete data |
| `QUALIFIED` | Computed, but something needs a human's attention before filing |
| `NIL` | Genuinely nil — no dividend was paid, nothing was sold |
| `UNAVAILABLE` | Could not be computed; the reason is attached |

`NIL` and `UNAVAILABLE` both look like an absence of value and mean opposite
things. A holding that paid no dividend reports nil. A holding whose dividend
cannot be determined reports unavailable and blocks the filing.

## Each field uses its own exchange rate

The rule version states, per field, which date's rate applies. They differ,
and the engine follows each one separately:

| Field | Rate date |
| --- | --- |
| Initial value | each acquisition's own date |
| Peak value | each candidate valuation date |
| Closing value | the last day of the reporting period |
| Income credited | the date each amount was credited |
| Gross proceeds | the date of each sale |

Converting everything at one rate would be simpler and wrong. Purchases months
apart do not share an exchange rate, so the initial value is the **sum of
per-lot rupee amounts**, not the rupee value of the summed dollar cost.

## Why the peak is searched in rupees

Peak value is the highest rupee value the holding reached. That is not the
highest dollar value converted once. A holding can peak in dollars in June and
in rupees in November, if the rupee weakened in between. So the engine values
the holding on every priced day it was held, converts each valuation at the
rate for that same day, and takes the maximum of the rupee results.

Dates the holding changed are always valuation candidates, because a peak can
fall on a purchase date and omitting it would understate.

Peak value uses the **intra-day maximum** quantity rather than the closing
balance. Shares bought and sold on one date were still held that date. The
closing value, by contrast, uses the end-of-day balance, which is what it
asks for.

A coarser search frequency (`MONTH_END`, `QUARTER_END`) is available for
sparse price data and is labelled on the figure, because sampling fewer dates
can only find a lower maximum.

## What blocks, and what merely warns

Blocking, no tables produced at all:

- the price series' split-adjustment basis is unknown or does not match the
  share quantities. Valuing unadjusted quantities with adjusted prices
  understates a pre-split holding by the whole split ratio, with nothing
  visibly wrong in the output, so no valuation is attempted at all.

Reported but not filable:

- any missing identity field — legal entity name, address, ITR country code,
  nature of the entity. These come from the security master and are never
  derived from a ticker symbol.
- initial value where part of the holding predates the uploaded statements.
- the Table A2 account number, status and opening date, which a transaction
  export does not contain and which are never inferred. The earliest
  transaction date is not an account opening date.

Labelled on every figure:

- the rule version is `REQUIRES_CONFIRMATION`. Until the reporting period and
  per-field rate conventions are checked against the published instructions
  for that assessment year, no figure is `COMPLETE`.
- a carried-forward price, with how many days it was carried.
- a peak built on inferred history, which is a lower bound.

## Holdings with missing acquisition history

A file that begins mid-history produces a holding with an inferred lot: a sale
of three shares proves three were held, so three are recorded with no
acquisition date and no cost. The split of what remains computable is precise:

- **Peak value** is computed, because it needs only quantity — but only over
  the dates the holding is *provably* held, and labelled a lower bound. The
  shares were very likely held earlier too; asserting the period start as the
  acquisition date would invent information.
- **Closing value** is computed, because it needs only the closing quantity.
- **Initial value** is unavailable. A cost basis missing one lot is not a
  cheaper holding, so the partial figure is never reported — it would
  understate cost and overstate gain.
- **Date of acquiring the interest** is blank. The earliest date that happens
  to be in the file is not the acquisition date.

## Table A2 reports the account, not its contents

The custodial-account row reports the **cash balance only**. The value of the
securities in the account is reported in Table A3. Adding it to A2 as well
would report the same wealth twice.

The peak balance is derived from the transaction ledger rather than from any
balance the broker states, so that it comes from the same data as everything
else and any disagreement with the broker's own figure surfaces in
reconciliation instead of being hidden.

Deposits the account holder funded the account with are excluded from "gross
amount paid or credited": that is the holder's own money moving in, not an
amount paid or credited to them.

## Running it

```
python -m backend.app.cli schedule-fa <broker-file> \
  --assessment-year 2026-27 \
  --fx-dataset sbi-ttbr --fx-version 2025.1 \
  --prices <price-file> --basis UNADJUSTED
```

The command exits `0` only when every row is complete and nothing blocks;
otherwise `2`. It prints both tables, then the derivation and caveats of every
figure, then the issues.

`--basis` is required and has no default, for the reason given above. The
`--valuation-point`, `--peak-frequency` and `--method` options are platform
policy choices, not statutory rules, and are printed on every report.
