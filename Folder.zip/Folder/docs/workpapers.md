# Workpapers

The workpaper is the deliverable. Everything upstream of it exists so that
this document can be handed to a preparer, read without access to the system
that produced it, and defended years later if the figures are questioned.

Two formats are produced from the same in-memory document:

| Format | What you get | When to use it |
| --- | --- | --- |
| XLSX | One workbook, thirteen sheets, formatted | Review and filing |
| CSV bundle | One file per sheet plus a manifest | Diffing, scripting, archiving |

Both are built by `WorkpaperBuilder` from a `WorkpaperInputs`, so they cannot
disagree about a figure. The writers differ only in what the format can carry.

## Sheet order is the argument

A reviewer opens the file and reads, in order:

1. **Cover** — what this is, the assessment year, the rule version, the filing
   verdict, and the hash of every uploaded file.
2. **Methodology** — the choices the platform made that are configuration
   rather than statute: lot allocation, valuation point, peak frequency, the
   exchange-rate dataset, the market-data basis.
3. **Schedule FA A2** and **Schedule FA A3** — the two tables as the form asks
   for them.
4. **Figure Derivation** — one row per reported money figure with the
   arithmetic, the rate applied, the rate's date and the reasoning.
5. **Peak Valuation** — every valuation considered while searching for the
   peak, with the selected date marked.
6. **Exchange Rates Used** — each rate this run actually applied, with why it
   was the applicable one.
7. **Transactions**, **Lots**, **Disposals**, **Securities** — the underlying
   data, each row carrying the reference back to a cell in the broker's export.
8. **Worklist** and **Issues** — what is wrong and what to do about it.

Putting the figures first and the caveats last would make it a sales document.
The verdict goes on the cover: if the run is blocked, the first thing on the
first sheet is `DO NOT FILE FROM THIS DOCUMENT AS IT STANDS`.

## NOT AVAILABLE is not zero

A figure the engine could not compute is written as the text `NOT AVAILABLE`
on a shaded, italic cell. It is never written as `0`, and never left blank.

This is the single most consequential rule in the module. A blank cell in a
tax workpaper reads as nil, and a nil foreign asset value is a filed position
that the taxpayer never took. Every `NOT AVAILABLE` has a matching row on the
Figure Derivation sheet giving the reason, and a matching entry on the
Worklist saying what would fill it.

A genuine nil — a holding disposed of before the period ended, say — is a real
zero and is written as a number.

## Numbers stay numbers

Money, quantities and rates are written to the XLSX as `Decimal`, which
openpyxl serialises digit for digit. Nothing passes through `float` on the way
out, so the file holds the figure the engine computed rather than the nearest
binary approximation of it. A preparer can total a column and get the same
answer the system did.

Dates are written as dates, so the ledger can be sorted and filtered.

## Formula injection

Every string on these sheets originated in a file somebody uploaded. A cell
whose text begins with `=`, `+`, `-`, `@`, a tab or a carriage return is
interpreted as a formula by Excel, LibreOffice and Google Sheets, and a
workpaper emailed to an accountant is exactly the delivery path such a payload
is built for.

The two formats defend differently, because they can:

**XLSX** writes the cell with an explicit string type. The text is preserved
exactly as the broker wrote it — no apostrophe, no escaping — and the file
contains no `<f>` element for a spreadsheet to evaluate. The reader sees the
original, and nothing runs.

**CSV** has no type system, so the value has to change: a single leading
apostrophe is prefixed. Because that alters what the user uploaded, every
alteration is counted and reported in `00-manifest.csv`, naming the sheet,
column and row, and recommending the XLSX where this matters. Silently
changing a value would be worse than the injection.

A value that merely looks arithmetic — `-1234.00`, `+42` — is left alone. No
spreadsheet evaluates it as a formula, and prefixing every negative amount
would turn the numbers into text for every downstream consumer.

Also handled: control characters, which XLSX's XML cannot carry at all, are
stripped; cells longer than Excel's 32,767-character limit are clipped, marked
`[truncated]` and reported; and sheet names are stripped of the characters
Excel forbids, clipped to 31 characters and de-duplicated.

## Producing one

```bash
# One workbook
fa schedule-fa export.xlsx \
  --assessment-year 2026-27 \
  --fx-dataset sbi-ttbr --fx-version 2025-01 \
  --prices prices.csv --basis UNADJUSTED \
  --workpaper out/workpaper.xlsx

# The CSV bundle: any path that is not .xlsx is treated as a directory
fa schedule-fa export.xlsx ... --workpaper out/workpaper/
```

The command prints any neutralisation the writer had to perform. It exits `0`
when the Schedule FA is filable and `2` when something blocks it, so it can be
used in a pipeline.

## Adding a sheet

Add a `_method` to `WorkpaperBuilder` returning a `Sheet`, and one
`paper.add(...)` call in `build` at the position it should be read. Both
writers pick it up with no change: the XLSX writer walks the sheets, and the
CSV writer emits one file per sheet with a numbered name so that sorting the
folder reproduces the reading order.

Do not compute anything in a sheet method. Every figure comes from the stage
that owns it, because a workpaper that derives its own numbers can disagree
with the system it is supposed to document.
