# Adding a broker

Adding a broker is a self-contained change. Nothing in the exchange-rate, lot,
valuation or Schedule FA modules is touched, because a parser's only output is
the canonical ledger.

## What you write

| File | What goes in it |
| --- | --- |
| `backend/app/brokers/<broker>/mapping.py` | Sheet names, column alias lists, date layouts, activity-label table |
| `backend/app/brokers/<broker>/parser.py` | `detect`, `normalize`, and any broker-specific quirks |
| `backend/app/brokers/registry.py` | One line registering the parser |
| `tests/fixtures/<broker>/builder.py` | A synthetic workbook covering the broker's real cases |
| `tests/unit/test_<broker>_parser.py` | Tests against that fixture |

Most of the work is the mapping. The base class in `backend/app/brokers/base.py`
already locates sheets, validates headers, resolves date layouts across a whole
column, extracts decimals without ever touching a float, derives deterministic
transaction ids, and builds the parser report.

## Confirming the mapping against a real file

The alias lists ship as a best guess. Confirm them against an actual export
before trusting any figure:

```bash
python -m backend.app.cli inspect-broker path/to/statement.xlsx
```

That prints the real sheet names, the real column headers, the resolved date
layout, every distinct activity label, and which labels the mapping does not
cover. Add `--parse` to also see the normalized ledger and the parser report.

To see what a registered parser currently expects:

```bash
python -m backend.app.cli brokers
```

## Rules the parser layer holds to

**A required column that is absent stops the parse.** The platform raises
`BROKER_FORMAT_CHANGED` and names the column. It does not infer which of the
remaining columns now holds the price. A parse that stops is recoverable; a
parse that guesses produces a finished-looking, wrong tax figure.

**A file no parser recognises is rejected.** `BROKER_UNIDENTIFIED` names the
sheets it found and each parser's verdict. There is no best-effort fallback
parser, and two parsers claiming a file with equal confidence is also an error
rather than a coin toss.

**Column matching is exact after normalising case and punctuation.** `Price /
Share` matches an alias of `Price/Share`. `Scrip` does *not* match
`Description`, even though the letters are in there — an earlier substring
fallback did exactly that and gave cash deposits a ticker of "Additional
Funding". Declare the real spelling instead; unmatched columns are reported as
unmapped, not silently bound.

**Date layouts are resolved per column, not per cell.** `01/02/2025` cannot be
read in isolation. The resolver looks at every value in the column, and if two
layouts both parse all of them but disagree on any one, it refuses and reports
the ambiguity. A silently transposed date moves a transaction into the wrong
reporting period.

**Unknown activity labels become `UNKNOWN`, never a guess.** The row is kept and
flagged. If it carries a quantity it is a blocking error, because holdings
cannot be reconstructed around a transaction of unknown effect.

**Gross income and withholding tax stay separate.** A $10 dividend with $1
withheld is recorded as gross 10, tax 1, net 9 — two transactions from one
source row, both pointing back at it. It is never recorded as a $9 dividend.

**Cash movements are not acquisitions.** A deposit funds the cash account and
creates no lot. A securities transfer in does create one. The distinction is
whether the row names a security and a quantity, not which sheet it came from.

**Duplicates are flagged, never removed.** An investor can legitimately buy the
same quantity of the same stock twice in a day. The platform reports the
candidates and the user decides.

**Nothing is a float.** Values are read from the file's exact digit string into
`Decimal`. Magnitudes are stored unsigned; direction comes from the transaction
type.

**Every transaction traces back.** Source file id, sheet, row, a hash of the raw
row, the broker id and the parser version are recorded on each one, and the
verbatim row is retained alongside it.

## Parser version

Bump `PARSER_VERSION` on any change to parsing behaviour. It is stored on every
transaction, so a figure in a filed return can always be traced to the code that
produced it.
