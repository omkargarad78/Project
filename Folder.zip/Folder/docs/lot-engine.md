# The lot engine

A *lot* is a parcel of shares acquired in one transaction, with its own
acquisition date and cost. Schedule FA Table A3 needs both, and a holding
built from three purchases has three answers to each.

The engine walks the ledger in date order and maintains, per security, the
open lots and the running share count. Everything downstream reads from what
it produces.

## Missing history is the normal case

An investor who opened a Vested account in 2022 and uploads only this year's
statement has a file in which shares are sold that were never bought. The
synthetic fixture models this with MSFT: three shares sold in June, no
acquisition anywhere.

The engine neither fails nor pretends. Selling three shares **proves** three
shares were held, so it records an inferred opening lot of three shares:

```
MSFT: 0 held, 1 lot(s), 1 disposal(s)
    LOT-INFERRED-... MSFT 3 acquired acquisition date unknown, 0 remaining, cost unknown [INFERRED]
    disposed 3 on 2025-06-12, cost basis UNKNOWN
```

The quantity is a **lower bound** — at least three were held. The acquisition
date and cost stay empty, because neither can be deduced from a sale, and both
raise blocking errors. The practical consequence is worth stating plainly:

- Peak and closing value **can** still be computed, because they depend only
  on quantity.
- Initial value and gain **cannot**, and say so rather than guessing.

A partly-known cost basis is reported as unknown, not as a smaller number. A
basis missing one lot is not a cheaper holding; reporting the partial figure
would overstate the gain.

Two switches change this behaviour. `infer_opening_positions=False` leaves the
shortfall unmatched instead. `assume_complete_history=True` says every
statement has been uploaded, which turns a shortfall into a contradiction —
`OVERSOLD_POSITION` — rather than a gap.

## Allocation is a methodology, not arithmetic

FIFO, LIFO, highest-cost-first and lowest-cost-first are all supported. The
method changes the cost basis of a disposal and therefore the gain, so it is
declared, recorded on every run, and described in the workpaper. The platform
selects FIFO by default and does **not** assert that FIFO is statutorily
required.

It matters less than it looks for Schedule FA itself: peak and closing values
depend only on how many shares were held, which no allocation method changes.
There's a test asserting exactly that.

`BROKER_SPECIFIED` has no strategy of its own, because a transaction export
doesn't identify which lots the broker assigned. The engine falls back to FIFO
and records that it substituted, rather than claiming to have honoured an
assignment it never received.

## Corporate actions

A split restates every open lot: share counts scale, the **total cost does
not**, and cost per share is derived from the two so it can't drift out of
step. A lot acquired after the ex-date is untouched. Each adjustment is stored
on the lot with before and after quantities, for the audit trail.

Ratios are applied as an unevaluated numerator and denominator (see
[market data](market-data.md)), so a 1-for-3 reverse split doesn't shed
fractional shares.

## Reconciliation earns its place

Comparing reconstructed holdings against the broker's own closing figures
catches what everything upstream missed. On the synthetic fixture:

```
NVDA does not reconcile: the transactions produce 15.25 share(s) but the
broker states 11.15, a difference of 4.10.
```

That 4.10 decomposes exactly: 4 shares from the duplicated buy row, and 0.1
from the "Fractional Share Liquidation" the parser couldn't map and therefore
didn't apply. Both were flagged upstream; reconciliation independently
quantifies how much each moved the holding.

A mismatch is reported, never corrected. The broker's figure is evidence about
the answer, not the answer.

## Using it

```bash
python -m backend.app.cli holdings statement.xlsx
python -m backend.app.cli holdings statement.xlsx --method LIFO
```
