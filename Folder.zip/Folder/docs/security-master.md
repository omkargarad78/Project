# The security master

Schedule FA Table A3 asks for the **name of the entity**, its address, its
country and its nature. A broker export contains none of those. It contains a
ticker symbol and a display string.

The security master is where that gap is filled — by a curated dataset and by
what you confirm in the application, never by inference.

## Why a ticker is not an identity

`AAPL` is not a company. It is a symbol that, on a particular venue, during a
particular period, routes to a particular security. Three consequences shape
the design:

- **Symbols change.** `FB` became `META` in 2022. A holding spanning the change
  is one interest and one Schedule FA line, not two.
- **Symbols are reused.** A retired symbol can later be assigned to an
  unrelated company, so a lookup is only meaningful with a date attached.
- **Symbols collide.** The same letters name different securities on different
  exchanges, with different countries.

So every master record holds its symbols as `TickerAssignment`s with validity
ranges, and resolution always asks "what did this symbol mean on this date".
A ledger's symbols are resolved as at the date each was first used.

## What the platform will not do

| It will not | Because |
| --- | --- |
| Use the ticker as the entity name | A wrong entity name is a defect the filer answers for |
| Promote the broker's display name to the legal name | "Apple Inc." in a broker file is a display string, not evidence of a registered name |
| Pick between two candidates for a symbol | The wrong pick yields a confident, wrong country |
| Approximate a near-miss symbol | `NVDAA` resolves to nothing, not to `NVDA` |
| Invent an address | Not the exchange's, not the broker's, not a registered agent's |
| Substitute an ISO code for the ITR country code | The ITR instruction list is not always identical to ISO 3166-1 |
| Infer an account opening date | A transaction export has none; the earliest transaction is not it |

## What blocks and what warns

A resolved security with gaps still flows through the pipeline. The gaps are
reported at their real severity:

- **Blocking** (`ERROR`): unresolved symbol, ambiguous symbol, missing legal
  entity name, missing country.
- **Advisory** (`WARNING`): missing address, missing ZIP, undetermined nature,
  identity not yet confirmed against a source, broker display name disagreeing
  with the recorded legal name.

## The shipped dataset

`data/securities/securities.json` seeds a handful of well-known US issuers.
Every record ships as `REQUIRES_CONFIRMATION` with tier-5 provenance, because
nothing in it has been checked against a filing. No record carries an address.

Two entries are deliberately incomplete, and their incompleteness is the point:

- **`SEC-US-VOO`** has no legal entity name. An ETF share class is not obviously
  the entity Schedule FA means, and that decision belongs to you and your tax
  professional, not to a default.
- **`INST-VESTED`** has no legal name. Table A2 asks for the institution holding
  the custodial account, and Vested Finance is an intermediary routing to a US
  broker-dealer and custodian. Those are different entities with different
  addresses, so the platform leaves it for you to take from your statement.

## Working with it

```bash
# What the master holds and what each record still needs
python -m backend.app.cli securities

# Parse a broker file and resolve its tickers end to end
python -m backend.app.cli resolve-securities path/to/statement.xlsx
```

Corrections go in `data/securities/user_overrides.json` as a list of
`SecurityOverride` objects, and later through the Security Master page. An
override outranks the shipped dataset — you have access to the company's
filings and the dataset is only a convenience — and is recorded as
user-confirmed provenance with whatever reference you cite, so the report can
say where each value came from.

```json
[
  {
    "security_id": "SEC-US-NVDA",
    "address": { "line1": "2788 San Tomas Expressway", "city": "Santa Clara", "state": "CA", "zip_code": "95051" },
    "reference": "Form 10-K cover page, FY2025",
    "confirmed_on": "2026-01-15"
  }
]
```
