# Validation, the worklist and recorded decisions

Every pipeline stage reports what it found where it found it. That is right for
the stage and useless for a person: a real broker file produces hundreds of
issues, most of them the same problem seen from different rows. This module
turns that into one ranked worklist and one honest answer to "can I file
this?".

## Issues are grouped by the action that clears them

The unit of work is the action, not the issue. Two hundred missing-rate
messages are one trip to import a rate dataset. Presented as two hundred tasks
they misrepresent the effort and bury the five things that actually need a
decision, so each group names the work:

| Action | What the user does |
| --- | --- |
| `IMPORT_FX_DATASET` | Import exchange-rate data covering the missing dates |
| `IMPORT_PRICE_DATA` | Import market prices, or the right adjustment basis |
| `UPLOAD_EARLIER_STATEMENT` | Supply the history the file begins after |
| `SUPPLY_ENTITY_DETAILS` | Fill in the issuer's name, address, country, nature |
| `SUPPLY_ACCOUNT_DETAILS` | Fill in the account and institution details |
| `CONFIRM_TAX_RULES` | Check the rule version against the published form |
| `CORRECT_SOURCE_FILE` | Fix or re-export the broker file |
| `EXTEND_BROKER_SUPPORT` | The parser needs a mapping it does not have |
| `ACKNOWLEDGE` | Nothing to fix; decide whether to accept it |

## Ordering is by what the work unblocks

Blocking work comes first, because nothing can be filed until it is done.
Within that, groups standing in the way of the most reported figures come
first: a warning between the user and four holdings deserves more attention
than an error on one holding that has other unfixable problems anyway. Groups
where every issue already has a recorded decision sink to the bottom. Severity
only breaks the remaining ties.

Each group states which figures it stands in the way of, and that claim is
narrowed as far as the data allows. An issue that names the form fields it
concerns is attributed to exactly those; only an issue that names none is
attributed to every blank field of its subject. Over-claiming would be worse
than useless here — a user who supplies the account number and watches the
blocked-figure count stay where it was stops trusting the list.

## Acknowledgement is not a universal escape hatch

The distinction is **not** severity. It is whether the figure can still be
produced correctly:

- **Not waivable.** A missing exchange rate, a missing price, an unknown
  acquisition cost, an unconfirmed legal entity name. Accepting these does not
  produce the figure they guard. There is no rupee amount to report without a
  rate, no matter who accepts what, so acknowledging them leaves the run
  blocked.
- **Waivable.** A holding that disagrees with the broker's stated closing
  balance, or a suspected duplicate row. Every figure is computed; the question
  is whether the platform's reading or the broker's is right, and the user may
  legitimately know the broker's own number is stale.

At the time of writing exactly two errors are waivable —
`LOT_RECONCILIATION_FAILED` and `CASH_RECONCILIATION_FAILED` — and a test
asserts that list in full, so widening it is a deliberate act rather than an
implementation detail. Waivers are the only way the platform's guard rails can
be stepped around, so what is steppable is kept short and reviewable in one
place (`_WORKFLOW` in `backend/app/core/errors.py`).

An acknowledgement always requires a written reason. A bare one is
indistinguishable from a mis-click a year later, and these notes are what
explain why a figure looks the way it does.

## Accepting and fixing behave differently across a re-run

Every re-run regenerates the issue list from scratch, which is what makes the
platform deterministic. It also puts every recorded decision at risk of being
lost, or worse, of being re-applied when it should not be.

- **Acknowledging** is a judgement about a condition expected to persist —
  "yes, those two identical trades are both real". It survives a re-run,
  because the condition surviving is exactly what was accepted.
- **Recording a fix** claims the underlying data changed — "I imported the
  missing rates". It does **not** survive a re-run. If the issue is generated
  again then the data evidently did not change, and carrying the claim forward
  would hide a live problem behind a stale assertion. The claim is reopened
  with a note saying when it was made and that the condition is still present.

Decisions are keyed on the *condition* (code, scope, subject) rather than on
the issue's wording, so rewording does not orphan them. When the wording does
change, the decision is kept and flagged `NEEDS_RECONFIRMATION` with both the
old and new text — the user accepted a specific statement, and neither
silently dropping their decision nor silently carrying it onto a different
statement is acceptable. A condition that no longer occurs is reported
`OBSOLETE`, so a decision is never carried onto data it was never about.

### Known limitation: a re-export loses decisions about transactions

The `subject` half of that key is, for transaction-level conditions, the
transaction id — and a transaction id is derived from where the row sat:
`(source file hash, sheet name, row number)`. That is stable when the same
file is re-uploaded, which is what the determinism tests assert.

It is *not* stable when the broker re-exports the statement. A single extra
row shifts every row number below it, so every transaction id changes, and
every decision recorded against those transactions is reported `OBSOLETE`
rather than carried forward. Nothing is silently mis-applied — which is the
important part — but the user is asked to re-confirm work they already did.

Fixing this means keying transaction ids on transaction *content* rather than
file position. That is a deliberate change with its own trade-off, since two
genuinely identical trades on the same day would then share an id, which is
exactly the case the duplicate detector exists to surface. It is recorded
here rather than done quietly.

## No blank box without an explanation

The engine cross-checks the produced Schedule FA against the issue list: every
field the report could not fill must have an issue behind it. A gap in the form
with nothing in the worklist is the worst outcome available, because the user
sees an empty box and finds nothing telling them how to close it. Where that
happens the engine raises the issue itself and labels it as a gap in the
platform's own reporting rather than a judgement about the user's data. The
integration suite asserts that this list comes back empty on a full run.

## The verdict

| Verdict | Meaning |
| --- | --- |
| `READY` | Every figure computed from confirmed rules and complete data |
| `READY_WITH_QUALIFICATIONS` | Complete, but qualifications need reading first |
| `BLOCKED` | At least one required figure or field does not exist |

While a rule version is `REQUIRES_CONFIRMATION`, no run reaches `READY` — the
reporting period and the per-field rate conventions have to be checked against
the published instructions first. That is a qualification rather than a
blocker: the figures are computed and labelled, and a person decides.

## Running it

```
python -m backend.app.cli schedule-fa <broker-file> ... \
  --resolutions decisions.json
```

Exit code is `0` when the run is filable and `2` otherwise. With
`--resolutions`, previously recorded decisions are re-applied under the rules
above and the command prints an account of what happened to each one,
including the ones it deliberately did not apply.
