# Market data

Peak and closing values need a price for a security on a date. Two things
about that are easy to get wrong, and both produce numbers that look fine.

## The split-adjustment trap

Most free price series are **split-adjusted**: after a 4-for-1 split, every
earlier price is divided by four so the chart stays smooth. Multiply such a
price by the shares you actually held back then, and you understate the
holding by the whole split ratio.

Using the synthetic NVDA fixture, which has a 4-for-1 split mid-year, valuing
10 shares held on 3 March:

| Basis | Price | × 10 shares |
| --- | --- | --- |
| Unadjusted | 135.20 | 1352.00 |
| Split-adjusted | 33.80 | 338.00 |

Both are arithmetically correct. Only one answers the question. Nothing in the
result reveals which, and after the ex-date the two series agree exactly — so
the error is invisible unless the basis is tracked.

The platform therefore treats the basis as data, not an assumption:

- Every `PriceRecord` and every snapshot carries an `AdjustmentBasis`.
- `UNKNOWN` is an **error**, not a silent default to unadjusted.
- Pairing adjusted prices with historical share counts (or the reverse) raises
  `PRICE_ADJUSTMENT_BASIS_MISMATCH` and stops.
- A total-return series is refused outright for valuation: it folds reinvested
  dividends into the price, answering "what would this investment have
  returned" rather than "what was this share worth".
- A snapshot whose records disagree about their basis is refused.

The CLI has no default either:

```bash
python -m backend.app.cli inspect-prices prices.csv --basis UNADJUSTED --currency USD
```

If your provider doesn't state the basis, check a stock that split during the
period: an adjusted series shows no price jump on the ex-date.

## Missing prices are never invented

There is no interpolation option, by design. Averaging across a gap invents a
quotation that never existed, and a peak value built on invented quotations
isn't defensible on assessment.

What the engine does instead is distinguish two cases that look identical in
the data:

- **The market was closed.** Weekends and exchange holidays have no price
  because no trading happened. The last traded price is the correct value, and
  using it is convention rather than estimation.
- **The data is incomplete.** A price absent on a day the market was open.

It tells them apart using a trading calendar inferred from the snapshot itself
— a date counts as a trading day when at least 40% of covered securities have
a price on it — rather than a hard-coded holiday list that would go stale and
differ by venue. Every carried-forward price is labelled with how many days it
was carried and whether other securities traded in that gap. Beyond
`max_carry_forward_days` (default 4, enough for a weekend plus a holiday) the
price is reported missing rather than stretched.

## Snapshots are immutable and content-addressed

A calculation names a snapshot; the snapshot never changes. This matters
because providers restate history every time a split happens, so a report
re-run six months later would otherwise produce different figures from the
same inputs.

The version id is a hash of the prices and corporate actions, so identical
data always yields the same id and any change yields a different one. Two
snapshots holding different values for the same quotation cannot be merged —
that's an error, not a precedence rule, because silently preferring one source
hides a disagreement you'd want to see.

## Corporate actions

Ratios are stored as an unevaluated numerator and denominator. A 1-for-3
reverse split has no finite decimal factor, so `adjust_quantity` multiplies
before dividing: 900 shares through two 1-for-3 reverse splits give exactly
100, where composing rounded factors would shed fractional shares at each
step.

Actions are never inferred from price jumps. An unverified action warns,
because its ratio changes every share count after the ex-date.

## Adding a provider

Implement `PriceProvider.fetch`. Providers return records and nothing else —
they don't decide policy and don't value anything, which is what lets a new
source be added without touching valuation. Whatever a provider returns must
still be frozen into a snapshot before it's used, including a network one.
