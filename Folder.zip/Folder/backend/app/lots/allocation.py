"""Choosing which lots a disposal consumes.

The allocation method changes the cost basis of a sale and therefore the gain,
so it is a methodology choice rather than an arithmetic detail. The platform
selects FIFO by default and says so on every output; it does not assert that
FIFO is statutorily required.

It matters less than it looks for Schedule FA itself. Peak and closing values
depend only on how many shares were held, which no allocation method changes.
Allocation affects the cost basis of disposals, and the acquisition date and
initial value reported for a holding built from several purchases.

Each strategy is a pure function from open lots to a consumption order, so a
new method is a function and a table entry, not a change to the engine.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from datetime import date

from ..tax.rules.models import LotAllocationMethod
from .models import Lot


#: Sort key used to break ties deterministically. Two lots acquired on the
#: same date with the same cost must still be consumed in a fixed order, or
#: the same inputs would produce different lot ids between runs.
def _stable(lot: Lot) -> tuple[str, str]:
    return (lot.source_transaction_id or "", lot.lot_id)


def _acquisition_key(lot: Lot) -> date:
    """Sort key for date ordering.

    A lot with no acquisition date sorts earliest. That is the honest
    placement: an inferred lot exists precisely because the shares were
    acquired before anything in the file.
    """
    return lot.acquisition_date or date.min


def fifo(lots: Sequence[Lot]) -> list[Lot]:
    """Oldest first."""
    return sorted(lots, key=lambda lot: (_acquisition_key(lot), _stable(lot)))


def lifo(lots: Sequence[Lot]) -> list[Lot]:
    """Newest first.

    Inferred lots still sort last here rather than first, because ``date.min``
    reversed puts them at the end, which is the desired behaviour: a method
    that prefers recent lots should reach for the undocumented opening
    position only when nothing else remains.
    """
    return sorted(
        lots, key=lambda lot: (_acquisition_key(lot), _stable(lot)), reverse=True
    )


# A lot with no known cost cannot be ranked by cost at all. The cost-based
# methods below place such lots last, so documented lots are consumed first
# and as much of the disposal as possible stays on a known basis.


def highest_cost_first(lots: Sequence[Lot]) -> list[Lot]:
    known = [lot for lot in lots if lot.cost_per_share is not None]
    unknown = [lot for lot in lots if lot.cost_per_share is None]
    known.sort(key=lambda lot: (-(lot.cost_per_share or 0), _stable(lot)))
    unknown.sort(key=_stable)
    return [*known, *unknown]


def lowest_cost_first(lots: Sequence[Lot]) -> list[Lot]:
    known = [lot for lot in lots if lot.cost_per_share is not None]
    unknown = [lot for lot in lots if lot.cost_per_share is None]
    known.sort(key=lambda lot: (lot.cost_per_share, _stable(lot)))
    unknown.sort(key=_stable)
    return [*known, *unknown]


AllocationStrategy = Callable[[Sequence[Lot]], list[Lot]]

STRATEGIES: dict[LotAllocationMethod, AllocationStrategy] = {
    LotAllocationMethod.FIFO: fifo,
    LotAllocationMethod.LIFO: lifo,
    LotAllocationMethod.HIGHEST_COST_FIRST: highest_cost_first,
    LotAllocationMethod.LOWEST_COST_FIRST: lowest_cost_first,
    # BROKER_SPECIFIED has no strategy of its own. The broker's lot assignment
    # is not present in a transaction export, so the engine falls back to FIFO
    # and says that it did, rather than claiming to have honoured an
    # assignment it never received.
    LotAllocationMethod.BROKER_SPECIFIED: fifo,
}


def strategy_for(method: LotAllocationMethod) -> AllocationStrategy:
    try:
        return STRATEGIES[method]
    except KeyError as exc:  # pragma: no cover - guarded by the enum
        raise ValueError(f"no allocation strategy for {method}") from exc


def describe_method(method: LotAllocationMethod) -> str:
    """Wording used in the workpaper's methodology sheet."""
    descriptions = {
        LotAllocationMethod.FIFO: (
            "First in, first out: the oldest shares still held are treated as "
            "the ones sold."
        ),
        LotAllocationMethod.LIFO: (
            "Last in, first out: the most recently acquired shares still held "
            "are treated as the ones sold."
        ),
        LotAllocationMethod.HIGHEST_COST_FIRST: (
            "Highest cost first: the most expensive shares still held are "
            "treated as the ones sold."
        ),
        LotAllocationMethod.LOWEST_COST_FIRST: (
            "Lowest cost first: the cheapest shares still held are treated as "
            "the ones sold."
        ),
        LotAllocationMethod.BROKER_SPECIFIED: (
            "Broker-specified lots, where the export identifies them. A "
            "transaction export does not, so first in, first out was applied "
            "and the substitution is recorded."
        ),
    }
    return descriptions[method]
