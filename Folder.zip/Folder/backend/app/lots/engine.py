"""Reconstructing holdings from a transaction ledger.

The engine walks the ledger in date order and maintains, per security, the
open lots and the running share count. Everything downstream — peak value,
closing value, acquisition date, cost basis — reads from what it produces.

The hard case is missing history, and it is the normal case. An investor who
started with Vested in 2022 and uploads only the current year's statement has
a file in which shares are sold that were never bought. The engine handles
that by deducing what the data requires rather than by failing or by
pretending: a sale of three shares proves three shares were held, so an
inferred opening lot of three shares is recorded, its quantity treated as a
lower bound, its acquisition date and cost left empty, and a blocking error
raised. Peak and closing value can still be computed from the quantity;
initial value and gain cannot, and say so.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from decimal import Decimal

from ..core.errors import ErrorCode
from ..core.hashing import derive_id
from ..core.money import (
    ZERO,
    as_amount,
    as_quantity,
    decimal_to_str,
    is_effectively_zero,
)
from ..marketdata.dataset import MarketDataSnapshot
from ..tax.rules.models import CalculationPolicy, LotAllocationMethod
from ..transactions.ledger import TransactionLedger
from ..transactions.models import NormalizedTransaction, TransactionType
from ..validation.issues import IssueCollector, IssueScope
from .allocation import describe_method, strategy_for
from .models import (
    CorporateActionAdjustment,
    Disposal,
    HoldingChange,
    Lot,
    LotAllocation,
    LotOrigin,
    PositionTimeline,
    ReconciliationResult,
)

#: Difference below which a reconciliation counts as matching. Brokers round
#: fractional-share holdings for display, so an exact match is not expected.
RECONCILIATION_TOLERANCE = Decimal("0.00001")

_ORIGIN_BY_TYPE: Mapping[TransactionType, LotOrigin] = {
    TransactionType.BUY: LotOrigin.PURCHASE,
    TransactionType.TRANSFER_IN: LotOrigin.TRANSFER_IN,
    TransactionType.RSU_VEST: LotOrigin.RSU_VEST,
    TransactionType.ESPP_PURCHASE: LotOrigin.ESPP_PURCHASE,
    TransactionType.SPINOFF: LotOrigin.SPINOFF,
}


@dataclass(slots=True)
class SecurityPosition:
    """Everything the engine knows about one security."""

    symbol: str
    lots: list[Lot] = field(default_factory=list)
    disposals: list[Disposal] = field(default_factory=list)
    timeline: PositionTimeline | None = None

    def open_lots(self) -> list[Lot]:
        return [lot for lot in self.lots if lot.is_open]

    def lot(self, lot_id: str) -> Lot | None:
        return next((lot for lot in self.lots if lot.lot_id == lot_id), None)

    def replace_lot(self, updated: Lot) -> None:
        for index, existing in enumerate(self.lots):
            if existing.lot_id == updated.lot_id:
                self.lots[index] = updated
                return
        raise KeyError(updated.lot_id)

    @property
    def quantity(self) -> Decimal:
        return as_quantity(sum((lot.remaining_quantity for lot in self.lots), ZERO))

    @property
    def has_inferred_lots(self) -> bool:
        return any(lot.is_inferred for lot in self.lots)

    def total_cost_of_open_lots(self) -> Decimal | None:
        """Cost of shares still held, or nothing if any lot's cost is unknown."""
        open_lots = self.open_lots()
        if not open_lots or any(not lot.has_cost for lot in open_lots):
            return None
        return as_amount(
            sum((lot.cost_of(lot.remaining_quantity) or ZERO for lot in open_lots), ZERO)
        )


@dataclass(slots=True)
class LotBook:
    """The reconstructed position of every security in a ledger."""

    positions: dict[str, SecurityPosition] = field(default_factory=dict)
    allocation_method: LotAllocationMethod = LotAllocationMethod.FIFO
    method_note: str = ""
    #: Symbols where an opening position had to be inferred.
    inferred_symbols: tuple[str, ...] = ()

    def symbols(self) -> list[str]:
        return sorted(self.positions)

    def position(self, symbol: str) -> SecurityPosition | None:
        return self.positions.get(symbol.strip().upper())

    def timeline(self, symbol: str) -> PositionTimeline | None:
        position = self.position(symbol)
        return position.timeline if position else None

    def all_lots(self) -> list[Lot]:
        return [lot for symbol in self.symbols() for lot in self.positions[symbol].lots]

    def all_disposals(self) -> list[Disposal]:
        return [
            disposal
            for symbol in self.symbols()
            for disposal in self.positions[symbol].disposals
        ]

    def closing_quantities(self) -> dict[str, Decimal]:
        return {s: self.positions[s].quantity for s in self.symbols()}

    def summary(self) -> str:
        lines = [
            f"allocation method: {self.allocation_method}",
            f"  {self.method_note}",
            f"securities: {len(self.positions)}",
        ]
        for symbol in self.symbols():
            position = self.positions[symbol]
            lines.append(
                f"\n  {symbol}: {decimal_to_str(position.quantity)} held, "
                f"{len(position.lots)} lot(s), {len(position.disposals)} disposal(s)"
            )
            for lot in position.lots:
                lines.append(f"      {lot.describe()}")
            for disposal in position.disposals:
                basis = disposal.cost_basis_native
                lines.append(
                    f"      disposed {decimal_to_str(disposal.quantity)} on "
                    f"{disposal.disposal_date.isoformat()}, cost basis "
                    + (decimal_to_str(basis) if basis is not None else "UNKNOWN")
                )
        if self.inferred_symbols:
            lines.append(
                f"\n  opening positions inferred for: "
                f"{', '.join(self.inferred_symbols)}"
            )
        return "\n".join(lines)


class LotEngine:
    """Builds a :class:`LotBook` from a ledger."""

    def __init__(
        self,
        *,
        policy: CalculationPolicy | None = None,
        market_data: MarketDataSnapshot | None = None,
        infer_opening_positions: bool = True,
        assume_complete_history: bool = False,
    ) -> None:
        self.policy = policy or CalculationPolicy()
        self.market_data = market_data
        #: When false, a shortfall is left unmatched instead of being deduced.
        self.infer_opening_positions = infer_opening_positions
        #: Set when the user states that every statement has been uploaded. A
        #: shortfall then means the data is contradictory, not incomplete.
        self.assume_complete_history = assume_complete_history

    # --- construction ----------------------------------------------------

    def build(
        self,
        ledger: TransactionLedger,
        issues: IssueCollector | None = None,
    ) -> LotBook:
        method = self.policy.lot_allocation_method
        book = LotBook(
            allocation_method=method,
            method_note=describe_method(method),
        )
        if method is LotAllocationMethod.BROKER_SPECIFIED and issues is not None:
            issues.report(
                ErrorCode.SECONDARY_SOURCE_USED,
                scope=IssueScope.CALCULATION,
                subject="lot allocation",
                message=(
                    "the configured allocation method is BROKER_SPECIFIED, but a "
                    "transaction export does not identify which lots the broker "
                    "assigned. First in, first out was applied instead, and every "
                    "cost basis below reflects that substitution."
                ),
            )

        events = self._collect_events(ledger)
        inferred: list[str] = []

        for symbol in sorted(events):
            position = SecurityPosition(symbol=symbol)
            position.timeline = PositionTimeline(symbol=symbol)
            book.positions[symbol] = position
            self._replay(symbol, events[symbol], position, issues)
            if position.has_inferred_lots:
                inferred.append(symbol)

        book.inferred_symbols = tuple(inferred)
        return book

    def _collect_events(
        self, ledger: TransactionLedger
    ) -> dict[str, list[NormalizedTransaction]]:
        """Group security-affecting transactions by symbol, in ledger order."""
        grouped: dict[str, list[NormalizedTransaction]] = defaultdict(list)
        for transaction in ledger.ordered():
            if not transaction.ticker:
                continue
            behaviour = transaction.behaviour
            if behaviour.quantity_sign == 0 and not behaviour.is_corporate_action:
                continue
            grouped[transaction.ticker.strip().upper()].append(transaction)
        return grouped

    # --- replay ----------------------------------------------------------

    def _replay(
        self,
        symbol: str,
        transactions: Sequence[NormalizedTransaction],
        position: SecurityPosition,
        issues: IssueCollector | None,
    ) -> None:
        """Walk one security's transactions, interleaving corporate actions."""
        actions = (
            self.market_data.actions_for(symbol) if self.market_data else []
        )
        pending = sorted(actions, key=lambda a: a.ex_date)
        action_index = 0

        for transaction in transactions:
            # Apply every corporate action whose ex-date precedes this
            # transaction, so the share counts it meets are already restated.
            while (
                action_index < len(pending)
                and pending[action_index].ex_date <= transaction.transaction_date
            ):
                self._apply_action(position, pending[action_index], issues)
                action_index += 1

            if transaction.behaviour.is_acquisition:
                self._open_lot(position, transaction)
            elif transaction.behaviour.is_disposal:
                self._dispose(position, transaction, issues)

        while action_index < len(pending):
            self._apply_action(position, pending[action_index], issues)
            action_index += 1

    def _open_lot(
        self, position: SecurityPosition, transaction: NormalizedTransaction
    ) -> None:
        quantity = as_quantity(transaction.quantity or ZERO)
        if is_effectively_zero(quantity):
            return

        lot = Lot(
            lot_id=derive_id("LOT", transaction.transaction_id),
            symbol=position.symbol,
            origin=_ORIGIN_BY_TYPE.get(
                transaction.transaction_type, LotOrigin.PURCHASE
            ),
            acquisition_date=transaction.transaction_date,
            original_quantity=quantity,
            remaining_quantity=quantity,
            currency=transaction.currency,
            total_cost_native=transaction.gross_amount_native,
            fees_native=transaction.fees_native,
            source_transaction_id=transaction.transaction_id,
            source_reference=transaction.source_reference,
            notes=(
                ()
                if transaction.gross_amount_native is not None
                else (
                    "the source row states no acquisition amount, so this lot has no "
                    "cost basis",
                )
            ),
        )
        position.lots.append(lot)
        assert position.timeline is not None
        position.timeline.record(
            HoldingChange(
                change_date=transaction.transaction_date,
                quantity_delta=quantity,
                quantity_after=position.quantity,
                reason=f"{transaction.transaction_type} {quantity}",
                transaction_id=transaction.transaction_id,
            )
        )

    def _dispose(
        self,
        position: SecurityPosition,
        transaction: NormalizedTransaction,
        issues: IssueCollector | None,
    ) -> None:
        quantity = as_quantity(transaction.quantity or ZERO)
        if is_effectively_zero(quantity):
            return

        available = position.quantity
        shortfall = quantity - available
        if shortfall > ZERO:
            self._handle_shortfall(
                position, transaction, shortfall, available, issues
            )

        allocations = self._allocate(position, quantity)
        matched = sum((a.quantity for a in allocations), ZERO)

        disposal = Disposal(
            transaction_id=transaction.transaction_id,
            symbol=position.symbol,
            disposal_date=transaction.transaction_date,
            quantity=quantity,
            currency=transaction.currency,
            gross_proceeds_native=transaction.gross_amount_native,
            fees_native=transaction.fees_native,
            allocations=tuple(allocations),
            unmatched_quantity=as_quantity(quantity - matched),
            source_reference=transaction.source_reference,
        )
        position.disposals.append(disposal)

        assert position.timeline is not None
        position.timeline.record(
            HoldingChange(
                change_date=transaction.transaction_date,
                quantity_delta=-matched,
                quantity_after=position.quantity,
                reason=f"{transaction.transaction_type} {quantity}",
                transaction_id=transaction.transaction_id,
            )
        )

        if disposal.uses_inferred_lots and issues is not None:
            issues.report(
                ErrorCode.ACQUISITION_COST_MISSING,
                scope=IssueScope.LOT,
                subject=position.symbol,
                message=(
                    f"the disposal of {quantity} {position.symbol} on "
                    f"{transaction.transaction_date.isoformat()} draws on shares whose "
                    f"acquisition is not in the uploaded files, so its cost basis "
                    f"cannot be computed. The sale proceeds are still known."
                ),
                transaction_id=transaction.transaction_id,
            )

    def _handle_shortfall(
        self,
        position: SecurityPosition,
        transaction: NormalizedTransaction,
        shortfall: Decimal,
        available: Decimal,
        issues: IssueCollector | None,
    ) -> None:
        """Deal with selling more shares than the ledger accounts for."""
        if not self.infer_opening_positions:
            if issues is not None:
                issues.report(
                    ErrorCode.OVERSOLD_POSITION,
                    scope=IssueScope.LOT,
                    subject=position.symbol,
                    message=(
                        f"{transaction.source_reference} disposes of "
                        f"{transaction.quantity} {position.symbol} when only "
                        f"{available} are accounted for. Opening-position inference "
                        f"is disabled, so {shortfall} share(s) are left unmatched."
                    ),
                )
            return

        if self.assume_complete_history and issues is not None:
            issues.report(
                ErrorCode.OVERSOLD_POSITION,
                scope=IssueScope.LOT,
                subject=position.symbol,
                message=(
                    f"{transaction.source_reference} disposes of "
                    f"{transaction.quantity} {position.symbol} when only "
                    f"{available} are accounted for, and the upload is marked as "
                    f"a complete history. Either a transaction is missing after "
                    f"all, or a quantity is wrong."
                ),
            )

        lot = Lot(
            lot_id=derive_id("LOT-INFERRED", position.symbol, transaction.transaction_id),
            symbol=position.symbol,
            origin=LotOrigin.INFERRED_OPENING,
            acquisition_date=None,
            original_quantity=as_quantity(shortfall),
            remaining_quantity=as_quantity(shortfall),
            currency=transaction.currency,
            total_cost_native=None,
            fees_native=None,
            source_transaction_id=None,
            source_reference=None,
            notes=(
                f"deduced from the disposal at {transaction.source_reference}: "
                f"{shortfall} share(s) must have been held before the earliest "
                f"transaction in the uploaded files. The quantity is a lower bound; "
                f"the acquisition date and cost are unknown.",
            ),
        )
        # Inserted at the front so date-ordered methods treat it as the oldest
        # holding, which it is.
        position.lots.insert(0, lot)

        assert position.timeline is not None
        position.timeline.record(
            HoldingChange(
                change_date=transaction.transaction_date,
                quantity_delta=as_quantity(shortfall),
                quantity_after=position.quantity,
                reason=(
                    f"inferred opening position of {shortfall} share(s), deduced "
                    f"from a later disposal"
                ),
            )
        )

        if issues is not None:
            issues.report(
                ErrorCode.MISSING_HISTORICAL_DATA,
                scope=IssueScope.LOT,
                subject=position.symbol,
                message=(
                    f"{position.symbol} was sold on "
                    f"{transaction.transaction_date.isoformat()} in a quantity the "
                    f"uploaded files do not account for. {shortfall} share(s) must "
                    f"have been acquired earlier, in a statement that has not been "
                    f"uploaded. The platform has recorded them so the quantity held "
                    f"is right, but their acquisition date and cost are unknown, so "
                    f"the initial value of this investment and the gain on this "
                    f"disposal cannot be computed."
                ),
                shortfall=str(shortfall),
            )
            issues.report(
                ErrorCode.ACQUISITION_DATE_MISSING,
                scope=IssueScope.LOT,
                subject=position.symbol,
                message=(
                    f"the date on which {shortfall} {position.symbol} share(s) were "
                    f"acquired is not in the uploaded files. Schedule FA asks for the "
                    f"date of acquiring the interest, and the platform will not "
                    f"substitute the reporting period's start or the earliest "
                    f"transaction date for it."
                ),
            )

    def _allocate(
        self, position: SecurityPosition, quantity: Decimal
    ) -> list[LotAllocation]:
        """Consume ``quantity`` shares from open lots, in method order."""
        strategy = strategy_for(self.policy.lot_allocation_method)
        remaining = quantity
        allocations: list[LotAllocation] = []

        for lot in strategy(position.open_lots()):
            if is_effectively_zero(remaining):
                break
            take = min(remaining, lot.remaining_quantity)
            if is_effectively_zero(take):
                continue
            allocations.append(
                LotAllocation(
                    lot_id=lot.lot_id,
                    quantity=as_quantity(take),
                    acquisition_date=lot.acquisition_date,
                    cost_native=lot.cost_of(take),
                    acquisition_fees_native=lot.fees_of(take),
                    from_inferred_lot=lot.is_inferred,
                )
            )
            position.replace_lot(lot.consume(take))
            remaining = as_quantity(remaining - take)

        return allocations

    def _apply_action(
        self,
        position: SecurityPosition,
        action,  # noqa: ANN001 - CorporateAction
        issues: IssueCollector | None,
    ) -> None:
        """Restate every lot for a corporate action."""
        if not action.action_type.changes_quantity:
            return
        numerator, denominator = action.ratio()
        if numerator == denominator:
            return

        before = position.quantity
        if is_effectively_zero(before):
            return

        for lot in list(position.lots):
            adjustment = CorporateActionAdjustment(
                action_id=action.action_id,
                ex_date=action.ex_date,
                description=action.describe(),
                quantity_before=lot.remaining_quantity,
                quantity_after=as_quantity(
                    lot.remaining_quantity * numerator / denominator
                ),
            )
            position.replace_lot(lot.apply_ratio(numerator, denominator, adjustment))

        after = position.quantity
        assert position.timeline is not None
        position.timeline.record(
            HoldingChange(
                change_date=action.ex_date,
                quantity_delta=as_quantity(after - before),
                quantity_after=after,
                reason=action.describe(),
            )
        )

        if issues is not None and not action.is_verified:
            issues.report(
                ErrorCode.CORPORATE_ACTION_UNVERIFIED,
                scope=IssueScope.LOT,
                subject=position.symbol,
                message=(
                    f"{action.describe()} was applied to {position.symbol}, changing "
                    f"the holding from {before} to {after} shares, but the action has "
                    f"not been confirmed against an official source."
                ),
            )


# --- reconciliation -------------------------------------------------------


def reconcile(
    book: LotBook,
    broker_holdings: Mapping[str, Decimal],
    issues: IssueCollector | None = None,
    *,
    tolerance: Decimal = RECONCILIATION_TOLERANCE,
) -> list[ReconciliationResult]:
    """Compare reconstructed holdings against the broker's own figures.

    This is the check that catches everything the rest of the pipeline missed:
    an unmapped transaction type, a missing statement, a duplicate counted
    twice. A mismatch is reported rather than corrected, because the broker's
    figure is evidence about the answer, not the answer.
    """
    results: list[ReconciliationResult] = []
    symbols = sorted(set(book.symbols()) | {s.strip().upper() for s in broker_holdings})

    for symbol in symbols:
        position = book.position(symbol)
        computed = position.quantity if position else ZERO
        stated = broker_holdings.get(symbol)

        if stated is None:
            results.append(
                ReconciliationResult(
                    symbol=symbol,
                    computed_quantity=computed,
                    broker_quantity=None,
                    difference=None,
                    matches=True,
                    explanation=(
                        f"the broker statement does not list a closing holding for "
                        f"{symbol}, so there is nothing to reconcile against."
                    ),
                )
            )
            continue

        difference = as_quantity(computed - stated)
        matches = abs(difference) <= tolerance
        if matches:
            explanation = (
                f"{symbol} reconciles: {decimal_to_str(computed)} computed against "
                f"{decimal_to_str(stated)} stated."
            )
        else:
            explanation = (
                f"{symbol} does not reconcile: the transactions produce "
                f"{decimal_to_str(computed)} share(s) but the broker states "
                f"{decimal_to_str(stated)}, a difference of "
                f"{decimal_to_str(difference)}. Common causes are a missing "
                f"statement, a transaction type the parser did not map, or a "
                f"duplicated row."
            )
            if issues is not None:
                issues.report(
                    ErrorCode.LOT_RECONCILIATION_FAILED,
                    scope=IssueScope.LOT,
                    subject=symbol,
                    message=explanation,
                    computed=str(computed),
                    stated=str(stated),
                )

        results.append(
            ReconciliationResult(
                symbol=symbol,
                computed_quantity=computed,
                broker_quantity=stated,
                difference=difference,
                matches=matches,
                explanation=explanation,
            )
        )

    return results


def reconciliation_summary(results: Iterable[ReconciliationResult]) -> str:
    lines = ["=== holdings reconciliation ==="]
    for result in results:
        mark = "ok " if result.matches else "FAIL"
        lines.append(f"  [{mark}] {result.explanation}")
    return "\n".join(lines)
