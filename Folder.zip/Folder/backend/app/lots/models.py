"""Acquisition lots, disposals and the holding timeline.

A *lot* is a parcel of shares acquired in one transaction, carrying its own
acquisition date and cost. Schedule FA needs both: Table A3 asks for the date
of acquiring the interest and the initial value of the investment, and a
holding built from three purchases has three answers to each unless the rules
say how to combine them.

Two design points carry most of the weight.

**A lot the data implies but does not contain is marked as such.** Selling
three shares proves three shares were held, even when the acquisition sits in
a statement that was never uploaded. The engine records an inferred opening
lot so the *quantity* timeline is right — peak value depends only on quantity
— while its acquisition date and cost stay empty and blocking, because those
cannot be deduced from a sale.

**Quantities and costs move together under corporate actions.** A 4-for-1
split quadruples a lot's share count and quarters its cost per share. The
total cost is unchanged, and it is the total that is kept exact: dividing a
cost per share by three and multiplying back would not return the original.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import date
from decimal import Decimal
from enum import StrEnum

from ..core.money import (
    ZERO,
    as_amount,
    as_quantity,
    decimal_to_str,
    divide,
    is_effectively_zero,
)


class LotOrigin(StrEnum):
    """How a lot came into existence."""

    PURCHASE = "PURCHASE"
    TRANSFER_IN = "TRANSFER_IN"
    RSU_VEST = "RSU_VEST"
    ESPP_PURCHASE = "ESPP_PURCHASE"
    SPINOFF = "SPINOFF"
    #: Not present in any uploaded file. Its existence is deduced from a later
    #: disposal, and only its minimum quantity is known.
    INFERRED_OPENING = "INFERRED_OPENING"
    #: Entered by the user, typically to supply a missing opening position.
    MANUAL = "MANUAL"

    @property
    def is_documented(self) -> bool:
        """Whether a source transaction backs this lot."""
        return self is not LotOrigin.INFERRED_OPENING


@dataclass(frozen=True, slots=True)
class CorporateActionAdjustment:
    """A corporate action's effect on one lot, kept for the audit trail."""

    action_id: str
    ex_date: date
    description: str
    quantity_before: Decimal
    quantity_after: Decimal


@dataclass(frozen=True, slots=True)
class Lot:
    """One parcel of shares with its own acquisition date and cost."""

    lot_id: str
    symbol: str
    origin: LotOrigin
    #: ``None`` only for an inferred lot, where no acquisition is on record.
    acquisition_date: date | None
    #: Shares the lot started with, after any corporate-action restatement.
    original_quantity: Decimal
    #: Shares still held.
    remaining_quantity: Decimal
    currency: str
    #: Total acquisition cost, excluding fees. ``None`` when unknown.
    total_cost_native: Decimal | None = None
    #: Acquisition fees, kept separate so a policy can include or exclude them.
    fees_native: Decimal | None = None
    #: Transaction that created the lot. Empty for an inferred lot.
    source_transaction_id: str | None = None
    source_reference: str | None = None
    adjustments: tuple[CorporateActionAdjustment, ...] = ()
    notes: tuple[str, ...] = ()

    @property
    def is_inferred(self) -> bool:
        return self.origin is LotOrigin.INFERRED_OPENING

    @property
    def is_open(self) -> bool:
        return not is_effectively_zero(self.remaining_quantity)

    @property
    def disposed_quantity(self) -> Decimal:
        return self.original_quantity - self.remaining_quantity

    @property
    def has_cost(self) -> bool:
        return self.total_cost_native is not None

    @property
    def cost_per_share(self) -> Decimal | None:
        """Cost of one share in this lot.

        Derived from the total rather than stored, so a split restatement
        cannot leave the two inconsistent.
        """
        if self.total_cost_native is None or is_effectively_zero(
            self.original_quantity
        ):
            return None
        return divide(self.total_cost_native, self.original_quantity)

    def cost_of(self, quantity: Decimal) -> Decimal | None:
        """Cost attributable to part of this lot."""
        if self.total_cost_native is None or is_effectively_zero(
            self.original_quantity
        ):
            return None
        return as_amount(self.total_cost_native * quantity / self.original_quantity)

    def fees_of(self, quantity: Decimal) -> Decimal | None:
        if self.fees_native is None or is_effectively_zero(self.original_quantity):
            return None
        return as_amount(self.fees_native * quantity / self.original_quantity)

    def consume(self, quantity: Decimal) -> Lot:
        """Return this lot with ``quantity`` shares removed."""
        if quantity > self.remaining_quantity:
            raise ValueError(
                f"{self.lot_id}: cannot consume {quantity} from a lot holding "
                f"{self.remaining_quantity}"
            )
        return replace(
            self, remaining_quantity=as_quantity(self.remaining_quantity - quantity)
        )

    def apply_ratio(
        self,
        numerator: Decimal,
        denominator: Decimal,
        adjustment: CorporateActionAdjustment,
    ) -> Lot:
        """Restate the lot for a corporate action.

        Share counts scale; the total cost does not. Cost per share is derived
        from the two, so it follows automatically and cannot drift.
        """
        return replace(
            self,
            original_quantity=as_quantity(
                self.original_quantity * numerator / denominator
            ),
            remaining_quantity=as_quantity(
                self.remaining_quantity * numerator / denominator
            ),
            adjustments=(*self.adjustments, adjustment),
        )

    def describe(self) -> str:
        acquired = (
            self.acquisition_date.isoformat()
            if self.acquisition_date
            else "acquisition date unknown"
        )
        cost = (
            f"{decimal_to_str(self.total_cost_native)} {self.currency}"
            if self.total_cost_native is not None
            else "cost unknown"
        )
        return (
            f"{self.lot_id} {self.symbol} "
            f"{decimal_to_str(self.original_quantity)} acquired {acquired}, "
            f"{decimal_to_str(self.remaining_quantity)} remaining, {cost}"
            + (" [INFERRED]" if self.is_inferred else "")
        )


@dataclass(frozen=True, slots=True)
class LotAllocation:
    """The part of one disposal satisfied by one lot."""

    lot_id: str
    quantity: Decimal
    acquisition_date: date | None
    #: Cost attributed to these shares, ``None`` when the lot's cost is unknown.
    cost_native: Decimal | None
    acquisition_fees_native: Decimal | None
    from_inferred_lot: bool = False

    @property
    def cost_known(self) -> bool:
        return self.cost_native is not None


@dataclass(frozen=True, slots=True)
class Disposal:
    """A sale or transfer out, and the lots it consumed."""

    transaction_id: str
    symbol: str
    disposal_date: date
    quantity: Decimal
    currency: str
    gross_proceeds_native: Decimal | None
    fees_native: Decimal | None
    allocations: tuple[LotAllocation, ...] = ()
    #: Shares the engine could not match to any lot. Non-zero only when
    #: inference was disabled.
    unmatched_quantity: Decimal = ZERO
    source_reference: str | None = None

    @property
    def matched_quantity(self) -> Decimal:
        return sum((a.quantity for a in self.allocations), ZERO)

    @property
    def cost_basis_native(self) -> Decimal | None:
        """Total cost of the shares disposed, or nothing if any part is unknown.

        Returning ``None`` rather than a partial sum is deliberate: a cost
        basis missing one lot is not a smaller cost basis, it is an unknown
        one, and reporting the partial figure would understate the gain.
        """
        if not self.allocations or any(not a.cost_known for a in self.allocations):
            return None
        return as_amount(sum((a.cost_native or ZERO for a in self.allocations), ZERO))

    @property
    def uses_inferred_lots(self) -> bool:
        return any(a.from_inferred_lot for a in self.allocations)

    def gain_native(self) -> Decimal | None:
        """Gross proceeds less cost basis, when both are known."""
        basis = self.cost_basis_native
        if basis is None or self.gross_proceeds_native is None:
            return None
        return as_amount(self.gross_proceeds_native - basis)


@dataclass(frozen=True, slots=True)
class HoldingChange:
    """A dated change in the number of shares held."""

    change_date: date
    quantity_delta: Decimal
    quantity_after: Decimal
    reason: str
    transaction_id: str | None = None


@dataclass(slots=True)
class PositionTimeline:
    """How many shares of one symbol were held, day by day.

    Peak value needs a quantity for every priced date in the period, and
    quantity changes only on transaction and corporate-action dates. Holding
    the changes and answering by lookup keeps the peak calculation exact
    without materialising a row per calendar day.
    """

    symbol: str
    changes: list[HoldingChange] = field(default_factory=list)

    def record(self, change: HoldingChange) -> None:
        self.changes.append(change)

    def ordered(self) -> list[HoldingChange]:
        return sorted(self.changes, key=lambda c: c.change_date)

    def quantity_on(self, day: date) -> Decimal:
        """Shares held at the end of ``day``."""
        quantity = ZERO
        for change in self.ordered():
            if change.change_date > day:
                break
            quantity = change.quantity_after
        return quantity

    def peak_quantity_on(self, day: date) -> Decimal:
        """The most shares held at any point during ``day``.

        Distinct from :meth:`quantity_on`, which answers for the end of the
        day, and the two differ whenever shares were acquired and disposed of
        on the same date. The difference decides a peak value: a holding that
        existed for only part of a day was still held that day, so a
        peak-value field must see it. An inferred opening lot is always this
        case, because it is recorded on the date of the disposal that proved
        it existed and is consumed by that same disposal.
        """
        quantity = ZERO
        highest: Decimal | None = None
        for change in self.ordered():
            if change.change_date > day:
                break
            if change.change_date == day:
                if highest is None:
                    # The balance carried in from the previous day counts too.
                    highest = quantity
                highest = max(highest, change.quantity_after)
            quantity = change.quantity_after
        return quantity if highest is None else highest

    def first_acquisition_date(self) -> date | None:
        for change in self.ordered():
            if change.quantity_delta > ZERO:
                return change.change_date
        return None

    def closing_quantity(self) -> Decimal:
        ordered = self.ordered()
        return ordered[-1].quantity_after if ordered else ZERO

    def held_at_any_time(self, start: date, end: date) -> bool:
        """Whether any shares were held during the window.

        Schedule FA reports interests held at *any* time in the period,
        including ones bought and sold entirely inside it, so an end-of-period
        quantity of zero is not enough to exclude a holding.
        """
        if self.quantity_on(start) > ZERO:
            return True
        return any(
            start <= change.change_date <= end and change.quantity_after > ZERO
            for change in self.ordered()
        )

    def change_dates(self, start: date, end: date) -> list[date]:
        return sorted(
            {c.change_date for c in self.changes if start <= c.change_date <= end}
        )


@dataclass(frozen=True, slots=True)
class ReconciliationResult:
    """Computed holdings against what the broker stated."""

    symbol: str
    computed_quantity: Decimal
    broker_quantity: Decimal | None
    difference: Decimal | None
    matches: bool
    explanation: str
