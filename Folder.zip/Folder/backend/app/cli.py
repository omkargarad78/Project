"""Operator command line.

Dataset ingestion, rule inspection and report generation are operator actions
run from here rather than from an HTTP endpoint, so that importing a rate
archive can never be triggered by a user's calculation.

Run ``python -m backend.app.cli --help``.
"""

from __future__ import annotations

import argparse
import sys
from datetime import UTC, date, datetime
from pathlib import Path

from .core.config import get_settings
from .core.logging import configure_logging
from .fx.ingestion import ColumnMapping, SbiRateIngestor, coverage_report, profile_csv
from .fx.store import FxDatasetStore
from .tax.rules.models import FxRateType, SourceTier
from .tax.rules.registry import get_rule_registry

FX_DATASET_DIRNAME = "fx"


def _store() -> FxDatasetStore:
    return FxDatasetStore(get_settings().data_root / FX_DATASET_DIRNAME)


def cmd_profile_fx(args: argparse.Namespace) -> int:
    """Report a rate file's structure without importing anything."""
    path = Path(args.path)
    profile = profile_csv(path.read_bytes(), file_name=path.name)
    print(profile.summary())
    if not profile.has_tt_buying:
        print(
            "\nNo TT BUYING column was detected. Re-run the import with an explicit "
            "column mapping; the rate type is never inferred."
        )
        return 2
    return 0


def cmd_ingest_fx(args: argparse.Namespace) -> int:
    """Import a rate file or directory into an immutable dataset version."""
    tier = SourceTier(args.tier)
    ingestor = SbiRateIngestor(
        source_id=args.source_id,
        source_name=args.source_name,
        source_tier=tier,
        dataset_name=args.dataset,
        source_document_url=args.source_url,
    )
    mapping = None
    if args.date_column:
        mapping = ColumnMapping(
            date_column=args.date_column,
            currency_column=args.currency_column,
            fixed_currency=args.fixed_currency,
            rate_columns={FxRateType.TT_BUY: args.tt_buy_column},
            date_format=args.date_format,
        )

    path = Path(args.path)
    common = {
        "version": args.version,
        "mapping": mapping,
        "currencies": args.currencies,
        "imported_at": datetime.now(UTC),
        "notes": args.notes,
    }
    report = (
        ingestor.ingest_directory(path, pattern=args.pattern, **common)  # type: ignore[arg-type]
        if path.is_dir()
        else ingestor.ingest_path(path, **common)  # type: ignore[arg-type]
    )

    print(report.summary())
    if report.dataset is None:
        print("\nnothing imported")
        return 2
    if not args.dry_run:
        saved = _store().save(report.dataset)
        print(f"\nsaved dataset version to {saved}")
    else:
        print("\ndry run: nothing written")
    if tier is not SourceTier.STATUTORY:
        print(
            f"\nNOTE: this dataset is {tier.label}. Figures derived from it are flagged "
            f"SECONDARY_SOURCE_USED and must not be described as official SBI rates."
        )
    return 0


def cmd_list_fx(_args: argparse.Namespace) -> int:
    stored = _store().list()
    if not stored:
        print(f"no FX datasets stored under {_store().root}")
        return 0
    for item in stored:
        print(f"\n--- {item.path.name}")
        for key, value in item.dataset.describe().items():
            print(f"    {key}: {value}")
    return 0


def cmd_fx_coverage(args: argparse.Namespace) -> int:
    dataset = _store().load(args.dataset, args.version)
    report = coverage_report(
        dataset,
        currency=args.currency,
        rate_type=FxRateType.TT_BUY,
        start=date.fromisoformat(args.start),
        end=date.fromisoformat(args.end),
    )
    for key, value in report.items():
        print(f"{key}: {value}")
    return 0


def cmd_inspect_broker(args: argparse.Namespace) -> int:
    """Report a broker file's real structure without calculating anything.

    Run this against an actual broker export before trusting parser output.
    It prints the sheets, columns, date layouts and every distinct activity
    label found, so the mapping's alias lists can be confirmed against the file
    rather than assumed.
    """
    from .brokers.registry import default_registry
    from .io.loader import load_source_path

    source = load_source_path(args.path)
    print(source.profile_summary())

    registry = default_registry()
    print("\n=== broker detection ===")
    try:
        identification = registry.identify(source)
    except Exception as exc:  # noqa: BLE001 - reported, not raised, for an inspection
        print(f"not identified: {exc}")
        return 2

    for detection in identification.all_detections:
        mark = "->" if detection.broker_id == identification.detection.broker_id else "  "
        print(f"{mark} {detection.broker_id}: matched={detection.matched} "
              f"confidence={detection.confidence}")
        for reason in detection.reasons:
            print(f"     {reason}")

    parser = identification.parser
    print(f"\n=== schema validation ({parser.broker_name}) ===")
    validation = parser.validate(source)
    print(f"ok: {validation.ok}")
    if not validation.ok:
        print(f"problem: {validation.failure_message()}")
    for key, resolution in sorted(validation.date_formats.items()):
        print(
            f"date layout {key}: "
            + (f"{resolution.label} (from {resolution.sample_count} values)"
               if resolution.resolved
               else f"UNRESOLVED - {resolution.reason}")
        )
    for section, extra in sorted(validation.unmapped_columns.items(), key=lambda kv: str(kv[0])):
        print(f"unmapped columns in {section}: {', '.join(extra)}")

    print("\n=== activity labels found ===")
    for section, parsed in sorted(parser.parse_sections(source).items(), key=lambda kv: str(kv[0])):
        known, unknown = parser.activity_counts(parsed)
        if not known and not unknown:
            continue
        print(f"[{section}] sheet {parsed.sheet_name!r}")
        for label, count in sorted(known.items()):
            print(f"    mapped:   {label!r} x{count} -> {parser.classify(label)}")
        for label, count in sorted(unknown.items()):
            print(f"    UNMAPPED: {label!r} x{count}  <-- add to VESTED_ACTIVITY_TABLE")

    if not args.parse:
        print("\n(pass --parse to also normalize and print the parser report)")
        return 0

    result = parser.parse(source)
    print("\n=== parser report ===")
    print(result.report.summary())
    print("\n=== validation issues ===")
    counts = result.issues.counts()
    print(f"errors={counts['ERROR']} warnings={counts['WARNING']} info={counts['INFO']}")
    for item in result.issues:
        print(f"  [{item.severity}] {item.code} {item.subject}: {item.message}")
    return 0


def cmd_securities(_args: argparse.Namespace) -> int:
    """Show the security master and what each record still needs."""
    from .securities.master import load_default_master

    master = load_default_master()
    print(f"securities: {len(master)}   source hash: {master.source_hash}")
    for security in master.all_securities():
        print(f"\n{security.describe()}")
        print(f"    nature: {security.nature}   asset class: {security.asset_class}")
        for assignment in security.tickers:
            print(
                f"    symbol {assignment.normalized_symbol} "
                f"({assignment.exchange or 'no venue'}): {assignment.describe_period()}"
            )
        missing = security.missing_reporting_fields()
        if missing:
            print(f"    MISSING for Schedule FA: {', '.join(missing)}")
        unconfirmed = [
            name
            for name in ("legal_entity_name", "country", "nature")
            if not security.is_confirmed(name)
        ]
        if unconfirmed:
            print(f"    unconfirmed fields: {', '.join(unconfirmed)}")
        for note in security.notes:
            print(f"    note: {note}")

    print("\n=== financial institutions (Schedule FA Table A2) ===")
    for institution in master.all_institutions():
        print(f"\n{institution.institution_id} {institution.brand_name}")
        missing = institution.missing_reporting_fields()
        if missing:
            print(f"    MISSING for Schedule FA: {', '.join(missing)}")
        for note in institution.notes:
            print(f"    note: {note}")
    return 0


def cmd_resolve_securities(args: argparse.Namespace) -> int:
    """Parse a broker file and resolve its tickers against the master."""
    from .brokers.registry import default_registry
    from .io.loader import load_source_path
    from .securities.master import load_default_master
    from .securities.resolver import SecurityResolver, resolve_display_name_conflicts

    source = load_source_path(args.path)
    result = default_registry().parse(source)
    resolver = SecurityResolver(load_default_master())
    report = resolver.resolve_ledger(result.ledger, result.issues)
    resolve_display_name_conflicts(resolver.master, result.ledger, result.issues)

    print("=== security resolution ===")
    print(report.summary())
    print("\n=== issues ===")
    counts = result.issues.counts()
    print(f"errors={counts['ERROR']} warnings={counts['WARNING']} info={counts['INFO']}")
    for item in result.issues:
        print(f"  [{item.severity}] {item.code} {item.subject}: {item.message}")
    return 0


def cmd_inspect_prices(args: argparse.Namespace) -> int:
    """Load a price file, snapshot it and report coverage.

    The adjustment basis must be stated on the command line. There is no
    default, because guessing it wrong silently misstates every holding that
    had a split.
    """
    from .marketdata.models import AdjustmentBasis
    from .marketdata.provider import CsvPriceProvider, PricePolicy, PriceResolver
    from .validation.issues import IssueCollector

    content = Path(args.path).read_bytes()
    provider = CsvPriceProvider(
        content,
        file_name=Path(args.path).name,
        adjustment_basis=AdjustmentBasis(args.basis),
        default_currency=args.currency,
    )
    records = provider.all_records()
    from .marketdata.dataset import MarketDataSnapshot

    snapshot = MarketDataSnapshot(
        records, dataset_name=Path(args.path).name
    )
    print(snapshot.summary())

    issues = IssueCollector()
    resolver = PriceResolver(
        snapshot,
        policy=PricePolicy(quantities_are_adjusted=args.adjusted_quantities),
    )
    ok = resolver.check_basis(issues)
    print(f"\nbasis check: {'ok' if ok else 'FAILED'}")
    for item in issues:
        print(f"  [{item.severity}] {item.code}: {item.message}")
    return 0 if ok else 2


def cmd_holdings(args: argparse.Namespace) -> int:
    """Parse a broker file, rebuild the lots and reconcile them."""
    from .brokers.registry import default_registry
    from .io.loader import load_source_path
    from .lots.engine import LotEngine, reconcile, reconciliation_summary
    from .tax.rules.models import CalculationPolicy, LotAllocationMethod

    source = load_source_path(args.path)
    identification = default_registry().identify(source)
    parser = identification.parser
    result = parser.parse(source)

    policy = CalculationPolicy(
        lot_allocation_method=LotAllocationMethod(args.method)
    )
    book = LotEngine(policy=policy).build(result.ledger, result.issues)
    print(book.summary())

    stated = parser.broker_closing_holdings(parser.parse_sections(source))
    if stated:
        print()
        print(reconciliation_summary(reconcile(book, stated, result.issues)))
    else:
        print("\nthe file states no closing holdings, so nothing was reconciled")

    print("\n=== issues ===")
    counts = result.issues.counts()
    print(f"errors={counts['ERROR']} warnings={counts['WARNING']} info={counts['INFO']}")
    for item in result.issues:
        if item.severity.value == "ERROR":
            print(f"  [{item.severity}] {item.code} {item.subject}: {item.message}")
    return 0


def cmd_schedule_fa(args: argparse.Namespace) -> int:
    """Run the whole pipeline and print Schedule FA Tables A2 and A3.

    Every stage is involved, so this is the command that shows whether a real
    file can actually be reported: parsing, security resolution, lots, prices,
    exchange rates and the tables themselves.
    """
    from .brokers.registry import default_registry
    from .io.loader import load_source_path
    from .lots.engine import LotEngine
    from .marketdata.dataset import MarketDataSnapshot
    from .marketdata.models import AdjustmentBasis
    from .marketdata.provider import CsvPriceProvider, PricePolicy, PriceResolver
    from .schedulefa.engine import ScheduleFaEngine
    from .securities.master import load_default_master
    from .securities.resolver import SecurityResolver
    from .tax.periods import AssessmentYear
    from .tax.rules.models import (
        CalculationPolicy,
        LotAllocationMethod,
        PeakValuationFrequency,
        PriceValuationPoint,
    )
    from .tax.rules.registry import RuleRegistry

    source = load_source_path(args.path)
    result = default_registry().parse(source)

    registry = RuleRegistry.from_directory(Path(args.rules))
    rule = registry.rule_for(args.assessment_year)
    period = rule.schedule_fa.reporting_period.resolve(
        AssessmentYear.parse(args.assessment_year)
    )

    policy = CalculationPolicy(
        lot_allocation_method=LotAllocationMethod(args.method),
        price_valuation_point=PriceValuationPoint(args.valuation_point),
        peak_valuation_frequency=PeakValuationFrequency(args.peak_frequency),
    )

    resolution = SecurityResolver(load_default_master()).resolve_ledger(
        result.ledger, result.issues
    )
    book = LotEngine(policy=policy).build(result.ledger, result.issues)

    price_path = Path(args.prices)
    provider = CsvPriceProvider(
        price_path.read_bytes(),
        file_name=price_path.name,
        adjustment_basis=AdjustmentBasis(args.basis),
        default_currency=args.currency,
    )
    snapshot = MarketDataSnapshot(
        provider.all_records(),
        dataset_name=price_path.name,
        adjustment_basis=AdjustmentBasis(args.basis),
    )

    engine = ScheduleFaEngine(
        rule=rule,
        period=period,
        fx=_fx_resolver_for(args),
        market_data=snapshot,
        price_resolver=PriceResolver(
            snapshot,
            policy=PricePolicy(quantities_are_adjusted=args.adjusted_quantities),
            expected_currency=args.currency,
        ),
        policy=policy,
    )
    report = engine.build(
        result.ledger,
        book,
        resolution,
        result.issues,
        account_number=args.account_number,
        account_status=args.account_status,
        account_opening_date=(
            date.fromisoformat(args.account_opened) if args.account_opened else None
        ),
    )

    print(report.summary())

    print("\n=== how each figure was derived ===")
    for table_row in report.table_a3:
        print(f"\n{table_row.symbol}")
        for figure in table_row.figures():
            print(f"  {figure.label}: INR {figure.display}")
            print(f"      {figure.explanation}")
            for caveat in figure.caveats:
                print(f"      CAVEAT: {caveat}")

    from .validation.engine import ValidationEngine
    from .validation.resolutions import ResolutionStore, carry_summary

    if args.resolutions:
        store = ResolutionStore.load(Path(args.resolutions))
        carried = store.apply(result.issues)
        print("\n=== previously recorded decisions ===")
        print(carry_summary(carried))

    assessment = ValidationEngine().assess(result.issues, report)
    print()
    print(assessment.summary())

    if args.workpaper:
        _write_workpaper(
            Path(args.workpaper),
            schedule_fa=report,
            validation=assessment,
            issues=result.issues,
            fx=engine.fx,
            ledger=result.ledger,
            lots=book,
            securities=resolution,
            market_data=snapshot,
            source=source,
            parser_report=result.report,
        )

    return 0 if assessment.is_filable else 2


def _write_workpaper(destination: Path, *, source, parser_report, **parts) -> None:  # noqa: ANN001
    """Write the workbook or the CSV bundle, and say what was altered.

    The format is chosen from the path rather than a flag: a caller who
    already knows the file name they want should not have to say the same
    thing twice.
    """
    from .reports.builder import WorkpaperBuilder, WorkpaperInputs
    from .reports.csv_writer import write_csv_bundle
    from .reports.xlsx_writer import write_xlsx

    paper = WorkpaperBuilder().build(
        WorkpaperInputs(
            **parts,
            source_files=[(source.file_name, source.file_hash)],
            broker=parser_report.broker_name,
            parser_version=parser_report.parser_version,
        )
    )

    print("\n=== workpaper ===")
    if destination.suffix.lower() == ".xlsx":
        content, log = write_xlsx(paper)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(content)
        print(f"wrote {destination} ({len(paper.sheets)} sheets)")
    else:
        files, log = write_csv_bundle(paper)
        destination.mkdir(parents=True, exist_ok=True)
        for item in files:
            (destination / item.file_name).write_bytes(item.content)
        print(f"wrote {len(files)} files to {destination}")

    for note in log.notes():
        print(f"  NOTE: {note}")


def _fx_resolver_for(args: argparse.Namespace):  # noqa: ANN202 - FxResolver
    from .fx.resolver import FxResolver
    from .tax.rules.models import MultipleRatePolicy

    dataset = _store().load(args.fx_dataset, args.fx_version)
    return FxResolver(
        dataset, multiple_rate_policy=MultipleRatePolicy(args.multiple_rate_policy)
    )


def cmd_brokers(_args: argparse.Namespace) -> int:
    from .brokers.registry import default_registry

    for parser in default_registry().parsers():
        print(f"\n--- {parser.broker_name} ({parser.broker_id}) {parser.parser_version}")
        for spec in parser.mapping.sections:
            required = " [required]" if spec.required else ""
            print(f"    section {spec.section}{required}")
            print(f"      sheet names: {', '.join(spec.sheet_aliases)}")
            for field_spec in spec.fields:
                flag = "*" if field_spec.required else " "
                print(f"      {flag} {field_spec.name} ({field_spec.kind}): "
                      f"{', '.join(field_spec.aliases)}")
    return 0


def cmd_rules(_args: argparse.Namespace) -> int:
    registry = get_rule_registry()
    for year in registry.supported_assessment_years():
        rule = registry.rule_for(year)
        print(f"\n--- assessment year {year}")
        print(f"    rule version: {rule.rule_version_id}")
        print(f"    verification: {rule.verification_status}")
        for key, value in rule.tax_period().describe().items():
            print(f"    {key}: {value}")
        if rule.open_decisions:
            print("    open decisions requiring human confirmation:")
            for decision in rule.open_decisions:
                print(f"      - {decision}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="fa",
        description="Schedule FA platform operator commands",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    profile = sub.add_parser("profile-fx", help="report a rate file's structure")
    profile.add_argument("path")
    profile.set_defaults(func=cmd_profile_fx)

    ingest = sub.add_parser(
        "ingest-fx", help="import a rate file/directory as an immutable dataset version"
    )
    ingest.add_argument("path")
    ingest.add_argument("--dataset", required=True, help="dataset name, e.g. sbi-ttbr")
    ingest.add_argument("--version", required=True, help="dataset version, e.g. 2025.1")
    ingest.add_argument("--source-id", required=True, help="id in the official-source registry")
    ingest.add_argument("--source-name", required=True)
    ingest.add_argument(
        "--tier",
        type=int,
        required=True,
        choices=[t.value for t in SourceTier],
        help="1 statutory, 2 official third party, 3 data provider, 4 community dataset",
    )
    ingest.add_argument("--source-url")
    ingest.add_argument("--pattern", default="*.csv")
    ingest.add_argument("--currencies", nargs="*")
    ingest.add_argument("--date-column")
    ingest.add_argument("--date-format")
    ingest.add_argument("--currency-column")
    ingest.add_argument("--fixed-currency")
    ingest.add_argument("--tt-buy-column")
    ingest.add_argument("--notes")
    ingest.add_argument("--dry-run", action="store_true")
    ingest.set_defaults(func=cmd_ingest_fx)

    listing = sub.add_parser("list-fx", help="list stored FX dataset versions")
    listing.set_defaults(func=cmd_list_fx)

    coverage = sub.add_parser("fx-coverage", help="report dataset coverage of a period")
    coverage.add_argument("--dataset", required=True)
    coverage.add_argument("--version", required=True)
    coverage.add_argument("--currency", default="USD")
    coverage.add_argument("--start", required=True)
    coverage.add_argument("--end", required=True)
    coverage.set_defaults(func=cmd_fx_coverage)

    rules = sub.add_parser("rules", help="show registered tax rule versions")
    rules.set_defaults(func=cmd_rules)

    inspect = sub.add_parser(
        "inspect-broker",
        help="report a broker file's real sheets, columns, dates and activity labels",
    )
    inspect.add_argument("path")
    inspect.add_argument(
        "--parse",
        action="store_true",
        help="also normalize the file and print the parser report",
    )
    inspect.set_defaults(func=cmd_inspect_broker)

    brokers = sub.add_parser("brokers", help="show registered brokers and their field mappings")
    brokers.set_defaults(func=cmd_brokers)

    securities = sub.add_parser(
        "securities", help="show the security master and what each record still needs"
    )
    securities.set_defaults(func=cmd_securities)

    resolve = sub.add_parser(
        "resolve-securities",
        help="parse a broker file and resolve its tickers against the security master",
    )
    resolve.add_argument("path")
    resolve.set_defaults(func=cmd_resolve_securities)

    prices = sub.add_parser(
        "inspect-prices", help="load a price file, snapshot it and report coverage"
    )
    prices.add_argument("path")
    prices.add_argument(
        "--basis",
        required=True,
        choices=["UNADJUSTED", "SPLIT_ADJUSTED", "TOTAL_RETURN_ADJUSTED", "UNKNOWN"],
        help=(
            "whether the series is adjusted for splits. Required: guessing wrong "
            "misstates every holding that had a split, with no sign of it."
        ),
    )
    prices.add_argument("--currency", help="currency to use when the file states none")
    prices.add_argument(
        "--adjusted-quantities",
        action="store_true",
        help="the share counts being valued have themselves been restated for splits",
    )
    prices.set_defaults(func=cmd_inspect_prices)

    holdings = sub.add_parser(
        "holdings", help="rebuild lots from a broker file and reconcile them"
    )
    holdings.add_argument("path")
    holdings.add_argument(
        "--method",
        default="FIFO",
        choices=[
            "FIFO",
            "LIFO",
            "HIGHEST_COST_FIRST",
            "LOWEST_COST_FIRST",
            "BROKER_SPECIFIED",
        ],
        help="lot allocation methodology (platform selection, not a statutory rule)",
    )
    holdings.set_defaults(func=cmd_holdings)

    schedule = sub.add_parser(
        "schedule-fa",
        help="compute Schedule FA Tables A2 and A3 from a broker file",
    )
    schedule.add_argument("path", help="the broker export")
    schedule.add_argument(
        "--assessment-year", required=True, help="e.g. 2026-27"
    )
    schedule.add_argument(
        "--rules", default="data/rules", help="directory of tax rule versions"
    )
    schedule.add_argument("--fx-dataset", required=True, help="stored FX dataset name")
    schedule.add_argument("--fx-version", required=True)
    schedule.add_argument(
        "--multiple-rate-policy",
        default="FAIL",
        choices=[
            "FAIL",
            "EARLIEST_PUBLICATION",
            "LATEST_PUBLICATION",
            "HIGHEST_RATE",
            "LOWEST_RATE",
        ],
        help="what to do when a date has more than one published rate sheet",
    )
    schedule.add_argument("--prices", required=True, help="price file to value with")
    schedule.add_argument(
        "--basis",
        required=True,
        choices=["UNADJUSTED", "SPLIT_ADJUSTED", "TOTAL_RETURN_ADJUSTED", "UNKNOWN"],
        help="whether the price series is adjusted for splits",
    )
    schedule.add_argument(
        "--adjusted-quantities",
        action="store_true",
        help="the share counts have themselves been restated for splits",
    )
    schedule.add_argument("--currency", default="USD")
    schedule.add_argument(
        "--method",
        default="FIFO",
        choices=[
            "FIFO",
            "LIFO",
            "HIGHEST_COST_FIRST",
            "LOWEST_COST_FIRST",
            "BROKER_SPECIFIED",
        ],
        help="lot allocation methodology",
    )
    schedule.add_argument(
        "--valuation-point",
        default="DAILY_CLOSE",
        choices=[
            "DAILY_CLOSE",
            "DAILY_HIGH",
            "DAILY_LOW",
            "DAILY_OPEN",
            "DAILY_AVERAGE_HIGH_LOW",
        ],
        help="which point of the daily price series values a holding",
    )
    schedule.add_argument(
        "--peak-frequency",
        default="EVERY_PRICED_DAY",
        choices=["EVERY_PRICED_DAY", "MONTH_END", "QUARTER_END"],
        help="how often the holding is revalued when searching for the peak",
    )
    schedule.add_argument(
        "--account-number",
        help="custodial account number for Table A2. Never inferred from a file.",
    )
    schedule.add_argument("--account-status", help="ownership status for Table A2")
    schedule.add_argument(
        "--account-opened", help="account opening date, YYYY-MM-DD, for Table A2"
    )
    schedule.add_argument(
        "--resolutions",
        help=(
            "JSON file of previously recorded decisions to re-apply. "
            "Acknowledgements are carried forward; claimed fixes are reopened "
            "if the condition is still present."
        ),
    )
    schedule.add_argument(
        "--workpaper",
        help=(
            "where to write the workpaper. A path ending in .xlsx produces one "
            "workbook; any other path is treated as a directory and receives "
            "the CSV bundle, one file per sheet."
        ),
    )
    schedule.set_defaults(func=cmd_schedule_fa)

    return parser


def main(argv: list[str] | None = None) -> int:
    configure_logging()
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    sys.exit(main())
