"""File-type detection and upload validation.

Filenames are untrusted input. The type of an upload is decided by its content
signature, and the declared extension and MIME type are only cross-checked
against that finding so a mismatch can be reported. A file named
``statement.xlsx`` that is actually a ZIP of something else, or an HTML error
page the broker's site returned instead of a download, is rejected here rather
than part-way through parsing.
"""

from __future__ import annotations

import zipfile
from dataclasses import dataclass
from enum import StrEnum
from pathlib import PurePosixPath, PureWindowsPath

from ..core.errors import ErrorCode, ParseError

#: Content signatures, as ``(offset, magic bytes)``.
ZIP_MAGIC = b"PK\x03\x04"
EMPTY_ZIP_MAGIC = b"PK\x05\x06"
OLE2_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
PDF_MAGIC = b"%PDF-"

#: Entries that identify an OOXML package as a spreadsheet.
XLSX_MARKERS = ("xl/workbook.xml", "xl/workbook.bin")


class FileType(StrEnum):
    """Detected upload type."""

    XLSX = "XLSX"
    #: Legacy binary Excel (BIFF). Detected so it can be rejected clearly.
    XLS = "XLS"
    #: Excel binary workbook (.xlsb). Detected so it can be rejected clearly.
    XLSB = "XLSB"
    CSV = "CSV"
    PDF = "PDF"
    UNKNOWN = "UNKNOWN"

    @property
    def is_parseable(self) -> bool:
        """Whether the platform can extract a transaction ledger from it."""
        return self in (FileType.XLSX, FileType.CSV)


@dataclass(frozen=True, slots=True)
class DetectedFile:
    """The outcome of inspecting an upload's bytes."""

    file_type: FileType
    size_bytes: int
    #: Safe name derived from the upload, with any path component removed.
    safe_name: str
    #: The extension the uploader claimed, lowercased, including the dot.
    declared_extension: str | None
    #: True when the declared extension disagrees with the detected content.
    extension_mismatch: bool
    warnings: tuple[str, ...] = ()

    @property
    def is_parseable(self) -> bool:
        return self.file_type.is_parseable


def safe_file_name(name: str | None, *, fallback: str = "upload") -> str:
    """Strip every path component and unsafe character from a filename.

    Handles both separators regardless of host platform, because an upload made
    from Windows can reach a Linux server and ``..\\..\\etc\\passwd`` must not
    survive either way.
    """
    if not name:
        return fallback
    candidate = PureWindowsPath(PurePosixPath(name).name).name
    cleaned = "".join(
        ch if (ch.isalnum() or ch in "-._ ()[]") else "_" for ch in candidate
    ).strip()
    cleaned = cleaned.lstrip(".").strip()
    while ".." in cleaned:
        cleaned = cleaned.replace("..", ".")
    if not cleaned or cleaned in {".", ".."}:
        return fallback
    return cleaned[:200]


def detect_file_type(content: bytes) -> tuple[FileType, tuple[str, ...]]:
    """Identify an upload from its content alone."""
    warnings: list[str] = []
    if not content:
        return FileType.UNKNOWN, ("the file is empty",)

    if content.startswith(PDF_MAGIC):
        return FileType.PDF, ()

    if content.startswith(OLE2_MAGIC):
        # Legacy .xls, .doc and .msg all share this container signature.
        return FileType.XLS, ()

    if content.startswith(ZIP_MAGIC) or content.startswith(EMPTY_ZIP_MAGIC):
        import io

        try:
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                names = set(archive.namelist())
        except zipfile.BadZipFile:
            return FileType.UNKNOWN, ("the file looks like a ZIP but cannot be opened",)
        if "xl/workbook.bin" in names:
            return FileType.XLSB, ()
        if any(marker in names for marker in XLSX_MARKERS):
            return FileType.XLSX, ()
        if "word/document.xml" in names:
            return FileType.UNKNOWN, ("this is a Word document, not a spreadsheet",)
        return FileType.UNKNOWN, (
            "the file is a ZIP archive but does not contain a spreadsheet",
        )

    # Anything textual that is not one of the above is treated as a candidate
    # delimited file, after checking it is not actually an HTML page.
    head = content[:4096].lstrip()
    lowered = head[:512].lower()
    if lowered.startswith(b"<!doctype html") or lowered.startswith(b"<html"):
        return FileType.UNKNOWN, (
            "this is an HTML page, not a statement. The download may have returned "
            "a login or error page.",
        )
    if b"\x00" in content[:8192]:
        return FileType.UNKNOWN, ("the file contains binary data and is not readable text",)

    for encoding in ("utf-8-sig", "utf-16", "latin-1"):
        try:
            text = content[:8192].decode(encoding)
        except (UnicodeDecodeError, UnicodeError):
            continue
        if encoding != "utf-8-sig":
            warnings.append(f"the file was decoded as {encoding}, not UTF-8")
        if not text.strip():
            return FileType.UNKNOWN, ("the file contains no readable text",)
        return FileType.CSV, tuple(warnings)

    return FileType.UNKNOWN, ("the file's character encoding could not be determined",)


def validate_upload(
    content: bytes,
    *,
    file_name: str | None,
    max_bytes: int,
    allowed_extensions: tuple[str, ...] = (".xlsx", ".xls", ".csv", ".pdf"),
) -> DetectedFile:
    """Validate an upload's size, extension and actual content type.

    Raises for a file that cannot be accepted at all; returns a
    :class:`DetectedFile` carrying warnings for one that is accepted but
    questionable.
    """
    size = len(content)
    if size == 0:
        raise ParseError(ErrorCode.SOURCE_FILE_CORRUPT, "the uploaded file is empty")
    if size > max_bytes:
        raise ParseError(
            ErrorCode.SOURCE_FILE_UNSUPPORTED,
            f"the file is {size:,} bytes, over the {max_bytes:,}-byte upload limit",
        )

    safe_name = safe_file_name(file_name)
    declared = None
    if "." in safe_name:
        declared = "." + safe_name.rsplit(".", 1)[1].lower()

    if declared is not None and declared not in allowed_extensions:
        raise ParseError(
            ErrorCode.SOURCE_FILE_UNSUPPORTED,
            f"{declared} files are not accepted. Accepted types: "
            f"{', '.join(allowed_extensions)}",
        )

    file_type, warnings = detect_file_type(content)
    warning_list = list(warnings)

    if file_type is FileType.UNKNOWN:
        raise ParseError(
            ErrorCode.SOURCE_FILE_UNSUPPORTED,
            "the file type could not be identified from its contents"
            + (f": {warnings[0]}" if warnings else ""),
        )

    expected_extensions = {
        FileType.XLSX: {".xlsx", ".xlsm"},
        FileType.XLS: {".xls"},
        FileType.XLSB: {".xlsb"},
        FileType.CSV: {".csv", ".txt", ".tsv"},
        FileType.PDF: {".pdf"},
    }[file_type]
    mismatch = declared is not None and declared not in expected_extensions
    if mismatch:
        warning_list.append(
            f"the file is named {declared} but its contents are {file_type}. The "
            f"contents decide how it is processed."
        )

    if file_type is FileType.XLS:
        raise ParseError(
            ErrorCode.SOURCE_FILE_UNSUPPORTED,
            "this is a legacy binary Excel file (.xls). Open it in a spreadsheet "
            "application and save it as .xlsx, then upload it again. The platform does "
            "not parse the legacy binary format, because doing so reliably enough for "
            "tax figures is not something it will attempt on a best-effort basis.",
        )
    if file_type is FileType.XLSB:
        raise ParseError(
            ErrorCode.SOURCE_FILE_UNSUPPORTED,
            "this is an Excel binary workbook (.xlsb). Save it as .xlsx and upload it "
            "again.",
        )
    if file_type is FileType.PDF:
        raise ParseError(
            ErrorCode.SOURCE_FILE_UNSUPPORTED,
            "PDF statements cannot yet be parsed into a transaction ledger. Upload the "
            "broker's Excel or CSV transaction export instead. A PDF can be retained as "
            "supporting evidence but is not a parsing input.",
        )

    return DetectedFile(
        file_type=file_type,
        size_bytes=size,
        safe_name=safe_name,
        declared_extension=declared,
        extension_mismatch=mismatch,
        warnings=tuple(warning_list),
    )
