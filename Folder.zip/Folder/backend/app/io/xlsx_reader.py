"""A raw .xlsx reader that preserves the file's original cell text.

Why this exists instead of a spreadsheet library: every mainstream reader
parses numeric cells into Python floats. ``0.1 + 0.2`` and a price of
``123.45`` are not exactly representable in binary floating point, so a value
that has been through a float has already lost its source representation
before any tax arithmetic starts. This reader goes to the sheet XML, where a
number is stored as a decimal *string*, and carries that string through to
``Decimal``.

Security posture:

* XML is parsed with ``defusedxml``, so entity-expansion and external-entity
  attacks in a crafted workbook are blocked.
* The ZIP container is checked for entry count, per-entry uncompressed size and
  total uncompressed size before extraction, which stops a decompression bomb.
* Formulas are read as text and never evaluated.
* A VBA project or macro sheet is detected and reported, never extracted.
* External workbook links are reported, never followed.
"""

from __future__ import annotations

import io
import zipfile
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation

from defusedxml.ElementTree import fromstring as safe_fromstring

from ..core.errors import ErrorCode, ParseError
from .tabular import CellKind, RawCell, RawSheet, RawWorkbook, split_reference

NS_MAIN = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
NS_REL = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
NS_PKG_REL = "{http://schemas.openxmlformats.org/package/2006/relationships}"

# --- decompression-bomb limits -------------------------------------------
MAX_ZIP_ENTRIES = 4096
MAX_ENTRY_UNCOMPRESSED_BYTES = 512 * 1024 * 1024
MAX_TOTAL_UNCOMPRESSED_BYTES = 1024 * 1024 * 1024
MAX_COMPRESSION_RATIO = 500

# --- sheet size limits ----------------------------------------------------
MAX_ROWS = 1_048_576
MAX_COLUMNS = 16_384

#: Built-in number-format ids that denote a date, a time or a datetime. The
#: numeric ids are fixed by the file format; ids 18-22 and 45-47 are times.
BUILTIN_DATE_FORMAT_IDS: frozenset[int] = frozenset(
    {14, 15, 16, 17, 18, 19, 20, 21, 22, 27, 30, 36, 45, 46, 47, 50, 57}
)

#: Characters that appear only in date/time format codes.
_DATE_FORMAT_TOKENS = ("yy", "yyyy", "mmm", "dd", "hh", "ss", "am/pm", "a/p")

MACRO_MARKERS = ("vbaProject.bin", "xl/macrosheets/", "xl/vbaProject.bin")


@dataclass(frozen=True, slots=True)
class _Styles:
    """Cell-format index to number-format code."""

    formats_by_style: dict[int, str]
    date_styles: frozenset[int]


def _is_date_format(code: str) -> bool:
    """Decide whether a number-format code renders a date or time.

    Literal text in a format code is quoted or escaped, and the colour/
    condition sections in brackets can contain letters that would otherwise
    look like date tokens, so both are stripped before looking for tokens.
    """
    stripped = []
    index = 0
    in_quotes = False
    while index < len(code):
        char = code[index]
        if char == '"':
            in_quotes = not in_quotes
            index += 1
            continue
        if in_quotes:
            index += 1
            continue
        if char == "\\":
            index += 2
            continue
        if char == "[":
            close = code.find("]", index)
            index = len(code) if close == -1 else close + 1
            continue
        stripped.append(char)
        index += 1

    text = "".join(stripped).lower()
    # A bare "m" is ambiguous between month and minute; requiring a two-token
    # form avoids classifying a currency format like "#,##0.00" as a date.
    return any(token in text for token in _DATE_FORMAT_TOKENS) or (
        "d" in text and "m" in text
    )


def _read_styles(archive: zipfile.ZipFile) -> _Styles:
    formats_by_style: dict[int, str] = {}
    date_styles: set[int] = set()
    try:
        raw = archive.read("xl/styles.xml")
    except KeyError:
        return _Styles(formats_by_style={}, date_styles=frozenset())

    root = safe_fromstring(raw)

    custom: dict[int, str] = {}
    for number_format in root.iter(f"{NS_MAIN}numFmt"):
        try:
            format_id = int(number_format.attrib.get("numFmtId", "-1"))
        except ValueError:
            continue
        custom[format_id] = number_format.attrib.get("formatCode", "")

    cell_xfs = root.find(f"{NS_MAIN}cellXfs")
    if cell_xfs is None:
        return _Styles(formats_by_style={}, date_styles=frozenset())

    for style_index, xf in enumerate(cell_xfs.findall(f"{NS_MAIN}xf")):
        try:
            format_id = int(xf.attrib.get("numFmtId", "0"))
        except ValueError:
            continue
        code = custom.get(format_id, "")
        formats_by_style[style_index] = code or f"builtin:{format_id}"
        if format_id in BUILTIN_DATE_FORMAT_IDS or (code and _is_date_format(code)):
            date_styles.add(style_index)

    return _Styles(formats_by_style=formats_by_style, date_styles=frozenset(date_styles))


def _read_shared_strings(archive: zipfile.ZipFile) -> list[str]:
    """Read the shared-string table, concatenating rich-text runs."""
    try:
        raw = archive.read("xl/sharedStrings.xml")
    except KeyError:
        return []

    root = safe_fromstring(raw)
    strings: list[str] = []
    for item in root.findall(f"{NS_MAIN}si"):
        parts: list[str] = []
        # A plain string has one <t>; a rich string has <r><t> runs. Phonetic
        # hints (<rPh>) must be skipped or they duplicate the text.
        direct = item.find(f"{NS_MAIN}t")
        if direct is not None:
            parts.append(direct.text or "")
        for run in item.findall(f"{NS_MAIN}r"):
            text_node = run.find(f"{NS_MAIN}t")
            if text_node is not None:
                parts.append(text_node.text or "")
        strings.append("".join(parts))
    return strings


def _read_sheet_index(archive: zipfile.ZipFile) -> list[tuple[str, str, bool]]:
    """Return ``(sheet name, part path, hidden)`` in workbook order."""
    try:
        workbook_raw = archive.read("xl/workbook.xml")
    except KeyError as exc:
        raise ParseError(
            ErrorCode.SOURCE_FILE_CORRUPT,
            "the workbook package has no xl/workbook.xml part",
        ) from exc

    relationships: dict[str, str] = {}
    try:
        rels_root = safe_fromstring(archive.read("xl/_rels/workbook.xml.rels"))
    except KeyError:
        rels_root = None
    if rels_root is not None:
        for relationship in rels_root.findall(f"{NS_PKG_REL}Relationship"):
            target = relationship.attrib.get("Target", "")
            # Targets are relative to xl/ and may use ../ or a leading /.
            normalized = target.lstrip("/")
            if normalized.startswith("xl/"):
                normalized = normalized[3:]
            relationships[relationship.attrib["Id"]] = f"xl/{normalized.lstrip('./')}"

    root = safe_fromstring(workbook_raw)
    sheets: list[tuple[str, str, bool]] = []
    sheets_node = root.find(f"{NS_MAIN}sheets")
    if sheets_node is None:
        return sheets

    for order, sheet in enumerate(sheets_node.findall(f"{NS_MAIN}sheet")):
        name = sheet.attrib.get("name", f"Sheet{order + 1}")
        rel_id = sheet.attrib.get(f"{NS_REL}id")
        part = relationships.get(rel_id or "", f"xl/worksheets/sheet{order + 1}.xml")
        hidden = sheet.attrib.get("state", "visible") in ("hidden", "veryHidden")
        sheets.append((name, part, hidden))
    return sheets


def _uses_1904_epoch(archive: zipfile.ZipFile) -> bool:
    """Whether the workbook uses the 1904 date system (classic Mac Excel)."""
    try:
        root = safe_fromstring(archive.read("xl/workbook.xml"))
    except KeyError:
        return False
    properties = root.find(f"{NS_MAIN}workbookPr")
    if properties is None:
        return False
    value = properties.attrib.get("date1904", "0").lower()
    return value in ("1", "true")


def serial_to_datetime(serial: Decimal, *, epoch_1904: bool = False) -> date | datetime:
    """Convert a spreadsheet date serial to a date or datetime.

    Excel's 1900 system contains a deliberate off-by-one: serial 60 is the
    non-existent 29 February 1900, kept for compatibility with an older
    product. Serials above 60 are therefore one day ahead of a true day count,
    which this corrects. Getting this wrong shifts every pre-March-1900 date by
    a day and, more importantly, indicates a reader that is guessing.
    """
    if epoch_1904:
        base = date(1904, 1, 1)
        day_offset = int(serial)
        fraction = serial - int(serial)
    else:
        if serial < 1:
            # Serial 0 is a time-only value on the epoch day.
            base = date(1899, 12, 31)
            day_offset = 0
            fraction = serial
        elif serial < 60:
            base = date(1899, 12, 31)
            day_offset = int(serial)
            fraction = serial - int(serial)
        elif serial == 60:
            raise ValueError(
                "date serial 60 is 29 February 1900, which does not exist; the source "
                "cell holds an invalid date"
            )
        else:
            base = date(1899, 12, 30)
            day_offset = int(serial)
            fraction = serial - int(serial)

    day = base + timedelta(days=day_offset)
    if fraction == 0:
        return day
    seconds = int((fraction * Decimal(86400)).quantize(Decimal(1)))
    return datetime.combine(day, datetime.min.time()) + timedelta(seconds=seconds)


def _check_zip_safety(archive: zipfile.ZipFile) -> None:
    """Reject archives whose expansion would be unreasonable."""
    infos = archive.infolist()
    if len(infos) > MAX_ZIP_ENTRIES:
        raise ParseError(
            ErrorCode.SOURCE_FILE_CORRUPT,
            f"the workbook package contains {len(infos)} entries, over the "
            f"{MAX_ZIP_ENTRIES} limit",
        )
    total = 0
    for info in infos:
        name = info.filename
        if name.startswith("/") or ".." in name.replace("\\", "/").split("/"):
            raise ParseError(
                ErrorCode.SOURCE_FILE_CORRUPT,
                f"the workbook package contains an unsafe entry path: {name!r}",
            )
        if info.file_size > MAX_ENTRY_UNCOMPRESSED_BYTES:
            raise ParseError(
                ErrorCode.SOURCE_FILE_CORRUPT,
                f"entry {name!r} expands to {info.file_size:,} bytes, over the "
                f"per-entry limit",
            )
        if info.compress_size > 0:
            ratio = info.file_size / info.compress_size
            if ratio > MAX_COMPRESSION_RATIO and info.file_size > 1024 * 1024:
                raise ParseError(
                    ErrorCode.SOURCE_FILE_CORRUPT,
                    f"entry {name!r} has a compression ratio of {ratio:.0f}:1, which "
                    f"indicates a decompression bomb rather than a statement",
                )
        total += info.file_size
    if total > MAX_TOTAL_UNCOMPRESSED_BYTES:
        raise ParseError(
            ErrorCode.SOURCE_FILE_CORRUPT,
            f"the workbook expands to {total:,} bytes in total, over the limit",
        )


def _parse_cell(
    element,  # noqa: ANN001 - xml.etree element, kept untyped for the stdlib
    *,
    shared_strings: list[str],
    styles: _Styles,
    epoch_1904: bool,
    warnings: list[str],
) -> RawCell | None:
    reference = element.attrib.get("r")
    if reference is None:
        return None
    try:
        row_index, column_index = split_reference(reference)
    except ValueError:
        warnings.append(f"skipped a cell with an unreadable reference {reference!r}")
        return None
    if row_index >= MAX_ROWS or column_index >= MAX_COLUMNS:
        return None

    cell_type = element.attrib.get("t", "n")
    try:
        style_index = int(element.attrib.get("s", "-1"))
    except ValueError:
        style_index = -1
    number_format = styles.formats_by_style.get(style_index)

    formula_node = element.find(f"{NS_MAIN}f")
    formula = None
    if formula_node is not None:
        # Retained as text for the audit trail. Never evaluated.
        formula = (formula_node.text or "").strip() or "(shared formula)"

    value_node = element.find(f"{NS_MAIN}v")
    raw_value = value_node.text if value_node is not None else None

    if cell_type == "inlineStr":
        inline = element.find(f"{NS_MAIN}is")
        text = ""
        if inline is not None:
            direct = inline.find(f"{NS_MAIN}t")
            if direct is not None:
                text = direct.text or ""
            for run in inline.findall(f"{NS_MAIN}r"):
                node = run.find(f"{NS_MAIN}t")
                if node is not None:
                    text += node.text or ""
        return RawCell(
            row=row_index,
            column=column_index,
            kind=CellKind.TEXT if text else CellKind.EMPTY,
            raw_text=text or None,
            number_format=number_format,
            formula=formula,
        )

    if raw_value is None:
        return RawCell(
            row=row_index,
            column=column_index,
            kind=CellKind.EMPTY,
            raw_text=None,
            number_format=number_format,
            formula=formula,
        )

    if cell_type == "s":
        try:
            text = shared_strings[int(raw_value)]
        except (ValueError, IndexError):
            warnings.append(f"cell {reference} references a missing shared string")
            text = ""
        return RawCell(
            row=row_index,
            column=column_index,
            kind=CellKind.TEXT if text else CellKind.EMPTY,
            raw_text=text or None,
            number_format=number_format,
            formula=formula,
        )

    if cell_type == "str":
        return RawCell(
            row=row_index,
            column=column_index,
            kind=CellKind.TEXT if raw_value else CellKind.EMPTY,
            raw_text=raw_value or None,
            number_format=number_format,
            formula=formula,
        )

    if cell_type == "b":
        return RawCell(
            row=row_index,
            column=column_index,
            kind=CellKind.BOOLEAN,
            raw_text=raw_value,
            display_text="TRUE" if raw_value == "1" else "FALSE",
            number_format=number_format,
            formula=formula,
        )

    if cell_type == "e":
        return RawCell(
            row=row_index,
            column=column_index,
            kind=CellKind.ERROR,
            raw_text=raw_value,
            number_format=number_format,
            formula=formula,
        )

    # Numeric. The XML text is the exact decimal representation; it is kept as
    # a string and only converted to Decimal by the caller.
    if style_index in styles.date_styles:
        try:
            decoded = serial_to_datetime(Decimal(raw_value), epoch_1904=epoch_1904)
        except (InvalidOperation, ValueError, OverflowError) as exc:
            warnings.append(f"cell {reference} holds an invalid date serial: {exc}")
            return RawCell(
                row=row_index,
                column=column_index,
                kind=CellKind.NUMBER,
                raw_text=raw_value,
                number_format=number_format,
                formula=formula,
            )
        return RawCell(
            row=row_index,
            column=column_index,
            kind=CellKind.DATE,
            raw_text=raw_value,
            display_text=decoded.isoformat(),
            number_format=number_format,
            formula=formula,
            date_value=decoded,
        )

    return RawCell(
        row=row_index,
        column=column_index,
        kind=CellKind.NUMBER,
        raw_text=raw_value,
        number_format=number_format,
        formula=formula,
    )


def read_xlsx(content: bytes) -> RawWorkbook:
    """Read an .xlsx workbook, preserving original cell text."""
    try:
        archive = zipfile.ZipFile(io.BytesIO(content))
    except zipfile.BadZipFile as exc:
        raise ParseError(
            ErrorCode.SOURCE_FILE_CORRUPT,
            f"the file is not a readable .xlsx package: {exc}",
        ) from exc

    with archive:
        _check_zip_safety(archive)
        names = archive.namelist()

        warnings: list[str] = []
        contains_macros = any(
            marker in name for name in names for marker in MACRO_MARKERS
        )
        if contains_macros:
            warnings.append(
                "this workbook contains a VBA project or macro sheet. The macro code is "
                "neither extracted nor executed, but a broker statement export should "
                "not contain macros; treat the file's origin as suspect."
            )

        external_links = tuple(
            sorted(name for name in names if name.startswith("xl/externalLinks/"))
        )
        if external_links:
            warnings.append(
                f"the workbook references {len(external_links)} external workbook "
                f"link(s). These are not followed; any cell depending on them holds "
                f"only a cached value."
            )

        try:
            shared_strings = _read_shared_strings(archive)
            styles = _read_styles(archive)
            epoch_1904 = _uses_1904_epoch(archive)
            sheet_index = _read_sheet_index(archive)
        except ParseError:
            raise
        except Exception as exc:  # noqa: BLE001 - any XML defect is a corrupt file
            raise ParseError(
                ErrorCode.SOURCE_FILE_CORRUPT,
                f"the workbook's internal structure could not be read: {exc}",
            ) from exc

        if epoch_1904:
            warnings.append(
                "this workbook uses the 1904 date system; dates were decoded "
                "accordingly."
            )
        if not sheet_index:
            raise ParseError(
                ErrorCode.SOURCE_FILE_CORRUPT, "the workbook contains no worksheets"
            )

        sheets: list[RawSheet] = []
        for order, (name, part, hidden) in enumerate(sheet_index):
            try:
                sheet_raw = archive.read(part)
            except KeyError:
                warnings.append(f"sheet {name!r} is listed but its data part is missing")
                continue
            try:
                root = safe_fromstring(sheet_raw)
            except Exception as exc:  # noqa: BLE001
                raise ParseError(
                    ErrorCode.SOURCE_FILE_CORRUPT,
                    f"sheet {name!r} could not be parsed: {exc}",
                ) from exc

            cells: dict[tuple[int, int], RawCell] = {}
            max_row = 0
            max_column = 0
            formula_count = 0

            for cell_element in root.iter(f"{NS_MAIN}c"):
                cell = _parse_cell(
                    cell_element,
                    shared_strings=shared_strings,
                    styles=styles,
                    epoch_1904=epoch_1904,
                    warnings=warnings,
                )
                if cell is None:
                    continue
                if cell.is_formula:
                    formula_count += 1
                if cell.kind is CellKind.EMPTY and cell.formula is None:
                    continue
                cells[(cell.row, cell.column)] = cell
                max_row = max(max_row, cell.row + 1)
                max_column = max(max_column, cell.column + 1)

            if formula_count:
                warnings.append(
                    f"sheet {name!r} contains {formula_count} formula cell(s). Their "
                    f"cached values are read as data; no formula is evaluated."
                )

            sheets.append(
                RawSheet(
                    name=name,
                    index=order,
                    cells=cells,
                    row_count=max_row,
                    column_count=max_column,
                    hidden=hidden,
                    formula_cell_count=formula_count,
                )
            )

        return RawWorkbook(
            sheets=tuple(sheets),
            contains_macros=contains_macros,
            external_links=external_links,
            warnings=tuple(dict.fromkeys(warnings)),
        )
