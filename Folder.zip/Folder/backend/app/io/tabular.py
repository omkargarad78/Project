"""Broker-independent representation of a spreadsheet or delimited file.

Cells carry the *original text* the file contained. A numeric cell's
``raw_text`` is the digit string as stored, never a parsed float, so a value
can be turned into a ``Decimal`` without ever passing through binary floating
point. A date cell keeps both the serial number it was stored as and the
calendar date it decodes to, so a date-format misinterpretation is visible
rather than silent.

Formula cells keep the formula text alongside the cached value. The platform
never evaluates a formula: the cached value is treated as broker-supplied data
and the formula text is retained for the audit trail.
"""

from __future__ import annotations

import re
from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import StrEnum


class CellKind(StrEnum):
    """What a cell held in the source file."""

    EMPTY = "EMPTY"
    NUMBER = "NUMBER"
    TEXT = "TEXT"
    #: A number whose cell format makes it a date or datetime.
    DATE = "DATE"
    BOOLEAN = "BOOLEAN"
    #: An Excel error literal such as ``#N/A`` or ``#REF!``.
    ERROR = "ERROR"


@dataclass(frozen=True, slots=True)
class RawCell:
    """One cell, preserved as the file stored it."""

    #: Zero-based row index within the sheet.
    row: int
    #: Zero-based column index within the sheet.
    column: int
    kind: CellKind
    #: Exactly what the file contained: the digit string for a number, the
    #: string value for text, the serial number for a date.
    raw_text: str | None
    #: The interpreted value as text: ISO-8601 for dates, otherwise raw_text.
    display_text: str | None = None
    #: The cell's number format code, which is how a date is distinguished
    #: from a plain number in a spreadsheet.
    number_format: str | None = None
    #: Formula source text, when the cell was a formula. Never evaluated.
    formula: str | None = None
    #: Decoded calendar value for a DATE cell.
    date_value: date | datetime | None = None

    @property
    def reference(self) -> str:
        return f"{column_letter(self.column)}{self.row + 1}"

    @property
    def is_empty(self) -> bool:
        return self.kind is CellKind.EMPTY or not (self.text or "").strip()

    @property
    def text(self) -> str | None:
        """The value to interpret: the decoded form when one exists."""
        return self.display_text if self.display_text is not None else self.raw_text

    @property
    def is_formula(self) -> bool:
        return self.formula is not None


EMPTY_CELL_CACHE: dict[tuple[int, int], RawCell] = {}


def empty_cell(row: int, column: int) -> RawCell:
    key = (row, column)
    cached = EMPTY_CELL_CACHE.get(key)
    if cached is None:
        cached = RawCell(row=row, column=column, kind=CellKind.EMPTY, raw_text=None)
        if len(EMPTY_CELL_CACHE) < 20000:
            EMPTY_CELL_CACHE[key] = cached
    return cached


def column_letter(index: int) -> str:
    """Convert a zero-based column index to its spreadsheet letters."""
    if index < 0:
        raise ValueError(f"column index must be non-negative, got {index}")
    letters = ""
    current = index + 1
    while current > 0:
        current, remainder = divmod(current - 1, 26)
        letters = chr(ord("A") + remainder) + letters
    return letters


def column_index(letters: str) -> int:
    """Convert spreadsheet column letters to a zero-based index."""
    total = 0
    for char in letters.upper():
        if not "A" <= char <= "Z":
            raise ValueError(f"invalid column reference {letters!r}")
        total = total * 26 + (ord(char) - ord("A") + 1)
    return total - 1


#: A cell reference is column letters followed by a row number, optionally with
#: absolute-reference markers. Anything else is malformed and must not be
#: salvaged by picking out whichever characters happen to be letters or digits.
_REFERENCE_RE = re.compile(r"^\$?(?P<letters>[A-Za-z]{1,3})\$?(?P<digits>[1-9][0-9]*)$")


def split_reference(reference: str) -> tuple[int, int]:
    """Split ``B7`` into a zero-based ``(row, column)`` pair."""
    match = _REFERENCE_RE.match(reference.strip())
    if match is None:
        raise ValueError(f"invalid cell reference {reference!r}")
    return int(match.group("digits")) - 1, column_index(match.group("letters"))


@dataclass(frozen=True, slots=True)
class RawSheet:
    """A worksheet as a sparse grid of preserved cells."""

    name: str
    #: Position of the sheet in the workbook, zero-based.
    index: int
    #: Sparse cell map keyed by ``(row, column)``.
    cells: Mapping[tuple[int, int], RawCell]
    row_count: int
    column_count: int
    #: True when the sheet is hidden in the workbook.
    hidden: bool = False
    #: Number of cells that contained a formula.
    formula_cell_count: int = 0

    def cell(self, row: int, column: int) -> RawCell:
        return self.cells.get((row, column)) or empty_cell(row, column)

    def row(self, row: int) -> list[RawCell]:
        return [self.cell(row, column) for column in range(self.column_count)]

    def rows(self) -> Iterator[list[RawCell]]:
        for index in range(self.row_count):
            yield self.row(index)

    def non_empty_rows(self) -> list[int]:
        return sorted({row for (row, _col), cell in self.cells.items() if not cell.is_empty})

    def is_empty(self) -> bool:
        return not any(not cell.is_empty for cell in self.cells.values())


@dataclass(frozen=True, slots=True)
class RawWorkbook:
    """A workbook of preserved sheets, plus what was found about the file."""

    sheets: tuple[RawSheet, ...]
    #: True when the package contained a VBA project or macro sheet. Macros are
    #: never extracted or executed; their presence is reported because a
    #: statement export should not contain them.
    contains_macros: bool = False
    #: External workbook links found in the package, which are not followed.
    external_links: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()

    def sheet_names(self) -> list[str]:
        return [sheet.name for sheet in self.sheets]

    def sheet(self, name: str) -> RawSheet:
        wanted = normalize_sheet_name(name)
        for sheet in self.sheets:
            if normalize_sheet_name(sheet.name) == wanted:
                return sheet
        raise KeyError(f"workbook has no sheet named {name!r}; found {self.sheet_names()}")

    def has_sheet(self, name: str) -> bool:
        try:
            self.sheet(name)
        except KeyError:
            return False
        return True

    def find_sheet(self, *candidates: str) -> RawSheet | None:
        """Return the first sheet matching any candidate name, or ``None``.

        Matching is loose (case and punctuation insensitive, then substring) so
        that a broker renaming ``Trades`` to ``Trade History`` is still found,
        while the actual name found is reported to the user.
        """
        for candidate in candidates:
            if self.has_sheet(candidate):
                return self.sheet(candidate)
        normalized = {normalize_sheet_name(c) for c in candidates}
        for sheet in self.sheets:
            name = normalize_sheet_name(sheet.name)
            if any(c in name or name in c for c in normalized):
                return sheet
        return None


def normalize_sheet_name(name: str) -> str:
    """Reduce a sheet name to comparable form: lowercase alphanumerics only."""
    return "".join(ch for ch in name.lower() if ch.isalnum())


def sanitize_sheet_name(name: str, *, fallback: str = "Sheet") -> str:
    """Make a name safe to write into a generated workbook.

    Excel forbids ``: \\ / ? * [ ]`` in sheet names and caps them at 31
    characters. A name that arrives from a source file is untrusted input, so
    it is sanitized rather than passed through.
    """
    cleaned = "".join("_" if ch in ':\\/?*[]' else ch for ch in name)
    cleaned = "".join(ch for ch in cleaned if ch.isprintable()).strip().strip("'")
    if not cleaned:
        return fallback
    return cleaned[:31]


# --- header detection -----------------------------------------------------


@dataclass(frozen=True, slots=True)
class DetectedHeader:
    """Where a table's header row is and what it contains."""

    row_index: int
    #: Header text per column index, as it appeared in the file.
    headers: Mapping[int, str]
    #: Score used to choose this row, for diagnostics.
    score: int = 0

    def labels(self) -> list[str]:
        return [self.headers[key] for key in sorted(self.headers)]

    def normalized(self) -> Mapping[str, int]:
        """Normalized header text to column index."""
        return {normalize_header(text): index for index, text in self.headers.items()}


def normalize_header(text: str) -> str:
    """Reduce a header to comparable form: lowercase alphanumerics only."""
    return "".join(ch for ch in text.lower() if ch.isalnum())


def detect_header_row(
    sheet: RawSheet,
    *,
    expected_aliases: Sequence[str] = (),
    max_scan_rows: int = 25,
    min_columns: int = 2,
) -> DetectedHeader | None:
    """Locate the header row of a sheet.

    Broker exports routinely put a title, an account summary or a blank row
    above the real header, so the header cannot be assumed to be row 1. The row
    that matches the most expected column names wins; with no expectations
    supplied, the first row with at least ``min_columns`` non-empty text cells
    wins. Returning ``None`` is meaningful: the caller must then fail safely
    rather than guess.
    """
    wanted = {normalize_header(alias) for alias in expected_aliases}
    best: DetectedHeader | None = None

    for row_index in range(min(sheet.row_count, max_scan_rows)):
        cells = [cell for cell in sheet.row(row_index) if not cell.is_empty]
        if len(cells) < min_columns:
            continue
        # A header row is text, not numbers. Rows of data are rejected here.
        text_cells = [c for c in cells if c.kind in (CellKind.TEXT, CellKind.EMPTY)]
        if len(text_cells) < max(min_columns, len(cells) // 2):
            continue

        headers = {
            cell.column: (cell.text or "").strip() for cell in cells if (cell.text or "").strip()
        }
        if len(headers) < min_columns:
            continue

        normalized = {normalize_header(text) for text in headers.values()}
        matches = len(wanted & normalized) if wanted else 0
        score = matches * 100 + len(headers)

        if best is None or score > best.score:
            best = DetectedHeader(row_index=row_index, headers=headers, score=score)
        # A row matching every expected alias is as good as it gets.
        if wanted and matches == len(wanted):
            break

    return best


@dataclass(frozen=True, slots=True)
class TableRow:
    """One data row, addressable by header text."""

    sheet_name: str
    #: One-based row number as shown in the spreadsheet, for source references.
    row_number: int
    cells: Mapping[str, RawCell]
    #: Header text to cell, using the file's original header spelling.
    _normalized: Mapping[str, str] = field(default_factory=dict, repr=False)

    def cell(self, *aliases: str) -> RawCell | None:
        """Return the cell under any of ``aliases``.

        Matching ignores case and punctuation, so ``Price/Share`` finds a
        ``Price / Share`` header, but it is otherwise exact. There is
        deliberately no substring fallback: ``Scrip`` would match
        ``De-scrip-tion``, and a column mapping that quietly binds a tax figure
        to an unrelated column is worse than one that reports the column as
        missing. Parsers declare the real spellings instead.
        """
        for alias in aliases:
            header = self._normalized.get(normalize_header(alias))
            if header is not None:
                return self.cells[header]
        return None

    def text(self, *aliases: str) -> str | None:
        cell = self.cell(*aliases)
        if cell is None or cell.is_empty:
            return None
        return (cell.text or "").strip() or None

    def raw_values(self) -> dict[str, str | None]:
        """The verbatim row, for the raw transaction record."""
        return {header: cell.raw_text for header, cell in self.cells.items()}

    def display_values(self) -> dict[str, str | None]:
        return {header: cell.text for header, cell in self.cells.items()}

    def is_blank(self) -> bool:
        return all(cell.is_empty for cell in self.cells.values())


@dataclass(frozen=True, slots=True)
class DetectedTable:
    """A header plus its data rows, ready for a broker parser to map."""

    sheet_name: str
    header: DetectedHeader
    rows: tuple[TableRow, ...]

    @property
    def headers(self) -> list[str]:
        return self.header.labels()

    def __len__(self) -> int:
        return len(self.rows)

    def missing_headers(self, required: Sequence[str]) -> list[str]:
        """Required headers that are absent, matched loosely.

        A non-empty result means the export format has changed, which is an
        error rather than something to work around.
        """
        available = set(self.header.normalized())
        return [
            requirement
            for requirement in required
            if normalize_header(requirement) not in available
        ]

    def missing_field_groups(
        self, groups: Sequence[tuple[str, Sequence[str]]]
    ) -> list[str]:
        """Field labels for which none of the field's aliases is present.

        Takes alias *groups* rather than single names, because a field is
        satisfied by any of its declared spellings: a file headed ``Trade
        Date`` satisfies a field whose primary alias is ``Transaction Date``.
        """
        available = set(self.header.normalized())
        missing: list[str] = []
        for label, aliases in groups:
            if not any(normalize_header(alias) in available for alias in aliases):
                missing.append(label)
        return missing


def extract_table(
    sheet: RawSheet,
    *,
    expected_aliases: Sequence[str] = (),
    max_scan_rows: int = 25,
    min_columns: int = 2,
    stop_on_blank_rows: int = 5,
) -> DetectedTable | None:
    """Detect the header row and collect the data rows beneath it.

    Stops after ``stop_on_blank_rows`` consecutive blank rows so that a totals
    block or a second table further down the sheet is not swallowed into the
    first table's rows.
    """
    header = detect_header_row(
        sheet,
        expected_aliases=expected_aliases,
        max_scan_rows=max_scan_rows,
        min_columns=min_columns,
    )
    if header is None:
        return None

    normalized_map = {normalize_header(text): text for text in header.headers.values()}
    rows: list[TableRow] = []
    blank_streak = 0

    for row_index in range(header.row_index + 1, sheet.row_count):
        cells = {
            header_text: sheet.cell(row_index, column)
            for column, header_text in header.headers.items()
        }
        row = TableRow(
            sheet_name=sheet.name,
            row_number=row_index + 1,
            cells=cells,
            _normalized=normalized_map,
        )
        if row.is_blank():
            blank_streak += 1
            if blank_streak >= stop_on_blank_rows:
                break
            continue
        blank_streak = 0
        rows.append(row)

    return DetectedTable(sheet_name=sheet.name, header=header, rows=tuple(rows))

