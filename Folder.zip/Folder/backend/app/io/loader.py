"""Entry point for turning an uploaded file into a preserved-text workbook.

This is the boundary between "bytes someone uploaded" and "data the pipeline
will read". It validates the upload, dispatches on the *detected* type rather
than the filename, hashes the content, and records a profile of what was found
so the user can see the structure the platform actually read.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from ..core.errors import ErrorCode, ParseError
from ..core.hashing import derive_id, hash_bytes
from .csv_reader import read_csv
from .filetype import DetectedFile, FileType, validate_upload
from .tabular import CellKind, RawWorkbook
from .xlsx_reader import read_xlsx

DEFAULT_MAX_UPLOAD_BYTES = 25 * 1024 * 1024


@dataclass(frozen=True, slots=True)
class SheetProfile:
    """What a single worksheet contains, for the upload report."""

    name: str
    index: int
    hidden: bool
    row_count: int
    column_count: int
    populated_cell_count: int
    formula_cell_count: int
    #: Column headers, when a header row could be located.
    detected_headers: tuple[str, ...]
    header_row_number: int | None
    #: Headers whose cells are predominantly dates.
    date_columns: tuple[str, ...]
    #: Headers whose cells are predominantly numbers.
    numeric_columns: tuple[str, ...]
    #: Headers with at least one empty cell in the data rows.
    columns_with_missing_values: tuple[str, ...]
    data_row_count: int

    def to_row(self) -> dict[str, str]:
        return {
            "Sheet Name": self.name,
            "Hidden": "yes" if self.hidden else "no",
            "Rows": str(self.row_count),
            "Columns": str(self.column_count),
            "Data Rows": str(self.data_row_count),
            "Header Row": str(self.header_row_number) if self.header_row_number else "not found",
            "Column Names": ", ".join(self.detected_headers),
            "Detected Date Columns": ", ".join(self.date_columns),
            "Detected Amount Columns": ", ".join(self.numeric_columns),
            "Columns With Missing Values": ", ".join(self.columns_with_missing_values),
            "Formula Cells": str(self.formula_cell_count),
        }


@dataclass(frozen=True, slots=True)
class LoadedSource:
    """An uploaded file, validated, hashed and read into preserved cells."""

    source_file_id: str
    file_name: str
    file_hash: str
    file_type: FileType
    size_bytes: int
    uploaded_at: datetime
    workbook: RawWorkbook
    detection: DetectedFile
    sheet_profiles: tuple[SheetProfile, ...]

    @property
    def warnings(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys([*self.detection.warnings, *self.workbook.warnings]))

    def profile_summary(self) -> str:
        lines = [
            f"file: {self.file_name}",
            f"type: {self.file_type}",
            f"size: {self.size_bytes:,} bytes",
            f"hash: {self.file_hash}",
            f"sheets: {len(self.sheet_profiles)}",
        ]
        for profile in self.sheet_profiles:
            lines.append(f"\n  [{profile.name}]")
            lines.append(f"    rows: {profile.row_count} (data rows: {profile.data_row_count})")
            lines.append(
                f"    header row: "
                f"{profile.header_row_number if profile.header_row_number else 'NOT FOUND'}"
            )
            lines.append(f"    columns: {', '.join(profile.detected_headers) or 'none'}")
            if profile.date_columns:
                lines.append(f"    date columns: {', '.join(profile.date_columns)}")
            if profile.numeric_columns:
                lines.append(f"    amount columns: {', '.join(profile.numeric_columns)}")
            if profile.columns_with_missing_values:
                lines.append(
                    f"    columns with missing values: "
                    f"{', '.join(profile.columns_with_missing_values)}"
                )
        for warning in self.warnings:
            lines.append(f"\nwarning: {warning}")
        return "\n".join(lines)


def _profile_sheets(workbook: RawWorkbook) -> tuple[SheetProfile, ...]:
    from .tabular import extract_table

    profiles: list[SheetProfile] = []
    for sheet in workbook.sheets:
        table = extract_table(sheet)
        headers: tuple[str, ...] = ()
        header_row_number: int | None = None
        date_columns: list[str] = []
        numeric_columns: list[str] = []
        missing_columns: list[str] = []
        data_rows = 0

        if table is not None:
            headers = tuple(table.headers)
            header_row_number = table.header.row_index + 1
            data_rows = len(table.rows)
            for header in headers:
                kinds = [
                    row.cells[header].kind for row in table.rows if header in row.cells
                ]
                populated = [k for k in kinds if k is not CellKind.EMPTY]
                if not populated:
                    missing_columns.append(header)
                    continue
                if len(populated) < len(kinds):
                    missing_columns.append(header)
                if sum(1 for k in populated if k is CellKind.DATE) > len(populated) / 2:
                    date_columns.append(header)
                elif sum(1 for k in populated if k is CellKind.NUMBER) > len(populated) / 2:
                    numeric_columns.append(header)

        profiles.append(
            SheetProfile(
                name=sheet.name,
                index=sheet.index,
                hidden=sheet.hidden,
                row_count=sheet.row_count,
                column_count=sheet.column_count,
                populated_cell_count=len(sheet.cells),
                formula_cell_count=sheet.formula_cell_count,
                detected_headers=headers,
                header_row_number=header_row_number,
                date_columns=tuple(date_columns),
                numeric_columns=tuple(numeric_columns),
                columns_with_missing_values=tuple(missing_columns),
                data_row_count=data_rows,
            )
        )
    return tuple(profiles)


def load_source(
    content: bytes,
    *,
    file_name: str | None,
    max_bytes: int = DEFAULT_MAX_UPLOAD_BYTES,
    allowed_extensions: tuple[str, ...] = (".xlsx", ".xls", ".csv", ".pdf"),
    uploaded_at: datetime | None = None,
) -> LoadedSource:
    """Validate and read an uploaded statement file.

    The ``source_file_id`` is derived from the content hash, so uploading the
    same bytes twice yields the same id. That is what makes re-processing
    idempotent and lets a duplicate upload be recognised before any parsing
    work happens.
    """
    detection = validate_upload(
        content,
        file_name=file_name,
        max_bytes=max_bytes,
        allowed_extensions=allowed_extensions,
    )

    if detection.file_type is FileType.XLSX:
        workbook = read_xlsx(content)
    elif detection.file_type is FileType.CSV:
        workbook = read_csv(content, sheet_name=Path(detection.safe_name).stem or "CSV")
    else:  # pragma: no cover - validate_upload raises for everything else
        raise ParseError(
            ErrorCode.SOURCE_FILE_UNSUPPORTED,
            f"{detection.file_type} files cannot be read into a transaction ledger",
        )

    file_hash = hash_bytes(content)
    return LoadedSource(
        source_file_id=derive_id("SRC", file_hash),
        file_name=detection.safe_name,
        file_hash=file_hash,
        file_type=detection.file_type,
        size_bytes=detection.size_bytes,
        uploaded_at=uploaded_at or datetime.now(UTC),
        workbook=workbook,
        detection=detection,
        sheet_profiles=_profile_sheets(workbook),
    )


def load_source_path(path: str | Path, **kwargs: object) -> LoadedSource:
    """Read a statement file from disk, read-only.

    The source file is never modified or moved; it is opened for reading only.
    """
    file_path = Path(path)
    if not file_path.is_file():
        raise ParseError(ErrorCode.SOURCE_FILE_CORRUPT, f"{file_path} is not a file")
    return load_source(
        file_path.read_bytes(),
        file_name=file_path.name,
        **kwargs,  # type: ignore[arg-type]
    )
