"""Delimited-file reader producing the same preserved-text cells as the .xlsx reader.

A CSV holds only text, so nothing is lost to floating point by definition. The
reader still classifies numeric-looking cells as ``NUMBER`` while keeping their
original digit string, so that downstream code treats a CSV and an .xlsx the
same way.

Dates in a CSV stay ``TEXT``: the layout is a broker-specific convention and is
resolved by the broker parser against an explicit format list, rather than
being guessed here.
"""

from __future__ import annotations

import csv
import io

from ..core.errors import ErrorCode, ParseError
from ..core.money import normalize_numeric_text
from .tabular import CellKind, RawCell, RawSheet, RawWorkbook

MAX_FIELD_SIZE = 1024 * 1024
MAX_COLUMNS = 4096

#: Delimiters considered when sniffing. Tab and semicolon appear in exports
#: produced for European locales.
CANDIDATE_DELIMITERS = ",;\t|"


def _decode(content: bytes) -> tuple[str, str | None]:
    """Decode file bytes, returning the text and a warning if not UTF-8."""
    for encoding, warning in (
        ("utf-8-sig", None),
        ("utf-16", "the file was decoded as UTF-16"),
        ("cp1252", "the file was decoded as Windows-1252, not UTF-8"),
        ("latin-1", "the file was decoded as Latin-1, not UTF-8"),
    ):
        try:
            return content.decode(encoding), warning
        except (UnicodeDecodeError, UnicodeError):
            continue
    raise ParseError(
        ErrorCode.SOURCE_FILE_CORRUPT,
        "the file's character encoding could not be determined",
    )


def sniff_delimiter(sample: str) -> str:
    try:
        return csv.Sniffer().sniff(sample, delimiters=CANDIDATE_DELIMITERS).delimiter
    except csv.Error:
        # Fall back to whichever candidate appears most on the first line; a
        # single-column file legitimately has none, and comma is then correct.
        first_line = sample.splitlines()[0] if sample.splitlines() else ""
        counts = {d: first_line.count(d) for d in CANDIDATE_DELIMITERS}
        best = max(counts, key=lambda d: counts[d])
        return best if counts[best] else ","


def _classify(value: str) -> tuple[CellKind, str | None]:
    """Classify a CSV field, preserving its original text."""
    if not value.strip():
        return CellKind.EMPTY, None
    try:
        normalized = normalize_numeric_text(value)
    except Exception:  # noqa: BLE001 - a percentage or odd token is just text
        return CellKind.TEXT, value
    if normalized is None:
        return CellKind.TEXT, value
    # Only treat it as a number when the normalized form is actually numeric;
    # "1-800-FLOWERS" must not become a number.
    body = normalized[1:] if normalized[0] in "+-" else normalized
    if body and body.replace(".", "", 1).isdigit():
        return CellKind.NUMBER, normalized
    return CellKind.TEXT, value


def read_csv(content: bytes, *, sheet_name: str = "CSV") -> RawWorkbook:
    """Read a delimited file into a single-sheet :class:`RawWorkbook`."""
    text, encoding_warning = _decode(content)
    if not text.strip():
        raise ParseError(ErrorCode.SOURCE_FILE_CORRUPT, "the file contains no rows")

    warnings: list[str] = []
    if encoding_warning:
        warnings.append(encoding_warning)

    previous_limit = csv.field_size_limit()
    try:
        csv.field_size_limit(MAX_FIELD_SIZE)
        delimiter = sniff_delimiter(text[:8192])
        reader = csv.reader(io.StringIO(text), delimiter=delimiter)

        cells: dict[tuple[int, int], RawCell] = {}
        max_row = 0
        max_column = 0
        truncated_rows = 0

        for row_index, values in enumerate(reader):
            if len(values) > MAX_COLUMNS:
                truncated_rows += 1
                values = values[:MAX_COLUMNS]
            for column_index, value in enumerate(values):
                kind, preserved = _classify(value)
                if kind is CellKind.EMPTY:
                    continue
                cells[(row_index, column_index)] = RawCell(
                    row=row_index,
                    column=column_index,
                    kind=kind,
                    raw_text=preserved,
                    display_text=value if kind is CellKind.NUMBER else None,
                )
                max_row = max(max_row, row_index + 1)
                max_column = max(max_column, column_index + 1)
    except csv.Error as exc:
        raise ParseError(
            ErrorCode.SOURCE_FILE_CORRUPT, f"the delimited file could not be read: {exc}"
        ) from exc
    finally:
        csv.field_size_limit(previous_limit)

    if truncated_rows:
        warnings.append(
            f"{truncated_rows} row(s) had more than {MAX_COLUMNS} columns and were "
            f"truncated"
        )
    if delimiter != ",":
        warnings.append(f"the file's delimiter was detected as {delimiter!r}")
    if not cells:
        raise ParseError(ErrorCode.SOURCE_FILE_CORRUPT, "the file contains no data")

    sheet = RawSheet(
        name=sheet_name,
        index=0,
        cells=cells,
        row_count=max_row,
        column_count=max_column,
    )
    return RawWorkbook(sheets=(sheet,), warnings=tuple(warnings))
