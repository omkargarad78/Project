"""Date-layout resolution for source files.

A date column is resolved at the *column* level, not cell by cell. ``01/02/2025``
is 1 February under one convention and 2 January under another, and a cell
looked at in isolation cannot tell which. Looking at the whole column often
can: a single value with a day above 12 settles it. When it does not settle
it, the layout is reported as ambiguous and the caller must fail rather than
pick a convention, because a silently transposed date moves a transaction into
the wrong reporting period.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from datetime import date, datetime

#: Candidate layouts, as ``(strptime format, human label)``.
DATE_FORMATS: tuple[tuple[str, str], ...] = (
    ("%Y-%m-%d", "ISO 8601 (YYYY-MM-DD)"),
    ("%Y/%m/%d", "year/month/day (YYYY/MM/DD)"),
    ("%d-%m-%Y", "day-month-year (DD-MM-YYYY)"),
    ("%m-%d-%Y", "month-day-year (MM-DD-YYYY)"),
    ("%d/%m/%Y", "day/month/year (DD/MM/YYYY)"),
    ("%m/%d/%Y", "month/day/year (MM/DD/YYYY)"),
    ("%d-%b-%Y", "day-abbreviated month-year (DD-Mon-YYYY)"),
    ("%d %b %Y", "day abbreviated month year (DD Mon YYYY)"),
    ("%d-%B-%Y", "day-full month-year (DD-Month-YYYY)"),
    ("%d %B %Y", "day full month year (DD Month YYYY)"),
    ("%b %d, %Y", "abbreviated month day, year (Mon DD, YYYY)"),
    ("%B %d, %Y", "full month day, year (Month DD, YYYY)"),
    ("%d.%m.%Y", "day.month.year (DD.MM.YYYY)"),
    ("%Y%m%d", "compact ISO (YYYYMMDD)"),
    ("%d-%m-%y", "day-month-two-digit year (DD-MM-YY)"),
    ("%m/%d/%y", "month/day/two-digit year (MM/DD/YY)"),
)

#: Suffixes stripped before parsing, so that a datetime string resolves under a
#: date-only layout. The time component is discarded deliberately: Schedule FA
#: works in whole days and a broker's timestamp timezone is rarely stated.
_TIME_SEPARATORS = ("T", " ")


@dataclass(frozen=True, slots=True)
class DateFormatResolution:
    """The layout chosen for a column, or the reason none could be."""

    format: str | None
    label: str | None
    #: Layouts that parsed every sample. More than one means the column was
    #: only resolved because they all agreed.
    viable_formats: tuple[str, ...] = ()
    ambiguous: bool = False
    reason: str | None = None
    #: Number of samples the decision was based on.
    sample_count: int = 0

    @property
    def resolved(self) -> bool:
        return self.format is not None


def strip_time_component(text: str) -> str:
    """Remove a trailing time from a datetime string."""
    candidate = text.strip()
    for separator in _TIME_SEPARATORS:
        if separator in candidate:
            head, _, tail = candidate.partition(separator)
            # Only treat the tail as a time when it looks like one.
            if ":" in tail and head:
                return head.strip()
    return candidate


def parse_with_format(text: str, fmt: str) -> date | None:
    """Parse one value under one layout, tolerating a trailing time."""
    candidate = strip_time_component(text)
    if not candidate:
        return None
    try:
        return datetime.strptime(candidate, fmt).date()
    except ValueError:
        return None


def resolve_date_format(
    samples: Sequence[str],
    *,
    candidates: Sequence[tuple[str, str]] = DATE_FORMATS,
) -> DateFormatResolution:
    """Choose the layout for a column of date strings."""
    cleaned = [s.strip() for s in samples if s and s.strip()]
    if not cleaned:
        return DateFormatResolution(
            format=None, label=None, reason="the column contains no date values"
        )

    viable: list[tuple[str, str, list[date]]] = []
    for fmt, label in candidates:
        parsed: list[date] = []
        for sample in cleaned:
            value = parse_with_format(sample, fmt)
            if value is None:
                parsed = []
                break
            parsed.append(value)
        if parsed:
            viable.append((fmt, label, parsed))

    if not viable:
        return DateFormatResolution(
            format=None,
            label=None,
            reason=(
                f"no supported date layout parses every value in this column; "
                f"the first value is {cleaned[0]!r}"
            ),
            sample_count=len(cleaned),
        )

    first_fmt, first_label, first_parsed = viable[0]
    for _fmt, label, parsed in viable[1:]:
        disagreement = next(
            (
                (index, a, b)
                for index, (a, b) in enumerate(zip(first_parsed, parsed, strict=True))
                if a != b
            ),
            None,
        )
        if disagreement is not None:
            index, under_first, under_other = disagreement
            return DateFormatResolution(
                format=None,
                label=None,
                viable_formats=tuple(f for f, _l, _p in viable),
                ambiguous=True,
                reason=(
                    f"the date layout is ambiguous: {cleaned[index]!r} is "
                    f"{under_first.isoformat()} read as {first_label} but "
                    f"{under_other.isoformat()} read as {label}. Both layouts parse "
                    f"every value in this column, so the correct one cannot be "
                    f"determined from the data."
                ),
                sample_count=len(cleaned),
            )

    return DateFormatResolution(
        format=first_fmt,
        label=first_label,
        viable_formats=tuple(f for f, _l, _p in viable),
        sample_count=len(cleaned),
    )
