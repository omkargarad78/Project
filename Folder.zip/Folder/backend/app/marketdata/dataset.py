"""Immutable, versioned market-data snapshots.

A calculation names a snapshot, and the snapshot never changes. Re-running a
report six months later must produce the same figures, which it cannot do if
the price series underneath it is a live feed that has since been restated —
and providers do restate history, every time a split happens.

The snapshot also knows which days the market was open, inferred from the data
itself rather than from a hard-coded holiday calendar. That distinction is what
lets a missing price be classified correctly: no price on a day nothing else
traded is a closed market, and no price on a day everything else traded is a
gap in the data.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from datetime import date
from decimal import Decimal

from ..core.hashing import derive_id, hash_bytes
from ..core.money import decimal_to_str
from .models import (
    AdjustmentBasis,
    CorporateAction,
    CorporateActionType,
    PriceRecord,
    PriceType,
)

#: A date counts as a trading day when at least this share of the securities
#: covered by the dataset have a price on it. Set below a half so that a
#: dataset dominated by one heavily-traded name still recognises the calendar,
#: and above a token fraction so that a single stray record does not turn a
#: holiday into a trading day.
TRADING_DAY_COVERAGE_THRESHOLD = Decimal("0.4")


@dataclass(frozen=True, slots=True)
class Coverage:
    """What a snapshot actually contains for one symbol."""

    symbol: str
    first_date: date
    last_date: date
    record_count: int
    price_types: tuple[PriceType, ...]
    currencies: tuple[str, ...]
    #: Dates inside the covered span with no price, that the dataset's own
    #: calendar says were trading days.
    gap_count: int = 0

    def covers(self, day: date) -> bool:
        return self.first_date <= day <= self.last_date

    def describe(self) -> str:
        return (
            f"{self.symbol}: {self.record_count} prices from "
            f"{self.first_date.isoformat()} to {self.last_date.isoformat()}"
            + (f", {self.gap_count} trading-day gap(s)" if self.gap_count else "")
        )


class MarketDataSnapshot:
    """An immutable set of prices and corporate actions."""

    def __init__(
        self,
        records: Iterable[PriceRecord] = (),
        actions: Iterable[CorporateAction] = (),
        *,
        dataset_name: str,
        adjustment_basis: AdjustmentBasis = AdjustmentBasis.UNKNOWN,
        source_description: str | None = None,
        synthetic: bool = False,
    ) -> None:
        self.dataset_name = dataset_name
        self.source_description = source_description
        self.synthetic = synthetic

        self._records: dict[tuple[str, date, PriceType], PriceRecord] = {}
        self._by_symbol: dict[str, dict[date, dict[PriceType, PriceRecord]]] = (
            defaultdict(lambda: defaultdict(dict))
        )
        self._dates: set[date] = set()
        for record in records:
            self._add(record)

        self._actions: list[CorporateAction] = sorted(
            actions, key=lambda a: (a.ex_date, a.symbol, a.action_id)
        )

        #: The basis declared for the dataset as a whole. When records disagree
        #: with it, the record wins and the disagreement is visible in
        #: ``mixed_adjustment_bases``.
        self.adjustment_basis = self._resolve_basis(adjustment_basis)
        self._trading_days: frozenset[date] | None = None
        self.version_id = self._derive_version_id()

    # --- construction ----------------------------------------------------

    def _add(self, record: PriceRecord) -> None:
        if record.key in self._records:
            existing = self._records[record.key]
            if existing.price != record.price:
                raise ValueError(
                    f"conflicting prices for {record.symbol} on "
                    f"{record.price_date.isoformat()} ({record.price_type}): "
                    f"{existing.price} and {record.price}. A snapshot cannot hold two "
                    f"different values for the same quotation."
                )
            return
        self._records[record.key] = record
        self._by_symbol[record.symbol][record.price_date][record.price_type] = record
        self._dates.add(record.price_date)

    def _resolve_basis(self, declared: AdjustmentBasis) -> AdjustmentBasis:
        found = {r.adjustment_basis for r in self._records.values()}
        found.discard(AdjustmentBasis.UNKNOWN)
        if len(found) == 1:
            return found.pop()
        if len(found) > 1:
            # Mixed bases in one snapshot cannot be summarised by one value.
            return AdjustmentBasis.UNKNOWN
        return declared

    def _derive_version_id(self) -> str:
        """A content hash, so identical data always yields the same id."""
        parts = [
            f"{r.symbol}|{r.price_date.isoformat()}|{r.price_type}|"
            f"{decimal_to_str(r.price)}|{r.currency}|{r.adjustment_basis}"
            for r in sorted(self._records.values(), key=lambda r: r.key)
        ]
        parts.extend(
            f"CA|{a.action_id}|{a.symbol}|{a.ex_date.isoformat()}|{a.action_type}|"
            f"{decimal_to_str(a.ratio_to)}|{decimal_to_str(a.ratio_from)}"
            for a in self._actions
        )
        return derive_id("MDS", hash_bytes("\n".join(parts).encode("utf-8")))

    # --- access ----------------------------------------------------------

    def __len__(self) -> int:
        return len(self._records)

    @property
    def record_count(self) -> int:
        return len(self._records)

    @property
    def action_count(self) -> int:
        return len(self._actions)

    def symbols(self) -> list[str]:
        return sorted(self._by_symbol)

    def dates(self) -> list[date]:
        return sorted(self._dates)

    @property
    def mixed_adjustment_bases(self) -> bool:
        """True when records in this snapshot disagree about their basis."""
        found = {r.adjustment_basis for r in self._records.values()}
        found.discard(AdjustmentBasis.UNKNOWN)
        return len(found) > 1

    def price(
        self, symbol: str, day: date, price_type: PriceType = PriceType.CLOSE
    ) -> PriceRecord | None:
        """The exact price for a symbol, date and type, or nothing."""
        return self._records.get((symbol.strip().upper(), day, price_type))

    def prices_for(self, symbol: str) -> list[PriceRecord]:
        normalized = symbol.strip().upper()
        return sorted(
            (
                record
                for by_date in self._by_symbol.get(normalized, {}).values()
                for record in by_date.values()
            ),
            key=lambda r: (r.price_date, str(r.price_type)),
        )

    def latest_on_or_before(
        self, symbol: str, day: date, price_type: PriceType = PriceType.CLOSE
    ) -> PriceRecord | None:
        """The most recent price at or before a date.

        Used for weekends and holidays, where the last traded price is the
        correct value rather than an estimate. The caller decides whether the
        gap it spans is acceptable.
        """
        normalized = symbol.strip().upper()
        by_date = self._by_symbol.get(normalized)
        if not by_date:
            return None
        candidates = [d for d in by_date if d <= day and price_type in by_date[d]]
        if not candidates:
            return None
        return by_date[max(candidates)][price_type]

    # --- trading calendar -------------------------------------------------

    def trading_days(self) -> frozenset[date]:
        """Dates on which the dataset says the market was open.

        Inferred from coverage rather than from a hard-coded holiday list,
        because exchange calendars differ by venue and change over time, and a
        stale built-in calendar would misclassify real gaps as holidays.
        """
        if self._trading_days is not None:
            return self._trading_days

        symbol_count = len(self._by_symbol)
        if symbol_count == 0:
            self._trading_days = frozenset()
            return self._trading_days

        threshold = Decimal(symbol_count) * TRADING_DAY_COVERAGE_THRESHOLD
        per_day: dict[date, int] = defaultdict(int)
        for symbol_dates in self._by_symbol.values():
            for day in symbol_dates:
                per_day[day] += 1

        self._trading_days = frozenset(
            day for day, count in per_day.items() if Decimal(count) >= threshold
        )
        return self._trading_days

    def is_trading_day(self, day: date) -> bool:
        return day in self.trading_days()

    def trading_days_between(self, start: date, end: date) -> list[date]:
        return sorted(d for d in self.trading_days() if start <= d <= end)

    # --- corporate actions ------------------------------------------------

    def actions(self) -> list[CorporateAction]:
        return list(self._actions)

    def actions_for(
        self,
        symbol: str,
        *,
        start: date | None = None,
        end: date | None = None,
    ) -> list[CorporateAction]:
        """Actions affecting a symbol, optionally within a date window."""
        normalized = symbol.strip().upper()
        return [
            action
            for action in self._actions
            if action.symbol == normalized
            and (start is None or action.ex_date >= start)
            and (end is None or action.ex_date <= end)
        ]

    def actions_between(
        self, symbol: str, *, from_date: date, to_date: date
    ) -> list[CorporateAction]:
        """Actions applying to a holding carried across a date range.

        An action applies when its ex-date falls after ``from_date`` and on or
        before ``to_date``: a holding acquired on the ex-date itself is already
        on the new basis.
        """
        return [
            action
            for action in self.actions_for(symbol)
            if from_date < action.ex_date <= to_date
        ]

    def adjust_quantity(
        self, symbol: str, quantity: Decimal, *, from_date: date, to_date: date
    ) -> Decimal:
        """Restate a share count held on ``from_date`` as at ``to_date``.

        The authoritative path. Ratios are accumulated as an exact numerator
        and denominator and applied once, so a sequence of reverse splits does
        not shed fractional shares to rounding at each step.
        """
        numerator = Decimal(1)
        denominator = Decimal(1)
        for action in self.actions_between(
            symbol, from_date=from_date, to_date=to_date
        ):
            action_numerator, action_denominator = action.ratio()
            numerator *= action_numerator
            denominator *= action_denominator
        return quantity * numerator / denominator

    def quantity_factor(
        self, symbol: str, *, from_date: date, to_date: date
    ) -> Decimal:
        """Cumulative share multiplier between two dates.

        For display and comparison. Use :meth:`adjust_quantity` to restate a
        real holding, because a factor that does not divide evenly is rounded
        here and exact there.
        """
        return self.adjust_quantity(
            symbol, Decimal(1), from_date=from_date, to_date=to_date
        )

    def unverified_actions(self) -> list[CorporateAction]:
        return [a for a in self._actions if not a.is_verified]

    # --- coverage ---------------------------------------------------------

    def coverage(self, symbol: str) -> Coverage | None:
        normalized = symbol.strip().upper()
        by_date = self._by_symbol.get(normalized)
        if not by_date:
            return None
        days = sorted(by_date)
        records = [r for d in days for r in by_date[d].values()]
        first, last = days[0], days[-1]
        expected = self.trading_days_between(first, last)
        present = set(days)
        gaps = sum(1 for d in expected if d not in present)
        return Coverage(
            symbol=normalized,
            first_date=first,
            last_date=last,
            record_count=len(records),
            price_types=tuple(
                sorted({r.price_type for r in records}, key=str)
            ),
            currencies=tuple(sorted({r.currency for r in records})),
            gap_count=gaps,
        )

    def coverage_report(self) -> list[Coverage]:
        return [c for s in self.symbols() if (c := self.coverage(s)) is not None]

    def missing_symbols(self, symbols: Sequence[str]) -> list[str]:
        known = set(self.symbols())
        return sorted({s.strip().upper() for s in symbols} - known)

    def summary(self) -> str:
        lines = [
            f"snapshot {self.version_id}",
            f"name: {self.dataset_name}",
            f"prices: {self.record_count}   corporate actions: {self.action_count}",
            f"adjustment basis: {self.adjustment_basis}"
            + ("  (MIXED - records disagree)" if self.mixed_adjustment_bases else ""),
            f"symbols: {', '.join(self.symbols()) or 'none'}",
            f"trading days identified: {len(self.trading_days())}",
        ]
        if self.synthetic:
            lines.append("SYNTHETIC TEST DATA - not real market prices")
        for coverage in self.coverage_report():
            lines.append(f"  {coverage.describe()}")
        for action in self._actions:
            mark = "" if action.is_verified else "  [UNVERIFIED]"
            lines.append(f"  action: {action.describe()}{mark}")
        return "\n".join(lines)


def merge_snapshots(
    snapshots: Sequence[MarketDataSnapshot], *, dataset_name: str
) -> MarketDataSnapshot:
    """Combine snapshots into one, refusing to merge conflicting quotations.

    Used when a user supplies prices for a security the main dataset does not
    cover. A conflict is an error rather than a precedence rule, because
    silently preferring one source over another hides a disagreement the user
    would want to see.
    """
    records: list[PriceRecord] = []
    actions: list[CorporateAction] = []
    for snapshot in snapshots:
        records.extend(snapshot._records.values())  # noqa: SLF001
        actions.extend(snapshot.actions())
    return MarketDataSnapshot(
        records,
        actions,
        dataset_name=dataset_name,
        synthetic=any(s.synthetic for s in snapshots),
    )


def ticker_change_actions(snapshot: MarketDataSnapshot) -> list[CorporateAction]:
    return [
        a
        for a in snapshot.actions()
        if a.action_type is CorporateActionType.TICKER_CHANGE
    ]
