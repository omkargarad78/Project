"""Market prices and corporate actions.

Peak and closing values under Schedule FA need a price for a security on a
date. Two things about that are easy to get wrong and expensive to get wrong.

**The adjustment basis.** Most free price series are *split-adjusted*: after a
4-for-1 split, every earlier price in the series is divided by four, so the
chart stays smooth. If you multiply such a price by the number of shares you
actually held on that earlier date, you understate the holding by the whole
split ratio, and nothing in the resulting number looks wrong. So the basis is
recorded on every record and on the dataset, an unstated basis is an error
rather than an assumption, and pairing an adjusted series with historical
share counts is refused.

**A missing price is not a zero and not an average.** Weekends and exchange
holidays have no price because no trading happened, and the last traded price
is the right value there — that is convention, not estimation. A gap on a day
the market was open means the data is incomplete. The engine distinguishes the
two by looking at whether the rest of the dataset traded that day, and labels
every carried-forward price with how far it was carried.
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum
from typing import Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from ..core.money import ZERO, as_price, to_decimal
from ..tax.rules.models import SourceTier, VerificationStatus


class PriceType(StrEnum):
    """Which published price a record holds.

    Not interchangeable. A closing price and an intraday high answer different
    questions, and a peak-value rule that says "closing price on each date"
    is not satisfied by a series of highs.
    """

    CLOSE = "CLOSE"
    OPEN = "OPEN"
    HIGH = "HIGH"
    LOW = "LOW"
    #: Volume-weighted average price.
    VWAP = "VWAP"
    #: Net asset value, for funds that publish one instead of a traded price.
    NAV = "NAV"
    BID = "BID"
    ASK = "ASK"
    #: The broker's own valuation, from a statement rather than an exchange.
    BROKER_VALUATION = "BROKER_VALUATION"


class AdjustmentBasis(StrEnum):
    """Whether a price series has been restated for corporate actions."""

    #: The price as it traded on the day. Pairs with historical share counts.
    UNADJUSTED = "UNADJUSTED"
    #: Earlier prices restated for later splits. Pairs only with share counts
    #: restated the same way.
    SPLIT_ADJUSTED = "SPLIT_ADJUSTED"
    #: Restated for splits and for dividends reinvested. Never appropriate for
    #: valuing a holding, because it embeds returns the holding did not get.
    TOTAL_RETURN_ADJUSTED = "TOTAL_RETURN_ADJUSTED"
    #: The provider did not say. Treated as an error, not as unadjusted.
    UNKNOWN = "UNKNOWN"

    @property
    def is_stated(self) -> bool:
        return self is not AdjustmentBasis.UNKNOWN

    @property
    def needs_adjusted_quantities(self) -> bool:
        """Whether share counts must be restated to match this basis."""
        return self in (
            AdjustmentBasis.SPLIT_ADJUSTED,
            AdjustmentBasis.TOTAL_RETURN_ADJUSTED,
        )

    @property
    def is_valuation_safe(self) -> bool:
        """Whether this basis can value a holding at all.

        A total-return series is never safe: it folds reinvested dividends
        into the price, so it answers "what would this investment be worth"
        rather than "what was this share worth", and Schedule FA asks the
        second question.
        """
        return self in (AdjustmentBasis.UNADJUSTED, AdjustmentBasis.SPLIT_ADJUSTED)


class CorporateActionType(StrEnum):
    """Events that change what a share is."""

    SPLIT = "SPLIT"
    REVERSE_SPLIT = "REVERSE_SPLIT"
    STOCK_DIVIDEND = "STOCK_DIVIDEND"
    MERGER = "MERGER"
    SPINOFF = "SPINOFF"
    TICKER_CHANGE = "TICKER_CHANGE"
    #: Delisting or other termination of the interest.
    DELISTING = "DELISTING"

    @property
    def changes_quantity(self) -> bool:
        return self in (
            CorporateActionType.SPLIT,
            CorporateActionType.REVERSE_SPLIT,
            CorporateActionType.STOCK_DIVIDEND,
            CorporateActionType.MERGER,
        )


class PriceProvenance(BaseModel):
    """Where a price came from and how far it can be trusted."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    #: Source id in the official-source registry, when there is one.
    source_id: str | None = None
    tier: SourceTier = SourceTier.DATA_PROVIDER
    #: The exchange that published the price, when known. A price from an
    #: exchange outranks one from an aggregator with no stated venue.
    exchange: str | None = None
    retrieved_at: datetime | None = None
    reference: str | None = None
    verification_status: VerificationStatus = VerificationStatus.REQUIRES_CONFIRMATION

    @property
    def is_exchange_sourced(self) -> bool:
        return self.exchange is not None and self.tier <= SourceTier.OFFICIAL_THIRD_PARTY


class PriceRecord(BaseModel):
    """One security's price on one date."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    #: Security master id when resolved, otherwise the raw symbol is used.
    security_id: str | None = None
    symbol: str
    price_date: date
    price_type: PriceType = PriceType.CLOSE
    #: Held as Decimal. A float here would corrupt every value derived from it.
    price: Decimal
    currency: str
    adjustment_basis: AdjustmentBasis = AdjustmentBasis.UNKNOWN
    provenance: PriceProvenance = Field(default_factory=PriceProvenance)
    #: True for records generated for tests, so they can never be mistaken for
    #: real market data.
    synthetic: bool = False
    note: str | None = None

    @field_validator("price", mode="before")
    @classmethod
    def _coerce_price(cls, value: object) -> Decimal:
        # Rejects float at the boundary; to_decimal raises on one.
        return as_price(to_decimal(value, field="price"))

    @field_validator("symbol", "currency")
    @classmethod
    def _upper(cls, value: str) -> str:
        return value.strip().upper()

    @model_validator(mode="after")
    def _check_price(self) -> Self:
        if self.price < ZERO:
            raise ValueError(
                f"{self.symbol} on {self.price_date}: a negative price ({self.price}) "
                f"is not a valid quotation"
            )
        return self

    @property
    def key(self) -> tuple[str, date, PriceType]:
        return (self.symbol, self.price_date, self.price_type)


class CorporateAction(BaseModel):
    """An event that changes a share count or a security's identity.

    Ratios are held as an explicit numerator and denominator rather than as a
    single decimal, because a 3-for-1 split gives a factor of 3 exactly while
    a 1-for-3 reverse split gives 0.333..., and rounding that factor loses
    fractional shares that the investor actually holds.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    action_id: str
    action_type: CorporateActionType
    symbol: str
    security_id: str | None = None
    #: The date from which the change applies. A holding is adjusted for an
    #: action whose ex-date is on or before the valuation date.
    ex_date: date
    #: New shares received for each ``ratio_from`` shares held. A 4-for-1
    #: split is ratio_to=4, ratio_from=1.
    ratio_to: Decimal | None = None
    ratio_from: Decimal | None = None
    #: For ticker changes and mergers, the symbol that replaces this one.
    resulting_symbol: str | None = None
    resulting_security_id: str | None = None
    #: Cash paid per share in a merger, in the security's currency.
    cash_per_share: Decimal | None = None
    source_id: str | None = None
    tier: SourceTier = SourceTier.DATA_PROVIDER
    reference: str | None = None
    verification_status: VerificationStatus = VerificationStatus.REQUIRES_CONFIRMATION
    synthetic: bool = False
    note: str | None = None

    @field_validator("symbol", "resulting_symbol")
    @classmethod
    def _upper(cls, value: str | None) -> str | None:
        return value.strip().upper() if value else value

    @field_validator("ratio_to", "ratio_from", "cash_per_share", mode="before")
    @classmethod
    def _coerce(cls, value: object) -> Decimal | None:
        if value is None:
            return None
        return to_decimal(value, field="ratio")

    @model_validator(mode="after")
    def _check_ratio(self) -> Self:
        if self.action_type.changes_quantity and self.action_type is not (
            CorporateActionType.MERGER
        ):
            if self.ratio_to is None or self.ratio_from is None:
                raise ValueError(
                    f"{self.action_id}: a {self.action_type} must state both sides of "
                    f"its ratio; without them the share count cannot be adjusted"
                )
            if self.ratio_to <= ZERO or self.ratio_from <= ZERO:
                raise ValueError(
                    f"{self.action_id}: ratio values must be positive, got "
                    f"{self.ratio_to}/{self.ratio_from}"
                )
        return self

    @property
    def is_verified(self) -> bool:
        return self.verification_status is VerificationStatus.VERIFIED

    def ratio(self) -> tuple[Decimal, Decimal]:
        """The ratio as an exact ``(numerator, denominator)`` pair.

        Kept unevaluated. A 1-for-3 reverse split has no finite decimal
        factor, so dividing first and multiplying afterwards loses shares;
        callers multiply by the numerator before dividing by the denominator.
        """
        if not self.action_type.changes_quantity:
            return Decimal(1), Decimal(1)
        if self.ratio_to is None or self.ratio_from is None:
            return Decimal(1), Decimal(1)
        return self.ratio_to, self.ratio_from

    def apply_to_quantity(self, quantity: Decimal) -> Decimal:
        """Restate a share count for this action.

        The authoritative path for adjusting quantities. Multiplies before
        dividing, so 300 shares through a 1-for-3 reverse split give exactly
        100 rather than 99.999...
        """
        numerator, denominator = self.ratio()
        return quantity * numerator / denominator

    def quantity_factor(self) -> Decimal:
        """How many shares one pre-action share becomes.

        Convenient for display and for comparisons. Use
        :meth:`apply_to_quantity` when restating an actual holding, because
        this value is rounded for ratios that do not divide evenly.
        """
        numerator, denominator = self.ratio()
        return numerator / denominator

    def describe(self) -> str:
        if self.action_type is CorporateActionType.TICKER_CHANGE:
            return (
                f"{self.symbol} became {self.resulting_symbol} on "
                f"{self.ex_date.isoformat()}"
            )
        if self.ratio_to is not None and self.ratio_from is not None:
            return (
                f"{self.symbol} {self.action_type} {self.ratio_to}-for-"
                f"{self.ratio_from} with ex-date {self.ex_date.isoformat()}"
            )
        return f"{self.symbol} {self.action_type} on {self.ex_date.isoformat()}"
