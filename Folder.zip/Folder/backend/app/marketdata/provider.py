"""Price providers and price resolution.

``PriceProvider`` is the seam for getting prices in. Nothing here downloads
anything: the shipped providers read a CSV the user supplies and accept manual
entries. A network provider would implement the same interface, and would
still have to snapshot what it returned, because a report must be reproducible
after the provider has restated its history.

``PriceResolver`` is where the policies live. Its job is to answer "what was
this worth on this date" and, when it cannot, to say precisely why.
"""

from __future__ import annotations

import csv
import io
from abc import ABC, abstractmethod
from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from enum import StrEnum

from ..core.errors import ErrorCode, ParseError
from ..core.money import MoneyError, normalize_numeric_text, to_decimal
from ..io.dates import resolve_date_format
from ..validation.issues import IssueCollector, IssueScope
from .dataset import MarketDataSnapshot
from .models import (
    AdjustmentBasis,
    CorporateAction,
    PriceProvenance,
    PriceRecord,
    PriceType,
)


class PriceStatus(StrEnum):
    """How a price lookup turned out."""

    #: A price published on the requested date.
    EXACT = "EXACT"
    #: Carried forward from an earlier date the market was open on. Normal for
    #: weekends and holidays.
    CARRIED_FORWARD = "CARRIED_FORWARD"
    #: The symbol is covered but there is no usable price for this date.
    MISSING = "MISSING"
    #: The snapshot has no prices for this symbol at all.
    SYMBOL_NOT_COVERED = "SYMBOL_NOT_COVERED"
    #: A price exists but cannot be used, for example a currency mismatch or
    #: an unusable adjustment basis.
    UNUSABLE = "UNUSABLE"

    @property
    def usable(self) -> bool:
        return self in (PriceStatus.EXACT, PriceStatus.CARRIED_FORWARD)


class MissingPricePolicy(StrEnum):
    """What to do when no price is published on a valuation date."""

    #: Use the most recent earlier price, within the configured limit.
    CARRY_FORWARD = "CARRY_FORWARD"
    #: Never carry forward; treat any absence as missing.
    STRICT = "STRICT"

    # There is deliberately no INTERPOLATE option. Averaging the prices either
    # side of a gap invents a quotation that never existed, and a peak value
    # built on invented quotations is not defensible on assessment.


@dataclass(frozen=True, slots=True)
class PricePolicy:
    """How prices are selected. Data, so it can be versioned per rule set."""

    price_type: PriceType = PriceType.CLOSE
    missing_policy: MissingPricePolicy = MissingPricePolicy.CARRY_FORWARD
    #: How many calendar days a price may be carried forward. Four days spans
    #: a normal weekend plus a public holiday; beyond that, the absence more
    #: likely means incomplete data than a closed market.
    max_carry_forward_days: int = 4
    #: Whether the share counts being valued have been restated for splits.
    #: Must match the snapshot's adjustment basis.
    quantities_are_adjusted: bool = False
    #: Reject a snapshot whose basis the provider did not state.
    require_stated_basis: bool = True


@dataclass(frozen=True, slots=True)
class PriceResolution:
    """One price lookup, with everything needed to defend the number."""

    symbol: str
    requested_date: date
    status: PriceStatus
    price: Decimal | None = None
    currency: str | None = None
    price_date: date | None = None
    price_type: PriceType | None = None
    adjustment_basis: AdjustmentBasis | None = None
    #: Calendar days between the price's date and the requested date.
    staleness_days: int = 0
    record: PriceRecord | None = None
    explanation: str = ""

    @property
    def usable(self) -> bool:
        return self.status.usable and self.price is not None

    def describe(self) -> str:
        if not self.usable:
            return f"{self.symbol} on {self.requested_date.isoformat()}: {self.explanation}"
        basis = f", {self.adjustment_basis}" if self.adjustment_basis else ""
        carried = (
            f" carried forward {self.staleness_days} day(s) from "
            f"{self.price_date.isoformat() if self.price_date else '?'}"
            if self.status is PriceStatus.CARRIED_FORWARD
            else ""
        )
        return (
            f"{self.symbol} on {self.requested_date.isoformat()}: {self.price} "
            f"{self.currency} ({self.price_type}{basis}){carried}"
        )


class PriceProvider(ABC):
    """Source of price records.

    A provider returns records; it does not decide policy and does not value
    anything. Keeping it that narrow is what lets a new source be added
    without touching valuation.
    """

    provider_id: str = ""
    provider_name: str = ""
    #: Whether this provider states the adjustment basis of what it returns.
    states_adjustment_basis: bool = False

    @abstractmethod
    def fetch(
        self, symbols: Sequence[str], start: date, end: date
    ) -> list[PriceRecord]:
        """Return every price this provider has for the symbols and window."""

    def fetch_actions(
        self, symbols: Sequence[str], start: date, end: date
    ) -> list[CorporateAction]:
        """Corporate actions, when the provider supplies them."""
        return []

    def snapshot(
        self,
        symbols: Sequence[str],
        start: date,
        end: date,
        *,
        dataset_name: str | None = None,
    ) -> MarketDataSnapshot:
        """Fetch and freeze, so the result can be re-used verbatim."""
        records = self.fetch(symbols, start, end)
        actions = self.fetch_actions(symbols, start, end)
        return MarketDataSnapshot(
            records,
            actions,
            dataset_name=dataset_name or f"{self.provider_id} {start}..{end}",
            source_description=self.provider_name,
        )


class ManualPriceProvider(PriceProvider):
    """Prices a user typed in, each with the source they cite.

    Ranked above an unattributed dataset: a person who looked up a closing
    price and recorded where they found it has supplied better evidence than
    a file of unknown origin.
    """

    provider_id = "manual"
    provider_name = "Manually entered prices"
    states_adjustment_basis = True

    def __init__(self, records: Sequence[PriceRecord] = ()) -> None:
        self._records = list(records)

    def add(self, record: PriceRecord) -> None:
        self._records.append(record)

    def fetch(
        self, symbols: Sequence[str], start: date, end: date
    ) -> list[PriceRecord]:
        wanted = {s.strip().upper() for s in symbols}
        return [
            r
            for r in self._records
            if r.symbol in wanted and start <= r.price_date <= end
        ]


#: Header spellings accepted by the CSV provider, per field.
_CSV_ALIASES: dict[str, tuple[str, ...]] = {
    "date": ("date", "price date", "trade date", "as of"),
    "symbol": ("symbol", "ticker", "security"),
    "close": ("close", "closing price", "close price", "price", "last"),
    "open": ("open", "opening price"),
    "high": ("high", "day high"),
    "low": ("low", "day low"),
    "adj_close": ("adj close", "adjusted close", "adjusted closing price"),
    "currency": ("currency", "ccy", "currency code"),
}


def _normalize_header(text: str) -> str:
    return " ".join(
        "".join(ch if ch.isalnum() or ch.isspace() else " " for ch in text.lower())
        .split()
    )


def _find_column(columns: Sequence[str], aliases: Sequence[str]) -> str | None:
    normalized = {_normalize_header(c): c for c in columns}
    for alias in aliases:
        if alias in normalized:
            return normalized[alias]
    return None


class CsvPriceProvider(PriceProvider):
    """Prices from a delimited file the user supplies.

    The adjustment basis is a required argument rather than something guessed
    from the presence of an "Adj Close" column, because a file can be
    adjusted throughout and never say so.
    """

    provider_id = "csv"
    provider_name = "Delimited price file"
    states_adjustment_basis = True

    def __init__(
        self,
        content: bytes,
        *,
        file_name: str,
        adjustment_basis: AdjustmentBasis,
        default_currency: str | None = None,
        source_id: str | None = None,
        synthetic: bool = False,
    ) -> None:
        self.file_name = file_name
        self.adjustment_basis = adjustment_basis
        self.default_currency = default_currency
        self.source_id = source_id
        self.synthetic = synthetic
        self._records = self._parse(content)

    def _parse(self, content: bytes) -> list[PriceRecord]:
        try:
            text = content.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise ParseError(
                ErrorCode.SOURCE_FILE_CORRUPT,
                f"{self.file_name} is not valid UTF-8 text: {exc}",
            ) from exc

        reader = csv.DictReader(io.StringIO(text))
        columns = list(reader.fieldnames or ())
        if not columns:
            raise ParseError(
                ErrorCode.SOURCE_FILE_CORRUPT, f"{self.file_name} has no header row"
            )

        date_column = _find_column(columns, _CSV_ALIASES["date"])
        symbol_column = _find_column(columns, _CSV_ALIASES["symbol"])
        if date_column is None or symbol_column is None:
            raise ParseError(
                ErrorCode.SCHEMA_VALIDATION_FAILED,
                f"{self.file_name} must have a date column and a symbol column. "
                f"Found: {', '.join(columns)}",
            )

        price_columns: list[tuple[str, PriceType]] = []
        for key, price_type in (
            ("close", PriceType.CLOSE),
            ("open", PriceType.OPEN),
            ("high", PriceType.HIGH),
            ("low", PriceType.LOW),
        ):
            column = _find_column(columns, _CSV_ALIASES[key])
            if column is not None:
                price_columns.append((column, price_type))
        if not price_columns:
            raise ParseError(
                ErrorCode.SCHEMA_VALIDATION_FAILED,
                f"{self.file_name} has no recognised price column. "
                f"Found: {', '.join(columns)}",
            )

        currency_column = _find_column(columns, _CSV_ALIASES["currency"])
        rows = list(reader)

        resolution = resolve_date_format([r.get(date_column) or "" for r in rows])
        if not resolution.resolved:
            raise ParseError(
                ErrorCode.SCHEMA_VALIDATION_FAILED,
                f"{self.file_name}: {resolution.reason}",
            )

        from ..io.dates import parse_with_format

        provenance = PriceProvenance(
            source_id=self.source_id, reference=self.file_name
        )
        records: list[PriceRecord] = []
        for index, row in enumerate(rows, start=2):
            raw_date = (row.get(date_column) or "").strip()
            symbol = (row.get(symbol_column) or "").strip()
            if not raw_date or not symbol:
                continue
            assert resolution.format is not None
            price_date = parse_with_format(raw_date, resolution.format)
            if price_date is None:
                raise ParseError(
                    ErrorCode.SCHEMA_VALIDATION_FAILED,
                    f"{self.file_name} row {index}: {raw_date!r} does not match the "
                    f"date layout detected for this file ({resolution.label})",
                )

            currency = (
                (row.get(currency_column) or "").strip()
                if currency_column
                else (self.default_currency or "")
            )
            if not currency:
                raise ParseError(
                    ErrorCode.SCHEMA_VALIDATION_FAILED,
                    f"{self.file_name} row {index}: no currency column and no default "
                    f"currency was declared. The platform will not assume one, because "
                    f"the wrong currency misstates the value by the exchange rate.",
                )

            for column, price_type in price_columns:
                raw_value = (row.get(column) or "").strip()
                if not raw_value:
                    continue
                try:
                    value = to_decimal(
                        normalize_numeric_text(raw_value), field=column
                    )
                except MoneyError as exc:
                    raise ParseError(
                        ErrorCode.SCHEMA_VALIDATION_FAILED,
                        f"{self.file_name} row {index}: {exc}",
                    ) from exc
                records.append(
                    PriceRecord(
                        symbol=symbol,
                        price_date=price_date,
                        price_type=price_type,
                        price=value,
                        currency=currency,
                        adjustment_basis=self.adjustment_basis,
                        provenance=provenance,
                        synthetic=self.synthetic,
                    )
                )
        return records

    def fetch(
        self, symbols: Sequence[str], start: date, end: date
    ) -> list[PriceRecord]:
        wanted = {s.strip().upper() for s in symbols}
        return [
            r
            for r in self._records
            if r.symbol in wanted and start <= r.price_date <= end
        ]

    def all_records(self) -> list[PriceRecord]:
        return list(self._records)


@dataclass(slots=True)
class PriceResolutionReport:
    """Every lookup a valuation made, for the workpaper."""

    resolutions: list[PriceResolution] = field(default_factory=list)

    def add(self, resolution: PriceResolution) -> PriceResolution:
        self.resolutions.append(resolution)
        return resolution

    @property
    def missing(self) -> list[PriceResolution]:
        return [r for r in self.resolutions if not r.usable]

    @property
    def carried_forward(self) -> list[PriceResolution]:
        return [r for r in self.resolutions if r.status is PriceStatus.CARRIED_FORWARD]

    def summary(self) -> str:
        return (
            f"price lookups: {len(self.resolutions)}   "
            f"exact: {sum(1 for r in self.resolutions if r.status is PriceStatus.EXACT)}   "
            f"carried forward: {len(self.carried_forward)}   "
            f"unusable: {len(self.missing)}"
        )


class PriceResolver:
    """Answers "what was this worth on this date", or says why it cannot."""

    def __init__(
        self,
        snapshot: MarketDataSnapshot,
        *,
        policy: PricePolicy | None = None,
        expected_currency: str | None = None,
    ) -> None:
        self.snapshot = snapshot
        self.policy = policy or PricePolicy()
        self.expected_currency = (
            expected_currency.strip().upper() if expected_currency else None
        )

    # --- basis compatibility ---------------------------------------------

    def check_basis(self, issues: IssueCollector) -> bool:
        """Verify the snapshot's basis matches the quantities being valued.

        This is the check that prevents the quietest wrong answer in the whole
        platform: a split-adjusted price multiplied by a pre-split share
        count. Both numbers look reasonable and the product is wrong by the
        split ratio.
        """
        basis = self.snapshot.adjustment_basis

        if self.snapshot.mixed_adjustment_bases:
            issues.report(
                ErrorCode.PRICE_ADJUSTMENT_BASIS_MISMATCH,
                scope=IssueScope.MARKET_PRICE,
                subject=self.snapshot.version_id,
                message=(
                    "this market-data snapshot contains price records on different "
                    "adjustment bases. Values computed from it would be inconsistent "
                    "between securities."
                ),
            )
            return False

        if not basis.is_stated:
            if self.policy.require_stated_basis:
                issues.report(
                    ErrorCode.PRICE_ADJUSTMENT_BASIS_UNKNOWN,
                    scope=IssueScope.MARKET_PRICE,
                    subject=self.snapshot.version_id,
                    message=(
                        f"the snapshot {self.snapshot.dataset_name!r} does not state "
                        f"whether its prices are adjusted for splits, so it cannot be "
                        f"paired safely with share quantities."
                    ),
                )
                return False
            return True

        if not basis.is_valuation_safe:
            issues.report(
                ErrorCode.PRICE_ADJUSTMENT_BASIS_MISMATCH,
                scope=IssueScope.MARKET_PRICE,
                subject=self.snapshot.version_id,
                message=(
                    f"the snapshot is on a {basis} basis, which folds reinvested "
                    f"dividends into the price. Schedule FA asks what the shares were "
                    f"worth, not what the investment would have returned."
                ),
            )
            return False

        if basis.needs_adjusted_quantities != self.policy.quantities_are_adjusted:
            expected = (
                "split-adjusted share counts"
                if basis.needs_adjusted_quantities
                else "the share counts actually held on each date"
            )
            have = (
                "split-adjusted share counts"
                if self.policy.quantities_are_adjusted
                else "the share counts actually held on each date"
            )
            issues.report(
                ErrorCode.PRICE_ADJUSTMENT_BASIS_MISMATCH,
                scope=IssueScope.MARKET_PRICE,
                subject=self.snapshot.version_id,
                message=(
                    f"the snapshot is on a {basis} basis, which requires {expected}, "
                    f"but the valuation is using {have}. Multiplying across the "
                    f"mismatch misstates every holding that had a split, by the split "
                    f"ratio, with no sign of it in the result."
                ),
            )
            return False

        return True

    # --- single lookup ----------------------------------------------------

    def resolve(
        self,
        symbol: str,
        day: date,
        *,
        issues: IssueCollector | None = None,
        currency: str | None = None,
    ) -> PriceResolution:
        """Find the price for a symbol on a date under the configured policy."""
        normalized = symbol.strip().upper()
        price_type = self.policy.price_type
        want_currency = (currency or self.expected_currency or "").strip().upper()

        exact = self.snapshot.price(normalized, day, price_type)
        if exact is not None:
            return self._finish(exact, normalized, day, 0, PriceStatus.EXACT,
                                want_currency, issues)

        if not self.snapshot.prices_for(normalized):
            resolution = PriceResolution(
                symbol=normalized,
                requested_date=day,
                status=PriceStatus.SYMBOL_NOT_COVERED,
                explanation=(
                    f"the market-data snapshot {self.snapshot.dataset_name!r} contains "
                    f"no prices at all for {normalized}."
                ),
            )
            self._report_missing(resolution, issues)
            return resolution

        if self.policy.missing_policy is MissingPricePolicy.STRICT:
            resolution = PriceResolution(
                symbol=normalized,
                requested_date=day,
                status=PriceStatus.MISSING,
                explanation=(
                    f"no {price_type} price was published for {normalized} on "
                    f"{day.isoformat()}, and the configured policy does not allow "
                    f"carrying an earlier price forward."
                ),
            )
            self._report_missing(resolution, issues)
            return resolution

        earlier = self.snapshot.latest_on_or_before(normalized, day, price_type)
        if earlier is None:
            resolution = PriceResolution(
                symbol=normalized,
                requested_date=day,
                status=PriceStatus.MISSING,
                explanation=(
                    f"{normalized} has prices in the snapshot, but none on or before "
                    f"{day.isoformat()}. The snapshot starts after this valuation date."
                ),
            )
            self._report_missing(resolution, issues)
            return resolution

        gap = (day - earlier.price_date).days
        if gap > self.policy.max_carry_forward_days:
            traded = self.snapshot.trading_days_between(earlier.price_date, day)
            missed = [d for d in traded if d > earlier.price_date]
            resolution = PriceResolution(
                symbol=normalized,
                requested_date=day,
                status=PriceStatus.MISSING,
                explanation=(
                    f"the most recent {normalized} price is from "
                    f"{earlier.price_date.isoformat()}, {gap} days before "
                    f"{day.isoformat()}, which exceeds the {self.policy.max_carry_forward_days}"
                    f"-day carry-forward limit."
                    + (
                        f" The market was open on {len(missed)} day(s) in that gap, so "
                        f"the data is incomplete rather than the market being closed."
                        if missed
                        else " No other security traded in that gap either, so the "
                        "market may have been closed throughout."
                    )
                ),
            )
            self._report_missing(resolution, issues)
            return resolution

        return self._finish(
            earlier, normalized, day, gap, PriceStatus.CARRIED_FORWARD,
            want_currency, issues
        )

    def _finish(
        self,
        record: PriceRecord,
        symbol: str,
        day: date,
        gap: int,
        status: PriceStatus,
        want_currency: str,
        issues: IssueCollector | None,
    ) -> PriceResolution:
        if want_currency and record.currency != want_currency:
            resolution = PriceResolution(
                symbol=symbol,
                requested_date=day,
                status=PriceStatus.UNUSABLE,
                record=record,
                currency=record.currency,
                explanation=(
                    f"the price for {symbol} on {record.price_date.isoformat()} is "
                    f"quoted in {record.currency}, but the holding is in "
                    f"{want_currency}. Using it as though the currencies matched would "
                    f"misstate the value by the whole exchange rate."
                ),
            )
            if issues is not None:
                issues.report(
                    ErrorCode.MARKET_PRICE_CURRENCY_MISMATCH,
                    scope=IssueScope.MARKET_PRICE,
                    subject=symbol,
                    message=resolution.explanation,
                    price_currency=record.currency,
                    expected_currency=want_currency,
                )
            return resolution

        resolution = PriceResolution(
            symbol=symbol,
            requested_date=day,
            status=status,
            price=record.price,
            currency=record.currency,
            price_date=record.price_date,
            price_type=record.price_type,
            adjustment_basis=record.adjustment_basis,
            staleness_days=gap,
            record=record,
            explanation=(
                f"{record.price_type} price published on "
                f"{record.price_date.isoformat()}"
                if status is PriceStatus.EXACT
                else (
                    f"no price was published on {day.isoformat()}; the last traded "
                    f"{record.price_type} price, from "
                    f"{record.price_date.isoformat()} ({gap} day(s) earlier), was used"
                )
            ),
        )

        if status is PriceStatus.CARRIED_FORWARD and issues is not None:
            traded = [
                d
                for d in self.snapshot.trading_days_between(record.price_date, day)
                if d > record.price_date
            ]
            issues.report(
                ErrorCode.MARKET_PRICE_STALE,
                scope=IssueScope.MARKET_PRICE,
                subject=symbol,
                message=(
                    f"{resolution.explanation}."
                    + (
                        f" The snapshot shows {len(traded)} trading day(s) in that gap, "
                        f"so a price may be missing rather than unpublished."
                        if traded
                        else " No security in the snapshot traded in that gap, which is "
                        "consistent with a weekend or exchange holiday."
                    )
                ),
                staleness_days=gap,
            )
        return resolution

    def _report_missing(
        self, resolution: PriceResolution, issues: IssueCollector | None
    ) -> None:
        if issues is None:
            return
        issues.report(
            ErrorCode.MARKET_PRICE_MISSING,
            scope=IssueScope.MARKET_PRICE,
            subject=resolution.symbol,
            message=resolution.explanation,
            valuation_date=resolution.requested_date.isoformat(),
        )

    # --- bulk -------------------------------------------------------------

    def resolve_series(
        self,
        symbol: str,
        days: Sequence[date],
        *,
        issues: IssueCollector | None = None,
        currency: str | None = None,
    ) -> PriceResolutionReport:
        """Resolve a symbol across many dates, as a peak calculation needs."""
        report = PriceResolutionReport()
        for day in days:
            report.add(self.resolve(symbol, day, issues=issues, currency=currency))
        return report
