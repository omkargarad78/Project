"""Startup provisioning.

Runs once when the application starts, on a background thread. The thread
matters: installing rates means a network round trip, and a server that
refuses connections for thirty seconds because a GitHub mirror is slow looks
broken. The app serves immediately and the dataset appears when it arrives.

The report is kept in memory so the health endpoint can say what happened.
There is no "provisioning failed" state that stops the application — a
missing dataset is already something the engine, the API and the frontend all
describe properly.
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from datetime import UTC, datetime

from ..core.config import Settings, get_settings
from .fx import ensure_fx_dataset

logger = logging.getLogger(__name__)

_lock = threading.Lock()
_last: BootstrapReport | None = None


@dataclass(frozen=True, slots=True)
class DatasetOutcome:
    name: str
    ok: bool
    detail: str


@dataclass(frozen=True, slots=True)
class BootstrapReport:
    started_at: datetime
    finished_at: datetime | None = None
    outcomes: tuple[DatasetOutcome, ...] = field(default_factory=tuple)

    @property
    def running(self) -> bool:
        return self.finished_at is None

    @property
    def ok(self) -> bool:
        return all(outcome.ok for outcome in self.outcomes)

    def summary(self) -> str:
        if self.running:
            return "installing reference data"
        return "; ".join(f"{o.name}: {o.detail}" for o in self.outcomes) or "nothing to do"


def last_report() -> BootstrapReport | None:
    with _lock:
        return _last


def _publish(report: BootstrapReport) -> None:
    global _last  # noqa: PLW0603 - one process-wide status, guarded by the lock
    with _lock:
        _last = report


def bootstrap(settings: Settings | None = None) -> BootstrapReport:
    """Install everything the engine needs. Safe to call more than once."""
    settings = settings or get_settings()
    started = datetime.now(UTC)
    _publish(BootstrapReport(started_at=started))

    outcomes: list[DatasetOutcome] = []

    if not settings.auto_bootstrap_datasets:
        outcomes.append(
            DatasetOutcome(
                "exchange rates",
                True,
                "automatic installation is turned off; import with ingest-fx",
            )
        )
    else:
        try:
            installed = ensure_fx_dataset(settings)
            outcomes.append(
                DatasetOutcome(
                    "exchange rates",
                    True,
                    f"{installed.dataset_name}@{installed.version}, "
                    f"{installed.record_count} rates covering "
                    f"{installed.first_date} to {installed.last_date}"
                    + (" (already current)" if installed.already_current else ""),
                )
            )
        except Exception as exc:  # noqa: BLE001 - reported, never fatal
            logger.error("could not install an exchange-rate dataset: %s", exc)
            outcomes.append(DatasetOutcome("exchange rates", False, str(exc)))

    # Prices are deliberately not installed here. Which symbols to fetch is
    # only knowable from an uploaded statement, and fetching a whole market
    # on the chance it is needed would be slow and mostly wasted.
    outcomes.append(
        DatasetOutcome(
            "prices",
            True,
            "fetched per statement when one is uploaded"
            if settings.auto_fetch_prices
            else "automatic fetching is turned off",
        )
    )

    report = BootstrapReport(
        started_at=started,
        finished_at=datetime.now(UTC),
        outcomes=tuple(outcomes),
    )
    _publish(report)
    logger.info("startup provisioning: %s", report.summary())
    return report


def start_background_bootstrap(settings: Settings | None = None) -> threading.Thread:
    """Run :func:`bootstrap` without holding up the server."""
    settings = settings or get_settings()
    thread = threading.Thread(
        target=bootstrap,
        args=(settings,),
        name="dataset-bootstrap",
        # Daemon so that Ctrl+C during a slow download still exits.
        daemon=True,
    )
    thread.start()
    return thread
