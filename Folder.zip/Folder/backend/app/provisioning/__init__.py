"""Automatic installation of the reference data the engine needs.

The engine cannot calculate without an exchange-rate dataset and cannot value
a holding without prices. Making the user import both by hand before the first
calculation is a real barrier, so this package fetches them.

It is deliberately a separate layer from the calculation, and the boundary
matters more than it looks:

    fetch  ->  normalise  ->  snapshot to disk  ->  pin on the run  ->  calculate

The calculation reads only the snapshot. It has no access to this package and
no way to reach the network. That is what keeps a figure reproducible: a run
records the dataset name and version it used, those files are immutable once
written, and re-running a calculation from 2025 in 2028 reads the same bytes
even though the upstream repository has moved on.

The other rule this package keeps is that it never invents data. A download
that fails leaves the previously installed dataset alone and is reported. A
symbol with no price history produces no records, and the figures that needed
it come out as UNAVAILABLE, which is the honest answer.
"""

from .bootstrap import (
    BootstrapReport,
    DatasetOutcome,
    bootstrap,
    last_report,
    start_background_bootstrap,
)
from .fx import ensure_fx_dataset
from .prices import ensure_price_dataset

__all__ = [
    "BootstrapReport",
    "DatasetOutcome",
    "bootstrap",
    "ensure_fx_dataset",
    "ensure_price_dataset",
    "last_report",
    "start_background_bootstrap",
]
