"""Declared remote datasets, and the adapters that normalise them.

Each source is a fixed URL with a known shape. The adapter's job is to turn
that shape into one canonical CSV, which is then imported through the ordinary
ingestion path with an **explicit** column mapping.

Why normalise first instead of pointing the generic detector at the download:
the detector is allowed to say "I am not sure" and refuse, which is correct
for a file a human hands it, but useless at three in the morning inside a
startup hook. Here the shape is known in advance, so the adapter either
recognises it exactly or rejects the source and the next candidate is tried.

The one thing an adapter must never do is guess which column holds the TT
buying rate. Importing a TT *selling* column in its place would move every
rupee figure in the return by roughly the bank's spread, and nothing
downstream would look wrong. So the match is exact against a short list of
known spellings, and a source whose header changes fails loudly rather than
resolving to a neighbouring column.
"""

from __future__ import annotations

import csv
import io
import json
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from datetime import UTC, date, datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal

from ..tax.rules.models import SourceTier

#: The canonical shape every FX adapter produces.
FX_CANONICAL_HEADER = ("date", "currency", "tt_buy")

#: The canonical shape every price adapter produces.
PRICE_CANONICAL_HEADER = ("date", "symbol", "open", "high", "low", "close", "currency")


class AdapterError(Exception):
    """The download did not have the shape this adapter knows how to read."""


@dataclass(frozen=True, slots=True)
class RemoteFxSource:
    """One candidate source of historical SBI rates."""

    source_id: str
    source_name: str
    #: Dataset name the rates are stored under. Shared by every candidate, so
    #: that switching sources produces a new *version* of one dataset rather
    #: than a second dataset the user has to choose between.
    dataset_name: str
    url: str
    currency: str
    tier: SourceTier
    adapter: Callable[[bytes], bytes]
    notes: str


def _normalise_header(text: str) -> str:
    return "".join(ch for ch in text.lower() if ch.isalnum())


#: Exact spellings accepted for the TT buying column. Containment matching is
#: deliberately not used: "TT BUY" is a substring of nothing dangerous, but
#: "BUY" would match "BILL BUY", which is a different rate.
_TT_BUY_HEADERS = frozenset(
    {"ttbuy", "ttbuying", "ttbuyrate", "ttbuyingrate", "ttbr", "buyttrate"}
)

_DATE_HEADERS = frozenset({"date", "ratedate", "asondate", "effectivedate", "day"})

_CURRENCY_HEADERS = frozenset({"currency", "currencycode", "ccy"})


def _find(columns: Sequence[str], accepted: frozenset[str]) -> str | None:
    for column in columns:
        if _normalise_header(column) in accepted:
            return column
    return None


#: Layouts a rate file's date column is allowed to use. A value that matches
#: none of these is dropped rather than coerced.
_DATE_LAYOUTS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%d-%b-%Y", "%d %b %Y")


def _read_date(raw: str) -> date | None:
    text = raw.strip()
    if not text:
        return None
    # These feeds commonly stamp a publication time onto the date, because
    # SBI issues several rate cards a day. The date is the part that selects
    # the rate; the time only orders cards within a day and is handled by the
    # resolver, not here.
    head = text.split("T")[0].split(" ")[0]
    for layout in _DATE_LAYOUTS:
        try:
            return datetime.strptime(head, layout).date()
        except ValueError:
            continue
    return None


def sbi_rate_csv_adapter(currency: str) -> Callable[[bytes], bytes]:
    """Read a delimited SBI rate archive into the canonical three columns.

    Handles both shapes these community archives come in: one file per
    currency with no currency column, and one file covering several
    currencies with one.
    """

    def adapt(content: bytes) -> bytes:
        try:
            text = content.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise AdapterError(f"not UTF-8 text: {exc}") from exc

        reader = csv.DictReader(io.StringIO(text))
        columns = list(reader.fieldnames or ())
        if not columns:
            raise AdapterError("no header row")

        date_column = _find(columns, _DATE_HEADERS)
        if date_column is None:
            raise AdapterError(f"no date column among {', '.join(columns)}")

        rate_column = _find(columns, _TT_BUY_HEADERS)
        if rate_column is None:
            raise AdapterError(
                f"no telegraphic-transfer BUYING column among {', '.join(columns)}. "
                f"The rate type is never inferred from a neighbouring column."
            )

        currency_column = _find(columns, _CURRENCY_HEADERS)

        out = io.StringIO(newline="")
        writer = csv.writer(out, lineterminator="\n")
        writer.writerow(FX_CANONICAL_HEADER)

        written = 0
        for row in reader:
            rate_date = _read_date(row.get(date_column) or "")
            if rate_date is None:
                continue
            code = (
                (row.get(currency_column) or "").strip().upper()
                if currency_column
                else currency
            )
            if code != currency:
                continue
            value = (row.get(rate_column) or "").strip()
            if not value:
                continue
            writer.writerow([rate_date.isoformat(), code, value])
            written += 1

        if not written:
            raise AdapterError(
                f"no usable {currency} rows: the file parsed but held no rate for "
                f"that currency"
            )
        return out.getvalue().encode("utf-8")

    return adapt


#: Tried in order until one yields a usable dataset.
#:
#: Both are community archives, and that is a real limitation rather than an
#: implementation detail: SBI publishes no programmatic historical archive, so
#: a machine-readable history has to come from someone republishing it. Every
#: rate from them is imported at tier 4 and raises SECONDARY_SOURCE_USED,
#: which travels with the figure into the workbook. Where a filing matters,
#: the corresponding SBI rate sheet should be attached as primary evidence.
FX_SOURCES: tuple[RemoteFxSource, ...] = (
    RemoteFxSource(
        source_id="SBI-TT-RATES-HISTORICAL-GITHUB",
        source_name="sbi-fx-ratekeeper (community archive of SBI rate sheets)",
        dataset_name="sbi-ttbr",
        url=(
            "https://raw.githubusercontent.com/sahilgupta/sbi-fx-ratekeeper/"
            "main/csv_files/SBI_REFERENCE_RATES_USD.csv"
        ),
        currency="USD",
        tier=SourceTier.COMMUNITY_DATASET,
        adapter=sbi_rate_csv_adapter("USD"),
        notes=(
            "Community archive of SBI daily reference rate sheets. Tier 4: "
            "machine-readable history, not statutory authority."
        ),
    ),
    RemoteFxSource(
        source_id="SBI-TT-RATES-HISTORICAL-GITHUB",
        source_name="sbi_forex_rates (same archive, earlier repository name)",
        dataset_name="sbi-ttbr",
        url=(
            "https://raw.githubusercontent.com/sahilgupta/sbi_forex_rates/"
            "main/csv_files/SBI_REFERENCE_RATES_USD.csv"
        ),
        currency="USD",
        tier=SourceTier.COMMUNITY_DATASET,
        adapter=sbi_rate_csv_adapter("USD"),
        notes=(
            "Fallback community archive, used when the primary one cannot be "
            "reached or has changed shape. Tier 4."
        ),
    ),
)


# --- prices ---------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class PriceSeries:
    """One symbol's daily prices, and what is true about them."""

    symbol: str
    #: Canonical CSV rows, without a header.
    rows: bytes
    row_count: int
    currency: str
    #: Split ratios the provider reported inside the requested window. Empty
    #: means the series is identical to an unadjusted one over this period.
    splits_in_window: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class RemotePriceSource:
    """Where daily prices come from."""

    source_id: str
    source_name: str
    tier: SourceTier
    url_for: Callable[[str, date, date], str]
    #: Extra request headers. Some providers answer a non-browser
    #: user-agent with a 403.
    headers: dict[str, str]
    parse: Callable[[bytes, str, date, date], PriceSeries]


def _yahoo_url(symbol: str, start: date, end: date) -> str:
    # Unix seconds, and the end is exclusive of the following midnight, so a
    # day is added to keep the last day in range.
    period1 = _epoch(start)
    period2 = _epoch(end + timedelta(days=1))
    return (
        f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol.upper()}"
        f"?period1={period1}&period2={period2}&interval=1d&events=split"
    )


def _epoch(value: date) -> int:
    return int(datetime(value.year, value.month, value.day, tzinfo=UTC).timestamp())


#: Prices are rounded to this many decimals. See ``_decimal`` for why.
_PRICE_EXPONENT = Decimal("0.0001")


def _decimal(value: object) -> str | None:
    """Turn one JSON number into an exact decimal string.

    The payload is parsed with ``parse_float=Decimal``, so what arrives here
    is the precise value the provider transmitted — and that value carries a
    float artifact, because the provider serialises a 32-bit float into a
    64-bit JSON number. A close of 109.665 is transmitted as
    109.66500091552734.

    Quantising to four decimals recovers the quoted price exactly for any
    instrument priced in cents, and keeps sub-cent precision for anything
    that is not. This is undoing a serialisation artifact, not rounding a
    figure: carrying fourteen junk digits into a workpaper would make every
    price look falsely precise and would not match the exchange's own
    quotation.
    """
    if value is None:
        return None
    try:
        number = value if isinstance(value, Decimal) else Decimal(str(value))
    except (ArithmeticError, ValueError):
        return None
    if number <= 0:
        return None
    return str(number.quantize(_PRICE_EXPONENT, rounding=ROUND_HALF_UP).normalize())


def _yahoo_parse(content: bytes, symbol: str, start: date, end: date) -> PriceSeries:
    """Read Yahoo's chart response for one symbol."""
    try:
        payload = json.loads(content.decode("utf-8"), parse_float=Decimal)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise AdapterError(f"response was not JSON: {exc}") from exc

    chart = payload.get("chart") or {}
    if chart.get("error"):
        raise AdapterError(str(chart["error"]))
    results = chart.get("result") or []
    if not results:
        return PriceSeries(symbol, b"", 0, "USD", ())

    result = results[0]
    stamps = result.get("timestamp") or []
    quote = ((result.get("indicators") or {}).get("quote") or [{}])[0]
    currency = str((result.get("meta") or {}).get("currency") or "USD").upper()

    closes = quote.get("close") or []
    opens = quote.get("open") or []
    highs = quote.get("high") or []
    lows = quote.get("low") or []

    out = io.StringIO(newline="")
    writer = csv.writer(out, lineterminator="\n")
    written = 0
    for index, stamp in enumerate(stamps):
        close = _decimal(closes[index] if index < len(closes) else None)
        if close is None:
            # A null close is a day the provider has no print for. Skipped,
            # not filled: the resolver decides whether to carry a price
            # forward, and it records that it did.
            continue
        day = datetime.fromtimestamp(int(stamp), tz=UTC).date()
        writer.writerow(
            [
                day.isoformat(),
                symbol.upper(),
                _decimal(opens[index] if index < len(opens) else None) or "",
                _decimal(highs[index] if index < len(highs) else None) or "",
                _decimal(lows[index] if index < len(lows) else None) or "",
                close,
                currency,
            ]
        )
        written += 1

    splits = ((result.get("events") or {}).get("splits") or {}).values()
    in_window = tuple(
        f"{str(event.get('splitRatio') or '?')} on "
        f"{datetime.fromtimestamp(int(event['date']), tz=UTC).date().isoformat()}"
        for event in splits
        if event.get("date") is not None
        and start <= datetime.fromtimestamp(int(event["date"]), tz=UTC).date() <= end
    )

    return PriceSeries(
        symbol=symbol.upper(),
        rows=out.getvalue().encode("utf-8"),
        row_count=written,
        currency=currency,
        splits_in_window=in_window,
    )


PRICE_SOURCE = RemotePriceSource(
    source_id="YAHOO-CHART-DAILY",
    source_name="Yahoo Finance daily chart",
    # An established data aggregator, not the listing exchange. Tier 3, and
    # the tier travels with every figure it produces.
    tier=SourceTier.DATA_PROVIDER,
    url_for=_yahoo_url,
    headers={"Accept": "application/json"},
    parse=_yahoo_parse,
)
