"""Fetch and snapshot the daily prices a statement needs.

Driven by the statement rather than by a universe list: peak and closing
values need a price series only for the symbols actually held, over the
period actually held, so that is exactly what is requested.

The snapshot is the point of this module. Prices are written to a CSV named
after the hash of its own contents before the calculation reads it, and the
run records that name. Stooq restating a historical close next year cannot
move a figure that has already been filed, because the filed figure was
computed from a file that still exists and still says what it said.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import UTC, date, datetime, timedelta
from pathlib import Path

from ..core.config import Settings, get_settings
from ..core.hashing import hash_bytes
from ..fx.remote import fetch_document
from .sources import PRICE_CANONICAL_HEADER, PRICE_SOURCE, AdapterError

logger = logging.getLogger(__name__)

MARKET_DIRNAME = "market"

#: Fetched either side of the holding period. The peak search needs a price
#: on the first day held, and the resolver may carry one forward across a
#: weekend or a holiday, so the window has to open before the period does.
_PADDING_DAYS = 10


def _digest(content: bytes, length: int = 16) -> str:
    """A short, file-name-safe content hash.

    ``hash_bytes`` returns ``sha256:<hex>``. The prefix is right for a value
    stored in a record, where the algorithm has to travel with the digest,
    and wrong for a file name, because Windows does not allow a colon.
    """
    return hash_bytes(content).split(":")[-1][:length]


@dataclass(frozen=True, slots=True)
class PriceInstallation:
    """The snapshot a run should be pinned to."""

    #: Dataset name to pass as ``market_dataset``. None when nothing usable
    #: could be fetched, in which case the run proceeds and every figure that
    #: needed a price is reported UNAVAILABLE.
    dataset_name: str | None
    path: Path | None
    symbols_requested: tuple[str, ...]
    symbols_covered: tuple[str, ...]
    row_count: int
    reused: bool
    #: Symbols with no usable history, and why. Surfaced rather than logged:
    #: an unpriced holding changes what the return can say.
    problems: tuple[tuple[str, str], ...] = ()

    @property
    def symbols_missing(self) -> tuple[str, ...]:
        covered = set(self.symbols_covered)
        return tuple(s for s in self.symbols_requested if s not in covered)


def ensure_price_dataset(
    symbols: list[str],
    start: date,
    end: date,
    settings: Settings | None = None,
) -> PriceInstallation:
    """Fetch prices for these symbols and snapshot them. Never raises.

    A failure to price something is a normal, reportable outcome here, not an
    error: the engine is built to say NOT AVAILABLE and explain why. Throwing
    would turn one unlisted ticker into a failed run for the whole account.
    """
    settings = settings or get_settings()
    wanted = sorted({s.strip().upper() for s in symbols if s and s.strip()})
    if not wanted:
        return PriceInstallation(None, None, (), (), 0, False)

    window_start = start - timedelta(days=_PADDING_DAYS)
    window_end = end + timedelta(days=_PADDING_DAYS)

    if not settings.auto_fetch_prices:
        return PriceInstallation(
            None,
            None,
            tuple(wanted),
            (),
            0,
            False,
            (("*", "automatic price fetching is turned off"),),
        )

    sections: list[bytes] = []
    covered: list[str] = []
    problems: list[tuple[str, str]] = []

    for symbol in wanted:
        url = PRICE_SOURCE.url_for(symbol, window_start, window_end)
        try:
            document = fetch_document(
                url, settings=settings, headers=PRICE_SOURCE.headers
            )
            series = PRICE_SOURCE.parse(
                document.content, symbol, window_start, window_end
            )
        except AdapterError as exc:
            problems.append((symbol, f"unexpected response shape: {exc}"))
            continue
        except Exception as exc:  # noqa: BLE001 - one symbol must not stop the rest
            problems.append((symbol, _explain(exc)))
            logger.warning("no prices for %s: %s", symbol, exc)
            continue

        if not series.row_count:
            problems.append(
                (symbol, "the provider returned no price history for this symbol")
            )
            continue

        # The provider restates history for splits. Over a window with no
        # split that is indistinguishable from an unadjusted series, so it
        # can be used as one. Over a window containing a split it is not,
        # and pairing it with the unrestated share counts in the statement
        # would be wrong by the split ratio in both directions — the quiet
        # kind of wrong that looks plausible. So the symbol is left out and
        # the reason is reported.
        if series.splits_in_window:
            problems.append(
                (
                    symbol,
                    f"the price history is restated for a split "
                    f"({'; '.join(series.splits_in_window)}) inside the period held, "
                    f"so it cannot be paired with the share counts in the statement. "
                    f"Supply an unadjusted price file for this holding.",
                )
            )
            continue

        sections.append(series.rows)
        covered.append(symbol)

    if not sections:
        return PriceInstallation(
            None, None, tuple(wanted), (), 0, False, tuple(problems)
        )

    header = ",".join(PRICE_CANONICAL_HEADER).encode("utf-8") + b"\n"
    content = header + b"".join(sections)

    # Named after its contents, so the same request resolves to the same file
    # and re-running a calculation reuses the snapshot instead of refetching.
    # The algorithm prefix is dropped because its colon is not a legal
    # character in a Windows file name.
    name = f"auto-{_digest(content)}"
    root = Path(settings.data_root) / MARKET_DIRNAME
    root.mkdir(parents=True, exist_ok=True)
    path = root / f"{name}.csv"

    reused = path.exists()
    if not reused:
        # Written to a temporary name and moved into place, so a run that
        # starts while this is being written cannot read half a file.
        partial = path.with_suffix(".csv.partial")
        partial.write_bytes(content)
        partial.replace(path)
        logger.info(
            "snapshotted prices for %s into %s",
            ", ".join(covered),
            path.name,
        )
        _write_provenance(
            path.with_suffix(".meta.json"),
            symbols=covered,
            start=window_start,
            end=window_end,
            retrieved_at=datetime.now(UTC),
        )

    return PriceInstallation(
        dataset_name=name,
        path=path,
        symbols_requested=tuple(wanted),
        symbols_covered=tuple(covered),
        row_count=content.count(b"\n") - 1,
        reused=reused,
        problems=tuple(problems),
    )


def _explain(error: Exception) -> str:
    """Say what went wrong in the reader's terms.

    The retrieval layer is shared with rate ingestion and raises with that
    module's error code, so the raw text of a failed price lookup reads
    "FX_DATASET_MISSING", which is both alarming and wrong. The common
    cases are worth naming; anything else falls through as-is.
    """
    text = str(error)
    if "returned HTTP 404" in text:
        return (
            "the price provider does not recognise this symbol. It may be "
            "delisted, or listed on an exchange this provider does not cover."
        )
    if "CERTIFICATE_VERIFY_FAILED" in text or "SSLError" in text:
        return (
            "the secure connection to the price provider could not be verified. "
            "On a network that inspects TLS, set FA_CA_BUNDLE to your "
            "organisation's certificate bundle."
        )
    if "is not on the ingestion allow-list" in text or "disabled" in text:
        return text
    return f"the price provider could not be reached: {text}"


def _write_provenance(
    path: Path,
    *,
    symbols: list[str],
    start: date,
    end: date,
    retrieved_at: datetime,
) -> None:
    """Record where a snapshot came from, alongside the snapshot.

    The CSV on its own is an anonymous list of numbers. A year later the
    question asked of it is "who said this, and when", and the answer has to
    live next to the file rather than in a log that has rotated away.
    """
    path.write_text(
        json.dumps(
            {
                "source_id": PRICE_SOURCE.source_id,
                "source_name": PRICE_SOURCE.source_name,
                "source_tier": int(PRICE_SOURCE.tier),
                "adjustment_basis": "UNADJUSTED",
                "adjustment_note": (
                    "The provider restates history for splits. Only symbols with no "
                    "split inside the requested window are included, so over this "
                    "window the series is identical to an unadjusted one."
                ),
                "symbols": sorted(symbols),
                "requested_from": start.isoformat(),
                "requested_to": end.isoformat(),
                "retrieved_at": retrieved_at.isoformat(),
            },
            indent=2,
            sort_keys=True,
        ),
        encoding="utf-8",
    )
