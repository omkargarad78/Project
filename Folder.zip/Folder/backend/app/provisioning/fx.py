"""Install the exchange-rate dataset without anyone having to ask.

Tries each declared source until one produces a usable dataset, then freezes
it as an ordinary :class:`FxDatasetVersion` — the same object the manual
``ingest-fx`` command produces, stored in the same place and read by the
engine the same way. Automatic installation is a different way of *getting*
the file, not a different kind of file.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime

from ..core.config import Settings, get_settings
from ..core.hashing import hash_bytes
from ..fx.ingestion import ColumnMapping, SbiRateIngestor
from ..fx.models import FxDatasetVersion
from ..fx.remote import fetch_document
from ..fx.store import FxDatasetStore
from ..tax.rules.models import FxRateType
from .sources import FX_SOURCES, AdapterError, RemoteFxSource

logger = logging.getLogger(__name__)

FX_DIRNAME = "fx"

#: The canonical file the adapters emit is fixed, so the mapping is stated
#: outright. Nothing about this import is detected.
_CANONICAL_MAPPING = ColumnMapping(
    date_column="date",
    currency_column="currency",
    rate_columns={FxRateType.TT_BUY: "tt_buy"},
    date_format="%Y-%m-%d",
)


@dataclass(frozen=True, slots=True)
class FxInstallation:
    """What the installer did, for the health endpoint and the logs."""

    dataset_name: str
    version: str
    source_id: str
    source_url: str
    record_count: int
    first_date: str | None
    last_date: str | None
    #: True when this content was already installed and nothing was written.
    already_current: bool


def _version_for(content: bytes, last_date: str | None) -> str:
    """Name a version after what is in it, not after when it arrived.

    A timestamp would make every refresh a new version even when the upstream
    file had not changed, and each one would look to a reader like a distinct
    set of rates. Deriving the name from the content hash means an unchanged
    download resolves to the version already on disk and writes nothing,
    while any change at all produces a new one.

    The leading date is there only so the directory sorts readably. The
    digest drops its ``sha256:`` prefix, because the version becomes part of
    a file name and a colon is not legal in one on Windows.
    """
    digest = hash_bytes(content).split(":")[-1][:12]
    return f"{(last_date or 'undated').replace('-', '')}-{digest}"


def ensure_fx_dataset(
    settings: Settings | None = None,
    *,
    force: bool = False,
) -> FxInstallation:
    """Install or refresh the rate dataset. Returns what is now on disk.

    Raises only when nothing usable could be installed *and* nothing was
    installed before. If a refresh fails but an older version is present, the
    older one is returned: stale rates that are labelled are far better than
    no rates, and the coverage check will report any date the run needs and
    the dataset lacks.
    """
    settings = settings or get_settings()
    store = FxDatasetStore(settings.data_root / FX_DIRNAME)
    existing = _most_recent(store)

    if existing is not None and not force and not _is_stale(existing, settings):
        return _describe(existing, source_url="", already_current=True)

    failures: list[str] = []
    for source in FX_SOURCES:
        try:
            return _install(source, store, settings)
        except Exception as exc:  # noqa: BLE001 - every source is allowed to fail
            failures.append(f"{source.url}: {exc}")
            logger.warning("rate source %s unusable: %s", source.url, exc)

    if existing is not None:
        logger.warning(
            "keeping the installed rate dataset %s; no source could be refreshed",
            existing.version_label,
        )
        return _describe(existing, source_url="", already_current=True)

    raise RuntimeError(
        "no exchange-rate dataset could be installed. Tried:\n  "
        + "\n  ".join(failures)
        + "\nImport one by hand with the ingest-fx command, or start the "
        "application with network access."
    )


def _install(
    source: RemoteFxSource, store: FxDatasetStore, settings: Settings
) -> FxInstallation:
    document = fetch_document(source.url, settings=settings)
    try:
        canonical = source.adapter(document.content)
    except AdapterError as exc:
        raise RuntimeError(f"the download did not have the expected shape: {exc}") from exc

    ingestor = SbiRateIngestor(
        source_id=source.source_id,
        source_name=source.source_name,
        source_tier=source.tier,
        dataset_name=source.dataset_name,
        source_document_url=source.url,
        source_document_reference=(
            f"{source.source_name}, retrieved {document.retrieved_at.date().isoformat()}, "
            f"upstream content hash {document.content_hash[:16]}"
        ),
    )
    report = ingestor.ingest_csv(
        canonical,
        file_name=f"{source.dataset_name}.csv",
        version="pending",
        mapping=_CANONICAL_MAPPING,
        currencies=[source.currency],
        imported_at=datetime.now(UTC),
        notes=source.notes,
    )
    if report.dataset is None:
        raise RuntimeError("the source parsed but yielded no usable rate records")

    dates = sorted(r.rate_date for r in report.dataset.records)
    version = _version_for(canonical, dates[-1].isoformat() if dates else None)

    # Rebuilt under its real name now that the content is known. The version
    # is part of the dataset's identity and of its content hash, so it cannot
    # be assigned after the fact.
    dataset = FxDatasetVersion.build(
        dataset_name=report.dataset.dataset_name,
        version=version,
        source_id=report.dataset.source_id,
        source_tier=report.dataset.source_tier,
        imported_at=report.dataset.imported_at,
        records=report.dataset.records,
        source_file_hashes=[document.content_hash],
        notes=report.dataset.notes,
    )

    already = any(
        stored.dataset.dataset_name == dataset.dataset_name
        and stored.dataset.version == dataset.version
        for stored in store.list()
    )
    # Idempotent by design: identical content resolves to the same version
    # name, and saving a version that already holds those bytes is a no-op.
    store.save(dataset)
    if not already:
        logger.info(
            "installed rate dataset %s: %d records, %s to %s, from %s",
            dataset.version_label,
            len(dataset.records),
            dates[0].isoformat() if dates else "?",
            dates[-1].isoformat() if dates else "?",
            source.url,
        )
    return _describe(dataset, source_url=source.url, already_current=already)


def _most_recent(store: FxDatasetStore) -> FxDatasetVersion | None:
    stored = store.list()
    if not stored:
        return None
    return max(stored, key=lambda s: s.dataset.imported_at).dataset


def _is_stale(dataset: FxDatasetVersion, settings: Settings) -> bool:
    imported = dataset.imported_at
    if imported.tzinfo is None:
        imported = imported.replace(tzinfo=UTC)
    age_hours = (datetime.now(UTC) - imported).total_seconds() / 3600
    return age_hours >= settings.fx_refresh_after_hours


def _describe(
    dataset: FxDatasetVersion, *, source_url: str, already_current: bool
) -> FxInstallation:
    dates = sorted(r.rate_date for r in dataset.records)
    return FxInstallation(
        dataset_name=dataset.dataset_name,
        version=dataset.version,
        source_id=dataset.source_id,
        source_url=source_url,
        record_count=len(dataset.records),
        first_date=dates[0].isoformat() if dates else None,
        last_date=dates[-1].isoformat() if dates else None,
        already_current=already_current,
    )
