"""Storage and lookup for the security master.

The master is a small, curated dataset plus whatever the user has confirmed in
the application. It is deliberately not a live data feed: an entity's legal
name and country change rarely, and a filing is better served by a stable,
auditable record than by whatever a provider returned on the day the report ran.

Lookup is date-scoped throughout. ``resolve("FB", on=date(2021, 6, 1))`` and
``resolve("FB", on=date(2023, 6, 1))`` are different questions, and the second
one has no answer unless somebody reassigned the symbol.
"""

from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from datetime import date
from pathlib import Path

from pydantic import BaseModel, ConfigDict, TypeAdapter, ValidationError

from ..core.errors import ErrorCode, ParseError
from ..core.hashing import hash_file
from .models import (
    Address,
    Country,
    EntityNature,
    FieldProvenance,
    FinancialInstitution,
    Security,
)

SECURITIES_FILENAME = "securities.json"
INSTITUTIONS_FILENAME = "institutions.json"
OVERRIDES_FILENAME = "user_overrides.json"


def read_json(path: Path) -> object:
    """Read a data file, tolerating a byte-order mark.

    These files are hand-authored and Windows editors routinely add a BOM,
    which strict UTF-8 JSON parsing rejects.
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


@dataclass(frozen=True, slots=True)
class SecurityMatch:
    """One candidate for a symbol on a date."""

    security: Security
    symbol: str
    exchange: str | None
    #: True when the match came from a user override rather than the dataset.
    from_override: bool = False

    def describe(self) -> str:
        venue = f" on {self.exchange}" if self.exchange else ""
        return f"{self.security.describe()}{venue}"


class SecurityOverride(BaseModel):
    """A user's correction to one security master record.

    Only the fields the user actually set are applied. Everything supplied
    here is marked user-confirmed, because a person typed it after looking at
    a source; that is a stronger warrant than the shipped dataset carries.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    security_id: str
    legal_entity_name: str | None = None
    country: Country | None = None
    address: Address | None = None
    nature: EntityNature | None = None
    isin: str | None = None
    #: What the user consulted, recorded in the audit trail.
    reference: str | None = None
    confirmed_on: date | None = None

    def apply_to(self, security: Security) -> Security:
        updates: dict[str, object] = {}
        provenance = dict(security.provenance)
        stamp = FieldProvenance(
            reference=self.reference,
            retrieved_on=self.confirmed_on,
            confirmed_by_user=True,
            note="set by the user in the application",
        )

        for field_name in ("legal_entity_name", "country", "address", "nature", "isin"):
            value = getattr(self, field_name)
            if value is not None:
                updates[field_name] = value
                provenance[field_name] = stamp

        if not updates:
            return security
        updates["provenance"] = provenance
        return security.model_copy(update=updates)


class SecurityMaster:
    """An in-memory security master with date-scoped symbol lookup."""

    def __init__(
        self,
        securities: Iterable[Security] = (),
        institutions: Iterable[FinancialInstitution] = (),
        *,
        source_hash: str | None = None,
        dataset_name: str | None = None,
    ) -> None:
        self._securities: dict[str, Security] = {}
        self._by_symbol: dict[str, list[Security]] = defaultdict(list)
        self._institutions: dict[str, FinancialInstitution] = {}
        self.source_hash = source_hash
        self.dataset_name = dataset_name

        for security in securities:
            self.add(security)
        for institution in institutions:
            self.add_institution(institution)

    # --- population ------------------------------------------------------

    def add(self, security: Security) -> None:
        if security.security_id in self._securities:
            raise ValueError(f"duplicate security id {security.security_id!r}")
        self._securities[security.security_id] = security
        for symbol in security.symbols():
            self._by_symbol[symbol].append(security)

    def add_institution(self, institution: FinancialInstitution) -> None:
        if institution.institution_id in self._institutions:
            raise ValueError(
                f"duplicate institution id {institution.institution_id!r}"
            )
        self._institutions[institution.institution_id] = institution

    def replace(self, security: Security) -> None:
        """Replace a record, keeping the symbol index consistent."""
        existing = self._securities.get(security.security_id)
        if existing is not None:
            for symbol in existing.symbols():
                bucket = self._by_symbol.get(symbol, [])
                self._by_symbol[symbol] = [
                    s for s in bucket if s.security_id != security.security_id
                ]
        self._securities[security.security_id] = security
        for symbol in security.symbols():
            self._by_symbol[symbol].append(security)

    # --- access ----------------------------------------------------------

    def __len__(self) -> int:
        return len(self._securities)

    def all_securities(self) -> list[Security]:
        return [self._securities[k] for k in sorted(self._securities)]

    def all_institutions(self) -> list[FinancialInstitution]:
        return [self._institutions[k] for k in sorted(self._institutions)]

    def by_id(self, security_id: str) -> Security | None:
        return self._securities.get(security_id)

    def institution(self, institution_id: str) -> FinancialInstitution | None:
        return self._institutions.get(institution_id)

    def institution_for_broker(self, broker_id: str) -> FinancialInstitution | None:
        for institution in self.all_institutions():
            if broker_id in institution.broker_ids:
                return institution
        return None

    def known_symbols(self) -> list[str]:
        return sorted(self._by_symbol)

    # --- resolution ------------------------------------------------------

    def candidates(self, symbol: str, *, on: date) -> list[SecurityMatch]:
        """Every security this symbol could mean on ``on``.

        Returning a list rather than a single record is the point: more than
        one candidate is a real condition that the caller must surface, not
        something to resolve by ordering.
        """
        normalized = symbol.strip().upper()
        matches: list[SecurityMatch] = []
        for security in self._by_symbol.get(normalized, []):
            assignment = security.assignment_on(normalized, on)
            if assignment is not None:
                matches.append(
                    SecurityMatch(
                        security=security,
                        symbol=normalized,
                        exchange=assignment.exchange or security.primary_exchange,
                    )
                )
        return sorted(matches, key=lambda m: m.security.security_id)

    def historic_candidates(self, symbol: str) -> list[Security]:
        """Every security that ever used this symbol, regardless of date.

        Used to explain a failed date-scoped lookup: "this symbol existed, but
        not on that date" is far more actionable than "not found".
        """
        normalized = symbol.strip().upper()
        return sorted(
            self._by_symbol.get(normalized, []), key=lambda s: s.security_id
        )

    # --- persistence -----------------------------------------------------

    @classmethod
    def from_directory(cls, root: Path) -> SecurityMaster:
        """Load the master from a data directory."""
        if not root.exists():
            return cls(dataset_name=str(root))

        securities: list[Security] = []
        institutions: list[FinancialInstitution] = []
        hashes: list[str] = []

        securities_path = root / SECURITIES_FILENAME
        if securities_path.exists():
            try:
                securities = list(
                    TypeAdapter(list[Security]).validate_python(
                        read_json(securities_path)
                    )
                )
            except ValidationError as exc:
                raise ParseError(
                    ErrorCode.SCHEMA_VALIDATION_FAILED,
                    f"{securities_path} is not a valid security master file: {exc}",
                ) from exc
            hashes.append(hash_file(securities_path))

        institutions_path = root / INSTITUTIONS_FILENAME
        if institutions_path.exists():
            try:
                institutions = list(
                    TypeAdapter(list[FinancialInstitution]).validate_python(
                        read_json(institutions_path)
                    )
                )
            except ValidationError as exc:
                raise ParseError(
                    ErrorCode.SCHEMA_VALIDATION_FAILED,
                    f"{institutions_path} is not a valid institution file: {exc}",
                ) from exc
            hashes.append(hash_file(institutions_path))

        master = cls(
            securities,
            institutions,
            source_hash=";".join(hashes) or None,
            dataset_name=str(root),
        )

        overrides_path = root / OVERRIDES_FILENAME
        if overrides_path.exists():
            master.apply_overrides(
                TypeAdapter(list[SecurityOverride]).validate_python(
                    read_json(overrides_path)
                )
            )
        return master

    def apply_overrides(self, overrides: Sequence[SecurityOverride]) -> list[str]:
        """Apply user-supplied corrections, returning the ids changed.

        A user correction outranks the shipped dataset, because the user has
        access to the company's filings and the shipped dataset is only ever a
        convenience. The correction is recorded as user-confirmed provenance so
        the report can say where the value came from.
        """
        changed: list[str] = []
        for override in overrides:
            security = self._securities.get(override.security_id)
            if security is None:
                continue
            self.replace(override.apply_to(security))
            changed.append(override.security_id)
        return changed


def default_master_path() -> Path:
    """Where the shipped security data lives."""
    return Path(__file__).resolve().parents[3] / "data" / "securities"


def load_default_master() -> SecurityMaster:
    return SecurityMaster.from_directory(default_master_path())
