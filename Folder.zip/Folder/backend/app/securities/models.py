"""The security master: what a ticker actually refers to.

Schedule FA Table A3 asks for the *legal entity name*, its address and its
country. A broker export supplies none of those. It supplies a ticker symbol
and a display string, and neither is evidence of an entity's legal identity:
``AAPL`` is not "Apple Inc.", it is a symbol that on the Nasdaq currently
routes to the security issued by a company whose registered name happens to be
Apple Inc.

Three facts drive the design.

**A ticker is not a stable identifier.** ``FB`` became ``META`` in 2022, and a
retired symbol can later be reassigned to an unrelated company. So a master
entry is valid over a date range, and resolution is always asked as "what did
this symbol mean on this date".

**A ticker is not unique across venues.** The same letters can name different
securities on different exchanges. When more than one entry claims a symbol for
a date, that is reported as ambiguous rather than settled by picking the first.

**Missing is not the same as blank.** Every field records where it came from
and whether a human confirmed it. The platform never derives an entity name
from a display string, never infers a country from a ticker's exchange, and
never emits a placeholder address.
"""

from __future__ import annotations

from datetime import date
from enum import StrEnum
from typing import Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..tax.rules.models import SourceTier, VerificationStatus


class AssetClass(StrEnum):
    """What kind of interest the security represents.

    Schedule FA treats these differently, and Table A3 asks for the nature of
    the entity, so the distinction cannot be left implicit.
    """

    #: Ordinary shares in a company.
    EQUITY = "EQUITY"
    #: A depositary receipt representing shares in a foreign company.
    DEPOSITARY_RECEIPT = "DEPOSITARY_RECEIPT"
    #: An exchange traded fund.
    ETF = "ETF"
    #: A mutual fund or other pooled vehicle.
    FUND = "FUND"
    #: A real estate investment trust.
    REIT = "REIT"
    #: A bond or other debt interest.
    DEBT = "DEBT"
    #: A unit in a trust or partnership.
    UNIT = "UNIT"
    #: Known to exist, classification not yet confirmed.
    UNCLASSIFIED = "UNCLASSIFIED"


class EntityNature(StrEnum):
    """The "nature of entity" wording Schedule FA Table A3 asks for.

    Held as a controlled vocabulary rather than free text so that a report can
    be generated consistently, and so that an unconfirmed value is visibly
    unconfirmed rather than an empty string.
    """

    LISTED_COMPANY = "LISTED_COMPANY"
    UNLISTED_COMPANY = "UNLISTED_COMPANY"
    EXCHANGE_TRADED_FUND = "EXCHANGE_TRADED_FUND"
    MUTUAL_FUND = "MUTUAL_FUND"
    REAL_ESTATE_INVESTMENT_TRUST = "REAL_ESTATE_INVESTMENT_TRUST"
    TRUST = "TRUST"
    PARTNERSHIP = "PARTNERSHIP"
    #: Not yet determined. Never written into a filing.
    UNDETERMINED = "UNDETERMINED"

    @property
    def is_determined(self) -> bool:
        return self is not EntityNature.UNDETERMINED

    def label(self) -> str:
        """The human wording used in the report."""
        return _NATURE_LABELS[self]


_NATURE_LABELS: dict[EntityNature, str] = {
    EntityNature.LISTED_COMPANY: "Listed company",
    EntityNature.UNLISTED_COMPANY: "Unlisted company",
    EntityNature.EXCHANGE_TRADED_FUND: "Exchange traded fund",
    EntityNature.MUTUAL_FUND: "Mutual fund",
    EntityNature.REAL_ESTATE_INVESTMENT_TRUST: "Real estate investment trust",
    EntityNature.TRUST: "Trust",
    EntityNature.PARTNERSHIP: "Partnership",
    EntityNature.UNDETERMINED: "",
}


class Country(BaseModel):
    """A country, carrying every code system the platform must emit.

    The ITR country-code list printed in the form instructions is not always
    identical to ISO 3166-1, so the ISO codes and the ITR code are stored
    separately. An absent ITR code is left absent: substituting the ISO code
    would put an unverified number on a filed return.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str
    #: ISO 3166-1 alpha-2, for example "US".
    iso_alpha_2: str = Field(min_length=2, max_length=2)
    #: ISO 3166-1 numeric, for example "840".
    iso_numeric: str | None = None
    #: The code from the ITR instruction country list, when it has been
    #: transcribed and confirmed for the relevant assessment year.
    itr_code: str | None = None
    itr_code_verified: bool = False

    @property
    def has_filing_code(self) -> bool:
        return bool(self.itr_code) and self.itr_code_verified


class Address(BaseModel):
    """A postal address.

    Every component is optional because a partial address is a real state: the
    platform reports what it has and flags what it lacks. It never fills a gap
    with the exchange's address, the broker's address or a registered-agent
    address, none of which is the entity's address.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    line1: str | None = None
    line2: str | None = None
    city: str | None = None
    state: str | None = None
    zip_code: str | None = None
    country_name: str | None = None

    @property
    def is_empty(self) -> bool:
        return not any(
            (self.line1, self.line2, self.city, self.state, self.zip_code)
        )

    def one_line(self) -> str:
        """Render for the form's single address field."""
        parts = [
            p
            for p in (self.line1, self.line2, self.city, self.state, self.country_name)
            if p and p.strip()
        ]
        return ", ".join(parts)


class FieldProvenance(BaseModel):
    """Where one field's value came from and whether anyone checked it."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    #: Source id in the official-source registry, when there is one.
    source_id: str | None = None
    tier: SourceTier = SourceTier.COMMUNITY_DATASET
    #: Free text describing the document or page, for the audit trail.
    reference: str | None = None
    retrieved_on: date | None = None
    verification_status: VerificationStatus = VerificationStatus.REQUIRES_CONFIRMATION
    #: Set when a user typed or confirmed the value in the application.
    confirmed_by_user: bool = False
    note: str | None = None

    @property
    def is_confirmed(self) -> bool:
        return (
            self.confirmed_by_user
            or self.verification_status is VerificationStatus.VERIFIED
        )


class TickerAssignment(BaseModel):
    """A symbol, on a venue, valid over a date range.

    Separating the symbol from the security is what lets the platform handle a
    ticker change without losing the position's history: ``FB`` and ``META``
    are two assignments of the same security, with adjoining date ranges.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    symbol: str
    #: Market Identifier Code or a common venue abbreviation, for example
    #: "XNAS" or "NASDAQ". Absent means the assignment is not venue-scoped.
    exchange: str | None = None
    #: First date the symbol referred to this security. ``None`` means "from
    #: before any date this platform handles", not "unknown".
    valid_from: date | None = None
    #: Last date inclusive. ``None`` means still current.
    valid_to: date | None = None
    note: str | None = None

    @property
    def normalized_symbol(self) -> str:
        return self.symbol.strip().upper()

    def covers(self, on: date) -> bool:
        if self.valid_from is not None and on < self.valid_from:
            return False
        return not (self.valid_to is not None and on > self.valid_to)

    def overlaps(self, other: TickerAssignment) -> bool:
        """Whether two assignments of the same symbol share any date."""
        if self.normalized_symbol != other.normalized_symbol:
            return False
        start = max(
            self.valid_from or date.min,
            other.valid_from or date.min,
        )
        end = min(self.valid_to or date.max, other.valid_to or date.max)
        return start <= end

    def describe_period(self) -> str:
        start = self.valid_from.isoformat() if self.valid_from else "any earlier date"
        end = self.valid_to.isoformat() if self.valid_to else "the present"
        return f"{start} to {end}"


class Security(BaseModel):
    """One security in the master.

    The identity fields the form needs are all optional on the record and
    checked at report time, so that a partially known security can still be
    carried through the pipeline with its gaps named, rather than blocking
    ingestion or being quietly completed.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    #: Stable internal id, independent of any ticker.
    security_id: str
    #: Every symbol this security has traded under, with validity ranges.
    tickers: tuple[TickerAssignment, ...] = ()

    #: The registered legal name. NOT the broker's display string.
    legal_entity_name: str | None = None
    #: The broker's display string, kept for traceability and for matching,
    #: explicitly separate from the legal name.
    display_names: tuple[str, ...] = ()

    country: Country | None = None
    address: Address | None = None
    nature: EntityNature = EntityNature.UNDETERMINED
    asset_class: AssetClass = AssetClass.UNCLASSIFIED

    #: Identifiers, only ever populated from a source that stated them.
    isin: str | None = None
    cusip: str | None = None
    figi: str | None = None

    #: Currency the security trades in, used to pick the right FX series.
    trading_currency: str | None = None
    primary_exchange: str | None = None

    #: Per-field provenance, keyed by field name.
    provenance: dict[str, FieldProvenance] = Field(default_factory=dict)
    #: Overall status of the record.
    verification_status: VerificationStatus = VerificationStatus.REQUIRES_CONFIRMATION
    #: True for records generated for tests, so they can never be mistaken for
    #: real reference data.
    synthetic: bool = False
    notes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def _check_ticker_ranges(self) -> Self:
        for index, assignment in enumerate(self.tickers):
            if (
                assignment.valid_from is not None
                and assignment.valid_to is not None
                and assignment.valid_from > assignment.valid_to
            ):
                raise ValueError(
                    f"{self.security_id}: ticker {assignment.symbol} has "
                    f"valid_from after valid_to"
                )
            for other in self.tickers[index + 1 :]:
                if assignment.overlaps(other):
                    raise ValueError(
                        f"{self.security_id}: ticker {assignment.symbol} is assigned "
                        f"twice over overlapping dates"
                    )
        return self

    def symbols(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys(a.normalized_symbol for a in self.tickers))

    def assignment_on(self, symbol: str, on: date) -> TickerAssignment | None:
        normalized = symbol.strip().upper()
        for assignment in self.tickers:
            if assignment.normalized_symbol == normalized and assignment.covers(on):
                return assignment
        return None

    def symbol_on(self, on: date) -> str | None:
        """The symbol this security traded under on a date."""
        for assignment in self.tickers:
            if assignment.covers(on):
                return assignment.normalized_symbol
        return None

    def provenance_for(self, field_name: str) -> FieldProvenance | None:
        return self.provenance.get(field_name)

    def is_confirmed(self, field_name: str) -> bool:
        entry = self.provenance.get(field_name)
        return entry is not None and entry.is_confirmed

    # --- reporting readiness --------------------------------------------

    @property
    def has_entity_name(self) -> bool:
        return bool(self.legal_entity_name and self.legal_entity_name.strip())

    @property
    def has_country(self) -> bool:
        return self.country is not None

    @property
    def has_address(self) -> bool:
        return self.address is not None and not self.address.is_empty

    @property
    def has_zip(self) -> bool:
        return self.address is not None and bool(self.address.zip_code)

    def missing_reporting_fields(self) -> tuple[str, ...]:
        """Fields Schedule FA A3 needs that this record does not supply."""
        missing: list[str] = []
        if not self.has_entity_name:
            missing.append("legal_entity_name")
        if not self.has_country:
            missing.append("country")
        if not self.nature.is_determined:
            missing.append("nature")
        if not self.has_address:
            missing.append("address")
        if not self.has_zip:
            missing.append("zip_code")
        return tuple(missing)

    def describe(self) -> str:
        name = self.legal_entity_name or "(legal entity name not set)"
        symbols = ", ".join(self.symbols()) or "(no symbols)"
        country = self.country.name if self.country else "(country not set)"
        return f"{self.security_id} {name} [{symbols}] {country}"


class FinancialInstitution(BaseModel):
    """A custodian or broker, for Schedule FA Table A2.

    Table A2 reports the *account*, and the institution holding it, which is a
    different entity from any security inside the account. The broker's name is
    the one piece of identity the platform can reasonably supply itself; the
    account number, the account's opening date and the ownership status come
    from the user, because a transaction export does not contain them.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    institution_id: str
    #: The legal name of the institution, which may differ from the brand a
    #: user knows. Vested Finance is an intermediary; the account is typically
    #: held with a US custodian, and Table A2 asks for the institution holding
    #: the account.
    legal_name: str | None = None
    brand_name: str | None = None
    #: Broker ids in the parser registry that route to this institution.
    broker_ids: tuple[str, ...] = ()
    country: Country | None = None
    address: Address | None = None
    provenance: dict[str, FieldProvenance] = Field(default_factory=dict)
    verification_status: VerificationStatus = VerificationStatus.REQUIRES_CONFIRMATION
    synthetic: bool = False
    notes: tuple[str, ...] = ()

    @property
    def has_legal_name(self) -> bool:
        return bool(self.legal_name and self.legal_name.strip())

    def missing_reporting_fields(self) -> tuple[str, ...]:
        missing: list[str] = []
        if not self.has_legal_name:
            missing.append("legal_name")
        if self.country is None:
            missing.append("country")
        if self.address is None or self.address.is_empty:
            missing.append("address")
        elif not self.address.zip_code:
            missing.append("zip_code")
        return tuple(missing)
