"""Resolving the tickers in a ledger to securities.

This module is where the platform's refusal to invent identity is enforced.
The rules it applies, and what each one prevents:

``a ticker is never an entity name``
    ``AAPL`` does not become "AAPL" in the Name of Entity field, and neither
    does the broker's display string "Apple Inc." become the legal name unless
    a source says it is. A wrong entity name on a filed return is a defect the
    filer is answerable for.

``an unknown ticker is unresolved, not approximated``
    No nearest-match, no "probably the US listing". The holding is carried
    through the pipeline with a named gap.

``two candidates is an error, not a tie-break``
    The same letters name different securities on different venues. Picking
    the first would produce a confident, wrong country.

``a symbol is resolved as at a date``
    ``FB`` in 2021 and ``FB`` in 2024 are different questions. Resolution uses
    the transaction's own date, so a ticker change mid-history resolves each
    side correctly.

``missing detail does not block ingestion``
    A resolved security with no address still flows through. The gap is
    reported at its real severity: no entity name or country blocks the
    filing, a missing address warns.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import date

from ..core.errors import ErrorCode
from ..transactions.ledger import TransactionLedger
from ..transactions.models import NormalizedTransaction
from ..validation.issues import IssueCollector, IssueScope
from .master import SecurityMaster
from .models import Security

#: Fields whose absence stops a filing, mapped to the code that reports it.
_BLOCKING_FIELDS: dict[str, ErrorCode] = {
    "legal_entity_name": ErrorCode.SECURITY_ENTITY_NAME_MISSING,
    "country": ErrorCode.SECURITY_COUNTRY_MISSING,
}

#: Fields whose absence is reported but does not stop a filing.
_ADVISORY_FIELDS: dict[str, ErrorCode] = {
    "address": ErrorCode.SECURITY_ADDRESS_MISSING,
    "zip_code": ErrorCode.SECURITY_ZIP_MISSING,
    "nature": ErrorCode.SECURITY_NATURE_MISSING,
}


@dataclass(frozen=True, slots=True)
class ResolvedSecurity:
    """The outcome of resolving one symbol as at one date."""

    symbol: str
    as_of: date
    security: Security | None
    #: Why resolution failed or succeeded, in words a user can act on.
    explanation: str
    #: Populated when more than one master entry claimed the symbol.
    ambiguous_candidates: tuple[Security, ...] = ()
    #: Populated when the symbol exists in the master but not on this date.
    out_of_period_candidates: tuple[Security, ...] = ()

    @property
    def resolved(self) -> bool:
        return self.security is not None

    @property
    def ambiguous(self) -> bool:
        return len(self.ambiguous_candidates) > 1

    def missing_fields(self) -> tuple[str, ...]:
        if self.security is None:
            return ()
        return self.security.missing_reporting_fields()

    @property
    def reportable(self) -> bool:
        """Whether Schedule FA could be filed from this record as it stands."""
        if self.security is None:
            return False
        return not any(f in _BLOCKING_FIELDS for f in self.missing_fields())


@dataclass(slots=True)
class ResolutionReport:
    """What resolution found across a whole ledger."""

    resolutions: dict[str, ResolvedSecurity] = field(default_factory=dict)
    #: Symbols seen in the ledger, with how many transactions used each.
    symbol_counts: dict[str, int] = field(default_factory=dict)
    #: Symbols that resolved to the same security, keyed by security id. A
    #: ticker change produces one of these and it is not a problem.
    aliases: dict[str, tuple[str, ...]] = field(default_factory=dict)

    @property
    def unresolved(self) -> list[str]:
        return sorted(s for s, r in self.resolutions.items() if not r.resolved)

    @property
    def ambiguous(self) -> list[str]:
        return sorted(s for s, r in self.resolutions.items() if r.ambiguous)

    @property
    def incomplete(self) -> list[str]:
        return sorted(
            s for s, r in self.resolutions.items() if r.resolved and not r.reportable
        )

    @property
    def resolved_count(self) -> int:
        return sum(1 for r in self.resolutions.values() if r.resolved)

    def security_for(self, symbol: str) -> Security | None:
        resolution = self.resolutions.get(symbol.strip().upper())
        return resolution.security if resolution else None

    def summary(self) -> str:
        lines = [
            f"symbols in ledger: {len(self.symbol_counts)}",
            f"resolved: {self.resolved_count}",
            f"unresolved: {len(self.unresolved)}",
            f"ambiguous: {len(self.ambiguous)}",
            f"resolved but not yet reportable: {len(self.incomplete)}",
        ]
        for symbol in sorted(self.resolutions):
            resolution = self.resolutions[symbol]
            count = self.symbol_counts.get(symbol, 0)
            status = "resolved" if resolution.resolved else "UNRESOLVED"
            lines.append(f"\n  {symbol} ({count} transactions): {status}")
            lines.append(f"    {resolution.explanation}")
            missing = resolution.missing_fields()
            if missing:
                lines.append(f"    missing for reporting: {', '.join(missing)}")
        for security_id, symbols in sorted(self.aliases.items()):
            lines.append(
                f"\n  {security_id} was held under more than one symbol: "
                f"{', '.join(symbols)}. These are the same interest and are "
                f"reported as one line."
            )
        return "\n".join(lines)


class SecurityResolver:
    """Resolves ledger symbols against a security master."""

    def __init__(self, master: SecurityMaster) -> None:
        self.master = master

    # --- single symbol ---------------------------------------------------

    def resolve(self, symbol: str, *, on: date) -> ResolvedSecurity:
        """Resolve one symbol as at one date."""
        normalized = symbol.strip().upper()
        if not normalized:
            return ResolvedSecurity(
                symbol=normalized,
                as_of=on,
                security=None,
                explanation="the transaction names no ticker symbol",
            )

        candidates = self.master.candidates(normalized, on=on)

        if len(candidates) == 1:
            match = candidates[0]
            return ResolvedSecurity(
                symbol=normalized,
                as_of=on,
                security=match.security,
                explanation=(
                    f"{normalized} resolved to {match.security.security_id} "
                    f"({match.security.legal_entity_name or 'legal name not set'})"
                    + (f" on {match.exchange}" if match.exchange else "")
                ),
            )

        if len(candidates) > 1:
            return ResolvedSecurity(
                symbol=normalized,
                as_of=on,
                security=None,
                ambiguous_candidates=tuple(c.security for c in candidates),
                explanation=(
                    f"{normalized} matches {len(candidates)} securities on "
                    f"{on.isoformat()}: "
                    + "; ".join(c.describe() for c in candidates)
                    + ". The platform will not choose between them, because the "
                    "wrong choice produces a confident but incorrect entity and "
                    "country on the return."
                ),
            )

        historic = self.master.historic_candidates(normalized)
        if historic:
            periods = "; ".join(
                f"{s.security_id} used it "
                + ", ".join(
                    a.describe_period()
                    for a in s.tickers
                    if a.normalized_symbol == normalized
                )
                for s in historic
            )
            return ResolvedSecurity(
                symbol=normalized,
                as_of=on,
                security=None,
                out_of_period_candidates=tuple(historic),
                explanation=(
                    f"{normalized} exists in the security master but was not "
                    f"assigned to any security on {on.isoformat()}. {periods}. "
                    f"Either the transaction date is wrong or the symbol's "
                    f"validity period needs extending."
                ),
            )

        return ResolvedSecurity(
            symbol=normalized,
            as_of=on,
            security=None,
            explanation=(
                f"{normalized} is not in the security master. The platform does "
                f"not infer an entity from a ticker symbol, so this holding has "
                f"no entity name, country or nature until the security is added."
            ),
        )

    # --- whole ledger ----------------------------------------------------

    def resolve_ledger(
        self,
        ledger: TransactionLedger,
        issues: IssueCollector | None = None,
        *,
        as_of: date | None = None,
    ) -> ResolutionReport:
        """Resolve every symbol in a ledger and report what is missing.

        Each symbol is resolved as at the date it was *first* used, which is
        what makes a mid-history ticker change work: the old symbol resolves
        against its own era rather than against today.
        """
        report = ResolutionReport()
        first_seen: dict[str, date] = {}
        by_symbol: dict[str, list[NormalizedTransaction]] = {}

        for transaction in ledger.ordered():
            if not transaction.ticker:
                continue
            symbol = transaction.ticker.strip().upper()
            report.symbol_counts[symbol] = report.symbol_counts.get(symbol, 0) + 1
            by_symbol.setdefault(symbol, []).append(transaction)
            existing = first_seen.get(symbol)
            if existing is None or transaction.transaction_date < existing:
                first_seen[symbol] = transaction.transaction_date

        for symbol, seen_on in sorted(first_seen.items()):
            resolution = self.resolve(symbol, on=as_of or seen_on)
            report.resolutions[symbol] = resolution
            if issues is not None:
                self._report_symbol(symbol, resolution, by_symbol[symbol], issues)

        self._detect_aliases(report)
        return report

    # --- issue reporting -------------------------------------------------

    def _report_symbol(
        self,
        symbol: str,
        resolution: ResolvedSecurity,
        transactions: Sequence[NormalizedTransaction],
        issues: IssueCollector,
    ) -> None:
        affected = ", ".join(t.source_reference for t in transactions[:5])
        if len(transactions) > 5:
            affected += f" and {len(transactions) - 5} more"

        if not resolution.resolved:
            issues.report(
                ErrorCode.SECURITY_AMBIGUOUS
                if resolution.ambiguous
                else ErrorCode.SECURITY_UNRESOLVED,
                scope=IssueScope.SECURITY,
                subject=symbol,
                message=(
                    f"{resolution.explanation} "
                    f"{len(transactions)} transaction(s) use this symbol: {affected}."
                ),
                field="ticker",
                value=symbol,
            )
            return

        security = resolution.security
        assert security is not None
        missing = set(security.missing_reporting_fields())

        for field_name, code in _BLOCKING_FIELDS.items():
            if field_name in missing:
                issues.report(
                    code,
                    scope=IssueScope.SECURITY,
                    subject=symbol,
                    message=(
                        f"{symbol} resolved to {security.security_id}, but that "
                        f"record has no {field_name.replace('_', ' ')}. Schedule FA "
                        f"requires it and the platform will not substitute the "
                        f"ticker symbol or the broker's display name for it."
                    ),
                    field=field_name,
                )

        for field_name, code in _ADVISORY_FIELDS.items():
            if field_name in missing:
                issues.report(
                    code,
                    scope=IssueScope.SECURITY,
                    subject=symbol,
                    message=(
                        f"{symbol} ({security.legal_entity_name or security.security_id}) "
                        f"has no {field_name.replace('_', ' ')} in the security master. "
                        f"The field will be left blank rather than filled with a "
                        f"substitute value."
                    ),
                    field=field_name,
                )

        unconfirmed = [
            name
            for name in ("legal_entity_name", "country")
            if getattr(security, name, None) is not None
            and not security.is_confirmed(name)
        ]
        if unconfirmed:
            issues.report(
                ErrorCode.SECURITY_DETAILS_UNCONFIRMED,
                scope=IssueScope.SECURITY,
                subject=symbol,
                message=(
                    f"{symbol} resolved to {security.describe()}, but "
                    f"{_join_fields(unconfirmed)} "
                    f"{'has' if len(unconfirmed) == 1 else 'have'} not been confirmed "
                    f"against an official source. Review the record on the Security "
                    f"Master page before filing."
                ),
            )

    def _detect_aliases(self, report: ResolutionReport) -> None:
        """Group symbols that resolved to the same security.

        A ticker change means two symbols and one interest. Schedule FA reports
        the interest once, so the grouping has to be visible before the report
        is built rather than discovered as a duplicate row afterwards.
        """
        by_security: dict[str, list[str]] = {}
        for symbol, resolution in report.resolutions.items():
            if resolution.security is None:
                continue
            by_security.setdefault(resolution.security.security_id, []).append(symbol)
        report.aliases = {
            security_id: tuple(sorted(symbols))
            for security_id, symbols in by_security.items()
            if len(symbols) > 1
        }


def resolve_display_name_conflicts(
    master: SecurityMaster,
    ledger: TransactionLedger,
    issues: IssueCollector,
) -> list[str]:
    """Flag where the broker's display name disagrees with the legal name.

    This does not change anything. It surfaces the disagreement, because the
    two most likely explanations both matter: the master entry is for the
    wrong company, or the broker abbreviates. Only a human can tell which.
    """
    conflicts: list[str] = []
    seen: set[tuple[str, str]] = set()

    for transaction in ledger.ordered():
        if not transaction.ticker or not transaction.security_name:
            continue
        symbol = transaction.ticker.strip().upper()
        display = transaction.security_name.strip()
        if (symbol, display) in seen:
            continue
        seen.add((symbol, display))

        matches = master.candidates(symbol, on=transaction.transaction_date)
        if len(matches) != 1:
            continue
        security = matches[0].security
        if not security.legal_entity_name:
            continue
        if _looks_like(display, security.legal_entity_name) or display in (
            security.display_names
        ):
            continue

        conflicts.append(symbol)
        issues.report(
            ErrorCode.SECURITY_NAME_MISMATCH,
            scope=IssueScope.SECURITY,
            subject=symbol,
            message=(
                f"the broker calls {symbol} {display!r}, but the security master "
                f"records the legal entity name as "
                f"{security.legal_entity_name!r}. Confirm that the master entry is "
                f"the right company before filing; the report uses the master's "
                f"legal name, not the broker's display name."
            ),
            field="security_name",
            value=display,
        )
    return conflicts


def _join_fields(names: Sequence[str]) -> str:
    """Render field names as readable prose rather than a bare list."""
    readable = [name.replace("_", " ") for name in names]
    if len(readable) == 1:
        return f"the {readable[0]}"
    return "the " + ", ".join(readable[:-1]) + f" and {readable[-1]}"


def _looks_like(display: str, legal: str) -> bool:
    """Whether a display name is plausibly the same entity as a legal name.

    Deliberately crude and used only to suppress noise on obvious matches such
    as "Apple Inc." against "Apple Inc". It never causes a name to be adopted,
    only a warning to be skipped, so a false positive costs a warning rather
    than a wrong filing.
    """
    return _simplify(display) == _simplify(legal)


_SUFFIXES = (
    "inc",
    "incorporated",
    "corp",
    "corporation",
    "co",
    "company",
    "ltd",
    "limited",
    "plc",
    "llc",
    "lp",
    "nv",
    "sa",
    "ag",
    "trust",
    "the",
)


def _simplify(name: str) -> str:
    words = [
        w
        for w in "".join(
            ch if ch.isalnum() or ch.isspace() else " " for ch in name.lower()
        ).split()
        if w not in _SUFFIXES
    ]
    return "".join(words)


def symbols_needing_attention(report: ResolutionReport) -> list[str]:
    """Symbols a user must act on before a report can be produced."""
    blocking = set(report.unresolved) | set(report.ambiguous)
    for symbol, resolution in report.resolutions.items():
        if resolution.resolved and not resolution.reportable:
            blocking.add(symbol)
    return sorted(blocking)
