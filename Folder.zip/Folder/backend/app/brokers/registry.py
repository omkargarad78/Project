"""Broker parser registry and broker identification.

Identification is structural: each registered parser inspects the file and
returns a confidence score, and the highest score wins. A file no parser
recognises raises ``BROKER_UNIDENTIFIED`` rather than being pushed through the
closest available parser, because a best-effort parse of an unsupported format
produces figures that look finished and are not.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass

from ..core.errors import ErrorCode, ParseError
from ..io.loader import LoadedSource
from .base import BrokerParser, DetectionResult
from .vested.parser import VestedParser


@dataclass(frozen=True, slots=True)
class IdentificationResult:
    """The chosen parser plus every parser's verdict, for the upload report."""

    parser: BrokerParser
    detection: DetectionResult
    #: Every candidate's result, highest confidence first.
    all_detections: tuple[DetectionResult, ...]

    @property
    def ambiguous(self) -> bool:
        """True when two parsers claimed the file with equal confidence."""
        matched = [d for d in self.all_detections if d.matched]
        if len(matched) < 2:
            return False
        return matched[0].confidence == matched[1].confidence


class BrokerRegistry:
    """Holds the available broker parsers."""

    def __init__(self, parsers: Iterable[BrokerParser] = ()) -> None:
        self._parsers: list[BrokerParser] = list(parsers)

    def register(self, parser: BrokerParser) -> None:
        if any(p.broker_id == parser.broker_id for p in self._parsers):
            raise ValueError(f"a parser for broker {parser.broker_id!r} is already registered")
        self._parsers.append(parser)

    def parsers(self) -> list[BrokerParser]:
        return list(self._parsers)

    def broker_ids(self) -> list[str]:
        return sorted(p.broker_id for p in self._parsers)

    def get(self, broker_id: str) -> BrokerParser:
        for parser in self._parsers:
            if parser.broker_id == broker_id:
                return parser
        raise ParseError(
            ErrorCode.BROKER_UNIDENTIFIED,
            f"no parser is registered for broker {broker_id!r}. Registered brokers: "
            f"{', '.join(self.broker_ids()) or 'none'}",
        )

    def identify(self, source: LoadedSource) -> IdentificationResult:
        """Choose the parser for ``source``."""
        detections = sorted(
            (parser.detect(source) for parser in self._parsers),
            key=lambda d: (-d.confidence, d.broker_id),
        )
        matched = [d for d in detections if d.matched]

        if not matched:
            explanation = "; ".join(
                f"{d.broker_id}: {'; '.join(d.reasons) or 'no expected sections found'}"
                for d in detections
            )
            raise ParseError(
                ErrorCode.BROKER_UNIDENTIFIED,
                f"no registered broker parser recognised {source.file_name}. "
                f"Worksheets found: {', '.join(source.workbook.sheet_names())}. "
                f"Parser verdicts: {explanation or 'no parsers are registered'}. "
                f"The platform does not attempt a best-effort parse of an "
                f"unrecognised format.",
            )

        best = matched[0]
        if len(matched) > 1 and matched[0].confidence == matched[1].confidence:
            tied = ", ".join(d.broker_id for d in matched if d.confidence == best.confidence)
            raise ParseError(
                ErrorCode.BROKER_UNIDENTIFIED,
                f"{source.file_name} was claimed with equal confidence by more than one "
                f"broker parser ({tied}). Specify the broker explicitly rather than "
                f"letting the platform choose.",
            )

        return IdentificationResult(
            parser=self.get(best.broker_id),
            detection=best,
            all_detections=tuple(detections),
        )

    def parse(self, source: LoadedSource, *, broker_id: str | None = None):  # noqa: ANN201
        """Identify (or use the stated broker) and parse in one call."""
        parser = self.get(broker_id) if broker_id else self.identify(source).parser
        return parser.parse(source)


def default_registry() -> BrokerRegistry:
    """The registry the application uses.

    Adding a broker means adding a parser here. Nothing in the transaction,
    FX, lot, valuation or Schedule FA modules changes.
    """
    return BrokerRegistry([VestedParser()])


def supported_brokers() -> Sequence[str]:
    return default_registry().broker_ids()
