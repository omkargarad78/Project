"""The broker parser interface and the generic machinery every parser reuses.

A broker is added by supplying data, not by writing a new reader:

``BrokerFieldMapping``
    Declares each statement section, the sheet names it may appear under, and
    the columns it must and may contain, as explicit alias lists.

``BrokerParser``
    Implements ``detect``, ``validate``, the ``parse_*`` section readers,
    and ``normalize``. The base class already provides sheet location, header
    validation, column-level date resolution and decimal extraction, so a
    concrete parser is mostly a mapping plus an activity-label classifier.

Nothing here knows anything about Schedule FA, exchange rates or valuation. A
parser's entire output is a canonical ledger plus a report of what it found.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field, replace
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum

from ..core.errors import ErrorCode, ParseError
from ..core.hashing import derive_id
from ..core.money import MoneyError, as_amount, as_price, as_quantity, opt_decimal
from ..io.dates import (
    DATE_FORMATS,
    DateFormatResolution,
    parse_with_format,
    resolve_date_format,
)
from ..io.loader import LoadedSource
from ..io.tabular import CellKind, DetectedTable, RawCell, RawSheet, TableRow, extract_table
from ..transactions.ledger import TransactionLedger
from ..transactions.models import RawTransactionRow, TransactionType
from ..validation.issues import IssueCollector, IssueScope


class Section(StrEnum):
    """Logical statement sections a broker export can contain."""

    TRADES = "TRADES"
    INCOME = "INCOME"
    TRANSFERS = "TRANSFERS"
    ACCOUNT = "ACCOUNT"
    CORPORATE_ACTIONS = "CORPORATE_ACTIONS"
    HOLDINGS = "HOLDINGS"


class FieldKind(StrEnum):
    """How a column's values are interpreted."""

    DATE = "DATE"
    DECIMAL = "DECIMAL"
    TEXT = "TEXT"


@dataclass(frozen=True, slots=True)
class FieldSpec:
    """One column of a statement section."""

    name: str
    #: Header spellings this field may appear under, most preferred first.
    aliases: tuple[str, ...]
    kind: FieldKind = FieldKind.TEXT
    #: A required field's absence means the export format has changed.
    required: bool = False
    notes: str | None = None


def required_in(spec: FieldSpec) -> FieldSpec:
    """Mark a shared field definition as required *in this section*.

    Whether a column is required is a property of the section, not of the
    field: a Trades row must name a ticker, while a cash deposit legitimately
    has no ticker at all. Sharing one alias list across sections and setting
    the requirement per section keeps both facts expressible.
    """
    return replace(spec, required=True)


def optional_in(spec: FieldSpec) -> FieldSpec:
    """Mark a shared field definition as optional in this section."""
    return replace(spec, required=False)


@dataclass(frozen=True, slots=True)
class SheetSpec:
    """One statement section and where to find it."""

    section: Section
    #: Sheet names this section may appear under, most preferred first.
    sheet_aliases: tuple[str, ...]
    fields: tuple[FieldSpec, ...]
    #: A required section's absence means the file is not a usable statement.
    required: bool = False
    notes: str | None = None

    def field(self, name: str) -> FieldSpec:
        for spec in self.fields:
            if spec.name == name:
                return spec
        raise KeyError(f"section {self.section} has no field {name!r}")

    def required_aliases(self) -> list[str]:
        """Primary alias of each required field, used for header detection."""
        return [spec.aliases[0] for spec in self.fields if spec.required]

    def required_groups(self) -> list[tuple[str, tuple[str, ...]]]:
        """Required fields as ``(label, every accepted spelling)`` pairs.

        Validation must accept any declared spelling, so it checks groups
        rather than the primary alias alone.
        """
        return [(spec.aliases[0], spec.aliases) for spec in self.fields if spec.required]

    def all_aliases(self) -> list[str]:
        return [alias for spec in self.fields for alias in spec.aliases]


@dataclass(frozen=True, slots=True)
class BrokerFieldMapping:
    """The complete declarative description of a broker's export."""

    broker_id: str
    sections: tuple[SheetSpec, ...]
    #: Date layouts this broker is known to use, narrowing the search and so
    #: reducing the chance of an ambiguous resolution.
    date_formats: tuple[tuple[str, str], ...] | None = None
    #: Currency to assume when the export states none. Declared explicitly
    #: rather than defaulted, because assuming USD for a non-US broker would
    #: mis-state every converted figure.
    default_currency: str | None = None

    def section(self, section: Section) -> SheetSpec | None:
        for spec in self.sections:
            if spec.section is section:
                return spec
        return None


@dataclass(frozen=True, slots=True)
class DetectionResult:
    """Whether a parser recognises a file, and why."""

    broker_id: str
    matched: bool
    #: Higher wins when several parsers match. Derived from how many expected
    #: sheets and columns were found, so a partial match loses to a full one.
    confidence: int = 0
    reasons: tuple[str, ...] = ()
    matched_sections: Mapping[Section, str] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class SchemaValidation:
    """Outcome of checking a recognised file's columns."""

    ok: bool
    #: Missing required columns, per section.
    missing_fields: Mapping[Section, tuple[str, ...]] = field(default_factory=dict)
    missing_sections: tuple[Section, ...] = ()
    #: Columns present in the file that the mapping does not describe.
    unmapped_columns: Mapping[Section, tuple[str, ...]] = field(default_factory=dict)
    date_formats: Mapping[str, DateFormatResolution] = field(default_factory=dict)
    notes: tuple[str, ...] = ()

    def failure_message(self) -> str:
        parts: list[str] = []
        for section, missing in sorted(self.missing_fields.items(), key=lambda kv: str(kv[0])):
            parts.append(f"{section} is missing required column(s): {', '.join(missing)}")
        if self.missing_sections:
            parts.append(
                f"required section(s) not found: "
                f"{', '.join(str(s) for s in self.missing_sections)}"
            )
        for key, resolution in sorted(self.date_formats.items()):
            if not resolution.resolved:
                parts.append(f"{key}: {resolution.reason}")
        return "; ".join(parts)


@dataclass(frozen=True, slots=True)
class ParsedSection:
    """A located, header-validated section of a statement."""

    section: Section
    sheet_name: str
    table: DetectedTable
    spec: SheetSpec
    #: Resolved date layout per date field name.
    date_formats: Mapping[str, str] = field(default_factory=dict)

    @property
    def row_count(self) -> int:
        return len(self.table)


@dataclass(frozen=True, slots=True)
class SectionReport:
    """What a parser found in one section, for the parser report."""

    section: Section
    sheet_name: str
    row_count: int
    column_names: tuple[str, ...]
    date_columns: tuple[str, ...]
    amount_columns: tuple[str, ...]
    detected_currencies: tuple[str, ...]
    #: Activity labels found, with their occurrence counts.
    transaction_categories: Mapping[str, int] = field(default_factory=dict)
    #: Activity labels the parser could not map, with counts.
    unknown_categories: Mapping[str, int] = field(default_factory=dict)
    #: Columns with at least one missing value in the data rows.
    columns_with_missing_values: tuple[str, ...] = ()
    unmapped_columns: tuple[str, ...] = ()
    date_format_label: str | None = None

    def to_row(self) -> dict[str, str]:
        return {
            "Section": str(self.section),
            "Sheet Name": self.sheet_name,
            "Row Count": str(self.row_count),
            "Column Names": ", ".join(self.column_names),
            "Detected Date Columns": ", ".join(self.date_columns),
            "Detected Amount Columns": ", ".join(self.amount_columns),
            "Detected Currency": ", ".join(self.detected_currencies),
            "Date Format": self.date_format_label or "",
            "Transaction Categories": ", ".join(
                f"{label} ({count})"
                for label, count in sorted(self.transaction_categories.items())
            ),
            "Unknown Transaction Types": ", ".join(
                f"{label} ({count})" for label, count in sorted(self.unknown_categories.items())
            ),
            "Columns With Missing Values": ", ".join(self.columns_with_missing_values),
            "Unmapped Columns": ", ".join(self.unmapped_columns),
        }


@dataclass(frozen=True, slots=True)
class ParserReport:
    """The report a user sees after upload, before anything is calculated."""

    broker_id: str
    broker_name: str
    parser_version: str
    source_file_id: str
    file_name: str
    file_hash: str
    sheet_names: tuple[str, ...]
    sections: tuple[SectionReport, ...]
    transaction_count: int
    #: Transactions emitted per canonical type.
    type_counts: Mapping[str, int] = field(default_factory=dict)
    duplicate_candidate_count: int = 0
    unknown_activity_labels: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()

    def summary(self) -> str:
        lines = [
            f"broker: {self.broker_name} ({self.broker_id})",
            f"parser: {self.parser_version}",
            f"file: {self.file_name}",
            f"hash: {self.file_hash}",
            f"sheets in workbook: {', '.join(self.sheet_names)}",
            f"normalized transactions: {self.transaction_count}",
        ]
        for section in self.sections:
            lines.append(f"\n  [{section.section}] sheet {section.sheet_name!r}")
            lines.append(f"    rows: {section.row_count}")
            lines.append(f"    columns: {', '.join(section.column_names)}")
            if section.date_columns:
                lines.append(
                    f"    date columns: {', '.join(section.date_columns)}"
                    + (f" [{section.date_format_label}]" if section.date_format_label else "")
                )
            if section.amount_columns:
                lines.append(f"    amount columns: {', '.join(section.amount_columns)}")
            if section.detected_currencies:
                lines.append(f"    currencies: {', '.join(section.detected_currencies)}")
            if section.transaction_categories:
                lines.append(
                    "    transaction categories: "
                    + ", ".join(
                        f"{k} ({v})" for k, v in sorted(section.transaction_categories.items())
                    )
                )
            if section.unknown_categories:
                lines.append(
                    "    UNKNOWN categories: "
                    + ", ".join(
                        f"{k} ({v})" for k, v in sorted(section.unknown_categories.items())
                    )
                )
            if section.columns_with_missing_values:
                lines.append(
                    f"    columns with missing values: "
                    f"{', '.join(section.columns_with_missing_values)}"
                )
            if section.unmapped_columns:
                lines.append(f"    unmapped columns: {', '.join(section.unmapped_columns)}")
        if self.type_counts:
            lines.append("\n  canonical types emitted:")
            for kind, count in sorted(self.type_counts.items()):
                lines.append(f"    {kind}: {count}")
        if self.duplicate_candidate_count:
            lines.append(f"\n  duplicate candidates: {self.duplicate_candidate_count}")
        for warning in self.warnings:
            lines.append(f"\nwarning: {warning}")
        return "\n".join(lines)


@dataclass(slots=True)
class ParseResult:
    """Everything a parse produces."""

    ledger: TransactionLedger
    report: ParserReport
    issues: IssueCollector


# --- cell helpers ---------------------------------------------------------


def cell_text(row: TableRow, spec: FieldSpec) -> str | None:
    return row.text(*spec.aliases)


def cell_decimal(
    row: TableRow,
    spec: FieldSpec,
    *,
    absolute: bool = False,
) -> tuple[Decimal | None, str | None]:
    """Extract a decimal from a cell, returning ``(value, error)``.

    ``absolute`` is used for magnitudes: a broker may write a sale quantity or
    a debit amount as negative, and direction is carried by the transaction
    type rather than by the sign of the magnitude.
    """
    cell = row.cell(*spec.aliases)
    if cell is None or cell.is_empty:
        return None, None
    raw = cell.raw_text if cell.kind is CellKind.NUMBER else cell.text
    try:
        value = opt_decimal(raw, field=spec.name)
    except MoneyError as exc:
        return None, str(exc)
    if value is None:
        return None, None
    return (abs(value) if absolute else value), None


def signed_decimal(row: TableRow, spec: FieldSpec) -> tuple[Decimal | None, str | None]:
    """Extract a decimal keeping its sign, for direction inference."""
    return cell_decimal(row, spec, absolute=False)


class BrokerParser(ABC):
    """Base class for broker statement parsers."""

    #: Stable identifier used in the ledger and in the audit trail.
    broker_id: str = ""
    broker_name: str = ""
    #: Bumped whenever parsing behaviour changes. Recorded on every
    #: transaction so a figure can be traced to the code that produced it.
    parser_version: str = "0.0.0"
    mapping: BrokerFieldMapping

    # --- interface ------------------------------------------------------

    @abstractmethod
    def detect(self, source: LoadedSource) -> DetectionResult:
        """Decide whether this parser recognises ``source``."""

    @abstractmethod
    def normalize(
        self,
        sections: Mapping[Section, ParsedSection],
        source: LoadedSource,
        issues: IssueCollector,
    ) -> TransactionLedger:
        """Map located sections onto the canonical ledger."""

    def validate(self, source: LoadedSource) -> SchemaValidation:
        """Check that every required section and column is present.

        A missing required column is not worked around. The platform reports
        ``BROKER_FORMAT_CHANGED`` and stops, because inferring which of the
        remaining columns now holds a price is exactly the kind of guess that
        produces a plausible, wrong tax figure.
        """
        missing_fields: dict[Section, tuple[str, ...]] = {}
        missing_sections: list[Section] = []
        unmapped: dict[Section, tuple[str, ...]] = {}
        date_formats: dict[str, DateFormatResolution] = {}
        notes: list[str] = []

        for spec in self.mapping.sections:
            sheet = self._find_sheet(source, spec)
            if sheet is None:
                if spec.required:
                    missing_sections.append(spec.section)
                continue
            table = self._extract(sheet, spec)
            if table is None:
                if spec.required:
                    missing_sections.append(spec.section)
                    notes.append(
                        f"sheet {sheet.name!r} was found for {spec.section} but no "
                        f"header row could be located in it"
                    )
                continue

            missing = table.missing_field_groups(spec.required_groups())
            if missing:
                missing_fields[spec.section] = tuple(missing)

            described = {_normalized(alias) for alias in spec.all_aliases()}
            extra = tuple(
                header for header in table.headers if _normalized(header) not in described
            )
            if extra:
                unmapped[spec.section] = extra

            for field_spec in spec.fields:
                if field_spec.kind is not FieldKind.DATE:
                    continue
                resolution = self._resolve_dates(table, field_spec)
                if resolution is not None:
                    date_formats[f"{spec.section}.{field_spec.name}"] = resolution

        unresolved_required_dates = [
            key
            for key, resolution in date_formats.items()
            if not resolution.resolved and resolution.sample_count > 0
        ]

        return SchemaValidation(
            ok=not missing_fields and not missing_sections and not unresolved_required_dates,
            missing_fields=missing_fields,
            missing_sections=tuple(missing_sections),
            unmapped_columns=unmapped,
            date_formats=date_formats,
            notes=tuple(notes),
        )

    # --- section readers -------------------------------------------------

    def parse_trades(self, source: LoadedSource) -> ParsedSection | None:
        return self._parse_section(source, Section.TRADES)

    def parse_income(self, source: LoadedSource) -> ParsedSection | None:
        return self._parse_section(source, Section.INCOME)

    def parse_transfers(self, source: LoadedSource) -> ParsedSection | None:
        return self._parse_section(source, Section.TRANSFERS)

    def parse_account(self, source: LoadedSource) -> ParsedSection | None:
        return self._parse_section(source, Section.ACCOUNT)

    def parse_corporate_actions(self, source: LoadedSource) -> ParsedSection | None:
        return self._parse_section(source, Section.CORPORATE_ACTIONS)

    def parse_holdings(self, source: LoadedSource) -> ParsedSection | None:
        return self._parse_section(source, Section.HOLDINGS)

    def parse_sections(self, source: LoadedSource) -> dict[Section, ParsedSection]:
        sections: dict[Section, ParsedSection] = {}
        for spec in self.mapping.sections:
            parsed = self._parse_section(source, spec.section)
            if parsed is not None:
                sections[spec.section] = parsed
        return sections

    # --- orchestration ---------------------------------------------------

    def parse(self, source: LoadedSource) -> ParseResult:
        """Detect, validate, parse and normalize in one call."""
        detection = self.detect(source)
        if not detection.matched:
            raise ParseError(
                ErrorCode.BROKER_UNIDENTIFIED,
                f"{self.broker_name} parser does not recognise {source.file_name}: "
                + ("; ".join(detection.reasons) or "no expected sections were found"),
            )

        validation = self.validate(source)
        if not validation.ok:
            raise ParseError(
                ErrorCode.BROKER_FORMAT_CHANGED,
                f"{source.file_name} was identified as a {self.broker_name} export, but "
                f"its layout does not match the supported format: "
                f"{validation.failure_message()}",
            )

        issues = IssueCollector()
        sections = self.parse_sections(source)
        ledger = self.normalize(sections, source, issues)

        ledger.report_duplicates(issues)
        ledger.report_unsupported(issues)

        report = self._build_report(source, sections, ledger, validation, issues)
        return ParseResult(ledger=ledger, report=report, issues=issues)

    # --- helpers ---------------------------------------------------------

    def _find_sheet(self, source: LoadedSource, spec: SheetSpec) -> RawSheet | None:
        return source.workbook.find_sheet(*spec.sheet_aliases)

    def _extract(self, sheet: RawSheet, spec: SheetSpec) -> DetectedTable | None:
        return extract_table(
            sheet,
            expected_aliases=spec.required_aliases() or spec.all_aliases(),
            min_columns=min(2, max(1, len(spec.required_aliases()))),
        )

    def _resolve_dates(
        self, table: DetectedTable, field_spec: FieldSpec
    ) -> DateFormatResolution | None:
        """Resolve one date column's layout across the whole column."""
        samples: list[str] = []
        already_dates = 0
        for row in table.rows:
            cell = row.cell(*field_spec.aliases)
            if cell is None or cell.is_empty:
                continue
            if cell.kind is CellKind.DATE:
                # A spreadsheet date cell is unambiguous: the file stored a
                # serial number, not a formatted string.
                already_dates += 1
                continue
            samples.append(cell.text or "")

        if not samples:
            if already_dates:
                return DateFormatResolution(
                    format="SPREADSHEET_SERIAL",
                    label="spreadsheet date serial (unambiguous)",
                    sample_count=already_dates,
                )
            return None

        candidates = self.mapping.date_formats
        return resolve_date_format(
            samples, candidates=candidates
        ) if candidates else resolve_date_format(samples)

    def _parse_section(self, source: LoadedSource, section: Section) -> ParsedSection | None:
        spec = self.mapping.section(section)
        if spec is None:
            return None
        sheet = self._find_sheet(source, spec)
        if sheet is None:
            return None
        table = self._extract(sheet, spec)
        if table is None:
            return None

        date_formats: dict[str, str] = {}
        for field_spec in spec.fields:
            if field_spec.kind is not FieldKind.DATE:
                continue
            resolution = self._resolve_dates(table, field_spec)
            if resolution is not None and resolution.format:
                date_formats[field_spec.name] = resolution.format

        return ParsedSection(
            section=section,
            sheet_name=sheet.name,
            table=table,
            spec=spec,
            date_formats=date_formats,
        )

    # --- row-level extraction -------------------------------------------

    def raw_row(
        self, source: LoadedSource, parsed: ParsedSection, row: TableRow
    ) -> RawTransactionRow:
        """Capture the broker row verbatim, before any interpretation."""
        return RawTransactionRow(
            source_file_id=source.source_file_id,
            source_sheet=parsed.sheet_name,
            source_row=row.row_number,
            values=row.raw_values(),
        )

    def read_date(
        self,
        parsed: ParsedSection,
        row: TableRow,
        field_name: str,
        *,
        issues: IssueCollector | None = None,
        required: bool = True,
    ) -> date | None:
        """Read a date cell under the column's resolved layout."""
        spec = parsed.spec.field(field_name)
        cell = row.cell(*spec.aliases)
        if cell is None or cell.is_empty:
            if required and issues is not None:
                issues.report(
                    ErrorCode.SCHEMA_VALIDATION_FAILED,
                    scope=IssueScope.TRANSACTION,
                    subject=f"{parsed.sheet_name}!row{row.row_number}",
                    message=(
                        f"{parsed.sheet_name} row {row.row_number} has no value in the "
                        f"{spec.aliases[0]!r} column, which is required to place the "
                        f"transaction in a reporting period."
                    ),
                    field=spec.name,
                )
            return None

        if cell.kind is CellKind.DATE and cell.date_value is not None:
            value = cell.date_value
            # A spreadsheet serial may decode to a datetime when the cell
            # carried a time; Schedule FA works in whole days, so drop it.
            return value.date() if isinstance(value, datetime) else value

        layout = parsed.date_formats.get(field_name)
        text = (cell.text or "").strip()
        parsed_date = (
            parse_with_format(text, layout)
            if layout and layout != "SPREADSHEET_SERIAL"
            else None
        )
        if parsed_date is None:
            # Last resort: try every candidate layout for this single cell, and
            # only accept a result when exactly one layout parses it.
            candidates = self.mapping.date_formats or DATE_FORMATS
            hits = {
                parse_with_format(text, fmt)
                for fmt, _label in candidates
                if parse_with_format(text, fmt) is not None
            }
            if len(hits) == 1:
                parsed_date = hits.pop()

        if parsed_date is None and issues is not None:
            issues.report(
                ErrorCode.SCHEMA_VALIDATION_FAILED,
                scope=IssueScope.TRANSACTION,
                subject=f"{parsed.sheet_name}!row{row.row_number}",
                message=(
                    f"{parsed.sheet_name} row {row.row_number} has {text!r} in the "
                    f"{spec.aliases[0]!r} column, which could not be read as a date "
                    f"under an unambiguous layout."
                ),
                field=spec.name,
                value=text,
            )
        return parsed_date

    def read_decimal(
        self,
        parsed: ParsedSection,
        row: TableRow,
        field_name: str,
        *,
        issues: IssueCollector | None = None,
        absolute: bool = True,
        kind: str = "amount",
    ) -> Decimal | None:
        """Read a numeric cell, reporting an unreadable value as an issue."""
        spec = parsed.spec.field(field_name)
        value, error = cell_decimal(row, spec, absolute=absolute)
        if error is not None and issues is not None:
            issues.report(
                ErrorCode.SCHEMA_VALIDATION_FAILED,
                scope=IssueScope.TRANSACTION,
                subject=f"{parsed.sheet_name}!row{row.row_number}",
                message=(
                    f"{parsed.sheet_name} row {row.row_number} has an unreadable "
                    f"{spec.aliases[0]!r} value: {error}"
                ),
                field=spec.name,
            )
            return None
        if value is None:
            return None
        if kind == "quantity":
            return as_quantity(value)
        if kind == "price":
            return as_price(value)
        return as_amount(value)

    def read_text(self, parsed: ParsedSection, row: TableRow, field_name: str) -> str | None:
        return cell_text(row, parsed.spec.field(field_name))

    def make_transaction_id(
        self,
        source: LoadedSource,
        parsed: ParsedSection,
        row: TableRow,
        *,
        suffix: str = "",
    ) -> str:
        """Derive a stable transaction id from the row's location.

        Deterministic rather than random, so re-parsing the same file yields
        the same ids and a re-run can be diffed against a previous one. The
        suffix distinguishes several transactions emitted from one row, such as
        a gross dividend and its withholding tax.
        """
        return derive_id(
            "TXN",
            source.source_file_id,
            parsed.sheet_name,
            row.row_number,
            suffix,
        )

    # --- reporting -------------------------------------------------------

    def _section_report(
        self,
        parsed: ParsedSection,
        validation: SchemaValidation,
        *,
        categories: Mapping[str, int],
        unknown: Mapping[str, int],
    ) -> SectionReport:
        table = parsed.table
        date_columns: list[str] = []
        amount_columns: list[str] = []
        missing_values: list[str] = []
        currencies: set[str] = set()

        for header in table.headers:
            cells: list[RawCell] = [
                row.cells[header] for row in table.rows if header in row.cells
            ]
            populated = [c for c in cells if not c.is_empty]
            if not populated:
                missing_values.append(header)
                continue
            if len(populated) < len(cells):
                missing_values.append(header)
            if sum(1 for c in populated if c.kind is CellKind.DATE) > len(populated) / 2:
                date_columns.append(header)
            elif sum(1 for c in populated if c.kind is CellKind.NUMBER) > len(populated) / 2:
                amount_columns.append(header)

        for field_spec in parsed.spec.fields:
            if field_spec.kind is FieldKind.DATE:
                cell_header = next(
                    (h for h in table.headers if _normalized(h) in
                     {_normalized(a) for a in field_spec.aliases}),
                    None,
                )
                if cell_header and cell_header not in date_columns:
                    date_columns.append(cell_header)

        currency_spec = next(
            (f for f in parsed.spec.fields if f.name == "currency"), None
        )
        if currency_spec is not None:
            for row in table.rows:
                value = row.text(*currency_spec.aliases)
                if value:
                    currencies.add(value.strip().upper())
        if not currencies and self.mapping.default_currency:
            currencies.add(f"{self.mapping.default_currency} (assumed, not stated in file)")

        label_key = next(
            (
                f"{parsed.section}.{f.name}"
                for f in parsed.spec.fields
                if f.kind is FieldKind.DATE
            ),
            None,
        )
        resolution = validation.date_formats.get(label_key or "")

        return SectionReport(
            section=parsed.section,
            sheet_name=parsed.sheet_name,
            row_count=parsed.row_count,
            column_names=tuple(table.headers),
            date_columns=tuple(date_columns),
            amount_columns=tuple(amount_columns),
            detected_currencies=tuple(sorted(currencies)),
            transaction_categories=dict(categories),
            unknown_categories=dict(unknown),
            columns_with_missing_values=tuple(missing_values),
            unmapped_columns=validation.unmapped_columns.get(parsed.section, ()),
            date_format_label=resolution.label if resolution else None,
        )

    def activity_counts(
        self, parsed: ParsedSection
    ) -> tuple[dict[str, int], dict[str, int]]:
        """Count activity labels in a section, split into known and unknown.

        Overridden by parsers that classify activity; the default reports
        nothing rather than inventing a category.
        """
        return {}, {}

    def _build_report(
        self,
        source: LoadedSource,
        sections: Mapping[Section, ParsedSection],
        ledger: TransactionLedger,
        validation: SchemaValidation,
        issues: IssueCollector,
    ) -> ParserReport:
        section_reports: list[SectionReport] = []
        all_unknown: dict[str, int] = {}
        for section in sorted(sections, key=str):
            parsed = sections[section]
            categories, unknown = self.activity_counts(parsed)
            for label, count in unknown.items():
                all_unknown[label] = all_unknown.get(label, 0) + count
            section_reports.append(
                self._section_report(
                    parsed, validation, categories=categories, unknown=unknown
                )
            )

        type_counts: dict[str, int] = {}
        for transaction in ledger.transactions:
            key = str(transaction.transaction_type)
            type_counts[key] = type_counts.get(key, 0) + 1

        warnings = list(source.warnings)
        warnings.extend(validation.notes)
        for section, extra in validation.unmapped_columns.items():
            warnings.append(
                f"{section}: {len(extra)} column(s) in the file are not described by "
                f"the {self.broker_name} mapping and were not read: {', '.join(extra)}"
            )
        if all_unknown:
            warnings.append(
                f"{len(all_unknown)} activity label(s) could not be mapped to a "
                f"canonical transaction type: "
                f"{', '.join(sorted(all_unknown))}. Those rows are retained as UNKNOWN "
                f"and excluded from calculations."
            )

        return ParserReport(
            broker_id=self.broker_id,
            broker_name=self.broker_name,
            parser_version=self.parser_version,
            source_file_id=source.source_file_id,
            file_name=source.file_name,
            file_hash=source.file_hash,
            sheet_names=tuple(source.workbook.sheet_names()),
            sections=tuple(section_reports),
            transaction_count=len(ledger),
            type_counts=type_counts,
            duplicate_candidate_count=len(ledger.find_duplicates()),
            unknown_activity_labels=tuple(sorted(all_unknown)),
            warnings=tuple(dict.fromkeys(warnings)),
        )


def _normalized(text: str) -> str:
    return "".join(ch for ch in text.lower() if ch.isalnum())


def classify_activity(
    label: str | None,
    table: Mapping[str, TransactionType],
    *,
    default: TransactionType = TransactionType.UNKNOWN,
) -> TransactionType:
    """Map a broker activity label to a canonical type.

    Matching is exact on the normalized label first, then by the longest
    matching known label contained in it. Longest-first matters: a table
    containing both ``sell`` and ``sell to cover`` must not classify the latter
    as a plain sale because ``sell`` happens to be a substring.
    """
    if not label:
        return default
    normalized = _normalized(label)
    if not normalized:
        return default
    if normalized in table:
        return table[normalized]
    for known in sorted(table, key=len, reverse=True):
        if known and known in normalized:
            return table[known]
    return default


def build_activity_table(
    entries: Iterable[tuple[Sequence[str], TransactionType]],
) -> dict[str, TransactionType]:
    """Build a normalized activity lookup from declared label groups."""
    table: dict[str, TransactionType] = {}
    for labels, transaction_type in entries:
        for label in labels:
            table[_normalized(label)] = transaction_type
    return table
