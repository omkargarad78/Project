"""The Vested statement parser.

Its entire job is to turn a Vested workbook into the canonical ledger. It knows
nothing about Schedule FA, exchange rates, lots or valuation, and no other
module knows anything about Vested's column names.

Two behaviours in here are worth reading before trusting the output.

**Gross income and withholding tax stay separate.** When an income row carries
both a gross amount and a tax withheld, the parser emits *two* transactions
from that one row: a ``DIVIDEND`` for the gross and a ``WITHHOLDING_TAX`` for
the tax. Both point back at the same source row. A $10 dividend with $1
withheld is never recorded as a $9 dividend.

**Cash movements are not acquisitions.** A deposit funds the cash account and
produces no lot. A transfer of *securities* in is an acquisition and does. The
two are distinguished by whether the row names a security and a quantity, not
by which sheet they came from.
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Mapping
from decimal import Decimal

from ...core.errors import ErrorCode
from ...core.money import ZERO, as_amount, divide, is_effectively_zero, multiply
from ...io.loader import LoadedSource
from ...io.tabular import TableRow, normalize_sheet_name
from ...transactions.ledger import TransactionLedger
from ...transactions.models import NormalizedTransaction, TransactionType, behaviour
from ...validation.issues import IssueCollector, IssueScope
from ..base import (
    BrokerParser,
    DetectionResult,
    ParsedSection,
    Section,
    classify_activity,
)
from .mapping import (
    BROKER_ID,
    BROKER_NAME,
    DEFAULT_CURRENCY,
    VESTED_ACTIVITY_TABLE,
    VESTED_MAPPING,
)

#: Bump on any change to parsing behaviour. Stored on every transaction, so a
#: figure can always be traced to the code version that produced it.
PARSER_VERSION = "vested-parser-1.0.0"

#: Tolerance when checking that quantity x price reconciles to the stated cash
#: amount. Brokers round the reported total, so an exact match is not expected;
#: a difference beyond this is reported rather than absorbed.
AMOUNT_RECONCILIATION_TOLERANCE = Decimal("0.05")


class VestedParser(BrokerParser):
    """Parser for Vested Finance transaction exports."""

    broker_id = BROKER_ID
    broker_name = BROKER_NAME
    parser_version = PARSER_VERSION
    mapping = VESTED_MAPPING

    # --- detection -------------------------------------------------------

    def detect(self, source: LoadedSource) -> DetectionResult:
        """Recognise a Vested export from its structure.

        Detection is structural rather than name-based: a file is recognised
        because it contains the sections and columns a Vested statement has,
        not because "vested" appears in the filename, which an uploader
        controls.
        """
        reasons: list[str] = []
        matched_sections: dict[Section, str] = {}
        confidence = 0

        for spec in self.mapping.sections:
            sheet = source.workbook.find_sheet(*spec.sheet_aliases)
            if sheet is None:
                if spec.required:
                    reasons.append(
                        f"no worksheet matching {spec.section} "
                        f"({', '.join(spec.sheet_aliases[:3])}) was found"
                    )
                continue
            matched_sections[spec.section] = sheet.name
            confidence += 10 if spec.required else 5

            table = self._extract(sheet, spec)
            if table is None:
                reasons.append(f"sheet {sheet.name!r} has no locatable header row")
                continue
            found = len(spec.required_groups()) - len(
                table.missing_field_groups(spec.required_groups())
            )
            confidence += found * 5
            if normalize_sheet_name(sheet.name) in {
                normalize_sheet_name(a) for a in spec.sheet_aliases
            }:
                # An exact sheet-name match is stronger evidence than a loose one.
                confidence += 5

        trades = self.mapping.section(Section.TRADES)
        assert trades is not None
        matched = Section.TRADES in matched_sections

        if matched:
            reasons.append(
                f"found {len(matched_sections)} expected section(s): "
                + ", ".join(f"{k}={v!r}" for k, v in sorted(matched_sections.items(), key=str))
            )

        return DetectionResult(
            broker_id=self.broker_id,
            matched=matched,
            confidence=confidence,
            reasons=tuple(reasons),
            matched_sections=matched_sections,
        )

    # --- activity classification ----------------------------------------

    def classify(self, label: str | None) -> TransactionType:
        return classify_activity(label, VESTED_ACTIVITY_TABLE)

    def activity_counts(
        self, parsed: ParsedSection
    ) -> tuple[dict[str, int], dict[str, int]]:
        """Count the activity labels in a section, split known from unknown."""
        if not any(f.name == "activity" for f in parsed.spec.fields):
            return {}, {}
        known: Counter[str] = Counter()
        unknown: Counter[str] = Counter()
        for row in parsed.table.rows:
            label = self.read_text(parsed, row, "activity")
            if not label:
                unknown["(blank activity)"] += 1
                continue
            if self.classify(label) is TransactionType.UNKNOWN:
                unknown[label] += 1
            else:
                known[label] += 1
        return dict(known), dict(unknown)

    # --- normalization ---------------------------------------------------

    def normalize(
        self,
        sections: Mapping[Section, ParsedSection],
        source: LoadedSource,
        issues: IssueCollector,
    ) -> TransactionLedger:
        ledger = TransactionLedger()

        if Section.TRADES in sections:
            self._normalize_trades(sections[Section.TRADES], source, ledger, issues)
        if Section.INCOME in sections:
            self._normalize_income(sections[Section.INCOME], source, ledger, issues)
        if Section.TRANSFERS in sections:
            self._normalize_transfers(sections[Section.TRANSFERS], source, ledger, issues)

        return ledger

    # --- section normalizers --------------------------------------------

    def _normalize_trades(
        self,
        parsed: ParsedSection,
        source: LoadedSource,
        ledger: TransactionLedger,
        issues: IssueCollector,
    ) -> None:
        for row in parsed.table.rows:
            label = self.read_text(parsed, row, "activity")
            transaction_type = self.classify(label)
            transaction_date = self.read_date(parsed, row, "transaction_date", issues=issues)
            if transaction_date is None:
                continue

            quantity = self.read_decimal(parsed, row, "quantity", issues=issues, kind="quantity")
            price = self.read_decimal(parsed, row, "price", issues=issues, kind="price")
            amount = self.read_decimal(parsed, row, "amount", issues=issues)
            fees = self.read_decimal(parsed, row, "fees", issues=issues)
            ticker = self.read_text(parsed, row, "ticker")
            notes: list[str] = []

            # A broker that states only two of quantity, price and amount lets
            # the third be derived. Deriving is recorded as a parser note so it
            # is never mistaken for a value the broker supplied.
            if amount is None and quantity is not None and price is not None:
                amount = as_amount(multiply(quantity, price))
                notes.append(
                    "gross amount was not stated in the file; derived as quantity x price"
                )
            elif price is None and amount is not None and quantity is not None:
                if not is_effectively_zero(quantity):
                    price = as_amount(divide(amount, quantity))
                    notes.append(
                        "price per share was not stated in the file; derived as "
                        "gross amount / quantity"
                    )
            elif quantity is None and amount is not None and price is not None:
                if price != 0:
                    quantity = as_amount(divide(amount, price))
                    notes.append(
                        "quantity was not stated in the file; derived as "
                        "gross amount / price per share"
                    )

            if (
                quantity is not None
                and price is not None
                and amount is not None
                and not is_effectively_zero(quantity)
            ):
                expected = multiply(quantity, price)
                difference = abs(expected - amount)
                if difference > AMOUNT_RECONCILIATION_TOLERANCE and difference > (
                    amount * Decimal("0.01")
                ):
                    notes.append(
                        f"quantity x price is {expected}, which differs from the stated "
                        f"amount {amount} by {difference}"
                    )

            if transaction_type is not TransactionType.UNKNOWN:
                info = behaviour(transaction_type)
                if info.security_scoped and not ticker:
                    issues.report(
                        ErrorCode.SCHEMA_VALIDATION_FAILED,
                        scope=IssueScope.TRANSACTION,
                        subject=f"{parsed.sheet_name}!row{row.row_number}",
                        message=(
                            f"{parsed.sheet_name} row {row.row_number} is a "
                            f"{transaction_type} but names no ticker, so it cannot be "
                            f"attributed to a security."
                        ),
                    )
                if info.quantity_sign != 0 and (
                    quantity is None or is_effectively_zero(quantity)
                ):
                    issues.report(
                        ErrorCode.SCHEMA_VALIDATION_FAILED,
                        scope=IssueScope.TRANSACTION,
                        subject=f"{parsed.sheet_name}!row{row.row_number}",
                        message=(
                            f"{parsed.sheet_name} row {row.row_number} is a "
                            f"{transaction_type} with no quantity, so holdings cannot "
                            f"be reconstructed from it."
                        ),
                    )

            self._emit(
                ledger=ledger,
                source=source,
                parsed=parsed,
                row=row,
                transaction_type=transaction_type,
                raw_activity=label,
                transaction_date=transaction_date,
                quantity=quantity,
                price=price,
                gross_amount=amount,
                fees=fees,
                notes=notes,
            )

    def _normalize_income(
        self,
        parsed: ParsedSection,
        source: LoadedSource,
        ledger: TransactionLedger,
        issues: IssueCollector,
    ) -> None:
        for row in parsed.table.rows:
            label = self.read_text(parsed, row, "activity")
            transaction_date = self.read_date(parsed, row, "transaction_date", issues=issues)
            if transaction_date is None:
                continue

            gross = self.read_decimal(parsed, row, "gross_amount", issues=issues)
            tax = self.read_decimal(parsed, row, "withholding_tax", issues=issues)
            net = self.read_decimal(parsed, row, "net_amount", issues=issues)

            transaction_type = self.classify(label)
            if transaction_type is TransactionType.UNKNOWN and label is None:
                # An income sheet with no activity column is dividend activity
                # by construction, but that inference is recorded, not silent.
                transaction_type = TransactionType.DIVIDEND

            notes: list[str] = []

            # Reconstruct the gross figure when the file states only net and tax.
            if gross is None and net is not None and tax is not None:
                gross = as_amount(net + tax)
                notes.append(
                    "gross income was not stated in the file; derived as "
                    "net credit + tax withheld"
                )
            elif gross is None and net is not None:
                gross = net
                notes.append(
                    "the file states only a net amount and no tax withheld, so the "
                    "gross income is taken to equal the net amount"
                )

            if (
                gross is not None
                and net is not None
                and tax is not None
                and abs((gross - tax) - net) > AMOUNT_RECONCILIATION_TOLERANCE
            ):
                notes.append(
                    f"gross {gross} less tax {tax} is {gross - tax}, which does not "
                    f"equal the stated net {net}"
                )

            is_tax_row = transaction_type is TransactionType.WITHHOLDING_TAX
            if is_tax_row:
                # A standalone withholding-tax row: the amount IS the tax.
                amount = gross if gross is not None else tax
                self._emit(
                    ledger=ledger,
                    source=source,
                    parsed=parsed,
                    row=row,
                    transaction_type=TransactionType.WITHHOLDING_TAX,
                    raw_activity=label,
                    transaction_date=transaction_date,
                    gross_amount=amount,
                    taxes=amount,
                    notes=notes,
                )
                continue

            if gross is None and tax is None:
                issues.report(
                    ErrorCode.SCHEMA_VALIDATION_FAILED,
                    scope=IssueScope.TRANSACTION,
                    subject=f"{parsed.sheet_name}!row{row.row_number}",
                    message=(
                        f"{parsed.sheet_name} row {row.row_number} has neither an income "
                        f"amount nor a tax withheld, so nothing can be recorded from it."
                    ),
                )
                continue

            if gross is not None:
                self._emit(
                    ledger=ledger,
                    source=source,
                    parsed=parsed,
                    row=row,
                    transaction_type=transaction_type,
                    raw_activity=label,
                    transaction_date=transaction_date,
                    gross_amount=gross,
                    # The tax is carried on the income row so the row's cash
                    # effect is correct, AND emitted as its own transaction so
                    # the foreign tax is separately reportable.
                    taxes=tax,
                    net_amount=net,
                    notes=notes,
                    suffix="income",
                )

            if tax is not None and not is_effectively_zero(tax, scale=2):
                self._emit(
                    ledger=ledger,
                    source=source,
                    parsed=parsed,
                    row=row,
                    transaction_type=TransactionType.WITHHOLDING_TAX,
                    raw_activity=label,
                    transaction_date=transaction_date,
                    gross_amount=tax,
                    taxes=tax,
                    notes=[
                        "foreign tax withheld at source, recorded separately from the "
                        "gross income on the same broker row"
                    ],
                    suffix="withholding",
                )

    def _normalize_transfers(
        self,
        parsed: ParsedSection,
        source: LoadedSource,
        ledger: TransactionLedger,
        issues: IssueCollector,
    ) -> None:
        for row in parsed.table.rows:
            label = self.read_text(parsed, row, "activity")
            transaction_date = self.read_date(parsed, row, "transaction_date", issues=issues)
            if transaction_date is None:
                continue

            amount = self.read_decimal(parsed, row, "amount", issues=issues)
            fees = self.read_decimal(parsed, row, "fees", issues=issues)
            ticker = self.read_text(parsed, row, "ticker")
            quantity = self.read_decimal(parsed, row, "quantity", issues=issues, kind="quantity")
            transaction_type = self.classify(label)
            notes: list[str] = []

            # Direction from the sign when the label alone does not say. A
            # transfer sheet commonly uses one label with a signed amount.
            if transaction_type is TransactionType.UNKNOWN:
                spec = parsed.spec.field("amount")
                cell = row.cell(*spec.aliases)
                signed = None
                if cell is not None and not cell.is_empty:
                    from ..base import signed_decimal

                    signed, _error = signed_decimal(row, spec)
                if signed is not None and ticker is None:
                    transaction_type = (
                        TransactionType.DEPOSIT if signed > 0 else TransactionType.WITHDRAWAL
                    )
                    notes.append(
                        f"the activity label {label!r} is not in the mapping; direction "
                        f"was taken from the sign of the amount"
                    )

            # A securities transfer names a security and a quantity; a cash
            # movement does not. Sheet membership alone does not decide it.
            if (
                ticker
                and quantity is not None
                and not is_effectively_zero(quantity)
                and transaction_type
                in (TransactionType.DEPOSIT, TransactionType.WITHDRAWAL)
            ):
                transaction_type = (
                    TransactionType.TRANSFER_IN
                    if transaction_type is TransactionType.DEPOSIT
                    else TransactionType.TRANSFER_OUT
                )
                notes.append(
                    "this row names a security and a quantity, so it is treated as a "
                    "securities transfer rather than a cash movement"
                )

            self._emit(
                ledger=ledger,
                source=source,
                parsed=parsed,
                row=row,
                transaction_type=transaction_type,
                raw_activity=label,
                transaction_date=transaction_date,
                quantity=quantity,
                gross_amount=amount,
                fees=fees,
                notes=notes,
            )

    # --- emission --------------------------------------------------------

    def _emit(
        self,
        *,
        ledger: TransactionLedger,
        source: LoadedSource,
        parsed: ParsedSection,
        row: TableRow,
        transaction_type: TransactionType,
        raw_activity: str | None,
        transaction_date,  # noqa: ANN001 - datetime.date
        quantity: Decimal | None = None,
        price: Decimal | None = None,
        gross_amount: Decimal | None = None,
        fees: Decimal | None = None,
        taxes: Decimal | None = None,
        net_amount: Decimal | None = None,
        notes: list[str] | None = None,
        suffix: str = "",
    ) -> None:
        raw = self.raw_row(source, parsed, row)
        currency = (self.read_text(parsed, row, "currency") or "").strip().upper()
        note_list = list(notes or [])
        if not currency:
            currency = DEFAULT_CURRENCY
            note_list.append(
                f"the file states no currency for this row; {DEFAULT_CURRENCY} was "
                f"applied as the declared default for this broker"
            )

        settlement_date = None
        if any(f.name == "settlement_date" for f in parsed.spec.fields):
            settlement_date = self.read_date(parsed, row, "settlement_date", required=False)

        if net_amount is None and gross_amount is not None:
            info = behaviour(transaction_type)
            if info.cash_sign > 0:
                net_amount = as_amount(gross_amount - (fees or ZERO) - (taxes or ZERO))
            elif info.cash_sign < 0:
                net_amount = as_amount(gross_amount + (fees or ZERO) + (taxes or ZERO))

        transaction = NormalizedTransaction(
            source_file_id=source.source_file_id,
            source_sheet=parsed.sheet_name,
            source_row=row.row_number,
            raw_data_hash=raw.raw_data_hash,
            source_reference=raw.source_reference,
            broker=self.broker_id,
            parser_version=self.parser_version,
            transaction_id=self.make_transaction_id(source, parsed, row, suffix=suffix),
            broker_transaction_id=self.read_text(parsed, row, "broker_transaction_id")
            if any(f.name == "broker_transaction_id" for f in parsed.spec.fields)
            else None,
            transaction_type=transaction_type,
            raw_activity=raw_activity,
            transaction_date=transaction_date,
            settlement_date=settlement_date,
            ticker=(self.read_text(parsed, row, "ticker") or None)
            if any(f.name == "ticker" for f in parsed.spec.fields)
            else None,
            security_name=self.read_text(parsed, row, "security_name")
            if any(f.name == "security_name" for f in parsed.spec.fields)
            else None,
            security_identifier=None,
            currency=currency,
            quantity=quantity,
            price_native=price,
            gross_amount_native=gross_amount,
            fees_native=fees,
            taxes_native=taxes,
            net_amount_native=net_amount,
            account_id=self.read_text(parsed, row, "account_id")
            if any(f.name == "account_id" for f in parsed.spec.fields)
            else None,
            description=self.read_text(parsed, row, "description")
            if any(f.name == "description" for f in parsed.spec.fields)
            else None,
            parser_notes=tuple(note_list),
        )
        ledger.add(transaction, raw)

    # --- broker-stated balances -----------------------------------------

    def broker_closing_cash(
        self, sections: Mapping[Section, ParsedSection]
    ) -> Decimal | None:
        """The closing cash balance the account sheet states, if any.

        Used only for reconciliation. It is never treated as a transaction and
        never used in place of a computed figure.
        """
        parsed = sections.get(Section.ACCOUNT)
        if parsed is None or not any(f.name == "cash_balance" for f in parsed.spec.fields):
            return None
        for row in reversed(parsed.table.rows):
            value = self.read_decimal(parsed, row, "cash_balance", absolute=False)
            if value is not None:
                return value
        return None

    def broker_closing_holdings(
        self, sections: Mapping[Section, ParsedSection]
    ) -> dict[str, Decimal]:
        """Broker-stated closing quantities per ticker, for reconciliation."""
        parsed = sections.get(Section.ACCOUNT)
        if parsed is None:
            return {}
        if not any(f.name == "holding_quantity" for f in parsed.spec.fields):
            return {}
        holdings: dict[str, Decimal] = {}
        for row in parsed.table.rows:
            ticker = self.read_text(parsed, row, "ticker")
            quantity = self.read_decimal(
                parsed, row, "holding_quantity", absolute=False, kind="quantity"
            )
            if ticker and quantity is not None:
                holdings[ticker.strip().upper()] = quantity
        return holdings
