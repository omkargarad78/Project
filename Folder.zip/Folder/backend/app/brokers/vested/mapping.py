"""Declarative description of the Vested transaction export.

IMPORTANT - CONFIRM AGAINST THE ACTUAL WORKBOOK
-----------------------------------------------
The alias lists below describe the sheets and columns a Vested export is
expected to contain. They were authored without the actual workbook available,
so they are deliberately written as *alias sets* rather than fixed column
names, and the parser validates what it finds instead of assuming.

Before relying on output from this parser, run::

    python -m backend.app.cli inspect-broker <path to the Vested workbook>

That prints the real sheet names, the real column headers, every distinct
activity label and the date layout found in the file. Any header the mapping
does not describe is reported as an unmapped column, and any required column
that is absent raises ``BROKER_FORMAT_CHANGED`` rather than being guessed at.
Add the real spellings to the alias tuples here; no parsing code changes.

The activity table is the other thing to confirm. Every label Vested actually
uses must appear in ``VESTED_ACTIVITY_TABLE``. A label that is absent becomes
``UNKNOWN``: the row is preserved, flagged, and excluded from calculations, and
it escalates to a blocking error if it carries a quantity.
"""

from __future__ import annotations

from ...transactions.models import TransactionType
from ..base import (
    BrokerFieldMapping,
    FieldKind,
    FieldSpec,
    Section,
    SheetSpec,
    build_activity_table,
    required_in,
)

BROKER_ID = "vested"
BROKER_NAME = "Vested Finance"

#: Vested reports a US brokerage account, so amounts are expected in USD. The
#: parser still prefers a currency column when the export supplies one, and
#: records that the currency was assumed when it does not.
DEFAULT_CURRENCY = "USD"

#: Date layouts to consider. Narrower than the global candidate list, which
#: reduces the chance of an unresolvable ambiguity; a layout outside this set
#: causes a reported failure rather than a wrong reading.
VESTED_DATE_FORMATS: tuple[tuple[str, str], ...] = (
    ("%Y-%m-%d", "ISO 8601 (YYYY-MM-DD)"),
    ("%d-%m-%Y", "day-month-year (DD-MM-YYYY)"),
    ("%d/%m/%Y", "day/month/year (DD/MM/YYYY)"),
    ("%m/%d/%Y", "month/day/year (MM/DD/YYYY)"),
    ("%d-%b-%Y", "day-abbreviated month-year (DD-Mon-YYYY)"),
    ("%b %d, %Y", "abbreviated month day, year (Mon DD, YYYY)"),
)

# --- field definitions ----------------------------------------------------

_TRADE_DATE = FieldSpec(
    name="transaction_date",
    aliases=(
        "Transaction Date",
        "Trade Date",
        "Date",
        "Txn Date",
        "Executed At",
        "Order Date",
    ),
    kind=FieldKind.DATE,
    required=True,
)

_SETTLEMENT_DATE = FieldSpec(
    name="settlement_date",
    aliases=("Settlement Date", "Settled Date", "Settle Date"),
    kind=FieldKind.DATE,
)

_ACTIVITY = FieldSpec(
    name="activity",
    aliases=("Activity", "Transaction Type", "Type", "Action", "Activity Type", "Side"),
    required=True,
    notes="Mapped to a canonical transaction type via VESTED_ACTIVITY_TABLE.",
)

#: Whether a ticker is required depends on the section: a trade must name one,
#: a cash deposit has none. Sections apply `required_in` where it applies.
_TICKER = FieldSpec(
    name="ticker",
    aliases=("Ticker", "Symbol", "Stock Symbol", "Security Symbol", "Scrip"),
)

_SECURITY_NAME = FieldSpec(
    name="security_name",
    aliases=(
        "Company Name",
        "Security Name",
        "Company",
        "Name",
        "Stock Name",
        "Description",
    ),
    notes=(
        "The broker's display name. This is NOT treated as the legal entity name "
        "for Schedule FA; the security master supplies that."
    ),
)

_QUANTITY = FieldSpec(
    name="quantity",
    aliases=("Quantity", "Shares", "Units", "No. of Shares", "Qty"),
    kind=FieldKind.DECIMAL,
    notes="Fractional shares are preserved to full precision.",
)

_PRICE = FieldSpec(
    name="price",
    aliases=(
        "Price Per Share",
        "Price / Share",
        "Price",
        "Share Price",
        "Execution Price",
        "Avg Price",
    ),
    kind=FieldKind.DECIMAL,
)

_CASH_AMOUNT = FieldSpec(
    name="amount",
    aliases=(
        "Cash Amount",
        "Amount",
        "Total Amount",
        "Gross Amount",
        "Value",
        "Net Amount",
        "Total",
    ),
    kind=FieldKind.DECIMAL,
)

_FEES = FieldSpec(
    name="fees",
    aliases=("Commission", "Fees", "Commission/Fees", "Brokerage", "Charges", "Fee"),
    kind=FieldKind.DECIMAL,
)

_CURRENCY = FieldSpec(
    name="currency",
    aliases=("Currency", "Currency Code", "Ccy"),
)

_ACCOUNT = FieldSpec(
    name="account_id",
    aliases=("Account", "Account Number", "Account ID", "Account No"),
)

_BROKER_TXN_ID = FieldSpec(
    name="broker_transaction_id",
    aliases=(
        "Transaction ID",
        "Reference",
        "Reference Number",
        "Order ID",
        "Confirmation Number",
        "ID",
    ),
)

_DESCRIPTION = FieldSpec(
    name="description",
    aliases=("Description", "Narration", "Remarks", "Notes", "Particulars"),
)

# --- income-specific fields ----------------------------------------------

_GROSS_DIVIDEND = FieldSpec(
    name="gross_amount",
    aliases=(
        "Gross Amount",
        "Dividend Amount",
        "Gross Dividend",
        "Amount",
        "Dividend",
        "Income Amount",
    ),
    kind=FieldKind.DECIMAL,
    notes=(
        "The GROSS amount before foreign tax withheld. Never the net credit: a "
        "$10 dividend with $1 withheld is recorded as gross 10, tax 1, net 9."
    ),
)

_WITHHOLDING_TAX = FieldSpec(
    name="withholding_tax",
    aliases=(
        "Tax Withheld",
        "Withholding Tax",
        "Tax",
        "US Tax",
        "Federal Tax Withheld",
        "TDS",
        "Foreign Tax",
    ),
    kind=FieldKind.DECIMAL,
    notes="Foreign tax withheld at source, kept separate from the gross income.",
)

_NET_AMOUNT = FieldSpec(
    name="net_amount",
    aliases=("Net Amount", "Net Credit", "Net", "Amount Credited", "Net Dividend"),
    kind=FieldKind.DECIMAL,
)

# --- account-specific fields ---------------------------------------------

_CASH_BALANCE = FieldSpec(
    name="cash_balance",
    aliases=("Cash Balance", "Closing Balance", "Balance", "Available Cash", "Cash"),
    kind=FieldKind.DECIMAL,
)

_HOLDING_QUANTITY = FieldSpec(
    name="holding_quantity",
    aliases=("Quantity", "Shares", "Units", "Holding", "Qty Held"),
    kind=FieldKind.DECIMAL,
)

_AS_OF_DATE = FieldSpec(
    name="as_of_date",
    aliases=("As Of", "As On", "Date", "Statement Date", "As Of Date"),
    kind=FieldKind.DATE,
)


VESTED_MAPPING = BrokerFieldMapping(
    broker_id=BROKER_ID,
    date_formats=VESTED_DATE_FORMATS,
    default_currency=DEFAULT_CURRENCY,
    sections=(
        SheetSpec(
            section=Section.TRADES,
            sheet_aliases=(
                "Trades",
                "Trade",
                "Transactions",
                "Trade History",
                "Orders",
                "Equity Transactions",
            ),
            required=True,
            fields=(
                _TRADE_DATE,
                _SETTLEMENT_DATE,
                _ACTIVITY,
                required_in(_TICKER),
                _SECURITY_NAME,
                _QUANTITY,
                _PRICE,
                _CASH_AMOUNT,
                _FEES,
                _CURRENCY,
                _ACCOUNT,
                _BROKER_TXN_ID,
                _DESCRIPTION,
            ),
            notes="Buys, sells and other security-level activity.",
        ),
        SheetSpec(
            section=Section.INCOME,
            sheet_aliases=(
                "Income",
                "Dividends",
                "Dividend",
                "Income History",
                "Corporate Income",
            ),
            fields=(
                _TRADE_DATE,
                _ACTIVITY,
                _TICKER,
                _SECURITY_NAME,
                _GROSS_DIVIDEND,
                _WITHHOLDING_TAX,
                _NET_AMOUNT,
                _CURRENCY,
                _ACCOUNT,
                _BROKER_TXN_ID,
                _DESCRIPTION,
            ),
            notes="Dividends and interest, with foreign tax withheld at source.",
        ),
        SheetSpec(
            section=Section.TRANSFERS,
            sheet_aliases=(
                "Transfers",
                "Transfer",
                "Fund Transfers",
                "Deposits",
                "Cash Transfers",
                "Funding",
            ),
            fields=(
                _TRADE_DATE,
                _ACTIVITY,
                _CASH_AMOUNT,
                _FEES,
                _CURRENCY,
                _ACCOUNT,
                _BROKER_TXN_ID,
                _DESCRIPTION,
                _TICKER,
                _QUANTITY,
            ),
            notes=(
                "Cash deposits and withdrawals, and security transfers in or out. "
                "A cash deposit funds the account and is NOT an acquisition."
            ),
        ),
        SheetSpec(
            section=Section.ACCOUNT,
            sheet_aliases=("Account", "My Account", "Account Summary", "Summary", "Portfolio"),
            fields=(
                _ACCOUNT,
                _AS_OF_DATE,
                _CASH_BALANCE,
                _TICKER,
                _SECURITY_NAME,
                _HOLDING_QUANTITY,
                _CURRENCY,
            ),
            notes=(
                "Account identity and broker-stated closing balances, used for "
                "reconciliation rather than as transactions."
            ),
        ),
    ),
)


#: Activity labels to canonical transaction types.
#:
#: Ordering within a group does not matter; matching is exact on the normalized
#: label first, then by the longest contained label, so "sell to cover" cannot
#: be swallowed by "sell".
VESTED_ACTIVITY_TABLE = build_activity_table(
    [
        (
            ("Buy", "Bought", "Purchase", "Purchased", "BUY", "Market Buy", "Limit Buy"),
            TransactionType.BUY,
        ),
        (
            ("Sell", "Sold", "Sale", "SELL", "Market Sell", "Limit Sell", "Redemption"),
            TransactionType.SELL,
        ),
        (
            ("Dividend", "Cash Dividend", "Dividend Received", "Div", "Ordinary Dividend"),
            TransactionType.DIVIDEND,
        ),
        (("Interest", "Interest Received", "Interest Credit"), TransactionType.INTEREST),
        (
            (
                "Withholding Tax",
                "Tax Withheld",
                "Dividend Tax",
                "US Withholding Tax",
                "Federal Tax Withholding",
                "NRA Withholding",
            ),
            TransactionType.WITHHOLDING_TAX,
        ),
        (
            (
                "Deposit",
                "Cash Deposit",
                "Funds Added",
                "Add Funds",
                "ACH Deposit",
                "Wire In",
                "Remittance In",
                "Funding",
            ),
            TransactionType.DEPOSIT,
        ),
        (
            (
                "Withdrawal",
                "Cash Withdrawal",
                "Funds Withdrawn",
                "Withdraw",
                "ACH Withdrawal",
                "Wire Out",
                "Remittance Out",
            ),
            TransactionType.WITHDRAWAL,
        ),
        (
            ("Fee", "Commission", "Brokerage Fee", "Account Fee", "Transaction Fee", "Charges"),
            TransactionType.FEE,
        ),
        (("Tax", "Other Tax", "Regulatory Fee Tax"), TransactionType.TAX),
        (
            ("Stock Split", "Split", "Forward Split", "Reverse Split", "Share Split"),
            TransactionType.STOCK_SPLIT,
        ),
        (("Merger", "Stock Merger", "Acquisition", "Amalgamation"), TransactionType.STOCK_MERGER),
        (("Spinoff", "Spin Off", "Spin-off", "Demerger"), TransactionType.SPINOFF),
        (
            ("Transfer In", "Shares Received", "Incoming Transfer", "ACATS In", "Received"),
            TransactionType.TRANSFER_IN,
        ),
        (
            ("Transfer Out", "Shares Delivered", "Outgoing Transfer", "ACATS Out", "Delivered"),
            TransactionType.TRANSFER_OUT,
        ),
        (("RSU Vest", "Vesting", "RSU Vesting", "Stock Vest"), TransactionType.RSU_VEST),
        (("RSU Sale", "Sell To Cover", "Sale Of Vested Shares"), TransactionType.RSU_SALE),
        (("ESPP Purchase", "ESPP", "Employee Stock Purchase"), TransactionType.ESPP_PURCHASE),
        (
            ("Option Exercise", "Option Assignment", "Option Expiry", "Option"),
            TransactionType.OPTION_EVENT,
        ),
    ]
)
