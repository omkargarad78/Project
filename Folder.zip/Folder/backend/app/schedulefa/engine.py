"""Computing Schedule FA Tables A2 and A3.

Each reported field is converted under *its own* rule. That is not
over-engineering: the rule version says which date's exchange rate applies to
each field, and they differ. Closing value uses the period-end rate; a
dividend uses the rate for the day it was credited; peak value uses the rate
for whichever day the peak fell on. Applying one rate to everything would be
simpler and wrong.

The peak deserves a note, because it is the field most easily got wrong. Peak
value is the highest *rupee* value the holding reached, which is not the same
as the highest foreign-currency value converted at some rate. A holding can
peak in dollars in June and in rupees in November, if the rupee weakened in
between. So the engine values the holding in rupees on every priced day it was
held and takes the maximum of those, rather than finding the dollar peak and
converting it once.
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import date, timedelta
from decimal import Decimal

from ..core.errors import ErrorCode
from ..core.money import ZERO, Rounding, as_amount, decimal_to_str, is_effectively_zero
from ..fx.resolver import FxResolver
from ..lots.engine import LotBook, SecurityPosition
from ..marketdata.dataset import MarketDataSnapshot
from ..marketdata.provider import PriceResolver
from ..securities.models import Security
from ..securities.resolver import ResolutionReport
from ..tax.periods import ReportingPeriod
from ..tax.rules.models import (
    CalculationPolicy,
    FieldValuationRule,
    PeakValuationFrequency,
    PriceValuationPoint,
    RelevantDateRule,
    RoundingRule,
    TaxRuleVersion,
)
from ..transactions.ledger import TransactionLedger
from ..transactions.models import NormalizedTransaction, TransactionType
from ..validation.issues import IssueCollector, IssueScope
from .models import (
    ComputedFigure,
    FigureStatus,
    ScheduleFaReport,
    TableA2Row,
    TableA3Row,
    TextField,
    ValuationPoint,
)

_ROUNDING = {
    RoundingRule.HALF_UP: Rounding.HALF_UP,
    RoundingRule.HALF_EVEN: Rounding.HALF_EVEN,
    RoundingRule.DOWN: Rounding.DOWN,
}

#: The subject every issue about the custodial account is filed under, and the
#: subject the Table A2 row reports itself as. One constant, because matching a
#: blank field to the issue explaining it depends on the two agreeing.
_CASH_ACCOUNT_SUBJECT = "cash account"


def _missing(field_name: str, label: str, reason: str) -> TextField:
    return TextField(
        field_name=field_name, label=label, value=None, explanation=reason,
        caveats=(reason,),
    )


class ScheduleFaEngine:
    """Builds Schedule FA tables from the reconstructed position."""

    def __init__(
        self,
        *,
        rule: TaxRuleVersion,
        period: ReportingPeriod,
        fx: FxResolver,
        market_data: MarketDataSnapshot,
        price_resolver: PriceResolver,
        policy: CalculationPolicy | None = None,
    ) -> None:
        self.rule = rule
        self.period = period
        self.fx = fx
        self.market_data = market_data
        self.prices = price_resolver
        self.policy = policy or CalculationPolicy()
        self.schedule = rule.schedule_fa

    # --- helpers ---------------------------------------------------------

    @property
    def _rounding(self) -> Rounding:
        return _ROUNDING[self.schedule.output_rounding]

    @property
    def _places(self) -> int:
        return self.schedule.output_decimal_places

    def _rule_caveats(self) -> tuple[str, ...]:
        """The label every figure carries while the rule version is unconfirmed.

        Attached to figures individually rather than to the report as a whole,
        because a figure can be copied out of the report and must carry its
        own provenance with it.
        """
        if self.rule.is_verified:
            return ()
        return (
            f"the rule version {self.rule.rule_version_id} has not been verified "
            f"against the published form for assessment year "
            f"{self.rule.assessment_year}",
        )

    def _relevant_date(
        self,
        rule: FieldValuationRule,
        *,
        transaction_date: date | None = None,
        valuation_date: date | None = None,
    ) -> date:
        """Which date's exchange rate applies, per the rule version."""
        if rule.relevant_date is RelevantDateRule.PERIOD_END_DATE:
            return self.period.end_date
        if rule.relevant_date is RelevantDateRule.VALUATION_DATE:
            if valuation_date is None:
                raise ValueError(
                    "this field's rule uses the valuation date, but none was supplied"
                )
            return valuation_date
        if rule.relevant_date is RelevantDateRule.PRECEDING_MONTH_END:
            anchor = valuation_date or transaction_date or self.period.end_date
            return anchor.replace(day=1) - timedelta(days=1)
        if transaction_date is None:
            raise ValueError(
                "this field's rule uses the transaction date, but none was supplied"
            )
        return transaction_date

    def _convert(
        self,
        field_name: str,
        label: str,
        native: Decimal,
        currency: str,
        rule: FieldValuationRule,
        issues: IssueCollector,
        *,
        subject: str,
        explanation: str,
        caveats: Sequence[str] = (),
        transaction_date: date | None = None,
        valuation_date: date | None = None,
        valuation_points: tuple[ValuationPoint, ...] = (),
    ) -> ComputedFigure:
        rate_date = self._relevant_date(
            rule, transaction_date=transaction_date, valuation_date=valuation_date
        )
        conversion = self.fx.convert_and_report(
            native,
            currency,
            rate_date,
            rule,
            issues,
            subject=subject,
            context_label=label,
            rounding=self._rounding,
            decimal_places=self._places,
        )
        extra = [*caveats, *self._rule_caveats()]
        return ComputedFigure.from_conversion(
            field_name,
            label,
            conversion,
            explanation=explanation,
            caveats=tuple(dict.fromkeys(extra)),
            valuation_points=valuation_points,
        )

    # --- valuation -------------------------------------------------------

    def _valuation_dates(self, position: SecurityPosition) -> list[date]:
        """Dates on which the holding is revalued while searching for a peak.

        Every priced day by default. Coarser frequencies exist because a
        sparse price dataset may not support daily valuation, and they are
        labelled on the output: a month-end peak is a different figure from a
        daily peak, and usually a lower one.
        """
        assert position.timeline is not None
        start, end = self.period.start_date, self.period.end_date
        frequency = self.policy.peak_valuation_frequency

        if frequency is PeakValuationFrequency.EVERY_PRICED_DAY:
            candidates = self.market_data.trading_days_between(start, end)
        elif frequency is PeakValuationFrequency.MONTH_END:
            candidates = _period_ends(start, end, months=1)
        else:
            candidates = _period_ends(start, end, months=3)

        # Every date the holding changed is also a valuation point. A peak
        # can fall on a purchase date, and omitting it would understate.
        change_dates = position.timeline.change_dates(start, end)
        return sorted(set(candidates) | set(change_dates))

    def _price_type(self):  # noqa: ANN202 - PriceType
        from ..marketdata.models import PriceType

        return {
            PriceValuationPoint.DAILY_CLOSE: PriceType.CLOSE,
            PriceValuationPoint.DAILY_HIGH: PriceType.HIGH,
            PriceValuationPoint.DAILY_LOW: PriceType.LOW,
            PriceValuationPoint.DAILY_OPEN: PriceType.OPEN,
            PriceValuationPoint.DAILY_AVERAGE_HIGH_LOW: PriceType.CLOSE,
        }[self.policy.price_valuation_point]

    def _value_on(
        self,
        position: SecurityPosition,
        day: date,
        currency: str,
        *,
        intraday_peak: bool = False,
    ) -> tuple[ValuationPoint | None, str | None]:
        """Value the holding on one date, or explain why it cannot be valued.

        ``intraday_peak`` selects the most shares held at any point during the
        day rather than the closing balance. Peak value wants the former,
        closing value the latter.
        """
        assert position.timeline is not None
        quantity = (
            position.timeline.peak_quantity_on(day)
            if intraday_peak
            else position.timeline.quantity_on(day)
        )
        if is_effectively_zero(quantity):
            return None, None

        resolution = self.prices.resolve(position.symbol, day, currency=currency)
        if not resolution.usable or resolution.price is None:
            return None, resolution.explanation

        return (
            ValuationPoint(
                valuation_date=day,
                quantity=quantity,
                price_native=resolution.price,
                currency=resolution.currency or currency,
                value_native=as_amount(quantity * resolution.price),
                price_date=resolution.price_date or day,
                price_carried_forward_days=resolution.staleness_days,
            ),
            None,
        )

    # --- Table A3 fields -------------------------------------------------

    def _peak_value(
        self,
        position: SecurityPosition,
        currency: str,
        issues: IssueCollector,
    ) -> ComputedFigure:
        """The highest rupee value the holding reached during the period.

        Converted per valuation date and compared in rupees. Finding the peak
        in dollars and converting it once would give a different, wrong answer
        whenever the exchange rate moved: a holding can peak in dollars in one
        month and in rupees in another.
        """
        rule = self.schedule.peak_value
        points: list[ValuationPoint] = []
        failures: list[str] = []

        for day in self._valuation_dates(position):
            point, failure = self._value_on(
                position, day, currency, intraday_peak=True
            )
            if point is not None:
                points.append(point)
            elif failure is not None:
                failures.append(f"{day.isoformat()}: {failure}")

        if not points:
            reason = (
                f"{position.symbol} could not be valued on any date in the "
                f"reporting period."
                + (f" First problem: {failures[0]}" if failures else "")
            )
            issues.report(
                ErrorCode.CALCULATION_INCOMPLETE,
                scope=IssueScope.CALCULATION,
                subject=position.symbol,
                message=reason,
            )
            return ComputedFigure.unavailable("peak_value", "Peak Value", reason)

        best: tuple[Decimal, ValuationPoint, object] | None = None
        for point in points:
            conversion = self.fx.convert(
                point.value_native,
                point.currency,
                self._relevant_date(rule, valuation_date=point.valuation_date),
                rule,
                rounding=self._rounding,
                decimal_places=self._places,
            )
            if not conversion.succeeded or conversion.inr_amount is None:
                failures.append(
                    f"{point.valuation_date.isoformat()}: "
                    f"{conversion.resolution.explanation}"
                )
                continue
            if best is None or conversion.inr_amount > best[0]:
                best = (conversion.inr_amount, point, conversion)

        if best is None:
            reason = (
                f"{position.symbol} was valued on {len(points)} date(s) but none "
                f"could be converted to rupees."
                + (f" First problem: {failures[0]}" if failures else "")
            )
            return ComputedFigure.unavailable("peak_value", "Peak Value", reason)

        _amount, point, conversion = best
        caveats: list[str] = list(self._rule_caveats())
        if failures:
            caveats.append(
                f"{len(failures)} valuation date(s) in the period could not be "
                f"priced or converted and were excluded from the peak search, so "
                f"the true peak may be higher. First: {failures[0]}"
            )
        if point.price_carried_forward_days:
            caveats.append(
                f"the peak fell on {point.valuation_date.isoformat()}, a date with "
                f"no published price; the price from "
                f"{point.price_date.isoformat()} was carried forward"
            )
        if position.has_inferred_lots:
            caveats.append(
                "part of this holding was acquired before the earliest uploaded "
                "statement, so it can only be valued on the dates it is provably "
                "held. This peak is a lower bound: the shares were very likely "
                "held on earlier dates too, and the peak may be higher. Upload "
                "the earlier statement to compute it."
            )
        if self.policy.peak_valuation_frequency is not (
            PeakValuationFrequency.EVERY_PRICED_DAY
        ):
            caveats.append(
                f"the peak was searched at {self.policy.peak_valuation_frequency} "
                f"frequency rather than on every priced day, so it may understate "
                f"the true peak"
            )

        explanation = (
            f"highest of {len(points)} rupee valuations across the reporting "
            f"period, reached on {point.valuation_date.isoformat()}: "
            f"{decimal_to_str(point.quantity)} share(s) at "
            f"{point.currency} {decimal_to_str(point.price_native)} "
            f"({self.policy.price_valuation_point.label}), converted at the "
            f"rate for that date. Each date was valued and converted separately, "
            f"because the peak in rupees need not fall on the same date as the "
            f"peak in {point.currency}."
        )
        figure = ComputedFigure.from_conversion(
            "peak_value",
            "Peak Value of Investment During the Period",
            conversion,
            explanation=explanation,
            caveats=tuple(caveats),
            valuation_points=tuple(points),
        )
        self.fx.report(
            conversion, issues, subject=position.symbol, context_label="peak value"
        )
        return figure

    def _closing_value(
        self,
        position: SecurityPosition,
        currency: str,
        issues: IssueCollector,
    ) -> ComputedFigure:
        rule = self.schedule.closing_value
        assert position.timeline is not None
        quantity = position.timeline.quantity_on(self.period.end_date)

        if is_effectively_zero(quantity):
            return ComputedFigure.nil(
                "closing_value",
                "Closing Value",
                f"{position.symbol} was not held at the end of the reporting "
                f"period, so the closing value is nil. The interest is still "
                f"reported because Schedule FA covers interests held at any time "
                f"during the period.",
            )

        point, failure = self._value_on(position, self.period.end_date, currency)
        if point is None:
            reason = (
                f"{position.symbol} was held at the period end but could not be "
                f"valued on {self.period.end_date.isoformat()}: "
                f"{failure or 'no price available'}"
            )
            issues.report(
                ErrorCode.CALCULATION_INCOMPLETE,
                scope=IssueScope.CALCULATION,
                subject=position.symbol,
                message=reason,
            )
            return ComputedFigure.unavailable("closing_value", "Closing Value", reason)

        caveats = []
        if point.price_carried_forward_days:
            caveats.append(
                f"no price was published on {self.period.end_date.isoformat()}; "
                f"the last traded price, from {point.price_date.isoformat()}, "
                f"was used"
            )
        return self._convert(
            "closing_value",
            "Closing Value",
            point.value_native,
            point.currency,
            rule,
            issues,
            subject=position.symbol,
            valuation_date=self.period.end_date,
            caveats=caveats,
            explanation=(
                f"{decimal_to_str(point.quantity)} share(s) held at the period end "
                f"at {point.currency} {decimal_to_str(point.price_native)} "
                f"({self.policy.price_valuation_point.label} on "
                f"{point.price_date.isoformat()})"
            ),
            valuation_points=(point,),
        )

    def _initial_value(
        self,
        position: SecurityPosition,
        currency: str,
        issues: IssueCollector,
    ) -> ComputedFigure:
        """Total acquisition cost of the interest, converted per acquisition.

        Each lot is converted at the rate for its own acquisition date and the
        rupee amounts are summed. Summing in dollars and converting once would
        apply a single rate to purchases made months apart.
        """
        rule = self.schedule.initial_value
        lots = [lot for lot in position.lots if lot.acquisition_date is not None]
        undocumented = [lot for lot in position.lots if lot.acquisition_date is None]

        if undocumented:
            reason = (
                f"{position.symbol} includes "
                f"{decimal_to_str(sum((lot.original_quantity for lot in undocumented), ZERO))} "
                f"share(s) whose acquisition is not in the uploaded files, so the "
                f"initial value of the investment cannot be computed. Upload the "
                f"earlier statement, or enter the acquisition cost manually."
            )
            return ComputedFigure.unavailable(
                "initial_value", "Initial Value of the Investment", reason
            )

        if not lots:
            return ComputedFigure.unavailable(
                "initial_value",
                "Initial Value of the Investment",
                f"no acquisition of {position.symbol} is recorded.",
            )

        total = ZERO
        parts: list[str] = []
        caveats: list[str] = list(self._rule_caveats())
        for lot in sorted(lots, key=lambda item: item.acquisition_date or date.min):
            if lot.total_cost_native is None:
                return ComputedFigure.unavailable(
                    "initial_value",
                    "Initial Value of the Investment",
                    f"the acquisition on {lot.acquisition_date} states no amount, "
                    f"so the initial value cannot be computed.",
                )
            cost = lot.total_cost_native
            if self.policy.include_fees_in_initial_value and lot.fees_native:
                cost = as_amount(cost + lot.fees_native)

            assert lot.acquisition_date is not None
            conversion = self.fx.convert_and_report(
                cost,
                lot.currency,
                self._relevant_date(rule, transaction_date=lot.acquisition_date),
                rule,
                issues,
                subject=position.symbol,
                context_label=f"initial value, lot acquired {lot.acquisition_date}",
                rounding=self._rounding,
                decimal_places=self._places,
            )
            if not conversion.succeeded or conversion.inr_rounded is None:
                return ComputedFigure.unavailable(
                    "initial_value",
                    "Initial Value of the Investment",
                    f"the acquisition on {lot.acquisition_date.isoformat()} could "
                    f"not be converted: {conversion.resolution.explanation}",
                )
            total += conversion.inr_rounded
            parts.append(
                f"{lot.acquisition_date.isoformat()} "
                f"{decimal_to_str(lot.original_quantity)} share(s) "
                f"{lot.currency} {decimal_to_str(cost)} = INR "
                f"{decimal_to_str(conversion.inr_rounded)}"
            )

        fee_note = (
            "acquisition fees are included"
            if self.policy.include_fees_in_initial_value
            else "acquisition fees are excluded"
        )
        return ComputedFigure(
            field_name="initial_value",
            label="Initial Value of the Investment",
            status=FigureStatus.QUALIFIED if caveats else FigureStatus.COMPLETE,
            currency=currency,
            inr_amount=total,
            formula=" + ".join(parts),
            explanation=(
                f"sum of {len(parts)} acquisition(s), each converted at the rate "
                f"for its own acquisition date rather than one rate for all, "
                f"because the purchases fall on different dates. {fee_note}."
            ),
            caveats=tuple(caveats),
        )

    def _income_credited(
        self,
        symbol: str,
        ledger: TransactionLedger,
        currency: str,
        issues: IssueCollector,
    ) -> ComputedFigure:
        """Gross income credited in respect of the holding.

        Gross, not net: the withholding tax is a separate transaction and is
        not deducted here. Each payment is converted at the rate for its own
        credit date.
        """
        rule = self.schedule.income_credited
        payments = [
            t
            for t in ledger.ordered()
            if t.ticker
            and t.ticker.strip().upper() == symbol
            and t.behaviour.is_income
            and self.period.contains(t.transaction_date)
        ]
        if not payments:
            return ComputedFigure.nil(
                "income_credited",
                "Gross Amount Paid/Credited",
                f"no income was credited in respect of {symbol} during the "
                f"reporting period.",
            )

        total = ZERO
        parts: list[str] = []
        for payment in payments:
            amount = (
                payment.gross_amount_native
                if self.policy.income_is_gross_of_withholding
                else payment.net_amount_native
            )
            if amount is None:
                return ComputedFigure.unavailable(
                    "income_credited",
                    "Gross Amount Paid/Credited",
                    f"the income credited on "
                    f"{payment.transaction_date.isoformat()} states no amount.",
                )
            conversion = self.fx.convert_and_report(
                amount,
                payment.currency,
                self._relevant_date(rule, transaction_date=payment.transaction_date),
                rule,
                issues,
                subject=symbol,
                context_label=f"income credited {payment.transaction_date}",
                rounding=self._rounding,
                decimal_places=self._places,
            )
            if not conversion.succeeded or conversion.inr_rounded is None:
                return ComputedFigure.unavailable(
                    "income_credited",
                    "Gross Amount Paid/Credited",
                    f"the income credited on "
                    f"{payment.transaction_date.isoformat()} could not be "
                    f"converted: {conversion.resolution.explanation}",
                )
            total += conversion.inr_rounded
            parts.append(
                f"{payment.transaction_date.isoformat()} {payment.currency} "
                f"{decimal_to_str(amount)} = INR "
                f"{decimal_to_str(conversion.inr_rounded)}"
            )

        withheld = sum(
            (
                p.taxes_native or ZERO
                for p in payments
                if self.policy.income_is_gross_of_withholding
            ),
            ZERO,
        )
        basis = (
            "gross of foreign tax withheld at source"
            if self.policy.income_is_gross_of_withholding
            else "net of foreign tax withheld at source"
        )
        explanation = (
            f"{len(parts)} income payment(s), each converted at the rate for the "
            f"date it was credited. Reported {basis}."
        )
        if self.policy.income_is_gross_of_withholding and withheld > ZERO:
            explanation += (
                f" Foreign tax of {currency} {decimal_to_str(withheld)} was "
                f"withheld and is not deducted from this figure."
            )
        return ComputedFigure(
            field_name="income_credited",
            label="Gross Amount Paid/Credited",
            status=FigureStatus.COMPLETE
            if self.rule.is_verified
            else FigureStatus.QUALIFIED,
            currency=currency,
            inr_amount=total,
            formula=" + ".join(parts),
            explanation=explanation,
            caveats=self._rule_caveats(),
        )

    def _gross_proceeds(
        self,
        position: SecurityPosition,
        currency: str,
        issues: IssueCollector,
    ) -> ComputedFigure:
        """Gross proceeds of disposals during the period.

        Gross means gross: selling fees are not deducted unless the policy
        says to, and the default says not to.
        """
        rule = self.schedule.sale_proceeds
        disposals = [
            d
            for d in position.disposals
            if self.period.contains(d.disposal_date)
        ]
        if not disposals:
            return ComputedFigure.nil(
                "gross_proceeds",
                "Gross Proceeds From Sale or Redemption",
                f"{position.symbol} was not sold or redeemed during the reporting "
                f"period.",
            )

        total = ZERO
        parts: list[str] = []
        for disposal in disposals:
            amount = disposal.gross_proceeds_native
            if amount is None:
                return ComputedFigure.unavailable(
                    "gross_proceeds",
                    "Gross Proceeds From Sale or Redemption",
                    f"the disposal on {disposal.disposal_date.isoformat()} states "
                    f"no proceeds.",
                )
            if self.policy.deduct_fees_from_gross_proceeds and disposal.fees_native:
                amount = as_amount(amount - disposal.fees_native)

            conversion = self.fx.convert_and_report(
                amount,
                disposal.currency,
                self._relevant_date(rule, transaction_date=disposal.disposal_date),
                rule,
                issues,
                subject=position.symbol,
                context_label=f"sale proceeds {disposal.disposal_date}",
                rounding=self._rounding,
                decimal_places=self._places,
            )
            if not conversion.succeeded or conversion.inr_rounded is None:
                return ComputedFigure.unavailable(
                    "gross_proceeds",
                    "Gross Proceeds From Sale or Redemption",
                    f"the disposal on {disposal.disposal_date.isoformat()} could "
                    f"not be converted: {conversion.resolution.explanation}",
                )
            total += conversion.inr_rounded
            parts.append(
                f"{disposal.disposal_date.isoformat()} "
                f"{decimal_to_str(disposal.quantity)} share(s) "
                f"{disposal.currency} {decimal_to_str(amount)} = INR "
                f"{decimal_to_str(conversion.inr_rounded)}"
            )

        fee_note = (
            "selling fees are deducted"
            if self.policy.deduct_fees_from_gross_proceeds
            else "selling fees are not deducted, because the field asks for gross "
            "proceeds"
        )
        return ComputedFigure(
            field_name="gross_proceeds",
            label="Gross Proceeds From Sale or Redemption",
            status=FigureStatus.COMPLETE
            if self.rule.is_verified
            else FigureStatus.QUALIFIED,
            currency=currency,
            inr_amount=total,
            formula=" + ".join(parts),
            explanation=(
                f"{len(parts)} disposal(s), each converted at the rate for its own "
                f"disposal date. {fee_note}."
            ),
            caveats=self._rule_caveats(),
        )

    # --- rows -------------------------------------------------------------

    def _identity_fields(self, security: Security | None, symbol: str) -> dict:
        """Entity identity from the security master, with gaps named."""
        if security is None:
            reason = (
                f"{symbol} is not resolved to a security master entry, so the "
                f"entity's name, country and nature are unknown. The platform "
                f"will not derive them from the ticker symbol."
            )
            return {
                "country_name": _missing("country_name", "Country/Region Name", reason),
                "country_code": _missing("country_code", "Country/Region Code", reason),
                "entity_name": _missing("entity_name", "Name of Entity", reason),
                "entity_address": _missing(
                    "entity_address", "Address of Entity", reason
                ),
                "zip_code": _missing("zip_code", "ZIP Code", reason),
                "nature_of_entity": _missing(
                    "nature_of_entity", "Nature of Entity", reason
                ),
            }

        country = security.country
        code_reason = (
            "the ITR country code list for this assessment year has not been "
            "transcribed and confirmed in this installation. The ISO code is not "
            "substituted, because the two lists are not always identical."
        )
        return {
            "country_name": TextField(
                "country_name",
                "Country/Region Name",
                country.name if country else None,
                explanation="from the security master",
                caveats=() if country else ("no country is recorded",),
            ),
            "country_code": TextField(
                "country_code",
                "Country/Region Code",
                country.itr_code if country and country.has_filing_code else None,
                explanation=(
                    "the ITR country code from the form's own code list"
                    if country and country.has_filing_code
                    else code_reason
                ),
                caveats=()
                if country and country.has_filing_code
                else (code_reason,),
            ),
            "entity_name": TextField(
                "entity_name",
                "Name of Entity",
                security.legal_entity_name,
                explanation=(
                    "the legal entity name from the security master, not the "
                    "ticker symbol and not the broker's display name"
                ),
                caveats=()
                if security.has_entity_name
                else ("no legal entity name is recorded for this security",),
            ),
            "entity_address": TextField(
                "entity_address",
                "Address of Entity",
                security.address.one_line()
                if security.address and security.has_address
                else None,
                explanation="from the security master",
                caveats=()
                if security.has_address
                else (
                    "no address is recorded. The platform leaves the field blank "
                    "rather than substituting the exchange's or the broker's address.",
                ),
            ),
            "zip_code": TextField(
                "zip_code",
                "ZIP Code",
                security.address.zip_code
                if security.address and security.has_zip
                else None,
                explanation="from the security master",
                caveats=() if security.has_zip else ("no ZIP code is recorded",),
            ),
            "nature_of_entity": TextField(
                "nature_of_entity",
                "Nature of Entity",
                security.nature.label() if security.nature.is_determined else None,
                explanation="from the security master",
                caveats=()
                if security.nature.is_determined
                else ("the nature of the entity has not been determined",),
            ),
        }

    def _acquisition_field(self, position: SecurityPosition) -> TextField:
        """Date of acquiring the interest.

        The earliest acquisition on record. When any part of the holding
        predates the uploaded files, the field is unavailable rather than
        showing the earliest date that happens to be present, which would
        assert an acquisition date the data does not support.
        """
        if any(lot.acquisition_date is None for lot in position.lots):
            reason = (
                f"part of the {position.symbol} holding was acquired before the "
                f"earliest uploaded statement, so the date of acquiring the "
                f"interest is unknown. The platform will not substitute the "
                f"earliest date it happens to have."
            )
            return _missing(
                "acquisition_date", "Date of Acquiring the Interest", reason
            )

        dates = [lot.acquisition_date for lot in position.lots if lot.acquisition_date]
        if not dates:
            return _missing(
                "acquisition_date",
                "Date of Acquiring the Interest",
                f"no acquisition of {position.symbol} is recorded.",
            )
        earliest = min(dates)
        note = (
            f"earliest of {len(dates)} acquisition(s) of this interest"
            if len(dates) > 1
            else "the single acquisition of this interest"
        )
        return TextField(
            "acquisition_date",
            "Date of Acquiring the Interest",
            earliest.isoformat(),
            explanation=note,
        )

    def build_a3_row(
        self,
        serial: int,
        position: SecurityPosition,
        security: Security | None,
        ledger: TransactionLedger,
        issues: IssueCollector,
    ) -> TableA3Row:
        currency = _position_currency(position)
        identity = self._identity_fields(security, position.symbol)
        assert position.timeline is not None
        closed = is_effectively_zero(
            position.timeline.quantity_on(self.period.end_date)
        )

        notes: list[str] = []
        if closed:
            notes.append(
                "the interest was disposed of before the end of the reporting "
                "period and is reported because Schedule FA covers interests held "
                "at any time during the period"
            )
        if position.has_inferred_lots:
            notes.append(
                "part of this holding predates the uploaded statements; its "
                "quantity is a lower bound deduced from a later disposal"
            )

        return TableA3Row(
            serial_number=serial,
            symbol=position.symbol,
            security_id=security.security_id if security else None,
            acquisition_date=self._acquisition_field(position),
            initial_value=self._initial_value(position, currency, issues),
            peak_value=self._peak_value(position, currency, issues),
            closing_value=self._closing_value(position, currency, issues),
            income_credited=self._income_credited(
                position.symbol, ledger, currency, issues
            ),
            gross_proceeds=self._gross_proceeds(position, currency, issues),
            closed_during_period=closed,
            notes=tuple(notes),
            **identity,
        )

    # --- Table A2 ---------------------------------------------------------

    def build_a2_row(
        self,
        serial: int,
        ledger: TransactionLedger,
        institution,  # noqa: ANN001 - FinancialInstitution | None
        issues: IssueCollector,
        *,
        account_number: str | None = None,
        account_status: str | None = None,
        account_opening_date: date | None = None,
    ) -> TableA2Row:
        """The custodial account itself.

        The account's cash balance only. The value of the securities inside it
        belongs in Table A3, and adding it here would report the same wealth
        twice.
        """
        currency = _ledger_currency(ledger)
        balances = _cash_balance_series(ledger, self.period)

        wanted = {
            "account_number": ("account number", account_number),
            "account_status": ("ownership status", account_status),
            "account_opening_date": ("account opening date", account_opening_date),
        }
        absent = {
            field_name: label
            for field_name, (label, value) in wanted.items()
            if not value
        }
        if absent:
            issues.report(
                ErrorCode.ACCOUNT_DETAILS_MISSING,
                scope=IssueScope.ACCOUNT,
                subject=_CASH_ACCOUNT_SUBJECT,
                message=(
                    f"Schedule FA Table A2 requires the "
                    f"{', '.join(absent.values())}, which a transaction export does "
                    f"not contain. Enter {'them' if len(absent) > 1 else 'it'} from "
                    f"your account statement."
                ),
                # Named so that validation can attribute exactly these blanks
                # to this condition and no others.
                fields=",".join(absent),
            )

        peak = self._a2_peak_balance(balances, currency, issues)
        closing = self._a2_closing_balance(balances, currency, issues)
        credited = self._a2_gross_credited(ledger, currency, issues)

        supplied_reason = (
            "a transaction export does not contain this. It must be entered by "
            "the user and is never inferred."
        )
        country = institution.country if institution else None

        unconfirmed: dict[str, str] = {}
        if institution is None or not institution.has_legal_name:
            unconfirmed["institution_name"] = "legal name"
        if country is None:
            unconfirmed["country_name"] = "country"
            unconfirmed["country_code"] = "country code"
        elif not country.has_filing_code:
            unconfirmed["country_code"] = "country code"
        if institution is None or institution.address is None:
            unconfirmed["institution_address"] = "address"
            unconfirmed["zip_code"] = "ZIP code"
        if unconfirmed:
            named = ", ".join(dict.fromkeys(unconfirmed.values()))
            issues.report(
                ErrorCode.INSTITUTION_DETAILS_MISSING,
                scope=IssueScope.ACCOUNT,
                subject=_CASH_ACCOUNT_SUBJECT,
                message=(
                    f"the {named} of the institution holding the account "
                    + (
                        f"({institution.brand_name}) "
                        if institution and institution.brand_name
                        else ""
                    )
                    + f"{'is' if len(unconfirmed) == 1 else 'are'} not confirmed, "
                    f"so Schedule FA Table A2 cannot be completed."
                ),
                fields=",".join(unconfirmed),
            )
        return TableA2Row(
            serial_number=serial,
            institution_id=institution.institution_id if institution else None,
            country_name=TextField(
                "country_name",
                "Country/Region Name",
                country.name if country else None,
                caveats=() if country else ("no country recorded for the institution",),
            ),
            country_code=TextField(
                "country_code",
                "Country/Region Code",
                country.itr_code if country and country.has_filing_code else None,
                caveats=()
                if country and country.has_filing_code
                else ("the ITR country code has not been confirmed",),
            ),
            institution_name=TextField(
                "institution_name",
                "Name of the Financial Institution",
                institution.legal_name if institution else None,
                explanation=(
                    "the institution holding the custodial account, which may "
                    "differ from the app or brand the account was opened through"
                ),
                caveats=()
                if institution and institution.has_legal_name
                else (
                    "the legal name of the institution holding the account has not "
                    "been confirmed. An app brand, its introducing broker and its "
                    "clearing custodian are different entities.",
                ),
            ),
            institution_address=TextField(
                "institution_address",
                "Address of the Financial Institution",
                institution.address.one_line()
                if institution and institution.address
                else None,
                caveats=()
                if institution and institution.address
                else ("no institution address is recorded",),
            ),
            zip_code=TextField(
                "zip_code",
                "ZIP Code",
                institution.address.zip_code
                if institution and institution.address
                else None,
                caveats=("no institution ZIP code is recorded",)
                if not (institution and institution.address and institution.address.zip_code)
                else (),
            ),
            account_number=TextField(
                "account_number",
                "Account Number",
                account_number,
                explanation="supplied by the user",
                caveats=() if account_number else (supplied_reason,),
            ),
            account_status=TextField(
                "account_status",
                "Status",
                account_status,
                explanation="ownership status, supplied by the user",
                caveats=() if account_status else (supplied_reason,),
            ),
            account_opening_date=TextField(
                "account_opening_date",
                "Account Opening Date",
                account_opening_date.isoformat() if account_opening_date else None,
                explanation="supplied by the user",
                caveats=()
                if account_opening_date
                else (
                    "the account opening date is not in a transaction export. The "
                    "earliest transaction date is not a substitute for it.",
                ),
            ),
            peak_balance=peak,
            closing_balance=closing,
            gross_amount_credited=credited,
            gross_amount_nature=TextField(
                "gross_amount_nature",
                "Nature of Amount Paid/Credited",
                "Dividends and interest credited to the account",
                explanation="derived from the income transactions in the period",
            ),
            subject=_CASH_ACCOUNT_SUBJECT,
            notes=(
                "this row reports the cash account only. The value of the "
                "securities held in it is reported in Table A3 and is not added "
                "here, which would report the same wealth twice.",
            ),
        )

    def _a2_peak_balance(
        self,
        balances: Sequence[tuple[date, Decimal]],
        currency: str,
        issues: IssueCollector,
    ) -> ComputedFigure:
        rule = self.schedule.peak_value
        positive = [(day, value) for day, value in balances if value > ZERO]
        if not positive:
            return ComputedFigure.nil(
                "peak_balance",
                "Peak Balance During the Period",
                "the cash balance did not rise above nil during the period.",
            )

        best = None
        for day, value in positive:
            conversion = self.fx.convert(
                value,
                currency,
                self._relevant_date(rule, valuation_date=day),
                rule,
                rounding=self._rounding,
                decimal_places=self._places,
            )
            if conversion.inr_amount is None:
                continue
            if best is None or conversion.inr_amount > best[0]:
                best = (conversion.inr_amount, day, value, conversion)

        if best is None:
            return ComputedFigure.unavailable(
                "peak_balance",
                "Peak Balance During the Period",
                "no cash balance during the period could be converted to rupees.",
            )

        _inr, day, value, conversion = best
        self.fx.report(
            conversion, issues, subject=_CASH_ACCOUNT_SUBJECT, context_label="peak balance"
        )
        return ComputedFigure.from_conversion(
            "peak_balance",
            "Peak Balance During the Period",
            conversion,
            explanation=(
                f"highest rupee cash balance during the period, reached on "
                f"{day.isoformat()} at {currency} {decimal_to_str(value)}. The "
                f"balance is converted on each date it changed and compared in "
                f"rupees, because the peak in rupees need not fall on the same "
                f"date as the peak in {currency}."
            ),
            caveats=self._rule_caveats(),
        )

    def _a2_closing_balance(
        self,
        balances: Sequence[tuple[date, Decimal]],
        currency: str,
        issues: IssueCollector,
    ) -> ComputedFigure:
        rule = self.schedule.closing_value
        closing = balances[-1][1] if balances else ZERO
        if is_effectively_zero(closing, scale=2):
            return ComputedFigure.nil(
                "closing_balance",
                "Closing Balance",
                "the cash balance at the end of the reporting period was nil.",
            )
        return self._convert(
            "closing_balance",
            "Closing Balance",
            closing,
            currency,
            rule,
            issues,
            subject=_CASH_ACCOUNT_SUBJECT,
            valuation_date=self.period.end_date,
            explanation=(
                f"cash balance of {currency} {decimal_to_str(closing)} at the end "
                f"of the reporting period, derived from the transaction ledger."
            ),
        )

    def _a2_gross_credited(
        self, ledger: TransactionLedger, currency: str, issues: IssueCollector
    ) -> ComputedFigure:
        """Gross amounts credited to the account during the period.

        Income credited to the account. Deposits the investor made are their
        own money moving in, not an amount paid or credited *to* them, so they
        are excluded and the exclusion is stated.
        """
        rule = self.schedule.income_credited
        payments = [
            t
            for t in ledger.ordered()
            if t.behaviour.is_income and self.period.contains(t.transaction_date)
        ]
        if not payments:
            return ComputedFigure.nil(
                "gross_amount_credited",
                "Gross Amount Paid/Credited to the Account",
                "no income was credited to the account during the period.",
            )

        total = ZERO
        for payment in payments:
            amount = payment.gross_amount_native
            if amount is None:
                continue
            conversion = self.fx.convert_and_report(
                amount,
                payment.currency,
                self._relevant_date(rule, transaction_date=payment.transaction_date),
                rule,
                issues,
                subject=_CASH_ACCOUNT_SUBJECT,
                context_label=f"amount credited {payment.transaction_date}",
                rounding=self._rounding,
                decimal_places=self._places,
            )
            if conversion.inr_rounded is None:
                return ComputedFigure.unavailable(
                    "gross_amount_credited",
                    "Gross Amount Paid/Credited to the Account",
                    f"the amount credited on "
                    f"{payment.transaction_date.isoformat()} could not be "
                    f"converted: {conversion.resolution.explanation}",
                )
            total += conversion.inr_rounded

        return ComputedFigure(
            field_name="gross_amount_credited",
            label="Gross Amount Paid/Credited to the Account",
            status=FigureStatus.COMPLETE
            if self.rule.is_verified
            else FigureStatus.QUALIFIED,
            currency=currency,
            inr_amount=total,
            explanation=(
                f"{len(payments)} income credit(s) during the period, each "
                f"converted at the rate for its own credit date. Deposits the "
                f"account holder funded the account with are excluded: they are "
                f"the holder's own money moving in, not an amount paid or "
                f"credited to them."
            ),
            caveats=self._rule_caveats(),
        )

    # --- orchestration ----------------------------------------------------

    def build(
        self,
        ledger: TransactionLedger,
        book: LotBook,
        resolution: ResolutionReport,
        issues: IssueCollector,
        *,
        institution=None,  # noqa: ANN001 - FinancialInstitution | None
        account_number: str | None = None,
        account_status: str | None = None,
        account_opening_date: date | None = None,
        include_cash_account: bool = True,
    ) -> ScheduleFaReport:
        report = ScheduleFaReport(
            assessment_year=self.rule.assessment_year,
            period_start=self.period.start_date,
            period_end=self.period.end_date,
            period_description=self.period.description,
            rule_version=self.rule.rule_version_id,
            rule_verified=self.rule.is_verified,
            calculation_policy=self.policy.describe(),
        )

        if not self.rule.is_verified:
            issues.report(
                ErrorCode.TAX_RULE_UNVERIFIED,
                scope=IssueScope.CALCULATION,
                subject=self.rule.assessment_year,
                message=(
                    f"the Schedule FA rules used for assessment year "
                    f"{self.rule.assessment_year} have not been verified against "
                    f"the published form and instructions. Every figure below is "
                    f"computed with them and labelled accordingly."
                ),
            )

        if not self.prices.check_basis(issues):
            report.blocking_reasons = (
                *report.blocking_reasons,
                "the market-data snapshot's split-adjustment basis is unusable or "
                "does not match the share quantities, so no valuation was attempted.",
            )
            return report

        serial = 0
        for symbol in book.symbols():
            position = book.positions[symbol]
            assert position.timeline is not None
            if not position.timeline.held_at_any_time(
                self.period.start_date, self.period.end_date
            ):
                report.excluded[symbol] = (
                    f"{symbol} was not held at any time during the reporting period."
                )
                continue
            serial += 1
            report.table_a3.append(
                self.build_a3_row(
                    serial,
                    position,
                    resolution.security_for(symbol),
                    ledger,
                    issues,
                )
            )

        if include_cash_account:
            report.table_a2.append(
                self.build_a2_row(
                    1,
                    ledger,
                    institution,
                    issues,
                    account_number=account_number,
                    account_status=account_status,
                    account_opening_date=account_opening_date,
                )
            )

        return report


# --- helpers --------------------------------------------------------------


def _position_currency(position: SecurityPosition) -> str:
    for lot in position.lots:
        if lot.currency:
            return lot.currency
    for disposal in position.disposals:
        if disposal.currency:
            return disposal.currency
    return "USD"


def _ledger_currency(ledger: TransactionLedger) -> str:
    currencies = ledger.currencies()
    return currencies[0] if currencies else "USD"


def _cash_balance_series(
    ledger: TransactionLedger, period: ReportingPeriod
) -> list[tuple[date, Decimal]]:
    """Running cash balance on each date it changed, within the period.

    Built from the transaction ledger rather than from any balance the broker
    states, so that the peak is derived from the same data as everything else
    and any disagreement with the broker surfaces in reconciliation.
    """
    balance = ZERO
    series: list[tuple[date, Decimal]] = []
    for transaction in ledger.ordered():
        delta = transaction.cash_delta_native
        if delta == ZERO:
            continue
        balance = as_amount(balance + delta)
        if period.contains(transaction.transaction_date):
            series.append((transaction.transaction_date, balance))
    return series


def _period_ends(start: date, end: date, *, months: int) -> list[date]:
    """Month or quarter ends falling inside the window."""
    results: list[date] = []
    year, month = start.year, start.month
    while True:
        next_month = month + months
        next_year = year + (next_month - 1) // 12
        next_month = (next_month - 1) % 12 + 1
        boundary = date(next_year, next_month, 1) - timedelta(days=1)
        if boundary > end:
            break
        if boundary >= start:
            results.append(boundary)
        year, month = next_year, next_month
    if end not in results:
        results.append(end)
    return results


def income_transactions(
    ledger: TransactionLedger, symbol: str, period: ReportingPeriod
) -> list[NormalizedTransaction]:
    """Income credited in respect of one holding, for the workpaper."""
    return [
        t
        for t in ledger.ordered()
        if t.ticker
        and t.ticker.strip().upper() == symbol.strip().upper()
        and t.transaction_type
        in (TransactionType.DIVIDEND, TransactionType.INTEREST)
        and period.contains(t.transaction_date)
    ]
