"""Schedule FA figures, each carrying the reasoning that produced it.

Every reported number is a :class:`ComputedFigure`: the native amount, the
rate that converted it, the rupee result, and a sentence a person can read
alongside the return. That is not decoration. A Schedule FA figure may have to
be defended years later, and "peak value 1,52,340" is indefensible on its own
while "highest of 248 daily closing valuations, on 2025-12-29, 15.25 shares at
USD 168.40 converted at SBI TTBR 84.12 for 29 December 2025" is not.

A figure that could not be computed is not zero. ``ComputedFigure`` holds
``None`` and the reason, and a table row knows whether it is complete. Writing
zero where a value is unknown is the single most dangerous thing this module
could do: zero is a number a reader will believe.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from enum import StrEnum

from ..core.money import decimal_to_str
from ..fx.resolver import ConversionResult


class FigureStatus(StrEnum):
    """Whether a figure is usable in a filing."""

    #: Computed from complete data.
    COMPLETE = "COMPLETE"
    #: Computed, but something about it needs a human's attention before
    #: filing, such as an unverified rule version or a carried-forward price.
    QUALIFIED = "QUALIFIED"
    #: Could not be computed. The reason is on the figure.
    UNAVAILABLE = "UNAVAILABLE"
    #: Legitimately nil: the holding genuinely had no income, no disposal.
    NIL = "NIL"

    @property
    def reportable(self) -> bool:
        return self in (FigureStatus.COMPLETE, FigureStatus.QUALIFIED, FigureStatus.NIL)


@dataclass(frozen=True, slots=True)
class ValuationPoint:
    """One security valued on one date, before conversion."""

    valuation_date: date
    quantity: Decimal
    price_native: Decimal
    currency: str
    value_native: Decimal
    #: Date the price actually came from, which differs on a carried-forward
    #: price. Kept so a peak can be traced to a real quotation.
    price_date: date
    price_carried_forward_days: int = 0

    def describe(self) -> str:
        carried = (
            f" (price carried forward {self.price_carried_forward_days} day(s) "
            f"from {self.price_date.isoformat()})"
            if self.price_carried_forward_days
            else ""
        )
        return (
            f"{self.valuation_date.isoformat()}: "
            f"{decimal_to_str(self.quantity)} x {self.currency} "
            f"{decimal_to_str(self.price_native)} = {self.currency} "
            f"{decimal_to_str(self.value_native)}{carried}"
        )


@dataclass(frozen=True, slots=True)
class ComputedFigure:
    """One reported money figure with its full derivation."""

    field_name: str
    label: str
    status: FigureStatus
    native_amount: Decimal | None = None
    currency: str | None = None
    inr_amount: Decimal | None = None
    #: The date whose exchange rate was applied, and why that date.
    rate_date: date | None = None
    rate_value: Decimal | None = None
    rate_type: str | None = None
    #: The arithmetic, as text: "USD 1,234.00 x 84.1200 = INR 1,03,800".
    formula: str = ""
    #: Prose explanation shown beside the figure.
    explanation: str = ""
    #: Reasons the figure is qualified or unavailable.
    caveats: tuple[str, ...] = ()
    #: Valuations considered, for peak figures.
    valuation_points: tuple[ValuationPoint, ...] = ()

    @property
    def available(self) -> bool:
        return self.status.reportable

    @property
    def display(self) -> str:
        """What goes in the form cell."""
        if self.status is FigureStatus.UNAVAILABLE:
            return "NOT AVAILABLE"
        if self.inr_amount is None:
            return "0"
        return decimal_to_str(self.inr_amount) or "0"

    @classmethod
    def unavailable(
        cls, field_name: str, label: str, reason: str, *, caveats: tuple[str, ...] = ()
    ) -> ComputedFigure:
        return cls(
            field_name=field_name,
            label=label,
            status=FigureStatus.UNAVAILABLE,
            explanation=reason,
            caveats=caveats or (reason,),
        )

    @classmethod
    def nil(cls, field_name: str, label: str, reason: str) -> ComputedFigure:
        """A figure that is genuinely nil, as distinct from unknown."""
        return cls(
            field_name=field_name,
            label=label,
            status=FigureStatus.NIL,
            inr_amount=Decimal(0),
            explanation=reason,
        )

    @classmethod
    def from_conversion(
        cls,
        field_name: str,
        label: str,
        conversion: ConversionResult,
        *,
        explanation: str,
        caveats: tuple[str, ...] = (),
        valuation_points: tuple[ValuationPoint, ...] = (),
    ) -> ComputedFigure:
        if not conversion.succeeded:
            return cls(
                field_name=field_name,
                label=label,
                status=FigureStatus.UNAVAILABLE,
                native_amount=conversion.native_amount,
                currency=conversion.currency,
                formula=conversion.formula,
                explanation=(
                    f"{explanation} The conversion could not be completed: "
                    f"{conversion.resolution.explanation}"
                ),
                caveats=(*caveats, conversion.resolution.explanation),
                valuation_points=valuation_points,
            )
        resolution = conversion.resolution
        return cls(
            field_name=field_name,
            label=label,
            status=FigureStatus.QUALIFIED if caveats else FigureStatus.COMPLETE,
            native_amount=conversion.native_amount,
            currency=conversion.currency,
            inr_amount=conversion.inr_rounded,
            rate_date=resolution.record.rate_date if resolution.record else None,
            rate_value=resolution.value,
            rate_type=str(resolution.rate_type),
            formula=conversion.formula,
            explanation=explanation,
            caveats=caveats,
            valuation_points=valuation_points,
        )


@dataclass(frozen=True, slots=True)
class TextField:
    """A non-numeric reported field, which can also be unavailable."""

    field_name: str
    label: str
    value: str | None
    explanation: str = ""
    caveats: tuple[str, ...] = ()

    @property
    def available(self) -> bool:
        return bool(self.value)

    @property
    def display(self) -> str:
        return self.value if self.value else "NOT AVAILABLE"


@dataclass(slots=True)
class TableA3Row:
    """One foreign equity or debt interest, as Schedule FA Table A3 asks for it."""

    serial_number: int
    symbol: str
    security_id: str | None
    country_name: TextField
    country_code: TextField
    entity_name: TextField
    entity_address: TextField
    zip_code: TextField
    nature_of_entity: TextField
    acquisition_date: TextField
    initial_value: ComputedFigure
    peak_value: ComputedFigure
    closing_value: ComputedFigure
    income_credited: ComputedFigure
    gross_proceeds: ComputedFigure
    #: Set when the holding closed before the period ended. Reported anyway,
    #: because Schedule FA covers interests held at any time in the period.
    closed_during_period: bool = False
    notes: tuple[str, ...] = ()

    @property
    def subject(self) -> str:
        """The identifier issues about this row are filed under.

        Exposed so that validation can match a blank field to the issue
        explaining it. Matching on a display label instead would break the
        moment either side was reworded, and the break would be silent.
        """
        return self.symbol

    def fields(self) -> list[TextField | ComputedFigure]:
        return [
            self.country_name,
            self.country_code,
            self.entity_name,
            self.entity_address,
            self.zip_code,
            self.nature_of_entity,
            self.acquisition_date,
            self.initial_value,
            self.peak_value,
            self.closing_value,
            self.income_credited,
            self.gross_proceeds,
        ]

    def figures(self) -> list[ComputedFigure]:
        """The money figures only, in the order the form asks for them.

        Derived from :meth:`fields` rather than listed again, so that adding
        a column cannot leave the workpaper documenting a figure the form
        reports but nothing explaining it.
        """
        return [f for f in self.fields() if isinstance(f, ComputedFigure)]

    @property
    def is_complete(self) -> bool:
        return all(f.available for f in self.fields())

    def missing_fields(self) -> tuple[str, ...]:
        return tuple(f.field_name for f in self.fields() if not f.available)

    def all_caveats(self) -> tuple[str, ...]:
        seen: dict[str, None] = {}
        for item in self.fields():
            for caveat in item.caveats:
                seen[caveat] = None
        for note in self.notes:
            seen[note] = None
        return tuple(seen)


@dataclass(slots=True)
class TableA2Row:
    """One foreign custodial account, as Schedule FA Table A2 asks for it."""

    serial_number: int
    institution_id: str | None
    country_name: TextField
    country_code: TextField
    institution_name: TextField
    institution_address: TextField
    zip_code: TextField
    account_number: TextField
    account_status: TextField
    account_opening_date: TextField
    peak_balance: ComputedFigure
    closing_balance: ComputedFigure
    gross_amount_credited: ComputedFigure
    gross_amount_nature: TextField
    #: The identifier issues about this account are filed under. See
    #: :attr:`TableA3Row.subject`.
    subject: str = "cash account"
    notes: tuple[str, ...] = ()

    def fields(self) -> list[TextField | ComputedFigure]:
        return [
            self.country_name,
            self.country_code,
            self.institution_name,
            self.institution_address,
            self.zip_code,
            self.account_number,
            self.account_status,
            self.account_opening_date,
            self.peak_balance,
            self.closing_balance,
            self.gross_amount_credited,
            self.gross_amount_nature,
        ]

    def figures(self) -> list[ComputedFigure]:
        """The money figures only. See :meth:`TableA3Row.figures`."""
        return [f for f in self.fields() if isinstance(f, ComputedFigure)]

    @property
    def is_complete(self) -> bool:
        return all(f.available for f in self.fields())

    def missing_fields(self) -> tuple[str, ...]:
        return tuple(f.field_name for f in self.fields() if not f.available)

    def all_caveats(self) -> tuple[str, ...]:
        seen: dict[str, None] = {}
        for item in self.fields():
            for caveat in item.caveats:
                seen[caveat] = None
        for note in self.notes:
            seen[note] = None
        return tuple(seen)


@dataclass(slots=True)
class ScheduleFaReport:
    """Everything the Schedule FA engine produced for one period."""

    assessment_year: str
    period_start: date
    period_end: date
    period_description: str
    rule_version: str
    rule_verified: bool
    calculation_policy: dict[str, str] = field(default_factory=dict)
    table_a2: list[TableA2Row] = field(default_factory=list)
    table_a3: list[TableA3Row] = field(default_factory=list)
    #: Symbols excluded from A3, with the reason for each.
    excluded: dict[str, str] = field(default_factory=dict)
    #: Set when a blocking condition means the report must not be filed as is.
    blocking_reasons: tuple[str, ...] = ()

    @property
    def is_filable(self) -> bool:
        """Whether every reported row is complete and nothing blocks."""
        if self.blocking_reasons:
            return False
        return all(row.is_complete for row in self.table_a3) and all(
            row.is_complete for row in self.table_a2
        )

    def incomplete_rows(self) -> list[str]:
        problems: list[str] = []
        for row in self.table_a2:
            if not row.is_complete:
                problems.append(
                    f"A2 row {row.serial_number}: missing "
                    f"{', '.join(row.missing_fields())}"
                )
        for row in self.table_a3:
            if not row.is_complete:
                problems.append(
                    f"A3 row {row.serial_number} ({row.symbol}): missing "
                    f"{', '.join(row.missing_fields())}"
                )
        return problems

    def summary(self) -> str:
        lines = [
            f"Schedule FA for assessment year {self.assessment_year}",
            f"reporting period: {self.period_start.isoformat()} to "
            f"{self.period_end.isoformat()} ({self.period_description})",
            f"rule version: {self.rule_version}"
            + ("" if self.rule_verified else "  [NOT VERIFIED AGAINST THE OFFICIAL FORM]"),
            "",
            f"Table A2 (custodial accounts): {len(self.table_a2)} row(s)",
        ]
        for row in self.table_a2:
            lines.append(
                f"  {row.serial_number}. {row.institution_name.display} "
                f"account {row.account_number.display}"
            )
            lines.append(f"       peak balance: INR {row.peak_balance.display}")
            lines.append(f"       closing balance: INR {row.closing_balance.display}")
            lines.append(
                f"       gross credited: INR {row.gross_amount_credited.display}"
            )
            if not row.is_complete:
                lines.append(f"       MISSING: {', '.join(row.missing_fields())}")

        lines.append("")
        lines.append(f"Table A3 (equity and debt interests): {len(self.table_a3)} row(s)")
        for row in self.table_a3:
            closed = "  [closed during the period]" if row.closed_during_period else ""
            lines.append(
                f"  {row.serial_number}. {row.symbol} - {row.entity_name.display}{closed}"
            )
            lines.append(f"       acquired: {row.acquisition_date.display}")
            lines.append(f"       initial value: INR {row.initial_value.display}")
            lines.append(f"       peak value: INR {row.peak_value.display}")
            lines.append(f"       closing value: INR {row.closing_value.display}")
            lines.append(f"       income credited: INR {row.income_credited.display}")
            lines.append(f"       gross proceeds: INR {row.gross_proceeds.display}")
            if not row.is_complete:
                lines.append(f"       MISSING: {', '.join(row.missing_fields())}")

        if self.excluded:
            lines.append("")
            lines.append("excluded from Table A3:")
            for symbol, reason in sorted(self.excluded.items()):
                lines.append(f"  {symbol}: {reason}")

        lines.append("")
        lines.append(f"filable as it stands: {self.is_filable}")
        for problem in self.incomplete_rows():
            lines.append(f"  {problem}")
        for reason in self.blocking_reasons:
            lines.append(f"  BLOCKING: {reason}")
        return "\n".join(lines)
