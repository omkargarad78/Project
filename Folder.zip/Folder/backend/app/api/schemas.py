"""Request and response bodies.

Money crosses this boundary as a decimal *string*, never a JSON number.
JSON numbers are IEEE doubles in every browser, so a rupee figure serialised
as a number is rounded by the client before it is ever displayed. A string
arrives with every digit the engine produced.

Nothing here is a database model. The schema the API promises and the schema
on disk change for different reasons, and letting one be the other means
every column rename is a breaking API change.
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Annotated, Any

from pydantic import BaseModel, ConfigDict, Field

#: Deliberately permissive, and not a substitute for sending a confirmation
#: message. Pydantic's ``EmailStr`` needs the optional ``email-validator``
#: package, and the stricter grammar it brings still cannot tell a
#: deliverable address from a plausible one. The only real check is whether
#: mail to it arrives.
EmailAddress = Annotated[
    str,
    Field(min_length=3, max_length=320, pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$"),
]

from ..db.models import ArtifactKind, Role, RunStatus


class Model(BaseModel):
    model_config = ConfigDict(from_attributes=True, extra="forbid")


def money(value: Decimal | None) -> str | None:
    return None if value is None else format(value, "f")


# --- auth -----------------------------------------------------------------


class RegisterRequest(Model):
    email: EmailAddress
    password: str = Field(min_length=12, max_length=1024)
    display_name: str = Field(default="", max_length=120)


class LoginRequest(Model):
    email: EmailAddress
    password: str = Field(max_length=1024)


class TokenResponse(Model):
    access_token: str
    token_type: str = "bearer"
    expires_at: datetime


class UserResponse(Model):
    id: str
    email: str
    display_name: str
    created_at: datetime


# --- workspaces -----------------------------------------------------------


class WorkspaceCreate(Model):
    name: str = Field(min_length=1, max_length=160)
    assessment_year: str = Field(pattern=r"^\d{4}-\d{2}$")
    residency_note: str = Field(default="", max_length=2000)


class WorkspaceResponse(Model):
    id: str
    name: str
    assessment_year: str
    role: Role
    created_at: datetime


class MemberInvite(Model):
    email: EmailAddress
    role: Role


class MemberResponse(Model):
    user_id: str
    email: str
    display_name: str
    role: Role


# --- files ----------------------------------------------------------------


class SourceFileResponse(Model):
    id: str
    file_name: str
    file_hash: str
    file_type: str
    size_bytes: int
    broker_id: str | None
    parser_version: str | None
    created_at: datetime


# --- runs -----------------------------------------------------------------


class RunRequest(Model):
    """Everything that decides what the figures will be.

    Defaulted rather than required, but every value is recorded on the run,
    because two runs that differ only here produce different figures and
    have to be tellable apart afterwards.
    """

    fx_dataset: str
    fx_dataset_version: str
    assessment_year: str | None = Field(default=None, pattern=r"^\d{4}-\d{2}$")
    lot_allocation_method: str = "FIFO"
    price_valuation_point: str = "DAILY_CLOSE"
    peak_valuation_frequency: str = "EVERY_PRICED_DAY"
    multiple_rate_policy: str = "LATEST_PUBLICATION"
    market_dataset: str | None = None
    account_number: str | None = Field(default=None, max_length=64)
    account_status: str | None = Field(default=None, max_length=64)
    account_opened: date | None = None


class RunSummary(Model):
    id: str
    status: RunStatus
    assessment_year: str
    rule_version: str
    rule_verified: bool
    readiness: str | None
    is_filable: bool
    blocking_count: int
    error_message: str | None
    created_at: datetime
    finished_at: datetime | None


class FigureResponse(Model):
    """One reported amount, with the reasoning that produced it.

    ``status`` is what makes this readable: ``UNAVAILABLE`` means the figure
    could not be computed and ``inr_amount`` is null. It is not zero, and a
    client that renders a null as 0 is reporting a position the taxpayer
    never took.
    """

    field_name: str
    label: str
    status: str
    inr_amount: str | None
    native_amount: str | None
    currency: str | None
    rate_date: date | None
    rate_value: str | None
    formula: str
    explanation: str
    caveats: list[str]


class ScheduleFaRowResponse(Model):
    serial_number: int
    table_name: str
    subject: str
    country_code: str | None
    entity_name: str | None
    acquisition_date: date | None
    is_complete: bool
    missing_fields: list[str]
    figures: list[FigureResponse]


class RunDetail(RunSummary):
    fx_dataset: str | None
    fx_dataset_version: str | None
    market_dataset: str | None
    market_data_synthetic: bool
    policy: dict[str, Any]
    source_file_hashes: list[str]
    blocking_reasons: list[str]
    qualifications: list[str]
    table_a2: list[ScheduleFaRowResponse]
    table_a3: list[ScheduleFaRowResponse]


# --- issues ---------------------------------------------------------------


class IssueResponse(Model):
    issue_id: str
    resolution_key: str
    code: str
    severity: str
    scope: str
    subject: str
    message: str
    status: str
    is_blocking: bool
    context: dict[str, Any]


class WorklistGroup(Model):
    code: str
    title: str
    action: str
    severity: str
    count: int
    is_blocking: bool
    is_waivable: bool
    subjects: list[str]
    affected_figures: list[str]
    remediation: str


class DecisionRequest(Model):
    resolution_key: str
    #: ACKNOWLEDGED accepts the condition as it stands; RESOLVED claims the
    #: data was corrected and is verified against the next run.
    status: str = Field(pattern="^(ACKNOWLEDGED|RESOLVED)$")
    #: Required. An acknowledgement with no stated reason is indistinguishable
    #: from a mis-click a year later.
    note: str = Field(min_length=3, max_length=2000)


class DecisionResponse(Model):
    resolution_key: str
    status: str
    note: str
    decided_at: datetime


# --- reports --------------------------------------------------------------


class ArtifactResponse(Model):
    id: str
    kind: ArtifactKind
    file_name: str
    size_bytes: int
    content_hash: str
    #: What the writer had to change to make the file safe to open. Shown to
    #: the user rather than left in a log, because an altered cell is exactly
    #: what a reviewer is supposed to notice.
    sanitisation_notes: list[str]
    created_at: datetime


class DownloadTicket(Model):
    artifact_id: str
    token: str
    expires_at: datetime


# --- errors ---------------------------------------------------------------


class ErrorResponse(Model):
    #: A stable machine-readable code. The message is for people and may be
    #: reworded; clients should branch on this.
    code: str
    message: str
    detail: dict[str, Any] = Field(default_factory=dict)


# --- reference data -------------------------------------------------------


class FxDatasetResponse(Model):
    dataset_name: str
    version: str
    source_id: str
    source_tier: int
    record_count: int
    first_date: date | None
    last_date: date | None
    imported_at: datetime
    content_hash: str
    notes: str | None


class RunOptionsResponse(Model):
    lot_allocation_method: list[str]
    price_valuation_point: list[str]
    peak_valuation_frequency: list[str]
    multiple_rate_policy: list[str]
    defaults: dict[str, str]


class HealthResponse(Model):
    status: str
    environment: str
    database: str
    storage: str
    version: str
