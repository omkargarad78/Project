"""The FastAPI application.

Built by a factory rather than created at import time, so that a test can
construct one against an in-memory database and a throwaway storage root
without touching the developer's real configuration. Everything mutable —
the session factory, the blob store, the job runner — hangs off ``app.state``
so a test can substitute it without monkeypatching a module global.
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from ..core.config import Environment, Settings, get_settings
from ..db.session import build_engine, build_session_factory
from ..jobs.runner import JobRunner, build_runner
from ..storage.local import BlobStore, get_store
from .errors import install_error_handlers
from .routes import auth, files, issues, reference, reports, runs, workspaces
from .schemas import HealthResponse

logger = logging.getLogger(__name__)

API_PREFIX = "/api/v1"
VERSION = "0.1.0"


def create_app(
    *,
    settings: Settings | None = None,
    engine: Engine | None = None,
    session_factory: sessionmaker[Session] | None = None,
    blob_store: BlobStore | None = None,
    job_runner: JobRunner | None = None,
) -> FastAPI:
    settings = settings or get_settings()
    engine = engine or build_engine(settings)
    session_factory = session_factory or build_session_factory(engine)
    blob_store = blob_store or get_store(settings)
    job_runner = job_runner or build_runner(settings, session_factory)

    @asynccontextmanager
    async def lifespan(application: FastAPI) -> Iterator[None]:
        yield
        application.state.job_runner.shutdown(wait=True)

    app = FastAPI(
        title=settings.app_name,
        version=VERSION,
        lifespan=lifespan,
        # Hidden in production. The schema is a map of every endpoint and
        # field name, which is free reconnaissance for anyone probing it.
        docs_url=None if settings.is_production else "/docs",
        openapi_url=None if settings.is_production else "/openapi.json",
    )
    app.state.settings = settings
    app.state.engine = engine
    app.state.session_factory = session_factory
    app.state.blob_store = blob_store
    app.state.job_runner = job_runner

    install_error_handlers(app)
    _install_cors(app, settings)
    _install_security_headers(app)

    for module in (auth, workspaces, files, runs, issues, reports, reference):
        app.include_router(module.router, prefix=API_PREFIX)

    @app.get(f"{API_PREFIX}/health", response_model=HealthResponse, tags=["health"])
    def health() -> HealthResponse:
        """Whether the process can actually serve a request.

        Checks its dependencies rather than returning a constant. A health
        endpoint that answers "ok" while the database is unreachable keeps a
        broken instance in the load balancer.
        """
        database = "ok"
        try:
            with app.state.session_factory() as session:
                session.execute(text("SELECT 1"))
        except Exception as exc:  # noqa: BLE001 - reported, not raised
            logger.error("health check: database unreachable: %s", exc)
            database = "unavailable"

        storage = "ok"
        try:
            app.state.blob_store.exists("health/probe")
        except Exception as exc:  # noqa: BLE001
            logger.error("health check: storage unreachable: %s", exc)
            storage = "unavailable"

        return HealthResponse(
            status="ok" if database == "ok" and storage == "ok" else "degraded",
            environment=str(settings.environment),
            database=database,
            storage=storage,
            version=VERSION,
        )

    _install_frontend(app, settings)
    return app


def _install_frontend(app: FastAPI, settings: Settings) -> None:
    """Serve the browser client from this process, if it is present.

    Same origin as the API, which is what lets the CORS policy above stay
    empty in production: there is no cross-origin request to allow. Mounted
    last so that a static file can never shadow an API route.
    """
    if not settings.serve_frontend:
        return
    root = settings.frontend_root
    if not (root / "index.html").is_file():
        logger.info("no frontend at %s; serving the API only", root)
        return

    @app.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(root / "index.html")

    # html=True makes an unknown path fall back to index.html, which is what
    # a hash-routed client needs after a hard refresh.
    app.mount("/", StaticFiles(directory=root, html=True), name="frontend")


def _install_cors(app: FastAPI, settings: Settings) -> None:
    """Allow the frontend's origin, and nothing else.

    No wildcard: these endpoints are credentialed, and a wildcard origin
    with credentials lets any site a signed-in user visits read their tax
    data.
    """
    origins = (
        []
        if settings.is_production
        else ["http://localhost:5173", "http://127.0.0.1:5173"]
    )
    if not origins:
        return
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
    )


def _install_security_headers(app: FastAPI) -> None:
    @app.middleware("http")
    async def _headers(request, call_next):  # noqa: ANN001, ANN202
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        if request.url.path.startswith(API_PREFIX):
            # The API returns JSON and file downloads, never markup, so the
            # strictest possible policy costs nothing here.
            policy = "default-src 'none'; frame-ancestors 'none'"
        else:
            # The frontend needs its own stylesheet, modules and blob URLs
            # (downloads are assembled client-side). Still no 'unsafe-inline':
            # there is no inline script or style anywhere in the client, so
            # injected markup cannot execute even if it reaches the page.
            policy = (
                "default-src 'self'; script-src 'self'; style-src 'self'; "
                "img-src 'self' data:; connect-src 'self'; "
                "object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
            )
        response.headers.setdefault("Content-Security-Policy", policy)
        if request.app.state.settings.environment is Environment.PRODUCTION:
            response.headers.setdefault(
                "Strict-Transport-Security", "max-age=31536000; includeSubDomains"
            )
        return response
