"""Start a calculation the moment a statement is uploaded.

The manual path is still there and unchanged — pick a rate dataset, pick the
policies, press the button. This exists because for the common case there is
exactly one sensible answer to every one of those questions, and making
someone answer them before seeing a single figure is a barrier for no gain.

What it decides, and what it does not:

* The rate dataset is the newest one installed. It is still *pinned* on the
  run by name and version, so the run remains reproducible.
* The prices are fetched for the symbols in the statement and snapshotted
  before the run reads them.
* The policies take their documented defaults, and are recorded on the run
  like any other run, so the workpaper still says which ones were used.

Nothing here decides anything the engine would otherwise refuse to decide. A
missing rate is still a missing rate, and an unpriced holding still reports
NOT AVAILABLE.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..audit import Action, record
from ..brokers.registry import default_registry
from ..core.config import Settings
from ..db.models import SourceFile, User
from ..fx.store import FxDatasetStore
from ..io.loader import load_source
from ..jobs.runner import JobRunner
from ..provisioning.fx import FX_DIRNAME, ensure_fx_dataset
from ..provisioning.prices import ensure_price_dataset
from ..storage.local import BlobStore
from ..tax.rules.models import (
    LotAllocationMethod,
    MultipleRatePolicy,
    PeakValuationFrequency,
    PriceValuationPoint,
)
from ..tax.rules.registry import RuleRegistry
from .pipeline import RunOptions, create_run, execute_run

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class AutoRunOutcome:
    """Whether a run was started, and what it is missing if it was not."""

    run_id: str | None
    started: bool
    reason: str
    #: Symbols the price provider had no history for. The run still proceeds;
    #: their market values come out UNAVAILABLE.
    unpriced_symbols: tuple[str, ...] = ()


def start_automatic_run(
    session: Session,
    *,
    workspace_id: str,
    assessment_year: str,
    actor: User | None,
    store: BlobStore,
    settings: Settings,
    runner: JobRunner,
    ip: str | None,
) -> AutoRunOutcome:
    """Provision what is needed and queue a calculation. Never raises.

    An upload that succeeded must not be reported as a failure because the
    calculation could not be started; the file is safely stored either way,
    and the user can press the button themselves.
    """
    try:
        return _start(
            session,
            workspace_id=workspace_id,
            assessment_year=assessment_year,
            actor=actor,
            store=store,
            settings=settings,
            runner=runner,
            ip=ip,
        )
    except Exception as exc:  # noqa: BLE001 - the upload itself still succeeded
        logger.warning("could not start an automatic run: %s", exc)
        return AutoRunOutcome(None, False, str(exc))


def _start(
    session: Session,
    *,
    workspace_id: str,
    assessment_year: str,
    actor: User | None,
    store: BlobStore,
    settings: Settings,
    runner: JobRunner,
    ip: str | None,
) -> AutoRunOutcome:
    sources = list(
        session.scalars(
            select(SourceFile)
            .where(
                SourceFile.workspace_id == workspace_id,
                SourceFile.deleted_at.is_(None),
            )
            .order_by(SourceFile.created_at)
        )
    )
    if not sources:
        return AutoRunOutcome(None, False, "no statements to calculate from")

    fx_dataset, fx_version = _newest_rate_dataset(settings)
    if fx_dataset is None:
        return AutoRunOutcome(
            None,
            False,
            "no exchange-rate dataset is installed yet. If the application has "
            "only just started, it is still downloading; try again shortly.",
        )

    symbols, first, last = _survey(sources, store)
    prices = ensure_price_dataset(symbols, first, last, settings) if symbols else None

    registry = RuleRegistry.from_directory(settings.data_root / "rules")
    rule = registry.rule_for(assessment_year)

    options = RunOptions(
        fx_dataset=fx_dataset,
        fx_dataset_version=fx_version,
        assessment_year=assessment_year,
        lot_allocation_method=LotAllocationMethod.FIFO,
        price_valuation_point=PriceValuationPoint.DAILY_CLOSE,
        peak_valuation_frequency=PeakValuationFrequency.EVERY_PRICED_DAY,
        multiple_rate_policy=MultipleRatePolicy.LATEST_PUBLICATION,
        market_dataset=prices.dataset_name if prices else None,
    )

    run = create_run(
        session,
        workspace_id=workspace_id,
        requested_by=actor.id if actor else None,
        options=options,
        rule_version=rule.rule_version_id,
        rule_verified=rule.is_verified,
        file_hashes=[s.file_hash for s in sources],
    )
    record(
        session,
        Action.RUN_REQUESTED,
        actor=actor,
        workspace_id=workspace_id,
        target_type="calculation_run",
        target_id=run.id,
        ip_address=ip,
        trigger="automatic on upload",
        **options.as_record(),
    )
    # The worker uses its own session and has to be able to find the run.
    session.commit()

    runner.enqueue(
        run.id,
        lambda job_session, run_id: execute_run(
            job_session, run_id, options=options, store=store, settings=settings
        ),
    )
    session.refresh(run)

    return AutoRunOutcome(
        run_id=run.id,
        started=True,
        reason="started automatically on upload",
        unpriced_symbols=prices.symbols_missing if prices else (),
    )


def _newest_rate_dataset(settings: Settings) -> tuple[str | None, str | None]:
    """The most recently imported rate dataset, installing one if there is none."""
    store = FxDatasetStore(settings.data_root / FX_DIRNAME)
    stored = store.list()
    if not stored and settings.auto_bootstrap_datasets:
        # Startup provisioning may still be in flight, or may have failed
        # while the network was down. Trying again here costs one request and
        # turns "upload, wait, press the button" back into "upload".
        try:
            installed = ensure_fx_dataset(settings)
            return installed.dataset_name, installed.version
        except Exception as exc:  # noqa: BLE001
            logger.warning("no rate dataset available for an automatic run: %s", exc)
            return None, None
    if not stored:
        return None, None
    newest = max(stored, key=lambda s: s.dataset.imported_at).dataset
    return newest.dataset_name, newest.version


def _survey(sources: list[SourceFile], store: BlobStore) -> tuple[list[str], date, date]:
    """Read the statements far enough to learn which prices to fetch.

    A full parse whose result is then thrown away — the run re-parses inside
    the pipeline with issue collection wired up. Parsing twice is cheap
    against a network fetch, and it keeps this module out of the calculation
    path entirely.
    """
    registry = default_registry()
    symbols: set[str] = set()
    earliest: date | None = None
    latest: date | None = None

    for stored in sources:
        try:
            loaded = load_source(store.get(stored.storage_key), file_name=stored.file_name)
            parsed = registry.parse(loaded)
        except Exception as exc:  # noqa: BLE001 - the run reports this properly
            logger.info("could not survey %s for prices: %s", stored.file_name, exc)
            continue
        symbols.update(parsed.ledger.tickers())
        span = parsed.ledger.date_range()
        if span is None:
            continue
        earliest = span[0] if earliest is None else min(earliest, span[0])
        latest = span[1] if latest is None else max(latest, span[1])

    today = date.today()
    earliest = earliest or today
    # A position held at the last transaction is still held afterwards, and
    # the closing and peak values need prices through the end of the
    # reporting period. Fetching up to today covers that without having to
    # resolve the period here.
    latest = max(latest or today, today)
    return sorted(symbols), earliest, latest
