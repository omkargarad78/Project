"""Running the pipeline for a workspace and persisting what it produced.

This is the only place the API layer and the calculation engines meet. The
engines know nothing about the database and the routes know nothing about
the engines, which is what lets the pipeline be tested without a web server
and the API be tested without recomputing a peak value.

What is persisted is the *outcome*, not a cache: every figure, every
explanation, every issue and the version of every input that produced them.
A run is never updated afterwards. Re-running writes a new one, because a
figure that was filed has to stay reproducible after the rate dataset moves
on.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, date, datetime
from pathlib import Path
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..audit import Action, record
from ..brokers.registry import default_registry
from ..core.config import Settings, get_settings
from ..core.errors import ErrorCode, ParseError, PriceError
from ..core.money import decimal_to_str
from ..db.models import (
    Artifact,
    ArtifactKind,
    CalculationRun,
    IssueResolution,
    RunIssue,
    RunStatus,
    ScheduleFaRow,
    SourceFile,
)
from ..fx.resolver import FxResolver
from ..fx.store import FxDatasetStore
from ..io.loader import load_source
from ..lots.engine import LotEngine, reconcile
from ..marketdata.dataset import MarketDataSnapshot
from ..marketdata.models import AdjustmentBasis
from ..marketdata.provider import CsvPriceProvider, PricePolicy, PriceResolver
from ..reports.builder import WorkpaperBuilder, WorkpaperInputs
from ..reports.csv_writer import write_csv_bundle
from ..reports.xlsx_writer import write_xlsx
from ..schedulefa.engine import ScheduleFaEngine
from ..schedulefa.models import ScheduleFaReport
from ..securities.master import load_default_master
from ..securities.resolver import SecurityResolver
from ..storage.local import BlobStore, put_content
from ..tax.periods import AssessmentYear
from ..tax.rules.models import (
    CalculationPolicy,
    LotAllocationMethod,
    MultipleRatePolicy,
    PeakValuationFrequency,
    PriceValuationPoint,
)
from ..tax.rules.registry import RuleRegistry
from ..validation.engine import ValidationEngine, ValidationReport
from ..validation.issues import IssueCollector, IssueStatus
from ..validation.resolutions import ResolutionRecord, ResolutionStore

FX_DATASET_DIRNAME = "fx"
MARKET_DATA_DIRNAME = "market"


@dataclass(frozen=True, slots=True)
class RunOptions:
    """The run request, already validated, in engine vocabulary."""

    fx_dataset: str
    fx_dataset_version: str
    assessment_year: str
    lot_allocation_method: LotAllocationMethod
    price_valuation_point: PriceValuationPoint
    peak_valuation_frequency: PeakValuationFrequency
    multiple_rate_policy: MultipleRatePolicy
    market_dataset: str | None = None
    account_number: str | None = None
    account_status: str | None = None
    account_opened: date | None = None

    def as_policy(self) -> CalculationPolicy:
        return CalculationPolicy(
            lot_allocation_method=self.lot_allocation_method,
            price_valuation_point=self.price_valuation_point,
            peak_valuation_frequency=self.peak_valuation_frequency,
        )

    def as_record(self) -> dict[str, Any]:
        """The policy as stored on the run, for reproducibility."""
        return {
            "lot_allocation_method": str(self.lot_allocation_method),
            "price_valuation_point": str(self.price_valuation_point),
            "peak_valuation_frequency": str(self.peak_valuation_frequency),
            "multiple_rate_policy": str(self.multiple_rate_policy),
        }


def create_run(
    session: Session,
    *,
    workspace_id: str,
    requested_by: str | None,
    options: RunOptions,
    rule_version: str,
    rule_verified: bool,
    file_hashes: list[str],
) -> CalculationRun:
    """Record a queued run. Called inside the request, before any work."""
    run = CalculationRun(
        workspace_id=workspace_id,
        requested_by=requested_by,
        status=RunStatus.QUEUED,
        assessment_year=options.assessment_year,
        rule_version=rule_version,
        rule_verified=rule_verified,
        fx_dataset=options.fx_dataset,
        fx_dataset_version=options.fx_dataset_version,
        market_dataset=options.market_dataset,
        policy=options.as_record(),
        source_file_hashes=file_hashes,
    )
    session.add(run)
    session.flush()
    return run


def execute_run(
    session: Session,
    run_id: str,
    *,
    options: RunOptions,
    store: BlobStore,
    settings: Settings | None = None,
) -> CalculationRun:
    """Do the work and write down everything it produced.

    Runs on a job worker with its own session. Nothing here assumes a
    request is still open.
    """
    settings = settings or get_settings()
    run = session.get(CalculationRun, run_id)
    if run is None:
        raise LookupError(f"no calculation run {run_id}")

    run.status = RunStatus.RUNNING
    run.started_at = datetime.now(UTC)
    session.flush()

    issues = IssueCollector()
    sources, ledger, parser_report = _parse_uploads(session, run, store, issues)

    master = load_default_master()
    resolution = SecurityResolver(master).resolve_ledger(ledger, issues)

    policy = options.as_policy()
    book = LotEngine(policy=policy).build(ledger, issues)
    if parser_report is not None:
        stated = getattr(parser_report, "closing_holdings", None)
        if stated:
            reconcile(book, stated, issues)

    registry = RuleRegistry.from_directory(settings.data_root / "rules")
    rule = registry.rule_for(options.assessment_year)
    fx = FxResolver(
        FxDatasetStore(settings.data_root / FX_DATASET_DIRNAME).load(
            options.fx_dataset, options.fx_dataset_version
        ),
        multiple_rate_policy=options.multiple_rate_policy,
    )
    snapshot = _load_market_data(settings, options)

    report = ScheduleFaEngine(
        rule=rule,
        period=rule.schedule_fa.reporting_period.resolve(
            AssessmentYear.parse(options.assessment_year)
        ),
        fx=fx,
        market_data=snapshot,
        price_resolver=PriceResolver(
            snapshot,
            policy=PricePolicy(),
            expected_currency="USD",
        ),
        policy=policy,
    ).build(
        ledger,
        book,
        resolution,
        issues,
        account_number=options.account_number,
        account_status=options.account_status,
        account_opening_date=options.account_opened,
    )

    # Decisions recorded against earlier runs are re-applied before the
    # verdict, so that an accepted condition does not block this run and a
    # claimed fix that did not take is reopened here rather than silently
    # carried.
    _apply_stored_decisions(session, run.workspace_id, issues)
    validation = ValidationEngine().assess(issues, report)

    _persist_rows(session, run, report)
    _persist_issues(session, run, issues)
    _persist_artifacts(
        session,
        run,
        store,
        WorkpaperInputs(
            schedule_fa=report,
            validation=validation,
            issues=issues,
            fx=fx,
            ledger=ledger,
            lots=book,
            securities=resolution,
            market_data=snapshot,
            source_files=[(s.file_name, s.file_hash) for s in sources],
            broker=parser_report.broker_name if parser_report else None,
            parser_version=parser_report.parser_version if parser_report else None,
        ),
    )

    run.rule_version = report.rule_version
    run.rule_verified = report.rule_verified
    run.market_data_synthetic = snapshot.synthetic
    run.readiness = str(validation.readiness)
    run.is_filable = validation.is_filable
    run.blocking_count = len(validation.blocking_reasons)
    run.status = RunStatus.COMPLETED
    run.finished_at = datetime.now(UTC)

    record(
        session,
        Action.RUN_COMPLETED,
        workspace_id=run.workspace_id,
        target_type="calculation_run",
        target_id=run.id,
        readiness=run.readiness,
        is_filable=run.is_filable,
        blocking_count=run.blocking_count,
    )
    session.flush()
    return run


# --- stages ---------------------------------------------------------------


def _parse_uploads(
    session: Session,
    run: CalculationRun,
    store: BlobStore,
    issues: IssueCollector,
):  # noqa: ANN202
    """Read every live upload in the workspace into one ledger."""
    sources = list(
        session.scalars(
            select(SourceFile)
            .where(
                SourceFile.workspace_id == run.workspace_id,
                SourceFile.deleted_at.is_(None),
            )
            .order_by(SourceFile.created_at)
        )
    )
    if not sources:
        raise ParseError(
            ErrorCode.SOURCE_FILE_UNSUPPORTED,
            "this workspace has no uploaded statements to calculate from",
        )

    registry = default_registry()
    ledger = None
    parser_report = None
    for stored in sources:
        loaded = load_source(store.get(stored.storage_key), file_name=stored.file_name)
        parsed = registry.parse(loaded)
        issues.merge(parsed.issues)
        parser_report = parsed.report
        if ledger is None:
            ledger = parsed.ledger
        else:
            ledger.extend(parsed.ledger.transactions)

    assert ledger is not None
    return sources, ledger, parser_report


def _load_market_data(settings: Settings, options: RunOptions) -> MarketDataSnapshot:
    """Load the named price dataset, or refuse to guess.

    A missing dataset raises rather than producing an empty snapshot. An
    empty snapshot would value every holding at nothing and report it as
    unavailable, which is technically honest and completely unhelpful.
    """
    if not options.market_dataset:
        raise PriceError(
            ErrorCode.MARKET_DATA_DATASET_MISSING,
            "a market-data dataset is required to value holdings; none was named",
        )

    path = Path(settings.data_root) / MARKET_DATA_DIRNAME / f"{options.market_dataset}.csv"
    if not path.exists():
        raise PriceError(
            ErrorCode.MARKET_DATA_DATASET_MISSING,
            f"no market-data dataset named {options.market_dataset!r} is installed",
        )

    provider = CsvPriceProvider(
        path.read_bytes(),
        file_name=path.name,
        adjustment_basis=AdjustmentBasis.UNADJUSTED,
        default_currency="USD",
    )
    return MarketDataSnapshot(
        provider.all_records(),
        dataset_name=options.market_dataset,
        adjustment_basis=AdjustmentBasis.UNADJUSTED,
    )


def _apply_stored_decisions(
    session: Session, workspace_id: str, issues: IssueCollector
) -> None:
    stored = session.scalars(
        select(IssueResolution).where(IssueResolution.workspace_id == workspace_id)
    )
    store = ResolutionStore(
        ResolutionRecord(
            resolution_key=row.resolution_key,
            status=IssueStatus(row.status),
            note=row.note,
            user=row.decided_by or "",
            at=row.decided_at,
            issue_id="",
            message=row.message,
            code=row.code,
            subject=row.subject,
        )
        for row in stored
    )
    store.apply(issues)


# --- persistence ----------------------------------------------------------


def _figure_payload(figure) -> dict[str, Any]:  # noqa: ANN001
    return {
        "field_name": figure.field_name,
        "label": figure.label,
        "status": str(figure.status),
        "inr_amount": decimal_to_str(figure.inr_amount),
        "native_amount": decimal_to_str(figure.native_amount),
        "currency": figure.currency,
        "rate_date": figure.rate_date.isoformat() if figure.rate_date else None,
        "rate_value": decimal_to_str(figure.rate_value),
        "rate_type": figure.rate_type,
        "formula": figure.formula,
        "explanation": figure.explanation,
        "caveats": list(figure.caveats),
    }


def _persist_rows(
    session: Session, run: CalculationRun, report: ScheduleFaReport
) -> None:
    for table_name, rows in (("A3", report.table_a3), ("A2", report.table_a2)):
        for row in rows:
            figures = {f.field_name: f for f in row.figures()}
            session.add(
                ScheduleFaRow(
                    run_id=run.id,
                    table_name=table_name,
                    serial_number=row.serial_number,
                    subject=row.subject,
                    country_code=row.country_code.value,
                    entity_name=getattr(row, "entity_name", None).value
                    if hasattr(row, "entity_name")
                    else getattr(row, "institution_name").value,
                    acquisition_date=_as_date(
                        getattr(row, "acquisition_date", None)
                    ),
                    initial_value_inr=_amount(figures.get("initial_value")),
                    peak_value_inr=_amount(
                        figures.get("peak_value") or figures.get("peak_balance")
                    ),
                    closing_value_inr=_amount(
                        figures.get("closing_value") or figures.get("closing_balance")
                    ),
                    income_credited_inr=_amount(
                        figures.get("income_credited")
                        or figures.get("gross_amount_credited")
                    ),
                    gross_proceeds_inr=_amount(figures.get("gross_proceeds")),
                    is_complete=row.is_complete,
                    derivation={
                        "missing_fields": list(row.missing_fields()),
                        "caveats": list(row.all_caveats()),
                        "figures": [_figure_payload(f) for f in row.figures()],
                    },
                )
            )


def _persist_issues(
    session: Session, run: CalculationRun, issues: IssueCollector
) -> None:
    for item in issues:
        session.add(
            RunIssue(
                run_id=run.id,
                issue_id=item.issue_id,
                resolution_key=item.resolution_key,
                code=str(item.code),
                severity=str(item.severity),
                scope=str(item.scope),
                subject=item.subject,
                message=item.message,
                status=str(item.status),
                is_blocking=item.is_blocking,
                context={k: _jsonable(v) for k, v in item.context.items()},
            )
        )


def _persist_artifacts(
    session: Session,
    run: CalculationRun,
    store: BlobStore,
    inputs: WorkpaperInputs,
) -> None:
    paper = WorkpaperBuilder().build(inputs)

    content, log = write_xlsx(paper)
    key, digest = put_content(store, "workpapers", content, suffix=".xlsx")
    session.add(
        Artifact(
            run_id=run.id,
            kind=ArtifactKind.WORKPAPER_XLSX,
            file_name=f"schedule-fa-{run.assessment_year}.xlsx",
            storage_key=key,
            content_hash=digest,
            size_bytes=len(content),
            sanitisation_notes=log.notes(),
        )
    )

    files, csv_log = write_csv_bundle(paper)
    bundle = _zip_bundle(files)
    key, digest = put_content(store, "workpapers", bundle, suffix=".zip")
    session.add(
        Artifact(
            run_id=run.id,
            kind=ArtifactKind.WORKPAPER_CSV,
            file_name=f"schedule-fa-{run.assessment_year}-csv.zip",
            storage_key=key,
            content_hash=digest,
            size_bytes=len(bundle),
            sanitisation_notes=csv_log.notes(),
        )
    )


def _zip_bundle(files) -> bytes:  # noqa: ANN001
    """Pack the CSV bundle for download.

    Entry timestamps are frozen so that the same run downloaded twice is the
    same bytes, which is the property the determinism tests assert about
    everything else the platform produces.
    """
    import io
    import zipfile

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for item in files:
            info = zipfile.ZipInfo(item.file_name, date_time=(2025, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, item.content)
    return buffer.getvalue()


def _amount(figure):  # noqa: ANN001, ANN202
    return figure.inr_amount if figure is not None else None


def _as_date(field):  # noqa: ANN001, ANN202
    if field is None or not field.available or not field.value:
        return None
    try:
        return date.fromisoformat(field.value)
    except ValueError:
        return None


def _jsonable(value: Any) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    return str(value)
