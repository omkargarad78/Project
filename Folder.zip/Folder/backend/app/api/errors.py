"""How failures become responses.

One shape for every error, so a client has one thing to parse:
``{"code": ..., "message": ..., "detail": {...}}``.

The unhandled-exception handler returns a generic message on purpose. A
stack trace or a raw exception string in a response body leaks file paths,
library versions and sometimes a fragment of the user's own financial data
to whoever provoked it. The detail goes to the log, which is where the
operator can see it and the caller cannot.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from ..auth.service import AuthError, PermissionDenied
from ..core.errors import PlatformError
from ..core.money import MoneyError
from ..storage.local import StorageError

logger = logging.getLogger(__name__)


class ApiError(Exception):
    """An error with a status code and a stable machine-readable code."""

    def __init__(
        self,
        status_code: int,
        code: str,
        message: str,
        *,
        detail: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.message = message
        self.detail = detail or {}
        self.headers = headers


def _body(code: str, message: str, detail: dict[str, Any] | None = None) -> dict:
    return {"code": code, "message": message, "detail": detail or {}}


def install_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(ApiError)
    async def _api_error(_request: Request, exc: ApiError) -> JSONResponse:
        return JSONResponse(
            status_code=exc.status_code,
            content=_body(exc.code, exc.message, exc.detail),
            headers=exc.headers,
        )

    @app.exception_handler(AuthError)
    async def _auth_error(_request: Request, exc: AuthError) -> JSONResponse:
        # Uniform message and status regardless of which half was wrong, so
        # the endpoint cannot be used to discover who has an account.
        logger.info("authentication refused: %s", exc)
        return JSONResponse(
            status_code=status.HTTP_401_UNAUTHORIZED,
            content=_body(
                "AUTHENTICATION_FAILED", "the email or password is incorrect"
            ),
        )

    @app.exception_handler(PermissionDenied)
    async def _denied(_request: Request, _exc: PermissionDenied) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content=_body("NOT_FOUND", "no such workspace"),
        )

    @app.exception_handler(RequestValidationError)
    async def _validation(
        _request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        return JSONResponse(
            status_code=422,
            content=_body(
                "INVALID_REQUEST",
                "the request body or parameters could not be accepted",
                {"fields": _readable_fields(exc)},
            ),
        )

    @app.exception_handler(PlatformError)
    async def _platform(_request: Request, exc: PlatformError) -> JSONResponse:
        # The platform's own errors already carry a stable code and a message
        # written for the user, so they pass through as they are.
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content=_body(str(exc.code), str(exc)),
        )

    @app.exception_handler(MoneyError)
    async def _money(_request: Request, exc: MoneyError) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content=_body("INVALID_AMOUNT", str(exc)),
        )

    @app.exception_handler(StorageError)
    async def _storage(_request: Request, exc: StorageError) -> JSONResponse:
        logger.error("storage failure: %s", exc)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=_body(
                "STORAGE_UNAVAILABLE",
                "the stored file could not be read. Nothing was changed.",
            ),
        )

    @app.exception_handler(Exception)
    async def _unhandled(_request: Request, exc: Exception) -> JSONResponse:
        # Correlates the caller's report with the log entry without putting
        # anything about the failure in the response.
        reference = uuid.uuid4().hex[:12]
        logger.exception("unhandled error [%s]", reference)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=_body(
                "INTERNAL_ERROR",
                "something went wrong and the request was not completed",
                {"reference": reference},
            ),
        )


def _readable_fields(exc: RequestValidationError) -> list[dict[str, str]]:
    """Which fields were rejected and why, without echoing their values.

    Pydantic's default output includes the offending input, which for this
    API can be a password.
    """
    fields = []
    for error in exc.errors():
        location = ".".join(str(part) for part in error.get("loc", ()) if part != "body")
        fields.append({"field": location or "body", "problem": error.get("msg", "")})
    return fields
