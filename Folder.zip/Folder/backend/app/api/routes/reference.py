"""Reference data: what the client is allowed to ask for.

Without this the frontend has to hardcode the FX dataset names and the policy
enum members, which means adding a rate dataset or an allocation method
requires shipping a new client. The server already knows both; it may as well
say so.

Read-only and unauthenticated only in the sense that it exposes no workspace
data — it still requires a signed-in user, because the set of installed rate
datasets is a fact about the deployment.
"""

from __future__ import annotations

from fastapi import APIRouter

from ...fx.store import FxDatasetStore
from ...tax.rules.models import (
    LotAllocationMethod,
    MultipleRatePolicy,
    PeakValuationFrequency,
    PriceValuationPoint,
)
from ..deps import SettingsDep, UserDep
from ..pipeline import FX_DATASET_DIRNAME, MARKET_DATA_DIRNAME
from ..schemas import FxDatasetResponse, RunOptionsResponse

router = APIRouter(prefix="/reference", tags=["reference"])


@router.get("/fx-datasets", response_model=list[FxDatasetResponse])
def fx_datasets(user: UserDep, settings: SettingsDep) -> list[FxDatasetResponse]:
    """The rate datasets installed on this deployment.

    A run cannot be requested without naming one, and naming one that is not
    installed fails the run rather than silently substituting another, so the
    client needs the real list.
    """
    store = FxDatasetStore(settings.data_root / FX_DATASET_DIRNAME)
    results: list[FxDatasetResponse] = []
    for stored in store.list():
        dataset = stored.dataset
        dates = sorted(record.rate_date for record in dataset.records)
        results.append(
            FxDatasetResponse(
                dataset_name=dataset.dataset_name,
                version=dataset.version,
                source_id=dataset.source_id,
                source_tier=int(dataset.source_tier),
                record_count=len(dataset.records),
                first_date=dates[0] if dates else None,
                last_date=dates[-1] if dates else None,
                imported_at=dataset.imported_at,
                content_hash=dataset.content_hash,
                notes=dataset.notes,
            )
        )
    return results


@router.get("/market-datasets", response_model=list[str])
def market_datasets(user: UserDep, settings: SettingsDep) -> list[str]:
    """Names of the installed price datasets.

    A run may omit this, in which case prices are unavailable and every value
    that depends on one is reported as such rather than guessed.
    """
    root = settings.data_root / MARKET_DATA_DIRNAME
    if not root.exists():
        return []
    return sorted(path.stem for path in root.glob("*.csv"))


@router.get("/run-options", response_model=RunOptionsResponse)
def run_options(user: UserDep) -> RunOptionsResponse:
    """The policy choices a run accepts, and the default for each.

    These are labelled as *policies* rather than rules throughout: the law
    requires a peak value to be reported without prescribing how often to
    revalue, so the choice is the filer's and is recorded on the run.
    """
    return RunOptionsResponse(
        lot_allocation_method=[str(m) for m in LotAllocationMethod],
        price_valuation_point=[str(m) for m in PriceValuationPoint],
        peak_valuation_frequency=[str(m) for m in PeakValuationFrequency],
        multiple_rate_policy=[str(m) for m in MultipleRatePolicy],
        defaults={
            "lot_allocation_method": str(LotAllocationMethod.FIFO),
            "price_valuation_point": str(PriceValuationPoint.DAILY_CLOSE),
            "peak_valuation_frequency": str(PeakValuationFrequency.EVERY_PRICED_DAY),
            "multiple_rate_policy": str(MultipleRatePolicy.LATEST_PUBLICATION),
        },
    )
