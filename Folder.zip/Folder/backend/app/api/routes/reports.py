"""Listing and downloading generated workpapers."""

from __future__ import annotations

from fastapi import APIRouter, Query, Response
from sqlalchemy import select

from ...audit import Action, record
from ...auth.tokens import TokenError, issue_download_token, read_download_token
from ...db.models import Artifact, ArtifactKind, CalculationRun
from ...storage.local import get_verified
from ..deps import IpDep, PrincipalDep, SessionDep, SettingsDep, StoreDep
from ..errors import ApiError
from ..schemas import ArtifactResponse, DownloadTicket

router = APIRouter(prefix="/workspaces/{workspace_id}", tags=["reports"])

_CONTENT_TYPES = {
    ArtifactKind.WORKPAPER_XLSX: (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    ),
    ArtifactKind.WORKPAPER_CSV: "application/zip",
}


@router.get("/runs/{run_id}/artifacts", response_model=list[ArtifactResponse])
def index(
    run_id: str, principal: PrincipalDep, session: SessionDep
) -> list[ArtifactResponse]:
    _run_or_404(session, principal.workspace.id, run_id)
    rows = session.scalars(
        select(Artifact).where(Artifact.run_id == run_id).order_by(Artifact.kind)
    )
    return [ArtifactResponse.model_validate(row) for row in rows]


@router.post("/artifacts/{artifact_id}/ticket", response_model=DownloadTicket)
def ticket(
    artifact_id: str,
    principal: PrincipalDep,
    session: SessionDep,
    settings: SettingsDep,
) -> DownloadTicket:
    """Mint a short-lived token for one artifact.

    A browser following a download link cannot set an Authorization header,
    so the credential has to travel in the URL. That makes it visible in
    history, proxy logs and referrer headers, which is why this token is
    scoped to a single artifact, expires in minutes, and is typed so it
    cannot be replayed as a session.
    """
    artifact = _artifact_or_404(session, principal.workspace.id, artifact_id)
    token, expires = issue_download_token(
        principal.user.id, artifact.id, settings=settings
    )
    return DownloadTicket(artifact_id=artifact.id, token=token, expires_at=expires)


@router.get("/artifacts/{artifact_id}/download")
def download(
    artifact_id: str,
    principal: PrincipalDep,
    session: SessionDep,
    store: StoreDep,
    settings: SettingsDep,
    ip: IpDep,
    token: str = Query(default=""),
) -> Response:
    """Serve the bytes, re-checking membership rather than trusting the token.

    The ticket proves the request came from a link this user was given. It
    does not prove they still have access, so the workspace check runs again
    here. A token minted before someone was removed from a workspace must
    stop working when they are, not when it expires.
    """
    artifact = _artifact_or_404(session, principal.workspace.id, artifact_id)

    if token:
        try:
            claims = read_download_token(token, settings=settings)
        except TokenError as exc:
            raise ApiError(403, "INVALID_DOWNLOAD_TOKEN", str(exc)) from exc
        if claims.artifact_id != artifact.id or claims.user_id != principal.user.id:
            raise ApiError(
                403,
                "INVALID_DOWNLOAD_TOKEN",
                "this link is not valid for this file",
            )

    content = get_verified(store, artifact.storage_key, artifact.content_hash)

    record(
        session,
        Action.REPORT_DOWNLOADED,
        actor=principal.user,
        workspace_id=principal.workspace.id,
        target_type="artifact",
        target_id=artifact.id,
        ip_address=ip,
        file_name=artifact.file_name,
    )

    return Response(
        content=content,
        media_type=_CONTENT_TYPES.get(
            ArtifactKind(artifact.kind), "application/octet-stream"
        ),
        headers={
            # "attachment" matters: without it a browser may render the file
            # inline, and an HTML-ish payload would execute in the site's
            # origin. nosniff stops the same thing by content sniffing.
            "Content-Disposition": f'attachment; filename="{artifact.file_name}"',
            "X-Content-Type-Options": "nosniff",
            "Cache-Control": "private, no-store",
        },
    )


def _run_or_404(session, workspace_id: str, run_id: str) -> CalculationRun:  # noqa: ANN001
    run = session.get(CalculationRun, run_id)
    if run is None or run.workspace_id != workspace_id:
        raise ApiError(404, "NOT_FOUND", "no such calculation run")
    return run


def _artifact_or_404(session, workspace_id: str, artifact_id: str) -> Artifact:  # noqa: ANN001
    artifact = session.get(Artifact, artifact_id)
    if artifact is None:
        raise ApiError(404, "NOT_FOUND", "no such report")
    # The artifact's workspace is reached through its run. Checked rather
    # than assumed, so that an id guessed from another workspace is refused.
    run = session.get(CalculationRun, artifact.run_id)
    if run is None or run.workspace_id != workspace_id:
        raise ApiError(404, "NOT_FOUND", "no such report")
    return artifact
