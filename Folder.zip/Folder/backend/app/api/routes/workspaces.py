"""Workspaces and who may see them."""

from __future__ import annotations

from fastapi import APIRouter, status
from sqlalchemy import select

from ...audit import Action, record
from ...auth.service import (
    PermissionDenied,
    AuthError,
    add_member,
    create_workspace,
    list_workspaces,
    remove_member,
)
from ...db.models import Membership, User
from ..deps import AdminDep, IpDep, PrincipalDep, SessionDep, UserDep
from ..errors import ApiError
from ..schemas import (
    MemberInvite,
    MemberResponse,
    WorkspaceCreate,
    WorkspaceResponse,
)

router = APIRouter(prefix="/workspaces", tags=["workspaces"])


@router.get("", response_model=list[WorkspaceResponse])
def list_mine(session: SessionDep, user: UserDep) -> list[WorkspaceResponse]:
    return [
        WorkspaceResponse(
            id=workspace.id,
            name=workspace.name,
            assessment_year=workspace.assessment_year,
            role=role,
            created_at=workspace.created_at,
        )
        for workspace, role in list_workspaces(session, user=user)
    ]


@router.post("", response_model=WorkspaceResponse, status_code=status.HTTP_201_CREATED)
def create(
    body: WorkspaceCreate, session: SessionDep, user: UserDep, ip: IpDep
) -> WorkspaceResponse:
    workspace = create_workspace(
        session, owner=user, name=body.name, assessment_year=body.assessment_year
    )
    workspace.residency_note = body.residency_note
    record(
        session,
        Action.WORKSPACE_CREATED,
        actor=user,
        workspace_id=workspace.id,
        target_type="workspace",
        target_id=workspace.id,
        ip_address=ip,
        assessment_year=body.assessment_year,
    )
    from ...db.models import Role

    return WorkspaceResponse(
        id=workspace.id,
        name=workspace.name,
        assessment_year=workspace.assessment_year,
        role=Role.OWNER,
        created_at=workspace.created_at,
    )


@router.get("/{workspace_id}", response_model=WorkspaceResponse)
def read(principal: PrincipalDep) -> WorkspaceResponse:
    return WorkspaceResponse(
        id=principal.workspace.id,
        name=principal.workspace.name,
        assessment_year=principal.workspace.assessment_year,
        role=principal.role,
        created_at=principal.workspace.created_at,
    )


@router.get("/{workspace_id}/members", response_model=list[MemberResponse])
def members(principal: PrincipalDep, session: SessionDep) -> list[MemberResponse]:
    rows = session.execute(
        select(User, Membership.role)
        .join(Membership, Membership.user_id == User.id)
        .where(Membership.workspace_id == principal.workspace.id)
        .order_by(User.email)
    ).all()
    return [
        MemberResponse(
            user_id=user.id,
            email=user.email,
            display_name=user.display_name,
            role=role,
        )
        for user, role in rows
    ]


@router.post(
    "/{workspace_id}/members",
    response_model=MemberResponse,
    status_code=status.HTTP_201_CREATED,
)
def invite(
    body: MemberInvite,
    principal: AdminDep,
    session: SessionDep,
    ip: IpDep,
) -> MemberResponse:
    try:
        membership = add_member(
            session, workspace=principal.workspace, email=body.email, role=body.role
        )
    except AuthError as exc:
        raise ApiError(404, "NO_SUCH_USER", str(exc)) from exc

    user = session.get(User, membership.user_id)
    assert user is not None
    record(
        session,
        Action.MEMBER_ADDED,
        actor=principal.user,
        workspace_id=principal.workspace.id,
        target_type="user",
        target_id=user.id,
        ip_address=ip,
        role=str(body.role),
    )
    return MemberResponse(
        user_id=user.id,
        email=user.email,
        display_name=user.display_name,
        role=body.role,
    )


@router.delete(
    "/{workspace_id}/members/{member_id}", status_code=status.HTTP_204_NO_CONTENT
)
def revoke(
    member_id: str,
    principal: AdminDep,
    session: SessionDep,
    ip: IpDep,
) -> None:
    try:
        remove_member(session, workspace=principal.workspace, user_id=member_id)
    except PermissionDenied as exc:
        # Refusing to remove the last owner is a conflict with the current
        # state, not a missing resource. The app-level handler turns
        # PermissionDenied into a 404 to avoid confirming that a workspace
        # exists, which is the wrong answer here: the caller is already an
        # owner of it.
        raise ApiError(409, "LAST_OWNER", str(exc)) from exc
    record(
        session,
        Action.MEMBER_REMOVED,
        actor=principal.user,
        workspace_id=principal.workspace.id,
        target_type="user",
        target_id=member_id,
        ip_address=ip,
    )
