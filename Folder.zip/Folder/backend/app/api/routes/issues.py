"""Reading the issue list and recording decisions about it."""

from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, Query, status
from sqlalchemy import select

from ...audit import Action, record
from ...core.errors import ERROR_CATALOG, ErrorCode
from ...db.models import CalculationRun, IssueResolution, RunIssue
from ...validation.issues import IssueStatus
from ..deps import IpDep, PrincipalDep, SessionDep, WriterDep
from ..errors import ApiError
from ..schemas import (
    DecisionRequest,
    DecisionResponse,
    IssueResponse,
    WorklistGroup,
)

router = APIRouter(prefix="/workspaces/{workspace_id}", tags=["issues"])


@router.get("/runs/{run_id}/issues", response_model=list[IssueResponse])
def issues_for_run(
    run_id: str,
    principal: PrincipalDep,
    session: SessionDep,
    blocking_only: bool = Query(default=False),
) -> list[IssueResponse]:
    _run_or_404(session, principal.workspace.id, run_id)
    statement = select(RunIssue).where(RunIssue.run_id == run_id)
    if blocking_only:
        statement = statement.where(RunIssue.is_blocking.is_(True))
    rows = session.scalars(statement.order_by(RunIssue.severity, RunIssue.code))
    return [IssueResponse.model_validate(row) for row in rows]


@router.get("/runs/{run_id}/worklist", response_model=list[WorklistGroup])
def worklist(
    run_id: str, principal: PrincipalDep, session: SessionDep
) -> list[WorklistGroup]:
    """Issues grouped by the action that clears them.

    Grouped here rather than by the client, because the grouping is a
    product decision — many occurrences of one condition are usually one
    task — and two clients grouping it differently would give two users
    different advice about the same data.
    """
    _run_or_404(session, principal.workspace.id, run_id)
    rows = list(session.scalars(select(RunIssue).where(RunIssue.run_id == run_id)))

    groups: dict[str, list[RunIssue]] = {}
    for row in rows:
        groups.setdefault(row.code, []).append(row)

    built = []
    for code, members in groups.items():
        try:
            definition = ERROR_CATALOG[ErrorCode(code)]
        except (KeyError, ValueError):
            continue
        built.append(
            WorklistGroup(
                code=code,
                title=definition.title,
                action=definition.action.label,
                severity=str(definition.default_severity),
                count=len(members),
                is_blocking=any(m.is_blocking for m in members),
                is_waivable=definition.waivable,
                subjects=sorted({m.subject for m in members})[:20],
                affected_figures=[],
                remediation=definition.remediation,
            )
        )

    # Blocking work first, then the largest clusters: the ordering the
    # validation engine uses, reproduced here so the API and the workpaper
    # present the same priorities.
    built.sort(key=lambda g: (not g.is_blocking, -g.count, g.code))
    return built


@router.get("/decisions", response_model=list[DecisionResponse])
def decisions(principal: PrincipalDep, session: SessionDep) -> list[DecisionResponse]:
    rows = session.scalars(
        select(IssueResolution)
        .where(IssueResolution.workspace_id == principal.workspace.id)
        .order_by(IssueResolution.decided_at.desc())
    )
    return [DecisionResponse.model_validate(row) for row in rows]


@router.put(
    "/decisions", response_model=DecisionResponse, status_code=status.HTTP_200_OK
)
def decide(
    body: DecisionRequest,
    principal: WriterDep,
    session: SessionDep,
    ip: IpDep,
) -> DecisionResponse:
    """Record a decision about a condition.

    Stored against the workspace and the resolution key, not against a run.
    A run is regenerated on every calculation and the decision has to
    outlive it.

    Acknowledging accepts the condition as it stands. Marking it resolved
    claims the data was corrected, and that claim is verified by the next
    run rather than trusted: if the condition is still there, it is
    reopened.
    """
    latest = session.scalar(
        select(CalculationRun)
        .where(CalculationRun.workspace_id == principal.workspace.id)
        .order_by(CalculationRun.created_at.desc())
    )
    issue = None
    if latest is not None:
        issue = session.scalar(
            select(RunIssue).where(
                RunIssue.run_id == latest.id,
                RunIssue.resolution_key == body.resolution_key,
            )
        )
    if issue is None:
        raise ApiError(
            404,
            "NO_SUCH_CONDITION",
            "the most recent run did not raise this condition",
        )

    status_value = IssueStatus(body.status)
    existing = session.scalar(
        select(IssueResolution).where(
            IssueResolution.workspace_id == principal.workspace.id,
            IssueResolution.resolution_key == body.resolution_key,
        )
    )
    now = datetime.now(UTC)
    if existing is None:
        existing = IssueResolution(
            workspace_id=principal.workspace.id,
            resolution_key=body.resolution_key,
            status=str(status_value),
            code=issue.code,
            subject=issue.subject,
            note=body.note,
            message=issue.message,
            decided_by=principal.user.id,
            decided_at=now,
        )
        session.add(existing)
    else:
        existing.status = str(status_value)
        existing.note = body.note
        # Re-captured so that a re-run can tell whether the user is still
        # accepting the same statement they accepted before.
        existing.message = issue.message
        existing.decided_by = principal.user.id
        existing.decided_at = now
    session.flush()

    record(
        session,
        Action.ISSUE_ACKNOWLEDGED
        if status_value is IssueStatus.ACKNOWLEDGED
        else Action.ISSUE_MARKED_RESOLVED,
        actor=principal.user,
        workspace_id=principal.workspace.id,
        target_type="condition",
        target_id=body.resolution_key,
        ip_address=ip,
        code=issue.code,
        subject=issue.subject,
        note=body.note,
    )
    return DecisionResponse.model_validate(existing)


@router.delete(
    "/decisions/{resolution_key}", status_code=status.HTTP_204_NO_CONTENT
)
def withdraw(
    resolution_key: str,
    principal: WriterDep,
    session: SessionDep,
    ip: IpDep,
) -> None:
    existing = session.scalar(
        select(IssueResolution).where(
            IssueResolution.workspace_id == principal.workspace.id,
            IssueResolution.resolution_key == resolution_key,
        )
    )
    if existing is None:
        return
    session.delete(existing)
    record(
        session,
        Action.ISSUE_DECISION_WITHDRAWN,
        actor=principal.user,
        workspace_id=principal.workspace.id,
        target_type="condition",
        target_id=resolution_key,
        ip_address=ip,
    )


def _run_or_404(session, workspace_id: str, run_id: str) -> CalculationRun:  # noqa: ANN001
    run = session.get(CalculationRun, run_id)
    if run is None or run.workspace_id != workspace_id:
        raise ApiError(404, "NOT_FOUND", "no such calculation run")
    return run
