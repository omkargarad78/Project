"""Uploading and listing statement files."""

from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, File, UploadFile, status
from sqlalchemy import select

from ...audit import Action, record
from ...core.errors import PlatformError
from ...db.models import SourceFile
from ...io.loader import load_source
from ...storage.local import put_content
from ..deps import (
    IpDep,
    PrincipalDep,
    SessionDep,
    SettingsDep,
    StoreDep,
    WriterDep,
)
from ..errors import ApiError
from ..schemas import SourceFileResponse

router = APIRouter(prefix="/workspaces/{workspace_id}/files", tags=["files"])


@router.get("", response_model=list[SourceFileResponse])
def index(principal: PrincipalDep, session: SessionDep) -> list[SourceFileResponse]:
    rows = session.scalars(
        select(SourceFile)
        .where(
            SourceFile.workspace_id == principal.workspace.id,
            SourceFile.deleted_at.is_(None),
        )
        .order_by(SourceFile.created_at.desc())
    )
    return [SourceFileResponse.model_validate(row) for row in rows]


@router.post("", response_model=SourceFileResponse, status_code=status.HTTP_201_CREATED)
async def upload(
    principal: WriterDep,
    session: SessionDep,
    store: StoreDep,
    settings: SettingsDep,
    ip: IpDep,
    file: UploadFile = File(...),  # noqa: B008 - FastAPI's declaration style
) -> SourceFileResponse:
    """Validate, hash and store one statement.

    The file is validated before anything is written: type sniffed from its
    content rather than its extension, size checked, archive entries
    inspected. A rejected upload leaves nothing behind but an audit entry.
    """
    content = await file.read()
    if len(content) > settings.max_upload_bytes:
        record(
            session,
            Action.FILE_REJECTED,
            actor=principal.user,
            workspace_id=principal.workspace.id,
            target_type="file",
            target_id=file.filename or "",
            ip_address=ip,
            reason="too large",
            size_bytes=len(content),
        )
        raise ApiError(
            413,
            "FILE_TOO_LARGE",
            f"the file exceeds the {settings.max_upload_bytes} byte limit",
        )

    try:
        loaded = load_source(
            content,
            file_name=file.filename,
            max_bytes=settings.max_upload_bytes,
            allowed_extensions=settings.allowed_upload_extensions,
        )
    except PlatformError as exc:
        record(
            session,
            Action.FILE_REJECTED,
            actor=principal.user,
            workspace_id=principal.workspace.id,
            target_type="file",
            target_id=file.filename or "",
            ip_address=ip,
            reason=str(exc.code),
        )
        session.commit()
        raise

    # Identical bytes are the same file. Returning the existing row rather
    # than storing a second copy keeps derived identifiers stable, since
    # every one of them is built from this hash.
    existing = session.scalar(
        select(SourceFile).where(
            SourceFile.workspace_id == principal.workspace.id,
            SourceFile.file_hash == loaded.file_hash,
        )
    )
    if existing is not None:
        existing.deleted_at = None
        return SourceFileResponse.model_validate(existing)

    key, _ = put_content(store, "uploads", content)
    stored = SourceFile(
        workspace_id=principal.workspace.id,
        uploaded_by=principal.user.id,
        file_name=loaded.file_name,
        file_hash=loaded.file_hash,
        file_type=str(loaded.file_type),
        size_bytes=loaded.size_bytes,
        storage_key=key,
    )
    session.add(stored)
    session.flush()

    record(
        session,
        Action.FILE_UPLOADED,
        actor=principal.user,
        workspace_id=principal.workspace.id,
        target_type="source_file",
        target_id=stored.id,
        ip_address=ip,
        file_name=loaded.file_name,
        file_hash=loaded.file_hash,
        size_bytes=loaded.size_bytes,
    )
    return SourceFileResponse.model_validate(stored)


@router.delete("/{file_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove(
    file_id: str,
    principal: WriterDep,
    session: SessionDep,
    ip: IpDep,
) -> None:
    """Withdraw a file from future runs without erasing the past.

    The row is marked deleted rather than dropped. Runs that cited this file
    recorded its hash, and a completed run has to stay explainable after the
    user tidies up their uploads.
    """
    stored = session.get(SourceFile, file_id)
    if stored is None or stored.workspace_id != principal.workspace.id:
        raise ApiError(404, "NOT_FOUND", "no such file")

    stored.deleted_at = datetime.now(UTC)
    record(
        session,
        Action.FILE_DELETED,
        actor=principal.user,
        workspace_id=principal.workspace.id,
        target_type="source_file",
        target_id=stored.id,
        ip_address=ip,
        file_name=stored.file_name,
    )
