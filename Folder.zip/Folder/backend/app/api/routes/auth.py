"""Registration and sign-in."""

from __future__ import annotations

from fastapi import APIRouter, status

from ...audit import Action, record
from ...auth.passwords import PasswordError
from ...auth.service import AuthError, authenticate, register_user
from ...auth.tokens import issue_access_token
from ..deps import IpDep, SessionDep, SettingsDep, UserDep
from ..errors import ApiError
from ..schemas import (
    LoginRequest,
    RegisterRequest,
    TokenResponse,
    UserResponse,
)

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post(
    "/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED
)
def register(
    body: RegisterRequest,
    session: SessionDep,
    settings: SettingsDep,
    ip: IpDep,
) -> TokenResponse:
    try:
        user = register_user(
            session,
            email=body.email,
            password=body.password,
            display_name=body.display_name,
        )
    except PasswordError as exc:
        raise ApiError(422, "WEAK_PASSWORD", str(exc)) from exc
    except AuthError as exc:
        # Deliberately 409 with a fixed message rather than "that email is
        # taken": the latter confirms who has an account here, and for a tax
        # product that is itself sensitive.
        raise ApiError(
            409,
            "REGISTRATION_REFUSED",
            "this email address cannot be registered",
        ) from exc

    record(
        session,
        Action.USER_REGISTERED,
        actor=user,
        target_type="user",
        target_id=user.id,
        ip_address=ip,
    )
    token, expires = issue_access_token(user.id, user.email, settings=settings)
    return TokenResponse(access_token=token, expires_at=expires)


@router.post("/login", response_model=TokenResponse)
def login(
    body: LoginRequest,
    session: SessionDep,
    settings: SettingsDep,
    ip: IpDep,
) -> TokenResponse:
    try:
        user = authenticate(session, email=body.email, password=body.password)
    except AuthError:
        # Recorded before re-raising, because a run of failures against one
        # address is the signal worth having.
        record(
            session,
            Action.USER_SIGN_IN_FAILED,
            target_type="email",
            target_id="",
            ip_address=ip,
            attempted_email=body.email.lower(),
        )
        session.commit()
        raise

    record(
        session,
        Action.USER_SIGNED_IN,
        actor=user,
        target_type="user",
        target_id=user.id,
        ip_address=ip,
    )
    token, expires = issue_access_token(user.id, user.email, settings=settings)
    return TokenResponse(access_token=token, expires_at=expires)


@router.get("/me", response_model=UserResponse)
def me(user: UserDep) -> UserResponse:
    return UserResponse.model_validate(user)
