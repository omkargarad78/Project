"""Requesting a calculation and reading what it produced."""

from __future__ import annotations

from datetime import date

from fastapi import APIRouter, status
from sqlalchemy import select

from ...audit import Action, record
from ...db.models import CalculationRun, ScheduleFaRow, SourceFile
from ...tax.rules.models import (
    LotAllocationMethod,
    MultipleRatePolicy,
    PeakValuationFrequency,
    PriceValuationPoint,
)
from ...tax.rules.registry import RuleRegistry
from ..deps import (
    IpDep,
    PrincipalDep,
    RunnerDep,
    SessionDep,
    SettingsDep,
    StoreDep,
    WriterDep,
)
from ..errors import ApiError
from ..pipeline import RunOptions, create_run, execute_run
from ..schemas import (
    FigureResponse,
    RunDetail,
    RunRequest,
    RunSummary,
    ScheduleFaRowResponse,
)

router = APIRouter(prefix="/workspaces/{workspace_id}/runs", tags=["runs"])


def _options(body: RunRequest, assessment_year: str) -> RunOptions:
    """Turn the request into engine vocabulary, rejecting unknown values.

    Each of these changes the figures. An unrecognised one is refused rather
    than defaulted, because a run that silently used FIFO when the caller
    asked for LIFO is a wrong answer that looks like a right one.
    """
    try:
        return RunOptions(
            fx_dataset=body.fx_dataset,
            fx_dataset_version=body.fx_dataset_version,
            assessment_year=body.assessment_year or assessment_year,
            lot_allocation_method=LotAllocationMethod(body.lot_allocation_method),
            price_valuation_point=PriceValuationPoint(body.price_valuation_point),
            peak_valuation_frequency=PeakValuationFrequency(
                body.peak_valuation_frequency
            ),
            multiple_rate_policy=MultipleRatePolicy(body.multiple_rate_policy),
            market_dataset=body.market_dataset,
            account_number=body.account_number,
            account_status=body.account_status,
            account_opened=body.account_opened,
        )
    except ValueError as exc:
        raise ApiError(422, "UNKNOWN_POLICY_VALUE", str(exc)) from exc


@router.post("", response_model=RunSummary, status_code=status.HTTP_202_ACCEPTED)
def request_run(
    body: RunRequest,
    principal: WriterDep,
    session: SessionDep,
    store: StoreDep,
    settings: SettingsDep,
    runner: RunnerDep,
    ip: IpDep,
) -> RunSummary:
    """Queue a run and return its id.

    Returns 202 even when the inline backend has already finished: the
    client's contract is "poll until terminal", and a client written against
    inline behaviour would otherwise break the day the backend changes.
    """
    options = _options(body, principal.workspace.assessment_year)

    registry = RuleRegistry.from_directory(settings.data_root / "rules")
    rule = registry.rule_for(options.assessment_year)

    hashes = list(
        session.scalars(
            select(SourceFile.file_hash).where(
                SourceFile.workspace_id == principal.workspace.id,
                SourceFile.deleted_at.is_(None),
            )
        )
    )
    if not hashes:
        raise ApiError(
            409,
            "NO_SOURCE_FILES",
            "upload at least one statement before calculating",
        )

    run = create_run(
        session,
        workspace_id=principal.workspace.id,
        requested_by=principal.user.id,
        options=options,
        rule_version=rule.rule_version_id,
        rule_verified=rule.is_verified,
        file_hashes=hashes,
    )
    record(
        session,
        Action.RUN_REQUESTED,
        actor=principal.user,
        workspace_id=principal.workspace.id,
        target_type="calculation_run",
        target_id=run.id,
        ip_address=ip,
        **options.as_record(),
    )
    # Committed before the job starts, so the worker can find the run in its
    # own session and the client can poll for it immediately.
    session.commit()

    runner.enqueue(
        run.id,
        lambda job_session, run_id: execute_run(
            job_session, run_id, options=options, store=store, settings=settings
        ),
    )
    session.refresh(run)
    return RunSummary.model_validate(run)


@router.get("", response_model=list[RunSummary])
def index(principal: PrincipalDep, session: SessionDep) -> list[RunSummary]:
    rows = session.scalars(
        select(CalculationRun)
        .where(CalculationRun.workspace_id == principal.workspace.id)
        .order_by(CalculationRun.created_at.desc())
        .limit(100)
    )
    return [RunSummary.model_validate(row) for row in rows]


@router.get("/{run_id}", response_model=RunDetail)
def read(run_id: str, principal: PrincipalDep, session: SessionDep) -> RunDetail:
    run = _run_or_404(session, principal.workspace.id, run_id)
    rows = list(
        session.scalars(
            select(ScheduleFaRow)
            .where(ScheduleFaRow.run_id == run.id)
            .order_by(ScheduleFaRow.table_name, ScheduleFaRow.serial_number)
        )
    )
    blocking = [
        issue.message for issue in run.issues if issue.is_blocking
    ]
    qualifications = sorted(
        {
            caveat
            for row in rows
            for caveat in row.derivation.get("caveats", [])
        }
    )
    return RunDetail(
        **RunSummary.model_validate(run).model_dump(),
        fx_dataset=run.fx_dataset,
        fx_dataset_version=run.fx_dataset_version,
        market_dataset=run.market_dataset,
        market_data_synthetic=run.market_data_synthetic,
        policy=run.policy,
        source_file_hashes=run.source_file_hashes,
        blocking_reasons=blocking,
        qualifications=qualifications,
        table_a2=[_row(r) for r in rows if r.table_name == "A2"],
        table_a3=[_row(r) for r in rows if r.table_name == "A3"],
    )


def _row(row: ScheduleFaRow) -> ScheduleFaRowResponse:
    return ScheduleFaRowResponse(
        serial_number=row.serial_number,
        table_name=row.table_name,
        subject=row.subject,
        country_code=row.country_code,
        entity_name=row.entity_name,
        acquisition_date=row.acquisition_date,
        is_complete=row.is_complete,
        missing_fields=row.derivation.get("missing_fields", []),
        figures=[
            FigureResponse(**_figure(payload))
            for payload in row.derivation.get("figures", [])
        ],
    )


def _figure(payload: dict) -> dict:
    return {
        "field_name": payload["field_name"],
        "label": payload["label"],
        "status": payload["status"],
        "inr_amount": payload.get("inr_amount"),
        "native_amount": payload.get("native_amount"),
        "currency": payload.get("currency"),
        "rate_date": date.fromisoformat(payload["rate_date"])
        if payload.get("rate_date")
        else None,
        "rate_value": payload.get("rate_value"),
        "formula": payload.get("formula", ""),
        "explanation": payload.get("explanation", ""),
        "caveats": payload.get("caveats", []),
    }


def _run_or_404(session, workspace_id: str, run_id: str) -> CalculationRun:  # noqa: ANN001
    run = session.get(CalculationRun, run_id)
    if run is None or run.workspace_id != workspace_id:
        raise ApiError(404, "NOT_FOUND", "no such calculation run")
    return run
