"""Request-scoped dependencies.

The important one is :func:`workspace_principal`. Every route that touches a
workspace declares it, which means authorisation is part of the function
signature rather than a line inside the body that can be left out. A route
missing its dependency will not resolve a workspace at all, so the mistake
shows up as a broken endpoint instead of an open one.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Annotated

from fastapi import Depends, Header, Path, Request
from sqlalchemy.orm import Session

from ..auth.service import PermissionDenied, Principal, authorise
from ..auth.tokens import TokenError, read_access_token
from ..core.config import Settings, get_settings
from ..db.models import User
from ..jobs.runner import JobRunner
from ..storage.local import BlobStore
from .errors import ApiError


def get_session(request: Request) -> Iterator[Session]:
    """One transaction per request.

    Committed only if the handler returns. A handler that raises leaves
    nothing behind, including the audit entry describing what it was doing,
    which is the behaviour that keeps the trail honest.
    """
    factory = request.app.state.session_factory
    session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


SessionDep = Annotated[Session, Depends(get_session)]


def get_app_settings(request: Request) -> Settings:
    return getattr(request.app.state, "settings", None) or get_settings()


def get_blob_store(request: Request) -> BlobStore:
    return request.app.state.blob_store


def get_job_runner(request: Request) -> JobRunner:
    return request.app.state.job_runner


SettingsDep = Annotated[Settings, Depends(get_app_settings)]
StoreDep = Annotated[BlobStore, Depends(get_blob_store)]
RunnerDep = Annotated[JobRunner, Depends(get_job_runner)]


def current_user(
    session: SessionDep,
    settings: SettingsDep,
    authorization: Annotated[str | None, Header()] = None,
) -> User:
    """Resolve the bearer token to a live, active account.

    The account is re-read on every request rather than trusted from the
    token. A token issued before an account was disabled must stop working
    the moment it is, not when it happens to expire.
    """
    if not authorization or not authorization.lower().startswith("bearer "):
        raise ApiError(
            401,
            "NOT_AUTHENTICATED",
            "this endpoint requires a bearer token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        claims = read_access_token(authorization[7:].strip(), settings=settings)
    except TokenError as exc:
        raise ApiError(
            401,
            "INVALID_TOKEN",
            str(exc),
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc

    user = session.get(User, claims.user_id)
    if user is None or not user.is_active:
        raise ApiError(401, "INVALID_TOKEN", "this session is no longer valid")
    return user


UserDep = Annotated[User, Depends(current_user)]


def workspace_principal(
    session: SessionDep,
    user: UserDep,
    workspace_id: Annotated[str, Path()],
) -> Principal:
    """Read access to a workspace the caller belongs to."""
    try:
        return authorise(session, user=user, workspace_id=workspace_id)
    except PermissionDenied as exc:
        raise _denied(exc) from exc


def workspace_writer(
    session: SessionDep,
    user: UserDep,
    workspace_id: Annotated[str, Path()],
) -> Principal:
    """Write access. Viewers are refused here, not inside the handler."""
    try:
        return authorise(
            session, user=user, workspace_id=workspace_id, require_write=True
        )
    except PermissionDenied as exc:
        raise _denied(exc) from exc


def workspace_admin(
    session: SessionDep,
    user: UserDep,
    workspace_id: Annotated[str, Path()],
) -> Principal:
    try:
        return authorise(
            session, user=user, workspace_id=workspace_id, require_admin=True
        )
    except PermissionDenied as exc:
        raise _denied(exc) from exc


def _denied(exc: PermissionDenied) -> ApiError:
    """Always 404, never 403.

    A 403 confirms the workspace exists, which turns the endpoint into a way
    to enumerate other people's workspace ids. The only exception is a
    caller who *is* a member but lacks the role, where the resource is
    already known to them.
    """
    message = str(exc)
    if "role" in message or "owner" in message:
        return ApiError(403, "INSUFFICIENT_ROLE", message)
    return ApiError(404, "NOT_FOUND", "no such workspace")


PrincipalDep = Annotated[Principal, Depends(workspace_principal)]
WriterDep = Annotated[Principal, Depends(workspace_writer)]
AdminDep = Annotated[Principal, Depends(workspace_admin)]


def client_ip(request: Request) -> str | None:
    """The caller's address for the audit trail.

    Taken from the socket, not from ``X-Forwarded-For``. That header is
    attacker-controlled unless a trusted proxy overwrites it, and a forged
    address in an audit log is worse than no address.
    """
    return request.client.host if request.client else None


IpDep = Annotated[str | None, Depends(client_ip)]
