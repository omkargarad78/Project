"""ASGI entry point.

Separate from :mod:`backend.app.api.app` because that module exports a
*factory*. A server needs a module-level object to import, and putting one in
the factory's module would build an application — opening a database pool —
as a side effect of importing it, which is exactly what the factory exists to
avoid in tests.
"""

from __future__ import annotations

from .app import create_app

app = create_app()
