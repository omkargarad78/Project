"""Versioned tax rules, the official-source registry and valuation policies.

Nothing in the calculation engine encodes a tax rule. A rule version is data:
it names the reporting period, the exchange-rate type and the relevant date for
each reported field, and it cites the official document it was transcribed
from. Adding an assessment year means adding a JSON rule file.

Every rule version carries a ``verification_status``. A rule transcribed from a
document that a human has checked is ``VERIFIED``; anything else calculates but
raises ``TAX_RULE_UNVERIFIED`` so the state is visible on screen and in the
generated workpaper. The platform never falls back to a different year's rules.
"""

from __future__ import annotations

from datetime import date, datetime
from enum import IntEnum, StrEnum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..periods import (
    AssessmentYear,
    FinancialYear,
    PeriodBasis,
    ReportingPeriod,
    TaxPeriod,
)


class SourceTier(IntEnum):
    """Authority ranking for every source the platform relies on.

    A tier-4 or tier-5 source is usable as machine-readable data but is never
    presented as statutory authority, and the tier travels with the figure it
    produced all the way into the output workbook.
    """

    #: Income Tax Department, government notifications, income-tax rules and
    #: official forms, State Bank of India official rate publications.
    STATUTORY = 1
    #: Official broker documentation, official exchange or company data.
    OFFICIAL_THIRD_PARTY = 2
    #: Established financial data providers.
    DATA_PROVIDER = 3
    #: Community datasets, such as historical SBI rate repositories.
    COMMUNITY_DATASET = 4
    #: Blogs, forums and community discussion. Research context only.
    COMMUNITY_DISCUSSION = 5

    @property
    def is_statutory(self) -> bool:
        return self is SourceTier.STATUTORY

    @property
    def label(self) -> str:
        return {
            SourceTier.STATUTORY: "Tier 1 - statutory / official",
            SourceTier.OFFICIAL_THIRD_PARTY: "Tier 2 - official third party",
            SourceTier.DATA_PROVIDER: "Tier 3 - established data provider",
            SourceTier.COMMUNITY_DATASET: "Tier 4 - community dataset",
            SourceTier.COMMUNITY_DISCUSSION: "Tier 5 - community discussion",
        }[self]


class SourceKind(StrEnum):
    TAX_FORM = "TAX_FORM"
    TAX_INSTRUCTIONS = "TAX_INSTRUCTIONS"
    NOTIFICATION = "NOTIFICATION"
    STATUTE_OR_RULE = "STATUTE_OR_RULE"
    FX_RATE_PUBLICATION = "FX_RATE_PUBLICATION"
    FX_RATE_DATASET = "FX_RATE_DATASET"
    MARKET_DATA = "MARKET_DATA"
    BROKER_DOCUMENTATION = "BROKER_DOCUMENTATION"
    SECURITY_REFERENCE_DATA = "SECURITY_REFERENCE_DATA"
    USER_SUPPLIED = "USER_SUPPLIED"


class OfficialSource(BaseModel):
    """A citable source with enough metadata to re-find the original document."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    source_id: str
    tier: SourceTier
    kind: SourceKind
    publisher: str
    title: str
    #: Document number, form name, circular reference or dataset release tag.
    document_reference: str | None = None
    url: str | None = None
    #: When the platform obtained the document or dataset.
    retrieved_at: datetime | None = None
    #: Hash of the retrieved document, when the document itself was stored.
    document_hash: str | None = None
    notes: str | None = None

    @property
    def citation(self) -> str:
        parts = [self.publisher, self.title]
        if self.document_reference:
            parts.append(self.document_reference)
        return " - ".join(parts)

    def to_row(self) -> dict[str, str]:
        return {
            "Source ID": self.source_id,
            "Tier": self.tier.label,
            "Kind": str(self.kind),
            "Publisher": self.publisher,
            "Title": self.title,
            "Document Reference": self.document_reference or "",
            "URL / Identifier": self.url or "",
            "Retrieved At": self.retrieved_at.isoformat() if self.retrieved_at else "",
            "Document Hash": self.document_hash or "",
            "Notes": self.notes or "",
        }


class VerificationStatus(StrEnum):
    """Whether a rule transcription has been checked against its source."""

    #: A human compared the rule against the cited official document.
    VERIFIED = "VERIFIED"
    #: Transcribed but not yet checked. Calculates, and raises a warning.
    REQUIRES_CONFIRMATION = "REQUIRES_CONFIRMATION"
    #: Replaced by a later version for the same assessment year.
    SUPERSEDED = "SUPERSEDED"


class FxRateType(StrEnum):
    """Exchange-rate types, which are not interchangeable.

    Schedule FA valuation uses the telegraphic transfer *buying* rate. Keeping
    every other published rate type in the model is what allows the platform to
    reject a dataset that actually contains TT selling or card rates.
    """

    TT_BUY = "TT_BUY"
    TT_SELL = "TT_SELL"
    BILL_BUY = "BILL_BUY"
    BILL_SELL = "BILL_SELL"
    CARD_RATE = "CARD_RATE"
    CASH_BUY = "CASH_BUY"
    CASH_SELL = "CASH_SELL"
    MARKET_MID = "MARKET_MID"
    RBI_REFERENCE = "RBI_REFERENCE"
    BROKER_SUPPLIED = "BROKER_SUPPLIED"
    OTHER = "OTHER"

    @property
    def label(self) -> str:
        return {
            FxRateType.TT_BUY: "Telegraphic Transfer Buying Rate (TTBR)",
            FxRateType.TT_SELL: "Telegraphic Transfer Selling Rate",
            FxRateType.BILL_BUY: "Bill Buying Rate",
            FxRateType.BILL_SELL: "Bill Selling Rate",
            FxRateType.CARD_RATE: "Card Rate",
            FxRateType.CASH_BUY: "Cash Buying Rate",
            FxRateType.CASH_SELL: "Cash Selling Rate",
            FxRateType.MARKET_MID: "Market Mid Rate",
            FxRateType.RBI_REFERENCE: "RBI Reference Rate",
            FxRateType.BROKER_SUPPLIED: "Broker-supplied conversion rate",
            FxRateType.OTHER: "Other rate type",
        }[self]


class RelevantDateRule(StrEnum):
    """Which date a reported field's exchange rate is taken from."""

    #: The date of the transaction being converted.
    TRANSACTION_DATE = "TRANSACTION_DATE"
    #: The date the holding is being valued on (used by peak valuation).
    VALUATION_DATE = "VALUATION_DATE"
    #: The last day of the reporting period.
    PERIOD_END_DATE = "PERIOD_END_DATE"
    #: The last day of the month preceding the relevant date.
    PRECEDING_MONTH_END = "PRECEDING_MONTH_END"


class MissingRatePolicy(StrEnum):
    """What to do when no rate is published on the relevant date.

    ``FAIL`` is the safe default. A carry-back or carry-forward is only ever
    used when the rule version explicitly selects it, because doing so is a
    treatment decision rather than a data-cleaning convenience.
    """

    FAIL = "FAIL"
    LAST_PUBLISHED_ON_OR_BEFORE = "LAST_PUBLISHED_ON_OR_BEFORE"
    NEXT_PUBLISHED_ON_OR_AFTER = "NEXT_PUBLISHED_ON_OR_AFTER"
    NEAREST_PUBLISHED = "NEAREST_PUBLISHED"


class MultipleRatePolicy(StrEnum):
    """How to choose when a date has more than one published rate sheet."""

    FAIL = "FAIL"
    EARLIEST_PUBLICATION = "EARLIEST_PUBLICATION"
    LATEST_PUBLICATION = "LATEST_PUBLICATION"
    HIGHEST_RATE = "HIGHEST_RATE"
    LOWEST_RATE = "LOWEST_RATE"


class PriceValuationPoint(StrEnum):
    """Which point of the daily price series values a holding.

    The official materials establish that a peak value must be reported without
    prescribing a market-data vendor or an intraday methodology, so this is a
    configured policy shown on every report rather than an asserted rule.
    """

    DAILY_CLOSE = "DAILY_CLOSE"
    DAILY_HIGH = "DAILY_HIGH"
    DAILY_LOW = "DAILY_LOW"
    DAILY_OPEN = "DAILY_OPEN"
    DAILY_AVERAGE_HIGH_LOW = "DAILY_AVERAGE_HIGH_LOW"

    @property
    def label(self) -> str:
        return {
            PriceValuationPoint.DAILY_CLOSE: "daily closing price",
            PriceValuationPoint.DAILY_HIGH: "daily high price",
            PriceValuationPoint.DAILY_LOW: "daily low price",
            PriceValuationPoint.DAILY_OPEN: "daily opening price",
            PriceValuationPoint.DAILY_AVERAGE_HIGH_LOW: "average of daily high and low",
        }[self]


class PeakValuationFrequency(StrEnum):
    """How often the holding is revalued when searching for the peak."""

    #: Every day in the holding period that has a price observation.
    EVERY_PRICED_DAY = "EVERY_PRICED_DAY"
    #: Month ends only. Cheaper, and materially different, so it is labelled.
    MONTH_END = "MONTH_END"
    #: Quarter ends only.
    QUARTER_END = "QUARTER_END"


class LotAllocationMethod(StrEnum):
    """How disposals are allocated against acquisition lots.

    FIFO is the platform's default selection, not an asserted statutory
    requirement. The method used is recorded on every calculation run.
    """

    FIFO = "FIFO"
    LIFO = "LIFO"
    HIGHEST_COST_FIRST = "HIGHEST_COST_FIRST"
    LOWEST_COST_FIRST = "LOWEST_COST_FIRST"
    #: Use the broker's own lot assignment where the export supplies one.
    BROKER_SPECIFIED = "BROKER_SPECIFIED"


class RoundingRule(StrEnum):
    HALF_UP = "ROUND_HALF_UP"
    HALF_EVEN = "ROUND_HALF_EVEN"
    DOWN = "ROUND_DOWN"


class FieldValuationRule(BaseModel):
    """The date and rate convention for one reported field."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    relevant_date: RelevantDateRule
    fx_rate_type: FxRateType = FxRateType.TT_BUY
    missing_rate_policy: MissingRatePolicy = MissingRatePolicy.FAIL
    #: Maximum number of calendar days a carry-back/forward may span. Prevents
    #: a sparse dataset from silently sourcing a rate months away.
    max_rate_gap_days: int = Field(default=7, ge=0, le=90)
    #: Human-readable statement of the convention, shown on the Methodology page.
    note: str | None = None


class ReportingPeriodRule(BaseModel):
    """How to derive the Schedule FA reporting period for an assessment year."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    basis: PeriodBasis
    #: For a calendar-year basis: the calendar year, expressed as an offset from
    #: the assessment year's starting year. The instructions for recent years
    #: describe a calendar year ending inside the relevant previous year, which
    #: is an offset of -1; the value is configured per year, never assumed.
    calendar_year_offset: int | None = None
    #: For an explicit-dates basis.
    start_date: date | None = None
    end_date: date | None = None
    #: The wording from the official instructions this was transcribed from.
    description: str

    @model_validator(mode="after")
    def _check(self) -> ReportingPeriodRule:
        if self.basis is PeriodBasis.CALENDAR_YEAR and self.calendar_year_offset is None:
            raise ValueError("calendar_year_offset is required for a CALENDAR_YEAR basis")
        if self.basis is PeriodBasis.EXPLICIT_DATES and (
            self.start_date is None or self.end_date is None
        ):
            raise ValueError("start_date and end_date are required for an EXPLICIT_DATES basis")
        return self

    def resolve(self, assessment_year: AssessmentYear) -> ReportingPeriod:
        if self.basis is PeriodBasis.CALENDAR_YEAR:
            year = assessment_year.start_year + (self.calendar_year_offset or 0)
            return ReportingPeriod(
                start_date=date(year, 1, 1),
                end_date=date(year, 12, 31),
                basis=self.basis,
                description=self.description,
            )
        if self.basis is PeriodBasis.FINANCIAL_YEAR:
            financial_year = assessment_year.financial_year
            return ReportingPeriod(
                start_date=financial_year.start_date,
                end_date=financial_year.end_date,
                basis=self.basis,
                description=self.description,
            )
        assert self.start_date is not None and self.end_date is not None
        return ReportingPeriod(
            start_date=self.start_date,
            end_date=self.end_date,
            basis=self.basis,
            description=self.description,
        )


class ScheduleFaRuleDefinition(BaseModel):
    """The Schedule FA portion of a rule version."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    reporting_period: ReportingPeriodRule
    #: Rate convention per reported field. Different fields can legitimately
    #: have different relevant dates, which is why this is a mapping rather
    #: than one global setting.
    initial_value: FieldValuationRule
    peak_value: FieldValuationRule
    closing_value: FieldValuationRule
    income_credited: FieldValuationRule
    sale_proceeds: FieldValuationRule
    #: Selection when a date carries several published rate sheets.
    multiple_rate_policy: MultipleRatePolicy = MultipleRatePolicy.FAIL
    #: Output rounding for reported money columns.
    output_rounding: RoundingRule = RoundingRule.HALF_UP
    output_decimal_places: int = Field(default=0, ge=0, le=4)
    #: Whether a fully disposed interest is still reported for the period.
    report_interests_held_at_any_time: bool = True

    def rule_for(self, field_name: str) -> FieldValuationRule:
        try:
            value = getattr(self, field_name)
        except AttributeError as exc:
            raise KeyError(f"no valuation rule named {field_name!r}") from exc
        if not isinstance(value, FieldValuationRule):
            raise KeyError(f"{field_name!r} is not a field valuation rule")
        return value


class TaxRuleVersion(BaseModel):
    """A versioned, cited ruleset for one assessment year."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    rule_version_id: str
    assessment_year: str
    form_version: str
    effective_from: date
    effective_to: date | None = None
    active: bool = True
    verification_status: VerificationStatus = VerificationStatus.REQUIRES_CONFIRMATION
    #: Source ids in the official-source registry backing this transcription.
    source_ids: tuple[str, ...] = ()
    #: Hash of the source document set, when the documents were stored.
    source_hash: str | None = None
    #: Points that a human must confirm before treating output as reliable.
    open_decisions: tuple[str, ...] = ()
    schedule_fa: ScheduleFaRuleDefinition
    #: Reserved for the FSI / TR / Form 67 modules. Present so that adding them
    #: does not change the rule-file schema or the database.
    schedule_fsi: dict[str, object] | None = None
    schedule_tr: dict[str, object] | None = None
    form_67: dict[str, object] | None = None

    @property
    def parsed_assessment_year(self) -> AssessmentYear:
        return AssessmentYear.parse(self.assessment_year)

    @property
    def is_verified(self) -> bool:
        return self.verification_status is VerificationStatus.VERIFIED

    def covers(self, assessment_year: AssessmentYear) -> bool:
        return self.active and self.parsed_assessment_year == assessment_year

    def tax_period(self) -> TaxPeriod:
        assessment_year = self.parsed_assessment_year
        return TaxPeriod(
            assessment_year=assessment_year,
            financial_year=FinancialYear(start_year=assessment_year.start_year - 1),
            fa_reporting_period=self.schedule_fa.reporting_period.resolve(assessment_year),
            form_version=self.form_version,
            rule_version_id=self.rule_version_id,
        )


class CalculationPolicy(BaseModel):
    """Workspace-level methodology choices that are not tax rules.

    These are the platform's own configurable decisions: which point of the
    daily price series values a holding, how often to revalue when searching
    for a peak, and how disposals are allocated to lots. They are versioned
    separately from tax rules so that a policy change is visibly a policy
    change and not a claim about the law.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    policy_version: str = "calc-policy-1.0.0"
    price_valuation_point: PriceValuationPoint = PriceValuationPoint.DAILY_CLOSE
    peak_valuation_frequency: PeakValuationFrequency = PeakValuationFrequency.EVERY_PRICED_DAY
    lot_allocation_method: LotAllocationMethod = LotAllocationMethod.FIFO
    #: Include fees in the initial value of the investment.
    include_fees_in_initial_value: bool = True
    #: Deduct fees from reported gross sale proceeds. Gross means gross, so the
    #: default is not to deduct.
    deduct_fees_from_gross_proceeds: bool = False
    #: Report the gross dividend rather than the net of withholding tax.
    income_is_gross_of_withholding: bool = True
    #: Refuse to value a holding from a price series whose corporate-action
    #: adjustment basis is unknown.
    require_corporate_action_alignment: bool = True
    #: Treat a market-data provider price as acceptable, with a warning.
    allow_non_exchange_price_source: bool = True
    #: Treat a community historical rate dataset as acceptable, with a warning.
    allow_secondary_fx_source: bool = True

    def describe(self) -> dict[str, str]:
        return {
            "Calculation Policy Version": self.policy_version,
            "Price Valuation Point": self.price_valuation_point.label,
            "Peak Valuation Frequency": str(self.peak_valuation_frequency),
            "Lot Allocation Method": (
                f"{self.lot_allocation_method} (platform-selected methodology, "
                f"not an asserted statutory requirement)"
            ),
            "Fees Included In Initial Value": str(self.include_fees_in_initial_value),
            "Fees Deducted From Gross Proceeds": str(self.deduct_fees_from_gross_proceeds),
            "Income Reported Gross Of Withholding Tax": str(
                self.income_is_gross_of_withholding
            ),
            "Corporate-Action Alignment Required": str(
                self.require_corporate_action_alignment
            ),
        }


FieldName = Literal[
    "initial_value",
    "peak_value",
    "closing_value",
    "income_credited",
    "sale_proceeds",
]
