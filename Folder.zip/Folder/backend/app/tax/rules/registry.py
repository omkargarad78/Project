"""Loading and lookup of tax rule versions, form schemas and official sources.

Rules live in ``data/rules`` as JSON so that adding an assessment year is a
data change reviewed like a document transcription, not a code change. Lookup
never falls back to an adjacent year: an unregistered year raises
``TAX_RULE_VERSION_MISSING`` and the affected calculation stops.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from pydantic import BaseModel, ConfigDict, TypeAdapter

from ...core.config import get_settings
from ...core.errors import ErrorCode, RuleError
from ...core.hashing import hash_file
from ..periods import AssessmentYear
from .models import OfficialSource, TaxRuleVersion

RULES_DIRNAME = "rules"
SOURCES_FILENAME = "official_sources.json"
FORM_SCHEMA_DIRNAME = "form_schemas"


def read_json(path: Path) -> object:
    """Read a JSON data file.

    Uses ``utf-8-sig`` because rule files are hand-authored and Windows editors
    routinely add a byte-order mark, which strict UTF-8 JSON parsing rejects.
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


class FormFieldSpec(BaseModel):
    """One column of an official Schedule FA table."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    key: str
    #: The column heading as printed on the official form.
    label: str
    data_type: str = "text"
    required: bool = True
    #: ``True`` when the value is computed rather than copied from source data.
    calculated: bool = False
    notes: str | None = None


class FormTableSpec(BaseModel):
    """An official Schedule FA table, such as A2 or A3."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    table_id: str
    title: str
    description: str
    fields: tuple[FormFieldSpec, ...]

    def field_labels(self) -> list[str]:
        return [field.label for field in self.fields]

    def field(self, key: str) -> FormFieldSpec:
        for spec in self.fields:
            if spec.key == key:
                return spec
        raise KeyError(f"table {self.table_id} has no field {key!r}")


class FormSchema(BaseModel):
    """The Schedule FA output layout for one assessment year / form version.

    Output columns are driven by this schema rather than invented by the report
    generator, so a change to the official form is absorbed by registering a
    new schema version.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    schema_version: str
    assessment_year: str
    form_version: str
    form_name: str
    source_ids: tuple[str, ...] = ()
    verification_status: str = "REQUIRES_CONFIRMATION"
    country_code_standard: str = "ITR_COUNTRY_CODE"
    country_code_notes: str | None = None
    tables: tuple[FormTableSpec, ...]

    def table(self, table_id: str) -> FormTableSpec:
        for spec in self.tables:
            if spec.table_id.upper() == table_id.upper():
                return spec
        raise RuleError(
            ErrorCode.FORM_SCHEMA_MISSING,
            f"form schema {self.schema_version} has no table {table_id!r}",
        )


@dataclass(frozen=True, slots=True)
class LoadedRuleFile:
    """A rule file plus the hash of the bytes it was loaded from."""

    path: Path
    file_hash: str
    rule: TaxRuleVersion


class RuleRegistry:
    """In-memory registry of rule versions, form schemas and sources."""

    def __init__(
        self,
        rules: Iterable[LoadedRuleFile] = (),
        form_schemas: Iterable[FormSchema] = (),
        sources: Iterable[OfficialSource] = (),
    ) -> None:
        self._rules: list[LoadedRuleFile] = list(rules)
        self._form_schemas: list[FormSchema] = list(form_schemas)
        self._sources: dict[str, OfficialSource] = {s.source_id: s for s in sources}

    # --- loading ------------------------------------------------------------

    @classmethod
    def from_directory(cls, root: Path) -> RuleRegistry:
        """Load every rule file, form schema and source from ``root``."""
        if not root.exists():
            raise RuleError(
                ErrorCode.TAX_RULE_VERSION_MISSING,
                f"rule directory {root} does not exist",
            )

        sources: list[OfficialSource] = []
        sources_path = root / SOURCES_FILENAME
        if sources_path.exists():
            payload = read_json(sources_path)
            sources = list(TypeAdapter(list[OfficialSource]).validate_python(payload))

        rules: list[LoadedRuleFile] = []
        for path in sorted(root.glob("ay_*.json")):
            data = read_json(path)
            rules.append(
                LoadedRuleFile(
                    path=path,
                    file_hash=hash_file(path),
                    rule=TaxRuleVersion.model_validate(data),
                )
            )

        schemas: list[FormSchema] = []
        schema_dir = root / FORM_SCHEMA_DIRNAME
        if schema_dir.exists():
            for path in sorted(schema_dir.glob("*.json")):
                schemas.append(FormSchema.model_validate(read_json(path)))

        return cls(rules=rules, form_schemas=schemas, sources=sources)

    # --- lookup -------------------------------------------------------------

    def rule_versions(self) -> list[TaxRuleVersion]:
        return [entry.rule for entry in self._rules]

    def supported_assessment_years(self) -> list[str]:
        return sorted({entry.rule.assessment_year for entry in self._rules if entry.rule.active})

    def rule_for(self, assessment_year: str | AssessmentYear) -> TaxRuleVersion:
        """Return the single active rule version for ``assessment_year``.

        Raises rather than picking a neighbouring year, and raises on ambiguity
        rather than choosing arbitrarily between two active versions.
        """
        parsed = AssessmentYear.parse(assessment_year)
        matches = [entry.rule for entry in self._rules if entry.rule.covers(parsed)]
        if not matches:
            available = ", ".join(self.supported_assessment_years()) or "none"
            raise RuleError(
                ErrorCode.TAX_RULE_VERSION_MISSING,
                f"no active tax rule version is registered for assessment year "
                f"{parsed.label}. Registered years: {available}. Another year's rules "
                f"are never substituted.",
            )
        if len(matches) > 1:
            ids = ", ".join(sorted(m.rule_version_id for m in matches))
            raise RuleError(
                ErrorCode.TAX_RULE_VERSION_MISSING,
                f"assessment year {parsed.label} has {len(matches)} active rule versions "
                f"({ids}); exactly one must be active",
            )
        return matches[0]

    def rule_by_id(self, rule_version_id: str) -> TaxRuleVersion:
        for entry in self._rules:
            if entry.rule.rule_version_id == rule_version_id:
                return entry.rule
        raise RuleError(
            ErrorCode.TAX_RULE_VERSION_MISSING,
            f"no rule version with id {rule_version_id!r}",
        )

    def rule_file_hash(self, rule_version_id: str) -> str | None:
        for entry in self._rules:
            if entry.rule.rule_version_id == rule_version_id:
                return entry.file_hash
        return None

    def form_schema_for(
        self,
        assessment_year: str | AssessmentYear,
        form_version: str | None = None,
    ) -> FormSchema:
        parsed = AssessmentYear.parse(assessment_year)
        matches = [
            schema
            for schema in self._form_schemas
            if AssessmentYear.parse(schema.assessment_year) == parsed
            and (form_version is None or schema.form_version == form_version)
        ]
        if not matches:
            raise RuleError(
                ErrorCode.FORM_SCHEMA_MISSING,
                f"no Schedule FA form schema is registered for assessment year "
                f"{parsed.label}"
                + (f" and form version {form_version!r}" if form_version else ""),
            )
        if len(matches) > 1:
            raise RuleError(
                ErrorCode.FORM_SCHEMA_MISSING,
                f"assessment year {parsed.label} has {len(matches)} form schemas; "
                f"specify a form version",
            )
        return matches[0]

    # --- sources ------------------------------------------------------------

    def source(self, source_id: str) -> OfficialSource:
        try:
            return self._sources[source_id]
        except KeyError as exc:
            raise RuleError(
                ErrorCode.TAX_RULE_VERSION_MISSING,
                f"rule cites source {source_id!r}, which is not in the source registry",
            ) from exc

    def sources(self, source_ids: Iterable[str] = ()) -> list[OfficialSource]:
        ids = list(source_ids)
        if not ids:
            return sorted(self._sources.values(), key=lambda s: (s.tier, s.source_id))
        return [self.source(source_id) for source_id in ids]

    def all_sources(self) -> Mapping[str, OfficialSource]:
        return dict(self._sources)

    def register_source(self, source: OfficialSource) -> None:
        self._sources[source.source_id] = source


@lru_cache
def get_rule_registry() -> RuleRegistry:
    """Load the process-wide rule registry from the configured data root."""
    return RuleRegistry.from_directory(get_settings().data_root / RULES_DIRNAME)
