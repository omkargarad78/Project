"""Assessment years, financial years and reporting periods.

Two timelines coexist and are never mixed:

* the **Schedule FA reporting period**, which the official form instructions
  define as a calendar period, and
* the **Indian financial year**, used for income-tax computation such as
  capital gains and foreign-source income.

Neither is derived from the other by convention inside the calculation code.
The Schedule FA period always comes from the rule version registered for the
selected assessment year, so a year whose instructions change is a data change
rather than a code change.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from enum import StrEnum
from functools import total_ordering

_AY_RE = re.compile(r"^(?P<start>\d{4})-(?P<end>\d{2}|\d{4})$")


class PeriodBasis(StrEnum):
    """The basis on which a reporting period is defined."""

    CALENDAR_YEAR = "CALENDAR_YEAR"
    FINANCIAL_YEAR = "FINANCIAL_YEAR"
    EXPLICIT_DATES = "EXPLICIT_DATES"


@total_ordering
@dataclass(frozen=True, slots=True)
class AssessmentYear:
    """An Indian assessment year, written ``2026-27``.

    The assessment year begins on 1 April and the previous year (financial
    year) it assesses is the twelve months ending on the preceding 31 March.
    """

    start_year: int

    @classmethod
    def parse(cls, value: str | AssessmentYear) -> AssessmentYear:
        if isinstance(value, AssessmentYear):
            return value
        match = _AY_RE.match(value.strip())
        if match is None:
            raise ValueError(
                f"assessment year must look like '2026-27' or '2026-2027', got {value!r}"
            )
        start = int(match.group("start"))
        end_text = match.group("end")
        end = int(end_text) if len(end_text) == 4 else (start // 100) * 100 + int(end_text)
        if end != start + 1:
            raise ValueError(f"assessment year {value!r} must span consecutive years")
        return cls(start_year=start)

    @property
    def label(self) -> str:
        return f"{self.start_year}-{str(self.start_year + 1)[-2:]}"

    @property
    def start_date(self) -> date:
        return date(self.start_year, 4, 1)

    @property
    def end_date(self) -> date:
        return date(self.start_year + 1, 3, 31)

    @property
    def financial_year(self) -> FinancialYear:
        """The previous year assessed by this assessment year."""
        return FinancialYear(start_year=self.start_year - 1)

    def __str__(self) -> str:
        return self.label

    def __lt__(self, other: AssessmentYear) -> bool:
        return self.start_year < other.start_year


@total_ordering
@dataclass(frozen=True, slots=True)
class FinancialYear:
    """An Indian financial year, 1 April to 31 March, written ``2025-26``."""

    start_year: int

    @classmethod
    def parse(cls, value: str | FinancialYear) -> FinancialYear:
        if isinstance(value, FinancialYear):
            return value
        match = _AY_RE.match(value.strip())
        if match is None:
            raise ValueError(f"financial year must look like '2025-26', got {value!r}")
        return cls(start_year=int(match.group("start")))

    @property
    def label(self) -> str:
        return f"{self.start_year}-{str(self.start_year + 1)[-2:]}"

    @property
    def start_date(self) -> date:
        return date(self.start_year, 4, 1)

    @property
    def end_date(self) -> date:
        return date(self.start_year + 1, 3, 31)

    @property
    def assessment_year(self) -> AssessmentYear:
        return AssessmentYear(start_year=self.start_year + 1)

    def contains(self, day: date) -> bool:
        return self.start_date <= day <= self.end_date

    def __str__(self) -> str:
        return self.label

    def __lt__(self, other: FinancialYear) -> bool:
        return self.start_year < other.start_year


@dataclass(frozen=True, slots=True)
class ReportingPeriod:
    """A closed date interval used for a specific schedule's reporting."""

    start_date: date
    end_date: date
    basis: PeriodBasis
    #: Free-text description taken from the official instructions, for display.
    description: str

    def __post_init__(self) -> None:
        if self.end_date < self.start_date:
            raise ValueError(
                f"reporting period end {self.end_date} precedes start {self.start_date}"
            )

    @property
    def label(self) -> str:
        return f"{self.start_date.isoformat()} to {self.end_date.isoformat()}"

    @property
    def calendar_year(self) -> int | None:
        """The calendar year when the period is exactly one calendar year."""
        if (
            self.basis is PeriodBasis.CALENDAR_YEAR
            and self.start_date == date(self.start_date.year, 1, 1)
            and self.end_date == date(self.start_date.year, 12, 31)
        ):
            return self.start_date.year
        return None

    def contains(self, day: date) -> bool:
        return self.start_date <= day <= self.end_date

    def clamp(self, day: date) -> date:
        if day < self.start_date:
            return self.start_date
        if day > self.end_date:
            return self.end_date
        return day

    def days(self) -> list[date]:
        """Every calendar day in the period, ascending."""
        from datetime import timedelta

        span = (self.end_date - self.start_date).days
        return [self.start_date + timedelta(days=offset) for offset in range(span + 1)]


@dataclass(frozen=True, slots=True)
class TaxPeriod:
    """The full period context a calculation run is bound to.

    ``fa_reporting_period`` drives Schedule FA. ``financial_year`` drives
    income-tax computation. Both are surfaced in the UI and in the generated
    workpaper so a reviewer can see that the two windows differ.
    """

    assessment_year: AssessmentYear
    financial_year: FinancialYear
    fa_reporting_period: ReportingPeriod
    form_version: str
    rule_version_id: str

    @property
    def fa_calendar_year(self) -> int | None:
        return self.fa_reporting_period.calendar_year

    @property
    def fa_closing_date(self) -> date:
        """The date on which the Schedule FA closing value is measured."""
        return self.fa_reporting_period.end_date

    def describe(self) -> dict[str, str]:
        return {
            "Assessment Year": self.assessment_year.label,
            "Financial Year": self.financial_year.label,
            "Financial Year Period": (
                f"{self.financial_year.start_date.isoformat()} to "
                f"{self.financial_year.end_date.isoformat()}"
            ),
            "Schedule FA Reporting Period": self.fa_reporting_period.label,
            "Schedule FA Period Basis": str(self.fa_reporting_period.basis),
            "Schedule FA Period Description": self.fa_reporting_period.description,
            "Schedule FA Calendar Year": (
                str(self.fa_calendar_year) if self.fa_calendar_year else "not a full calendar year"
            ),
            "Form Version": self.form_version,
            "Tax Rule Version": self.rule_version_id,
        }
