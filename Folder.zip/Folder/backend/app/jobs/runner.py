"""Running a calculation outside the request that asked for it.

A full pipeline run parses files, reconstructs lots, values every priced day
and writes a workbook. That is far longer than a request should hold a
connection open, so the API records a queued run, returns its id, and the
client polls.

Two backends, one interface:

``inline``
    Runs immediately, in-process, before the enqueue call returns. The
    default, because it needs no services and makes tests deterministic.

``thread``
    Runs on a worker thread with its own database session. Enough for a
    single-node deployment.

A Redis-backed distributed queue is the next implementation and slots in
here. Nothing above this module knows which backend is in use.
"""

from __future__ import annotations

import logging
import threading
from collections.abc import Callable
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
from datetime import UTC, datetime

from sqlalchemy.orm import Session, sessionmaker

from ..core.config import Settings, get_settings
from ..db.models import CalculationRun, RunStatus
from ..db.session import get_session_factory

logger = logging.getLogger(__name__)

#: A job is handed a fresh session and the id of the run to execute. It is
#: not handed the run object: that belongs to the session the request used,
#: and touching it from another thread is the classic way to corrupt one.
JobFunction = Callable[[Session, str], None]


@dataclass(frozen=True, slots=True)
class JobHandle:
    """What the caller gets back. Only the run id is durable."""

    run_id: str
    #: Present for the thread backend, so tests can wait rather than sleep.
    future: Future | None = None

    def wait(self, timeout: float | None = None) -> None:
        if self.future is not None:
            self.future.result(timeout=timeout)


class JobRunner:
    """Base class holding the part both backends share."""

    def __init__(self, session_factory: sessionmaker[Session] | None = None) -> None:
        self._session_factory = session_factory or get_session_factory()

    def enqueue(self, run_id: str, job: JobFunction) -> JobHandle:
        raise NotImplementedError

    def shutdown(self, *, wait: bool = True) -> None:
        return None

    def _execute(self, run_id: str, job: JobFunction) -> None:
        """Run the job in its own transaction and record the outcome.

        The failure path gets its own session. If the job's transaction is
        broken — which is the usual reason it failed — writing the failure
        through the same session would raise a second error and lose the
        first, leaving the run stuck in RUNNING forever.
        """
        session = self._session_factory()
        try:
            self._mark(session, run_id, RunStatus.RUNNING)
            session.commit()
            job(session, run_id)
            session.commit()
        except Exception as exc:  # noqa: BLE001 - the whole point is to record it
            logger.exception("calculation run %s failed", run_id)
            session.rollback()
            self._record_failure(run_id, exc)
        finally:
            session.close()

    def _mark(self, session: Session, run_id: str, status: RunStatus) -> None:
        run = session.get(CalculationRun, run_id)
        if run is None:
            raise LookupError(f"no calculation run {run_id}")
        run.status = status
        if status is RunStatus.RUNNING:
            run.started_at = datetime.now(UTC)

    def _record_failure(self, run_id: str, exc: BaseException) -> None:
        session = self._session_factory()
        try:
            run = session.get(CalculationRun, run_id)
            if run is None:
                return
            run.status = RunStatus.FAILED
            run.finished_at = datetime.now(UTC)
            # The class name, not the message. An exception message can carry
            # a file path or a fragment of the user's data, and this string is
            # shown in the API.
            run.error_message = (
                f"the calculation stopped with an internal error "
                f"({type(exc).__name__}). Nothing was saved from this run."
            )
            session.commit()
        finally:
            session.close()


class InlineJobRunner(JobRunner):
    """Executes before returning. The default, and what tests use."""

    def enqueue(self, run_id: str, job: JobFunction) -> JobHandle:
        self._execute(run_id, job)
        return JobHandle(run_id=run_id)


class ThreadJobRunner(JobRunner):
    """Executes on a small worker pool, one session per job."""

    def __init__(
        self,
        session_factory: sessionmaker[Session] | None = None,
        *,
        max_workers: int = 2,
    ) -> None:
        super().__init__(session_factory)
        self._pool = ThreadPoolExecutor(
            max_workers=max_workers, thread_name_prefix="fa-job"
        )
        self._lock = threading.Lock()
        self._closed = False

    def enqueue(self, run_id: str, job: JobFunction) -> JobHandle:
        with self._lock:
            if self._closed:
                raise RuntimeError("the job runner is shutting down")
            future = self._pool.submit(self._execute, run_id, job)
        return JobHandle(run_id=run_id, future=future)

    def shutdown(self, *, wait: bool = True) -> None:
        with self._lock:
            self._closed = True
        self._pool.shutdown(wait=wait)


def build_runner(
    settings: Settings | None = None,
    session_factory: sessionmaker[Session] | None = None,
) -> JobRunner:
    settings = settings or get_settings()
    backend = settings.job_backend.lower()
    if backend == "inline":
        return InlineJobRunner(session_factory)
    if backend == "thread":
        return ThreadJobRunner(session_factory)
    raise ValueError(
        f"unknown job backend {settings.job_backend!r}; expected 'inline' or 'thread'"
    )
