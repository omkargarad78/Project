"""Authentication, tokens and workspace authorisation."""

from .passwords import (
    MIN_PASSWORD_LENGTH,
    PasswordError,
    hash_password,
    needs_rehash,
    validate_password,
    verify_password,
)
from .service import (
    AuthError,
    PermissionDenied,
    Principal,
    add_member,
    authenticate,
    authorise,
    create_workspace,
    list_workspaces,
    normalise_email,
    register_user,
    remove_member,
)
from .tokens import (
    AccessClaims,
    DownloadClaims,
    TokenError,
    issue_access_token,
    issue_download_token,
    read_access_token,
    read_download_token,
)

__all__ = [
    "MIN_PASSWORD_LENGTH",
    "AccessClaims",
    "AuthError",
    "DownloadClaims",
    "PasswordError",
    "PermissionDenied",
    "Principal",
    "TokenError",
    "add_member",
    "authenticate",
    "authorise",
    "create_workspace",
    "hash_password",
    "issue_access_token",
    "issue_download_token",
    "list_workspaces",
    "needs_rehash",
    "normalise_email",
    "read_access_token",
    "read_download_token",
    "register_user",
    "remove_member",
    "validate_password",
    "verify_password",
]
