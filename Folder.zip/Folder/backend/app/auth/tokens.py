"""Access tokens and short-lived download tokens.

Both are HS256 JWTs signed with the application secret. They carry no
authority of their own: a token names a subject, and every request still
looks the subject up and re-checks what it may do. A token that carried its
own permissions would keep granting them after the membership was revoked.

Download tokens exist because a browser following a download link cannot set
an Authorization header. They are scoped to one artifact, expire in minutes,
and are typed so that one can never be replayed as a session token.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

import jwt

from ..core.config import Settings, get_settings

ALGORITHM = "HS256"

#: The audience claim separates the two kinds. Without it, a download link —
#: which travels in a URL and ends up in browser history, proxy logs and
#: referrer headers — could be pasted into an Authorization header and used
#: as a full session.
ACCESS_AUDIENCE = "fa:access"
DOWNLOAD_AUDIENCE = "fa:download"


class TokenError(ValueError):
    """Raised when a token is absent, malformed, expired or the wrong kind."""


@dataclass(frozen=True, slots=True)
class AccessClaims:
    user_id: str
    email: str
    issued_at: datetime
    expires_at: datetime


@dataclass(frozen=True, slots=True)
class DownloadClaims:
    user_id: str
    artifact_id: str
    expires_at: datetime


def _now() -> datetime:
    return datetime.now(UTC)


def issue_access_token(
    user_id: str,
    email: str,
    *,
    settings: Settings | None = None,
    now: datetime | None = None,
) -> tuple[str, datetime]:
    """Return a signed access token and the moment it stops working."""
    settings = settings or get_settings()
    issued = now or _now()
    expires = issued + timedelta(seconds=settings.access_token_ttl_seconds)
    payload = {
        "sub": user_id,
        "email": email,
        "aud": ACCESS_AUDIENCE,
        "iat": int(issued.timestamp()),
        "exp": int(expires.timestamp()),
    }
    return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM), expires


def read_access_token(
    token: str, *, settings: Settings | None = None
) -> AccessClaims:
    payload = _decode(token, ACCESS_AUDIENCE, settings)
    subject = payload.get("sub")
    if not subject:
        raise TokenError("the token names no subject")
    return AccessClaims(
        user_id=str(subject),
        email=str(payload.get("email", "")),
        issued_at=datetime.fromtimestamp(payload["iat"], tz=UTC),
        expires_at=datetime.fromtimestamp(payload["exp"], tz=UTC),
    )


def issue_download_token(
    user_id: str,
    artifact_id: str,
    *,
    settings: Settings | None = None,
    now: datetime | None = None,
) -> tuple[str, datetime]:
    """A token good for one artifact, for a few minutes."""
    settings = settings or get_settings()
    issued = now or _now()
    expires = issued + timedelta(seconds=settings.download_url_ttl_seconds)
    payload = {
        "sub": user_id,
        "artifact": artifact_id,
        "aud": DOWNLOAD_AUDIENCE,
        "iat": int(issued.timestamp()),
        "exp": int(expires.timestamp()),
    }
    return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM), expires


def read_download_token(
    token: str, *, settings: Settings | None = None
) -> DownloadClaims:
    payload = _decode(token, DOWNLOAD_AUDIENCE, settings)
    artifact = payload.get("artifact")
    if not artifact:
        raise TokenError("the token names no artifact")
    return DownloadClaims(
        user_id=str(payload.get("sub", "")),
        artifact_id=str(artifact),
        expires_at=datetime.fromtimestamp(payload["exp"], tz=UTC),
    )


def _decode(token: str, audience: str, settings: Settings | None) -> dict:
    settings = settings or get_settings()
    if not token:
        raise TokenError("no token was supplied")
    try:
        return jwt.decode(
            token,
            settings.secret_key,
            # Pinned rather than taken from the token's own header, which is
            # what makes the "alg: none" and RS256-verified-as-HS256 attacks
            # work.
            algorithms=[ALGORITHM],
            audience=audience,
            options={"require": ["exp", "iat", "sub", "aud"]},
        )
    except jwt.ExpiredSignatureError as exc:
        raise TokenError("the token has expired") from exc
    except jwt.InvalidAudienceError as exc:
        raise TokenError("the token is not valid for this purpose") from exc
    except jwt.InvalidTokenError as exc:
        raise TokenError("the token could not be verified") from exc
