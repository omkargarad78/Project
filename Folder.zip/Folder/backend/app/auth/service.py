"""Registration, sign-in and the workspace authorisation check.

The authorisation function in here is the one place that decides whether a
user may touch a workspace. Every route goes through it. Scattering the same
check across routes is how one route ends up missing it, and the missing one
is never noticed because it works perfectly for the person testing it.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db.models import Membership, Role, User, Workspace
from .passwords import hash_password, needs_rehash, verify_password


class AuthError(Exception):
    """Sign-in failed. Deliberately says no more than that."""


class PermissionDenied(Exception):
    """The user may not do this to this workspace."""

    def __init__(self, message: str = "you do not have access to this workspace") -> None:
        super().__init__(message)


@dataclass(frozen=True, slots=True)
class Principal:
    """Who is acting, and what they may do here.

    Carries the role rather than re-deriving it, so a route that has already
    been authorised cannot accidentally check a different workspace.
    """

    user: User
    workspace: Workspace
    role: Role

    @property
    def can_write(self) -> bool:
        return self.role.can_write

    @property
    def can_administer(self) -> bool:
        return self.role.can_administer


def normalise_email(email: str) -> str:
    """Lower-cased and trimmed.

    Uniqueness is enforced on this form, so two accounts cannot differ only
    in capitalisation and leave the user unsure which one they signed up
    with.
    """
    return email.strip().lower()


def register_user(
    session: Session, *, email: str, password: str, display_name: str = ""
) -> User:
    address = normalise_email(email)
    if not address or "@" not in address:
        raise AuthError("a valid email address is required")

    existing = session.scalar(select(User).where(User.email == address))
    if existing is not None:
        # The caller decides what to tell the client. The registration route
        # returns the same response either way so that the endpoint cannot be
        # used to discover who already has an account.
        raise AuthError("an account with that email already exists")

    user = User(
        email=address,
        password_hash=hash_password(password),
        display_name=display_name.strip() or address.split("@")[0],
    )
    session.add(user)
    session.flush()
    return user


def authenticate(session: Session, *, email: str, password: str) -> User:
    """Verify credentials, or raise without saying which half was wrong."""
    address = normalise_email(email)
    user = session.scalar(select(User).where(User.email == address))

    # Runs the hash even when there is no such user, so that a missing
    # account and a wrong password take the same time.
    if not verify_password(password, user.password_hash if user else None):
        raise AuthError("the email or password is incorrect")
    assert user is not None

    if not user.is_active:
        raise AuthError("this account is not active")

    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(password)
    user.last_login_at = datetime.now(UTC)
    return user


def create_workspace(
    session: Session, *, owner: User, name: str, assessment_year: str
) -> Workspace:
    workspace = Workspace(
        name=name.strip() or "Untitled workspace",
        assessment_year=assessment_year,
    )
    session.add(workspace)
    session.flush()
    session.add(
        Membership(user_id=owner.id, workspace_id=workspace.id, role=Role.OWNER)
    )
    session.flush()
    return workspace


def authorise(
    session: Session,
    *,
    user: User,
    workspace_id: str,
    require_write: bool = False,
    require_admin: bool = False,
) -> Principal:
    """Resolve a workspace the user may act on, or refuse.

    A workspace that exists but does not belong to the user raises the same
    error as one that does not exist. Distinguishing them would let anyone
    enumerate workspace ids by watching for a different status code.
    """
    row = session.execute(
        select(Workspace, Membership.role)
        .join(Membership, Membership.workspace_id == Workspace.id)
        .where(Workspace.id == workspace_id, Membership.user_id == user.id)
    ).first()
    if row is None:
        raise PermissionDenied()

    workspace, role = row
    role = Role(role)
    if require_admin and not role.can_administer:
        raise PermissionDenied("this action requires the workspace owner")
    if require_write and not role.can_write:
        raise PermissionDenied("your role on this workspace is read-only")
    return Principal(user=user, workspace=workspace, role=role)


def list_workspaces(session: Session, *, user: User) -> list[tuple[Workspace, Role]]:
    rows = session.execute(
        select(Workspace, Membership.role)
        .join(Membership, Membership.workspace_id == Workspace.id)
        .where(Membership.user_id == user.id)
        .order_by(Workspace.created_at.desc())
    ).all()
    return [(workspace, Role(role)) for workspace, role in rows]


def add_member(
    session: Session, *, workspace: Workspace, email: str, role: Role
) -> Membership:
    address = normalise_email(email)
    user = session.scalar(select(User).where(User.email == address))
    if user is None:
        raise AuthError("no account exists with that email address")

    existing = session.scalar(
        select(Membership).where(
            Membership.workspace_id == workspace.id, Membership.user_id == user.id
        )
    )
    if existing is not None:
        existing.role = role
        return existing

    membership = Membership(user_id=user.id, workspace_id=workspace.id, role=role)
    session.add(membership)
    session.flush()
    return membership


def remove_member(session: Session, *, workspace: Workspace, user_id: str) -> None:
    """Remove a member, refusing to leave the workspace unowned.

    A workspace with no owner cannot be administered by anyone, including
    the person who just locked themselves out of it.
    """
    membership = session.scalar(
        select(Membership).where(
            Membership.workspace_id == workspace.id, Membership.user_id == user_id
        )
    )
    if membership is None:
        return

    if Role(membership.role) is Role.OWNER:
        owners = session.scalar(
            select(func.count())
            .select_from(Membership)
            .where(
                Membership.workspace_id == workspace.id,
                Membership.role == Role.OWNER,
            )
        )
        if owners is not None and owners <= 1:
            raise PermissionDenied(
                "this is the only owner; promote another member first"
            )

    session.delete(membership)
