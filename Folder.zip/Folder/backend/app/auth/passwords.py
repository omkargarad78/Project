"""Password hashing.

Argon2id, because it is the current recommendation and because the
alternatives people reach for by habit — a bare SHA-256, or bcrypt with the
default cost from a decade ago — are the two ways this gets done wrong.

The verify path deliberately does the same amount of work whether or not the
account exists. Skipping the hash for an unknown email turns the login
endpoint into an account-enumeration oracle measurable over the network.
"""

from __future__ import annotations

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

#: Tuned to roughly 50ms on a modern server: slow enough to make offline
#: cracking expensive, fast enough that a login does not feel broken.
_hasher = PasswordHasher(
    time_cost=3,
    memory_cost=64 * 1024,
    parallelism=2,
    hash_len=32,
    salt_len=16,
)

#: A valid argon2id hash of a value nobody can supply, used to spend the same
#: time on a missing account as on a real one.
_DUMMY_HASH = _hasher.hash("password-for-an-account-that-does-not-exist")

MIN_PASSWORD_LENGTH = 12
MAX_PASSWORD_LENGTH = 1024


class PasswordError(ValueError):
    """Raised when a password cannot be accepted."""


def validate_password(password: str) -> None:
    """Refuse passwords that cannot protect a year of financial records.

    A maximum matters as much as a minimum: argon2's cost is driven by its
    parameters rather than input length, but an unbounded field is still a
    cheap way to make a server do unbounded work.
    """
    if len(password) < MIN_PASSWORD_LENGTH:
        raise PasswordError(
            f"a password must be at least {MIN_PASSWORD_LENGTH} characters"
        )
    if len(password) > MAX_PASSWORD_LENGTH:
        raise PasswordError(
            f"a password must be at most {MAX_PASSWORD_LENGTH} characters"
        )
    if not password.strip():
        raise PasswordError("a password cannot be only whitespace")


def hash_password(password: str) -> str:
    validate_password(password)
    return _hasher.hash(password)


def verify_password(password: str, password_hash: str | None) -> bool:
    """Check a password, taking the same time whether the account exists.

    ``password_hash`` is allowed to be ``None`` so that the caller can hand
    over a missing user directly instead of branching before the check and
    leaking the answer in the response time.
    """
    try:
        _hasher.verify(password_hash or _DUMMY_HASH, password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False
    return password_hash is not None


def needs_rehash(password_hash: str) -> bool:
    """Whether a stored hash predates the current cost parameters.

    Checked on every successful login so that raising the cost upgrades
    existing accounts as their owners sign in, rather than never.
    """
    try:
        return _hasher.check_needs_rehash(password_hash)
    except InvalidHashError:
        return True
