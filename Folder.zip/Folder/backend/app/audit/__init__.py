"""Append-only audit trail."""

from .log import Action, history, record

__all__ = ["Action", "history", "record"]
