"""The audit trail.

Every action that changes a figure, a file or who can see them is recorded
here. The trail is append-only: there is a write function and no amend
function, because a record that can be corrected after the fact answers a
different question from the one an auditor is asking.

What gets recorded is denormalised on purpose. The workspace may be deleted
and the actor's account closed, and the entry still has to be readable.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db.models import AuditEvent, User


class Action(StrEnum):
    """The recorded vocabulary.

    An enum rather than free text so that the trail can be queried and so
    that two places logging the same event cannot name it differently.
    """

    USER_REGISTERED = "USER_REGISTERED"
    USER_SIGNED_IN = "USER_SIGNED_IN"
    USER_SIGN_IN_FAILED = "USER_SIGN_IN_FAILED"

    WORKSPACE_CREATED = "WORKSPACE_CREATED"
    WORKSPACE_DELETED = "WORKSPACE_DELETED"
    MEMBER_ADDED = "MEMBER_ADDED"
    MEMBER_ROLE_CHANGED = "MEMBER_ROLE_CHANGED"
    MEMBER_REMOVED = "MEMBER_REMOVED"

    FILE_UPLOADED = "FILE_UPLOADED"
    FILE_REJECTED = "FILE_REJECTED"
    FILE_DELETED = "FILE_DELETED"

    RUN_REQUESTED = "RUN_REQUESTED"
    RUN_COMPLETED = "RUN_COMPLETED"
    RUN_FAILED = "RUN_FAILED"

    ISSUE_ACKNOWLEDGED = "ISSUE_ACKNOWLEDGED"
    ISSUE_MARKED_RESOLVED = "ISSUE_MARKED_RESOLVED"
    ISSUE_DECISION_WITHDRAWN = "ISSUE_DECISION_WITHDRAWN"

    REPORT_GENERATED = "REPORT_GENERATED"
    REPORT_DOWNLOADED = "REPORT_DOWNLOADED"


#: Keys whose values are never written to the trail, at any nesting depth.
#: The audit log is widely readable by design, so a secret that reaches it is
#: a secret in a place nobody thinks to look.
_REDACTED = frozenset(
    {
        "password",
        "new_password",
        "current_password",
        "token",
        "access_token",
        "download_token",
        "secret",
        "secret_key",
        "authorization",
    }
)


def _scrub(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            key: "[redacted]" if key.lower() in _REDACTED else _scrub(item)
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [_scrub(item) for item in value]
    return value


def record(
    session: Session,
    action: Action,
    *,
    actor: User | None = None,
    workspace_id: str | None = None,
    target_type: str = "",
    target_id: str = "",
    ip_address: str | None = None,
    at: datetime | None = None,
    **detail: Any,
) -> AuditEvent:
    """Append one entry.

    Added to the session but not committed: the entry belongs to the same
    transaction as the change it describes, so that a rolled-back action
    leaves no record of having happened.
    """
    event = AuditEvent(
        at=at or datetime.now(UTC),
        workspace_id=workspace_id,
        actor_id=actor.id if actor else None,
        actor_email=actor.email if actor else "",
        action=str(action),
        target_type=target_type,
        target_id=target_id,
        detail=_scrub(detail),
        ip_address=ip_address,
    )
    session.add(event)
    return event


def history(
    session: Session,
    *,
    workspace_id: str,
    limit: int = 200,
    before: datetime | None = None,
) -> list[AuditEvent]:
    """Most recent first, for one workspace."""
    statement = (
        select(AuditEvent)
        .where(AuditEvent.workspace_id == workspace_id)
        .order_by(AuditEvent.at.desc(), AuditEvent.id.desc())
        .limit(max(1, min(limit, 1000)))
    )
    if before is not None:
        statement = statement.where(AuditEvent.at < before)
    return list(session.scalars(statement))
