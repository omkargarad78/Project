"""The canonical ledger container, duplicate detection and cash reconciliation."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable, Iterator, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal

from ..core.errors import ErrorCode, Severity
from ..core.money import ZERO, add, as_amount, is_effectively_zero
from ..validation.issues import IssueCollector, IssueScope
from .models import (
    Ledger,
    NormalizedTransaction,
    RawTransactionRow,
    TransactionType,
)


@dataclass(frozen=True, slots=True)
class DuplicateGroup:
    """A set of transactions that share a duplicate fingerprint or broker id."""

    key: str
    reason: str
    transaction_ids: tuple[str, ...]
    source_references: tuple[str, ...]


@dataclass(slots=True)
class TransactionLedger:
    """Raw rows and normalized transactions for one workspace.

    Both collections are retained: a normalized transaction can always be
    traced back to the verbatim row it came from via :meth:`raw_for`.
    """

    transactions: list[NormalizedTransaction] = field(default_factory=list)
    raw_rows: list[RawTransactionRow] = field(default_factory=list)

    # --- construction -------------------------------------------------------

    def add(
        self,
        transaction: NormalizedTransaction,
        raw_row: RawTransactionRow | None = None,
    ) -> None:
        self.transactions.append(transaction)
        if raw_row is not None:
            self.raw_rows.append(raw_row)

    def extend(
        self,
        transactions: Iterable[NormalizedTransaction],
        raw_rows: Iterable[RawTransactionRow] = (),
    ) -> None:
        self.transactions.extend(transactions)
        self.raw_rows.extend(raw_rows)

    def merge(self, other: TransactionLedger) -> None:
        self.transactions.extend(other.transactions)
        self.raw_rows.extend(other.raw_rows)

    # --- access -------------------------------------------------------------

    def __iter__(self) -> Iterator[NormalizedTransaction]:
        return iter(self.ordered())

    def __len__(self) -> int:
        return len(self.transactions)

    def ordered(self) -> list[NormalizedTransaction]:
        """Deterministic processing order.

        Date first, then acquisitions before disposals on the same date so that
        a same-day buy/sell pair allocates against the intended lot, then the
        source row, then the transaction id as a final tie-break. Without the
        last two keys the lot engine's output would depend on file ordering.
        """
        priority = {
            TransactionType.TRANSFER_IN: 0,
            TransactionType.RSU_VEST: 0,
            TransactionType.ESPP_PURCHASE: 0,
            TransactionType.BUY: 0,
            TransactionType.STOCK_SPLIT: 1,
            TransactionType.STOCK_MERGER: 1,
            TransactionType.SPINOFF: 1,
            TransactionType.SELL: 2,
            TransactionType.RSU_SALE: 2,
            TransactionType.TRANSFER_OUT: 2,
        }
        return sorted(
            self.transactions,
            key=lambda t: (
                t.transaction_date,
                priority.get(t.transaction_type, 3),
                t.source_file_id,
                t.source_sheet,
                t.source_row,
                t.transaction_id,
            ),
        )

    def raw_index(self) -> Mapping[tuple[str, str, int], RawTransactionRow]:
        return {(r.source_file_id, r.source_sheet, r.source_row): r for r in self.raw_rows}

    def raw_for(self, transaction: NormalizedTransaction) -> RawTransactionRow | None:
        """Return the verbatim broker row behind ``transaction``."""
        return self.raw_index().get(
            (transaction.source_file_id, transaction.source_sheet, transaction.source_row)
        )

    def by_id(self) -> Mapping[str, NormalizedTransaction]:
        return {t.transaction_id: t for t in self.transactions}

    def tickers(self) -> list[str]:
        seen = {t.ticker.upper() for t in self.transactions if t.ticker}
        return sorted(seen)

    def accounts(self) -> list[str]:
        return sorted({t.account_id for t in self.transactions if t.account_id})

    def currencies(self) -> list[str]:
        return sorted({t.currency for t in self.transactions})

    def date_range(self) -> tuple[date, date] | None:
        if not self.transactions:
            return None
        dates = [t.transaction_date for t in self.transactions]
        return min(dates), max(dates)

    def for_ticker(self, ticker: str) -> list[NormalizedTransaction]:
        upper = ticker.upper()
        return [t for t in self.ordered() if t.ticker and t.ticker.upper() == upper]

    def of_type(self, *types: TransactionType) -> list[NormalizedTransaction]:
        wanted = set(types)
        return [t for t in self.ordered() if t.transaction_type in wanted]

    def in_period(self, start: date, end: date) -> list[NormalizedTransaction]:
        return [t for t in self.ordered() if start <= t.transaction_date <= end]

    def group_by_ticker(self) -> Mapping[str, list[NormalizedTransaction]]:
        grouped: dict[str, list[NormalizedTransaction]] = defaultdict(list)
        for transaction in self.ordered():
            if transaction.ticker:
                grouped[transaction.ticker.upper()].append(transaction)
        return dict(grouped)

    # --- duplicate detection ------------------------------------------------

    def find_duplicates(self) -> list[DuplicateGroup]:
        """Group transactions that appear to be the same broker event.

        Duplicates are reported, never removed. Two genuinely identical
        transactions on the same day are legitimate (for example two equal fills
        of one order), so only the user can decide.
        """
        groups: list[DuplicateGroup] = []

        # Keyed by transaction type as well as the broker's reference, because
        # one broker row can legitimately produce several transactions that all
        # carry that reference: an income row yields a gross dividend and its
        # withholding tax, and those two are not duplicates of each other.
        by_broker_id: dict[str, list[NormalizedTransaction]] = defaultdict(list)
        for transaction in self.ordered():
            if transaction.broker_transaction_id:
                key = (
                    f"{transaction.broker}:{transaction.broker_transaction_id}"
                    f":{transaction.transaction_type}"
                )
                by_broker_id[key].append(transaction)

        claimed: set[str] = set()
        for key, members in sorted(by_broker_id.items()):
            if len(members) > 1:
                claimed.update(m.transaction_id for m in members)
                groups.append(
                    DuplicateGroup(
                        key=key,
                        reason="identical broker transaction identifier",
                        transaction_ids=tuple(m.transaction_id for m in members),
                        source_references=tuple(m.source_reference for m in members),
                    )
                )

        by_print: dict[str, list[NormalizedTransaction]] = defaultdict(list)
        for transaction in self.ordered():
            if transaction.transaction_id in claimed:
                continue
            by_print[transaction.duplicate_fingerprint()].append(transaction)

        for key, members in sorted(by_print.items()):
            if len(members) > 1:
                groups.append(
                    DuplicateGroup(
                        key=key,
                        reason=(
                            "identical broker, account, date, ticker, activity, "
                            "quantity and amount"
                        ),
                        transaction_ids=tuple(m.transaction_id for m in members),
                        source_references=tuple(m.source_reference for m in members),
                    )
                )
        return groups

    def report_duplicates(self, issues: IssueCollector) -> list[DuplicateGroup]:
        groups = self.find_duplicates()
        by_id = self.by_id()
        for group in groups:
            first = by_id[group.transaction_ids[0]]
            issues.report(
                ErrorCode.DUPLICATE_TRANSACTION,
                scope=IssueScope.TRANSACTION,
                subject=group.transaction_ids[0],
                message=(
                    f"{len(group.transaction_ids)} transactions on "
                    f"{first.transaction_date.isoformat()} share the same "
                    f"{group.reason}. They are kept as separate transactions until "
                    f"you confirm whether they are duplicates."
                ),
                duplicate_reason=group.reason,
                transaction_ids=list(group.transaction_ids),
                source_references=list(group.source_references),
            )
        return groups

    def report_unsupported(self, issues: IssueCollector) -> None:
        """Flag rows the parser could not map to a canonical type.

        Severity escalates to ERROR when the row carries a quantity, because an
        unmapped row that moves shares makes every downstream holding figure
        unreliable.
        """
        for transaction in self.of_type(TransactionType.UNKNOWN):
            affects_holdings = transaction.quantity is not None and not is_effectively_zero(
                transaction.quantity
            )
            issues.report(
                ErrorCode.UNSUPPORTED_TRANSACTION,
                scope=IssueScope.TRANSACTION,
                subject=transaction.transaction_id,
                message=(
                    f"{transaction.broker} reported activity "
                    f"{transaction.raw_activity!r} on "
                    f"{transaction.transaction_date.isoformat()} at "
                    f"{transaction.source_reference}, which the parser does not map to "
                    f"a canonical transaction type."
                    + (
                        " The row carries a quantity, so holdings cannot be "
                        "reconstructed reliably until it is mapped."
                        if affects_holdings
                        else ""
                    )
                ),
                severity=Severity.ERROR if affects_holdings else Severity.WARNING,
                raw_activity=transaction.raw_activity,
                source_reference=transaction.source_reference,
            )


@dataclass(frozen=True, slots=True)
class CashReconciliation:
    """Cash-ledger reconciliation for one account and currency.

    ``opening + deposits + sale_proceeds + dividends + interest + other_credits
    - purchases - fees - withdrawals - taxes = closing``
    """

    account_id: str | None
    currency: str
    opening_balance: Decimal
    deposits: Decimal
    withdrawals: Decimal
    purchases: Decimal
    sale_proceeds: Decimal
    dividends: Decimal
    interest: Decimal
    fees: Decimal
    taxes: Decimal
    other_credits: Decimal
    other_debits: Decimal
    computed_closing: Decimal
    broker_closing: Decimal | None = None

    @property
    def difference(self) -> Decimal | None:
        if self.broker_closing is None:
            return None
        return as_amount(self.computed_closing - self.broker_closing)

    @property
    def reconciles(self) -> bool | None:
        difference = self.difference
        if difference is None:
            return None
        return is_effectively_zero(difference, scale=2)

    def to_row(self) -> dict[str, str]:
        from ..core.money import decimal_to_str

        return {
            "Account": self.account_id or "",
            "Currency": self.currency,
            "Opening Cash": decimal_to_str(self.opening_balance) or "",
            "Deposits": decimal_to_str(self.deposits) or "",
            "Sale Proceeds": decimal_to_str(self.sale_proceeds) or "",
            "Dividends": decimal_to_str(self.dividends) or "",
            "Interest": decimal_to_str(self.interest) or "",
            "Other Credits": decimal_to_str(self.other_credits) or "",
            "Purchases": decimal_to_str(self.purchases) or "",
            "Fees": decimal_to_str(self.fees) or "",
            "Withdrawals": decimal_to_str(self.withdrawals) or "",
            "Taxes Withheld": decimal_to_str(self.taxes) or "",
            "Other Debits": decimal_to_str(self.other_debits) or "",
            "Computed Closing Cash": decimal_to_str(self.computed_closing) or "",
            "Broker Closing Cash": decimal_to_str(self.broker_closing) or "",
            "Difference": decimal_to_str(self.difference) if self.difference is not None else "",
        }


def reconcile_cash(
    transactions: Sequence[NormalizedTransaction],
    *,
    account_id: str | None,
    currency: str,
    opening_balance: Decimal = ZERO,
    broker_closing: Decimal | None = None,
) -> CashReconciliation:
    """Build the cash reconciliation for one account and currency."""
    buckets: dict[str, list[Decimal]] = defaultdict(list)

    for transaction in transactions:
        if transaction.currency != currency:
            continue
        if account_id is not None and transaction.account_id != account_id:
            continue
        kind = transaction.transaction_type
        magnitude = abs(transaction.cash_delta_native)
        if magnitude == 0 and kind is not TransactionType.DEPOSIT:
            continue

        if kind is TransactionType.DEPOSIT:
            buckets["deposits"].append(magnitude)
        elif kind is TransactionType.WITHDRAWAL:
            buckets["withdrawals"].append(magnitude)
        elif kind in (TransactionType.BUY, TransactionType.ESPP_PURCHASE):
            buckets["purchases"].append(magnitude)
        elif kind in (TransactionType.SELL, TransactionType.RSU_SALE):
            buckets["sale_proceeds"].append(magnitude)
        elif kind is TransactionType.DIVIDEND:
            # A dividend row's cash effect is gross less any withholding
            # embedded in the same row; the gross figure is reported separately.
            buckets["dividends"].append(magnitude)
        elif kind is TransactionType.INTEREST:
            buckets["interest"].append(magnitude)
        elif kind is TransactionType.FEE:
            buckets["fees"].append(magnitude)
        elif kind in (TransactionType.TAX, TransactionType.WITHHOLDING_TAX):
            buckets["taxes"].append(magnitude)
        elif transaction.behaviour.ledger in (Ledger.CASH, Ledger.BOTH):
            key = "other_credits" if transaction.behaviour.cash_sign > 0 else "other_debits"
            buckets[key].append(magnitude)

    def total(key: str) -> Decimal:
        return as_amount(add(*buckets[key])) if buckets[key] else ZERO

    deposits = total("deposits")
    withdrawals = total("withdrawals")
    purchases = total("purchases")
    sale_proceeds = total("sale_proceeds")
    dividends = total("dividends")
    interest = total("interest")
    fees = total("fees")
    taxes = total("taxes")
    other_credits = total("other_credits")
    other_debits = total("other_debits")

    computed_closing = as_amount(
        add(
            opening_balance,
            deposits,
            sale_proceeds,
            dividends,
            interest,
            other_credits,
            -purchases,
            -fees,
            -withdrawals,
            -taxes,
            -other_debits,
        )
    )

    return CashReconciliation(
        account_id=account_id,
        currency=currency,
        opening_balance=as_amount(opening_balance),
        deposits=deposits,
        withdrawals=withdrawals,
        purchases=purchases,
        sale_proceeds=sale_proceeds,
        dividends=dividends,
        interest=interest,
        fees=fees,
        taxes=taxes,
        other_credits=other_credits,
        other_debits=other_debits,
        computed_closing=computed_closing,
        broker_closing=as_amount(broker_closing) if broker_closing is not None else None,
    )
