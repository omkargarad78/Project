"""The canonical, broker-independent transaction ledger.

Two record types exist side by side and both are retained forever:

``RawTransactionRow``
    The broker's row exactly as it was read, as ordered column-name to
    original-text pairs. No coercion, no cleanup, no dropped columns.

``NormalizedTransaction``
    The canonical interpretation of that row, pointing back at it by
    ``source_file_id`` / ``source_sheet`` / ``source_row``.

Sign convention
---------------
``quantity``, ``gross_amount_native``, ``fees_native`` and ``taxes_native`` are
always non-negative magnitudes. Direction is carried by
``transaction_type`` alone. Brokers disagree about whether a sale is a negative
quantity, a negative amount, both or neither, so a magnitude-plus-type model is
the only representation that survives adding a second broker.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from enum import StrEnum
from types import MappingProxyType

from ..core.hashing import fingerprint, hash_payload
from ..core.money import ZERO, decimal_to_str


class TransactionType(StrEnum):
    """Canonical transaction types.

    The domain model supports every type listed here from day one. A given
    broker parser only emits the subset its export actually contains; the
    remainder exist so that adding a broker, or a new statement section, never
    requires a schema migration.
    """

    BUY = "BUY"
    SELL = "SELL"
    DIVIDEND = "DIVIDEND"
    INTEREST = "INTEREST"
    WITHHOLDING_TAX = "WITHHOLDING_TAX"
    DEPOSIT = "DEPOSIT"
    WITHDRAWAL = "WITHDRAWAL"
    FEE = "FEE"
    TAX = "TAX"
    STOCK_SPLIT = "STOCK_SPLIT"
    STOCK_MERGER = "STOCK_MERGER"
    SPINOFF = "SPINOFF"
    TRANSFER_IN = "TRANSFER_IN"
    TRANSFER_OUT = "TRANSFER_OUT"
    RSU_VEST = "RSU_VEST"
    RSU_SALE = "RSU_SALE"
    ESPP_PURCHASE = "ESPP_PURCHASE"
    OPTION_EVENT = "OPTION_EVENT"
    UNKNOWN = "UNKNOWN"


class Ledger(StrEnum):
    """Which sub-ledger a transaction belongs to.

    The brokerage cash account and the underlying foreign securities are
    separate reportable things: the account maps to Schedule FA Table A2 and the
    securities to Table A3. Keeping the sub-ledger on the transaction is what
    prevents a share purchase from being counted both as a security holding and
    as brokerage cash.
    """

    CASH = "CASH"
    SECURITIES = "SECURITIES"
    BOTH = "BOTH"
    NONE = "NONE"


@dataclass(frozen=True, slots=True)
class TypeBehaviour:
    """Static semantics of a :class:`TransactionType`."""

    ledger: Ledger
    #: +1 increases the share position, -1 decreases it, 0 leaves it unchanged.
    quantity_sign: int
    #: +1 is a cash credit to the account, -1 a debit, 0 no cash movement.
    cash_sign: int
    is_acquisition: bool = False
    is_disposal: bool = False
    is_income: bool = False
    is_corporate_action: bool = False
    #: True when the type is attributable to a specific security holding.
    security_scoped: bool = False


_B = TypeBehaviour

TYPE_BEHAVIOUR: Mapping[TransactionType, TypeBehaviour] = MappingProxyType(
    {
        TransactionType.BUY: _B(Ledger.BOTH, +1, -1, is_acquisition=True, security_scoped=True),
        TransactionType.SELL: _B(Ledger.BOTH, -1, +1, is_disposal=True, security_scoped=True),
        TransactionType.DIVIDEND: _B(Ledger.CASH, 0, +1, is_income=True, security_scoped=True),
        TransactionType.INTEREST: _B(Ledger.CASH, 0, +1, is_income=True),
        # Foreign tax withheld at source is a debit recorded separately from the
        # gross dividend so that gross income and foreign tax stay distinguishable.
        TransactionType.WITHHOLDING_TAX: _B(Ledger.CASH, 0, -1, security_scoped=True),
        # A deposit funds the cash account. It is not the acquisition of a security.
        TransactionType.DEPOSIT: _B(Ledger.CASH, 0, +1),
        TransactionType.WITHDRAWAL: _B(Ledger.CASH, 0, -1),
        TransactionType.FEE: _B(Ledger.CASH, 0, -1),
        TransactionType.TAX: _B(Ledger.CASH, 0, -1),
        TransactionType.STOCK_SPLIT: _B(
            Ledger.SECURITIES, 0, 0, is_corporate_action=True, security_scoped=True
        ),
        TransactionType.STOCK_MERGER: _B(
            Ledger.SECURITIES, 0, 0, is_corporate_action=True, security_scoped=True
        ),
        TransactionType.SPINOFF: _B(
            Ledger.SECURITIES, 0, 0, is_corporate_action=True, security_scoped=True
        ),
        TransactionType.TRANSFER_IN: _B(
            Ledger.SECURITIES, +1, 0, is_acquisition=True, security_scoped=True
        ),
        TransactionType.TRANSFER_OUT: _B(
            Ledger.SECURITIES, -1, 0, is_disposal=True, security_scoped=True
        ),
        TransactionType.RSU_VEST: _B(
            Ledger.SECURITIES, +1, 0, is_acquisition=True, security_scoped=True
        ),
        TransactionType.RSU_SALE: _B(Ledger.BOTH, -1, +1, is_disposal=True, security_scoped=True),
        TransactionType.ESPP_PURCHASE: _B(
            Ledger.BOTH, +1, -1, is_acquisition=True, security_scoped=True
        ),
        TransactionType.OPTION_EVENT: _B(Ledger.NONE, 0, 0, security_scoped=True),
        # UNKNOWN deliberately affects nothing. It is preserved, flagged and
        # excluded from calculations rather than guessed at.
        TransactionType.UNKNOWN: _B(Ledger.NONE, 0, 0),
    }
)


def behaviour(transaction_type: TransactionType) -> TypeBehaviour:
    """Return the static semantics for ``transaction_type``."""
    return TYPE_BEHAVIOUR[transaction_type]


@dataclass(frozen=True, slots=True)
class RawTransactionRow:
    """A broker row preserved verbatim.

    ``values`` maps the header text found in the file to the cell's original
    text. Numeric cells keep their source digit string, so nothing is lost to
    binary floating point between the file and the ledger.
    """

    source_file_id: str
    source_sheet: str
    source_row: int
    values: Mapping[str, str | None]

    def __post_init__(self) -> None:
        object.__setattr__(self, "values", MappingProxyType(dict(self.values)))

    @property
    def raw_data_hash(self) -> str:
        """Hash of the verbatim row, used to prove the row was not altered."""
        return hash_payload(
            {
                "sheet": self.source_sheet,
                "row": self.source_row,
                "values": dict(self.values),
            }
        )

    @property
    def source_reference(self) -> str:
        """Human-readable pointer back into the source file."""
        return f"{self.source_sheet}!row{self.source_row}"


@dataclass(frozen=True, slots=True)
class NormalizedTransaction:
    """A canonical transaction, traceable to the exact source row."""

    # --- provenance ---------------------------------------------------------
    source_file_id: str
    source_sheet: str
    source_row: int
    raw_data_hash: str
    source_reference: str
    broker: str
    parser_version: str

    # --- identity -----------------------------------------------------------
    transaction_id: str
    #: The broker's own transaction identifier, when the export supplies one.
    broker_transaction_id: str | None

    # --- classification ----------------------------------------------------
    transaction_type: TransactionType
    #: The broker's original activity label, kept for audit and for mapping
    #: review when a broker introduces a new label.
    raw_activity: str | None

    # --- dates --------------------------------------------------------------
    transaction_date: date
    settlement_date: date | None

    # --- instrument ---------------------------------------------------------
    ticker: str | None
    security_name: str | None
    security_identifier: str | None

    # --- amounts (non-negative magnitudes) ---------------------------------
    currency: str
    quantity: Decimal | None = None
    price_native: Decimal | None = None
    gross_amount_native: Decimal | None = None
    fees_native: Decimal | None = None
    taxes_native: Decimal | None = None
    net_amount_native: Decimal | None = None

    # --- account ------------------------------------------------------------
    account_id: str | None = None

    # --- notes --------------------------------------------------------------
    description: str | None = None
    #: Set when the parser had to make a judgement call worth surfacing.
    parser_notes: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        for name in (
            "quantity",
            "price_native",
            "gross_amount_native",
            "fees_native",
            "taxes_native",
            "net_amount_native",
        ):
            value = getattr(self, name)
            if value is not None and value < 0:
                raise ValueError(
                    f"{name} must be a non-negative magnitude on a normalized "
                    f"transaction; direction is carried by transaction_type "
                    f"(got {value} for {self.transaction_type})"
                )
        if len(self.currency) != 3 or not self.currency.isupper():
            raise ValueError(f"currency must be a 3-letter ISO 4217 code, got {self.currency!r}")

    # --- derived semantics --------------------------------------------------

    @property
    def behaviour(self) -> TypeBehaviour:
        return behaviour(self.transaction_type)

    @property
    def signed_quantity(self) -> Decimal:
        """Quantity signed by the transaction's effect on the share position."""
        if self.quantity is None:
            return ZERO
        return self.quantity * self.behaviour.quantity_sign

    @property
    def cash_delta_native(self) -> Decimal:
        """Effect on the brokerage cash balance, in the native currency.

        Fees and taxes embedded in a trade row reduce the cash effect of that
        trade. A broker that reports fees as separate FEE rows must not also
        embed them here, which the cash reconciliation check verifies.
        """
        sign = self.behaviour.cash_sign
        if sign == 0:
            return ZERO
        gross = self.gross_amount_native if self.gross_amount_native is not None else ZERO
        fees = self.fees_native or ZERO
        taxes = self.taxes_native or ZERO
        if sign > 0:
            return gross - fees - taxes
        return -(gross + fees + taxes)

    @property
    def is_security_scoped(self) -> bool:
        return self.behaviour.security_scoped

    def duplicate_fingerprint(self) -> str:
        """Deterministic duplicate-detection fingerprint.

        Excludes the source file, sheet and row so that the same transaction
        appearing in two overlapping statements is detected. The broker's own
        transaction id is preferred when present and is checked separately.
        """
        return fingerprint(
            [
                self.broker,
                self.account_id,
                self.transaction_date,
                (self.ticker or "").upper(),
                self.transaction_type,
                decimal_to_str(self.quantity),
                decimal_to_str(self.price_native),
                decimal_to_str(self.gross_amount_native),
                decimal_to_str(self.net_amount_native),
                self.currency,
            ]
        )
