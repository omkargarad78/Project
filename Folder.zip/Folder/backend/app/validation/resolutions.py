"""Recording what a user decided about an issue, and re-applying it safely.

A calculation run is re-executed constantly: a corrected file is uploaded, a
rate dataset is imported, a policy is changed. Every re-run regenerates the
issue list from scratch, which is what makes the platform deterministic. It
also means every decision a user recorded is at risk of being lost or, worse,
of being re-applied when it should not be.

The distinction this module exists to enforce:

*Acknowledging* an issue is a judgement about a condition that is expected to
persist -- "yes, those two identical trades are both real". It should survive a
re-run, because the condition surviving is exactly what was accepted.

*Resolving* an issue is a claim that the underlying data has changed -- "I have
imported the missing rates". It must **not** survive a re-run, because if the
issue was generated again then the data evidently did not change. Carrying a
claimed resolution forward would hide a live problem behind a stale assertion,
which is the most dangerous failure mode this module could have.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from typing import Any

from .issues import IssueCollector, IssueStatus, ValidationIssue


class CarryOutcome(StrEnum):
    """What happened to a stored decision when a run regenerated its issue."""

    #: Re-applied unchanged.
    CARRIED = "CARRIED"
    #: Re-applied, but the issue's wording changed since the decision was made,
    #: so the user is asked to confirm it still applies.
    NEEDS_RECONFIRMATION = "NEEDS_RECONFIRMATION"
    #: A claimed fix that did not take: the issue came back.
    REOPENED = "REOPENED"
    #: The condition is gone, so the decision no longer applies to anything.
    OBSOLETE = "OBSOLETE"


@dataclass(frozen=True, slots=True)
class ResolutionRecord:
    """One recorded decision about one condition."""

    resolution_key: str
    status: IssueStatus
    note: str
    user: str
    at: datetime
    #: The issue as it was worded when the decision was made. Kept so that a
    #: re-run can tell whether the user is still accepting the same statement.
    issue_id: str
    message: str
    code: str
    subject: str

    def to_json(self) -> dict[str, Any]:
        return {
            "resolution_key": self.resolution_key,
            "status": str(self.status),
            "note": self.note,
            "user": self.user,
            "at": self.at.isoformat(),
            "issue_id": self.issue_id,
            "message": self.message,
            "code": self.code,
            "subject": self.subject,
        }

    @classmethod
    def from_json(cls, payload: Mapping[str, Any]) -> ResolutionRecord:
        return cls(
            resolution_key=str(payload["resolution_key"]),
            status=IssueStatus(payload["status"]),
            note=str(payload.get("note", "")),
            user=str(payload.get("user", "")),
            at=datetime.fromisoformat(str(payload["at"])),
            issue_id=str(payload.get("issue_id", "")),
            message=str(payload.get("message", "")),
            code=str(payload.get("code", "")),
            subject=str(payload.get("subject", "")),
        )


@dataclass(frozen=True, slots=True)
class CarryResult:
    """What became of one stored decision during a re-run."""

    record: ResolutionRecord
    outcome: CarryOutcome
    explanation: str

    @property
    def needs_user_attention(self) -> bool:
        return self.outcome in (
            CarryOutcome.NEEDS_RECONFIRMATION,
            CarryOutcome.REOPENED,
        )


class ResolutionStore:
    """Holds recorded decisions and re-applies them to a fresh issue list."""

    def __init__(self, records: Iterable[ResolutionRecord] = ()) -> None:
        self._records: dict[str, ResolutionRecord] = {
            record.resolution_key: record for record in records
        }

    def __len__(self) -> int:
        return len(self._records)

    def __iter__(self):  # noqa: ANN204 - Iterator[ResolutionRecord]
        return iter(sorted(self._records.values(), key=lambda r: (r.code, r.subject)))

    def get(self, resolution_key: str) -> ResolutionRecord | None:
        return self._records.get(resolution_key)

    # --- recording --------------------------------------------------------

    def acknowledge(
        self,
        item: ValidationIssue,
        *,
        note: str,
        user: str,
        at: datetime | None = None,
    ) -> ResolutionRecord:
        """Accept a condition as it stands.

        A note is required, not optional. An acknowledgement with no stated
        reason is indistinguishable from a mis-click a year later, and these
        are the records that explain why a figure looks the way it does.
        """
        if not note.strip():
            raise ValueError(
                "acknowledging an issue requires a reason: the note is what "
                "explains the decision to whoever reviews the filing later"
            )
        return self._record(item, IssueStatus.ACKNOWLEDGED, note, user, at)

    def mark_resolved(
        self,
        item: ValidationIssue,
        *,
        note: str,
        user: str,
        at: datetime | None = None,
    ) -> ResolutionRecord:
        """Record that the underlying data has been corrected.

        This claim is verified by the next run rather than trusted: if the
        issue is generated again, the claim is reopened.
        """
        if not note.strip():
            raise ValueError("recording a fix requires a note describing what changed")
        return self._record(item, IssueStatus.RESOLVED, note, user, at)

    def _record(
        self,
        item: ValidationIssue,
        status: IssueStatus,
        note: str,
        user: str,
        at: datetime | None,
    ) -> ResolutionRecord:
        record = ResolutionRecord(
            resolution_key=item.resolution_key,
            status=status,
            note=note.strip(),
            user=user,
            at=at or datetime.now(UTC),
            issue_id=item.issue_id,
            message=item.message,
            code=str(item.code),
            subject=item.subject,
        )
        self._records[record.resolution_key] = record
        return record

    def forget(self, resolution_key: str) -> None:
        self._records.pop(resolution_key, None)

    # --- re-applying ------------------------------------------------------

    def apply(self, issues: IssueCollector) -> list[CarryResult]:
        """Re-apply stored decisions to a freshly generated issue list.

        Mutates ``issues`` in place and returns an account of what happened to
        every stored decision, including the ones that were deliberately not
        applied.
        """
        live = {item.resolution_key: item for item in issues}
        results: list[CarryResult] = []
        updates: dict[str, ValidationIssue] = {}

        for key, record in self._records.items():
            item = live.get(key)
            if item is None:
                results.append(
                    CarryResult(
                        record,
                        CarryOutcome.OBSOLETE,
                        f"the condition on {record.subject} no longer occurs, so "
                        f"this decision no longer applies to anything",
                    )
                )
                continue

            if record.status is IssueStatus.RESOLVED:
                results.append(
                    CarryResult(
                        record,
                        CarryOutcome.REOPENED,
                        f"this was recorded as fixed on "
                        f"{record.at.date().isoformat()} ({record.note}), but the "
                        f"condition is still present in the current data, so it "
                        f"has been reopened rather than carried forward",
                    )
                )
                continue

            if record.message != item.message:
                updates[item.issue_id] = item.resolve(
                    status=IssueStatus.ACKNOWLEDGED,
                    note=record.note,
                    user=record.user,
                    at=record.at,
                )
                results.append(
                    CarryResult(
                        record,
                        CarryOutcome.NEEDS_RECONFIRMATION,
                        f"this was accepted when it read \u201c{record.message}\u201d "
                        f"and it now reads \u201c{item.message}\u201d. The "
                        f"acceptance has been kept, but confirm it still applies.",
                    )
                )
                continue

            updates[item.issue_id] = item.resolve(
                status=IssueStatus.ACKNOWLEDGED,
                note=record.note,
                user=record.user,
                at=record.at,
            )
            results.append(
                CarryResult(
                    record,
                    CarryOutcome.CARRIED,
                    f"accepted by {record.user} on "
                    f"{record.at.date().isoformat()}: {record.note}",
                )
            )

        issues.apply_resolutions(updates)
        return results

    # --- persistence ------------------------------------------------------

    def to_json(self) -> str:
        return json.dumps(
            {"resolutions": [r.to_json() for r in self]},
            indent=2,
            sort_keys=False,
        )

    @classmethod
    def from_json(cls, text: str) -> ResolutionStore:
        payload = json.loads(text)
        return cls(
            ResolutionRecord.from_json(entry)
            for entry in payload.get("resolutions", [])
        )

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.to_json(), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> ResolutionStore:
        if not path.exists():
            return cls()
        return cls.from_json(path.read_text(encoding="utf-8-sig"))


def carry_summary(results: Iterable[CarryResult]) -> str:
    items = list(results)
    if not items:
        return "no previously recorded decisions applied to this run"

    lines = [f"{len(items)} recorded decision(s) considered:"]
    for outcome in CarryOutcome:
        matching = [r for r in items if r.outcome is outcome]
        if not matching:
            continue
        lines.append(f"\n  {outcome} ({len(matching)}):")
        for result in matching:
            lines.append(f"    {result.record.code} {result.record.subject}")
            lines.append(f"      {result.explanation}")
    return "\n".join(lines)


def replace_status(item: ValidationIssue, status: IssueStatus) -> ValidationIssue:
    """Set a status without a note, for tests and internal transitions."""
    return replace(item, status=status)
