"""Validation issues and the issue collection carried through the pipeline.

An issue is the only way a stage reports a problem that should not abort the
whole run. Issues are deterministic: the same inputs produce the same issue
ids, so a re-run can be diffed against a previous one.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping, Sequence
from dataclasses import dataclass, field, replace
from datetime import datetime
from enum import StrEnum
from typing import Any

from ..core.errors import ErrorCode, ResolutionAction, Severity, definition
from ..core.hashing import derive_id


class IssueStatus(StrEnum):
    OPEN = "OPEN"
    #: The user reviewed the issue and supplied the missing data or correction.
    RESOLVED = "RESOLVED"
    #: The user reviewed the issue and accepted it as-is. Acknowledging an
    #: ERROR is recorded explicitly and still shows on the final report.
    ACKNOWLEDGED = "ACKNOWLEDGED"


class IssueScope(StrEnum):
    FILE = "FILE"
    TRANSACTION = "TRANSACTION"
    SECURITY = "SECURITY"
    LOT = "LOT"
    FX_RATE = "FX_RATE"
    MARKET_PRICE = "MARKET_PRICE"
    ACCOUNT = "ACCOUNT"
    CALCULATION = "CALCULATION"
    WORKSPACE = "WORKSPACE"


@dataclass(frozen=True, slots=True)
class ValidationIssue:
    """A single ERROR / WARNING / INFO condition with remediation guidance."""

    code: ErrorCode
    severity: Severity
    scope: IssueScope
    #: Identifier of the object the issue is about (ticker, lot id, date, ...).
    subject: str
    message: str
    #: Structured detail rendered into the validation report. Keys are stable.
    context: Mapping[str, Any] = field(default_factory=dict)
    status: IssueStatus = IssueStatus.OPEN
    resolution_note: str | None = None
    resolved_by: str | None = None
    resolved_at: datetime | None = None

    @property
    def issue_id(self) -> str:
        """Identity of this exact statement, message included.

        Two issues with the same code and subject but different wording are
        different issues, because the wording is what the user read when they
        decided what to do about it.
        """
        return derive_id("ISS", self.code, self.scope, self.subject, self.message)

    @property
    def resolution_key(self) -> str:
        """Identity of the *condition*, independent of how it is worded.

        Deliberately excludes the message. A re-run whose message differs only
        in a count would otherwise produce a new ``issue_id`` and silently
        orphan the decision the user already recorded. Keying decisions on the
        condition lets them be carried forward, and lets a changed message be
        surfaced for re-confirmation rather than ignored either way.
        """
        return derive_id("RES", self.code, self.scope, self.subject)

    @property
    def action(self) -> ResolutionAction:
        """What the user has to do about it."""
        return definition(self.code).action

    @property
    def is_waivable(self) -> bool:
        """Whether accepting this condition is enough to let a filing proceed."""
        return definition(self.code).waivable

    @property
    def title(self) -> str:
        return definition(self.code).title

    @property
    def explanation(self) -> str:
        return definition(self.code).explanation

    @property
    def remediation(self) -> str:
        return definition(self.code).remediation

    @property
    def is_blocking(self) -> bool:
        """True when this issue must stop final report generation.

        An acknowledged error only stops blocking when the catalogue says the
        condition is waivable. Otherwise acknowledgement would be a way to
        step around every guard rail with a checkbox, and the figure it
        guards still would not exist: accepting that no exchange rate is
        available does not produce a rupee amount.
        """
        if self.severity is not Severity.ERROR:
            return False
        if self.status is IssueStatus.RESOLVED:
            return False
        if self.status is IssueStatus.ACKNOWLEDGED:
            return not self.is_waivable
        return True

    def resolve(
        self,
        *,
        status: IssueStatus,
        note: str,
        user: str,
        at: datetime,
    ) -> ValidationIssue:
        return replace(
            self,
            status=status,
            resolution_note=note,
            resolved_by=user,
            resolved_at=at,
        )

    def to_row(self) -> dict[str, Any]:
        """Flatten for the Validation Report sheet."""
        return {
            "Issue ID": self.issue_id,
            "Severity": str(self.severity),
            "Error Code": str(self.code),
            "Scope": str(self.scope),
            "Subject": self.subject,
            "Title": self.title,
            "Message": self.message,
            "Explanation": self.explanation,
            "Remediation": self.remediation,
            "Status": str(self.status),
            "Resolution Note": self.resolution_note or "",
            "Resolved By": self.resolved_by or "",
            "Resolved At": self.resolved_at.isoformat() if self.resolved_at else "",
        }


def issue(
    code: ErrorCode,
    *,
    scope: IssueScope,
    subject: str,
    message: str,
    severity: Severity | None = None,
    **context: Any,
) -> ValidationIssue:
    """Build an issue, defaulting severity from the error catalogue.

    Severity is overridable because the same condition can be blocking in one
    stage and informational in another: an unmapped transaction type is a
    warning when it moves no cash, and an error when it changes a holding.
    """
    return ValidationIssue(
        code=code,
        severity=severity or definition(code).default_severity,
        scope=scope,
        subject=subject,
        message=message,
        context=context,
    )


class IssueCollector:
    """Accumulates issues across pipeline stages, de-duplicated by issue id."""

    def __init__(self, issues: Iterable[ValidationIssue] = ()) -> None:
        self._issues: dict[str, ValidationIssue] = {}
        self.extend(issues)

    def add(self, item: ValidationIssue) -> ValidationIssue:
        existing = self._issues.get(item.issue_id)
        # Keep the resolved form if one stage already carries a resolution, so
        # a re-run does not silently reopen something the user has answered.
        if existing is not None and existing.status is not IssueStatus.OPEN:
            return existing
        self._issues[item.issue_id] = item
        return item

    def report(
        self,
        code: ErrorCode,
        *,
        scope: IssueScope,
        subject: str,
        message: str,
        severity: Severity | None = None,
        **context: Any,
    ) -> ValidationIssue:
        return self.add(
            issue(
                code,
                scope=scope,
                subject=subject,
                message=message,
                severity=severity,
                **context,
            )
        )

    def extend(self, items: Iterable[ValidationIssue]) -> None:
        for item in items:
            self.add(item)

    def apply_resolutions(self, resolutions: Mapping[str, ValidationIssue]) -> None:
        """Re-apply stored user resolutions to freshly generated issues."""
        for issue_id, resolved in resolutions.items():
            current = self._issues.get(issue_id)
            if current is not None:
                self._issues[issue_id] = replace(
                    current,
                    status=resolved.status,
                    resolution_note=resolved.resolution_note,
                    resolved_by=resolved.resolved_by,
                    resolved_at=resolved.resolved_at,
                )

    # --- querying -----------------------------------------------------------

    def __iter__(self) -> Iterator[ValidationIssue]:
        return iter(self.sorted())

    def __len__(self) -> int:
        return len(self._issues)

    def sorted(self) -> list[ValidationIssue]:
        order = {Severity.ERROR: 0, Severity.WARNING: 1, Severity.INFO: 2}
        return sorted(
            self._issues.values(),
            key=lambda i: (order[i.severity], str(i.code), i.scope, i.subject),
        )

    def by_severity(self, severity: Severity) -> list[ValidationIssue]:
        return [i for i in self.sorted() if i.severity is severity]

    def by_code(self, code: ErrorCode) -> list[ValidationIssue]:
        return [i for i in self.sorted() if i.code is code]

    def by_subject(self, subject: str) -> list[ValidationIssue]:
        return [i for i in self.sorted() if i.subject == subject]

    def has(self, code: ErrorCode) -> bool:
        return any(i.code is code for i in self._issues.values())

    @property
    def errors(self) -> list[ValidationIssue]:
        return self.by_severity(Severity.ERROR)

    @property
    def warnings(self) -> list[ValidationIssue]:
        return self.by_severity(Severity.WARNING)

    @property
    def infos(self) -> list[ValidationIssue]:
        return self.by_severity(Severity.INFO)

    @property
    def blocking(self) -> list[ValidationIssue]:
        return [i for i in self.sorted() if i.is_blocking]

    @property
    def is_blocked(self) -> bool:
        return bool(self.blocking)

    def counts(self) -> dict[str, int]:
        return {
            "ERROR": len(self.errors),
            "WARNING": len(self.warnings),
            "INFO": len(self.infos),
            "BLOCKING": len(self.blocking),
        }

    def to_rows(self) -> list[dict[str, Any]]:
        return [i.to_row() for i in self.sorted()]

    def merge(self, other: IssueCollector | Sequence[ValidationIssue]) -> None:
        self.extend(other)
