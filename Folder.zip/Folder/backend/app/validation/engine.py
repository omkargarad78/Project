"""Turning scattered issues into one ranked worklist and a filing verdict.

Each pipeline stage reports what it found where it found it, which is right for
the stage and useless for the user. A real file produces hundreds of issues,
most of them the same problem seen from different rows: two hundred
missing-rate messages are one trip to import a rate dataset, not two hundred
tasks. Presented as a flat list they misrepresent the effort and bury the five
things that actually need a decision.

So this module does three things the raw list cannot:

* groups issues by the **action** that clears them, because the unit of work
  is the action rather than the issue;
* orders the groups by what they unblock, not by severity alone -- a warning
  standing between the user and four reportable holdings matters more than an
  error on a holding that has other unfixable problems anyway;
* states plainly whether the result can be filed, and if not, exactly what
  remains.

It also enforces one safety property that nothing else can: every field the
Schedule FA report could not fill must have an issue explaining why. A missing
figure with no corresponding issue would be invisible in the worklist -- the
user would see a gap in the form and find nothing telling them how to close
it. Where that happens, this module raises the issue itself.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING

from ..core.errors import ErrorCode, ResolutionAction, Severity, definition
from .issues import IssueCollector, IssueScope, IssueStatus, ValidationIssue

if TYPE_CHECKING:  # pragma: no cover
    # Imported for typing only. Every stage depends on ``validation.issues``,
    # so validation has to sit *below* the calculation stages in the import
    # graph; importing the Schedule FA report at runtime would invert that and
    # form a cycle. The engine reads the report structurally instead.
    from ..schedulefa.models import ScheduleFaReport


class FilingReadiness(StrEnum):
    """Whether the run's output can be used to file."""

    #: Every figure computed from confirmed rules and complete data.
    READY = "READY"
    #: Every figure computed, but qualifications are attached that a person
    #: must read and accept before filing.
    READY_WITH_QUALIFICATIONS = "READY_WITH_QUALIFICATIONS"
    #: At least one required figure or field does not exist.
    BLOCKED = "BLOCKED"

    @property
    def label(self) -> str:
        return {
            FilingReadiness.READY: "Ready to file",
            FilingReadiness.READY_WITH_QUALIFICATIONS: (
                "Complete, with qualifications that need review"
            ),
            FilingReadiness.BLOCKED: "Not ready to file",
        }[self]


@dataclass(frozen=True, slots=True)
class IssueGroup:
    """Issues sharing one condition, clearable by one action."""

    code: ErrorCode
    action: ResolutionAction
    severity: Severity
    issues: tuple[ValidationIssue, ...]
    #: Reported figures this group stands in the way of, as
    #: ``"NVDA: peak value"``. Empty when the group affects nothing reportable.
    affected_figures: tuple[str, ...] = ()

    @property
    def title(self) -> str:
        return definition(self.code).title

    @property
    def remediation(self) -> str:
        return definition(self.code).remediation

    @property
    def explanation(self) -> str:
        return definition(self.code).explanation

    @property
    def count(self) -> int:
        return len(self.issues)

    @property
    def subjects(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys(item.subject for item in self.issues))

    @property
    def open_issues(self) -> tuple[ValidationIssue, ...]:
        return tuple(i for i in self.issues if i.status is IssueStatus.OPEN)

    @property
    def blocking_issues(self) -> tuple[ValidationIssue, ...]:
        return tuple(i for i in self.issues if i.is_blocking)

    @property
    def is_blocking(self) -> bool:
        return bool(self.blocking_issues)

    @property
    def is_waivable(self) -> bool:
        return definition(self.code).waivable

    @property
    def is_settled(self) -> bool:
        """Every issue in the group has a recorded decision."""
        return not self.open_issues

    def headline(self) -> str:
        """One line naming the work, the scale and what it unblocks."""
        scale = (
            f"{self.count} occurrence(s) across {len(self.subjects)} subject(s)"
            if self.count > 1
            else f"{self.subjects[0] if self.subjects else 'one subject'}"
        )
        unblocks = (
            f" - blocks {len(self.affected_figures)} reported figure(s)"
            if self.affected_figures
            else ""
        )
        return f"[{self.severity}] {self.title}: {scale}{unblocks}"

    def describe(self) -> str:
        lines = [
            self.headline(),
            f"  what to do: {self.action.label}",
            f"  {self.remediation}",
        ]
        if not self.is_waivable and self.severity is Severity.ERROR:
            lines.append(
                "  this cannot be accepted and filed around: the figure does not "
                "exist until the data is supplied"
            )
        if self.affected_figures:
            shown = ", ".join(self.affected_figures[:6])
            more = (
                f", and {len(self.affected_figures) - 6} more"
                if len(self.affected_figures) > 6
                else ""
            )
            lines.append(f"  affects: {shown}{more}")
        for item in self.issues[:3]:
            lines.append(f"  e.g. {item.subject}: {item.message}")
        if self.count > 3:
            lines.append(f"  ... and {self.count - 3} more of the same")
        settled = [i for i in self.issues if i.status is not IssueStatus.OPEN]
        if settled:
            lines.append(
                f"  {len(settled)} of these already has a recorded decision"
            )
        return "\n".join(lines)


@dataclass(slots=True)
class ValidationReport:
    """The worklist, the verdict, and why."""

    readiness: FilingReadiness
    groups: list[IssueGroup] = field(default_factory=list)
    #: Reasons the run is blocked, in the order they should be addressed.
    blocking_reasons: list[str] = field(default_factory=list)
    #: Qualifications a person must read before filing even when nothing blocks.
    qualifications: list[str] = field(default_factory=list)
    counts: dict[str, int] = field(default_factory=dict)
    #: Figures with no figure and no issue explaining the absence. Should
    #: always be empty; kept as evidence that the check ran.
    unexplained_gaps: list[str] = field(default_factory=list)

    @property
    def is_filable(self) -> bool:
        return self.readiness is not FilingReadiness.BLOCKED

    @property
    def blocking_groups(self) -> list[IssueGroup]:
        return [g for g in self.groups if g.is_blocking]

    def by_action(self) -> dict[ResolutionAction, list[IssueGroup]]:
        """Groups clustered by the action that clears them, in worklist order."""
        clustered: dict[ResolutionAction, list[IssueGroup]] = {}
        for group in self.groups:
            clustered.setdefault(group.action, []).append(group)
        return clustered

    def next_action(self) -> IssueGroup | None:
        """The single most valuable thing to do next."""
        return self.groups[0] if self.groups else None

    def summary(self) -> str:
        lines = [
            f"=== {self.readiness.label} ===",
            f"errors={self.counts.get('ERROR', 0)} "
            f"warnings={self.counts.get('WARNING', 0)} "
            f"info={self.counts.get('INFO', 0)} "
            f"blocking={self.counts.get('BLOCKING', 0)}",
        ]

        if self.blocking_reasons:
            lines.append("\nwhat stops this being filed:")
            for index, reason in enumerate(self.blocking_reasons, start=1):
                lines.append(f"  {index}. {reason}")

        if self.qualifications:
            lines.append("\nqualifications to read before filing:")
            for note in self.qualifications:
                lines.append(f"  - {note}")

        if self.groups:
            lines.append("\n=== worklist, most valuable first ===")
            for index, group in enumerate(self.groups, start=1):
                lines.append(f"\n{index}. {group.describe()}")

        if self.unexplained_gaps:
            lines.append("\nfigures missing with no issue raised (a platform bug):")
            for gap in self.unexplained_gaps:
                lines.append(f"  {gap}")

        return "\n".join(lines)


class ValidationEngine:
    """Assembles the worklist and decides whether a run can be filed."""

    def assess(
        self,
        issues: IssueCollector,
        report: ScheduleFaReport | None = None,
    ) -> ValidationReport:
        if report is not None:
            self._raise_issues_for_unexplained_gaps(issues, report)

        affected = self._affected_figures(issues, report)
        groups = self._build_groups(issues, affected)

        result = ValidationReport(
            readiness=FilingReadiness.BLOCKED,
            groups=groups,
            counts=issues.counts(),
        )
        result.blocking_reasons = self._blocking_reasons(groups, report)
        result.qualifications = self._qualifications(issues, report)
        result.readiness = self._readiness(result, report)
        if report is not None:
            result.unexplained_gaps = self._remaining_gaps(issues, report)
        return result

    # --- gaps -------------------------------------------------------------

    def _missing_field_entries(
        self, report: ScheduleFaReport
    ) -> list[tuple[str, str, str]]:
        """Every field the report could not fill, as (subject, field, label)."""
        entries: list[tuple[str, str, str]] = []
        for row in report.table_a3:
            for item in row.fields():
                if not item.available:
                    entries.append((row.subject, item.field_name, item.label))
        for row in report.table_a2:
            for item in row.fields():
                if not item.available:
                    entries.append((row.subject, item.field_name, item.label))
        return entries

    def _raise_issues_for_unexplained_gaps(
        self, issues: IssueCollector, report: ScheduleFaReport
    ) -> None:
        """Ensure no unfillable field is missing from the worklist.

        A gap in the form with no issue behind it is the worst outcome
        available: the user sees a blank box and has nothing telling them how
        to fill it. Any stage that leaves a field empty is supposed to report
        why; where one did not, the omission is reported here so the field at
        least appears in the worklist.
        """
        explained = {item.subject for item in issues}
        for subject, field_name, label in self._missing_field_entries(report):
            if subject in explained:
                continue
            if field_name in _ACCOUNT_FIELDS:
                issues.report(
                    ErrorCode.ACCOUNT_DETAILS_MISSING,
                    scope=IssueScope.ACCOUNT,
                    subject=subject,
                    message=(
                        f"{label} is required by Schedule FA Table A2 and is not "
                        f"available. A transaction export does not contain it."
                    ),
                    field=field_name,
                )
                continue
            issues.report(
                ErrorCode.CALCULATION_INCOMPLETE,
                scope=IssueScope.CALCULATION,
                subject=subject,
                message=(
                    f"{label} could not be produced for {subject}, and no stage "
                    f"reported why. This is a gap in the platform's own "
                    f"reporting, not a judgement about your data."
                ),
                field=field_name,
            )

    def _remaining_gaps(
        self, issues: IssueCollector, report: ScheduleFaReport
    ) -> list[str]:
        subjects = {item.subject for item in issues}
        return [
            f"{subject}: {label}"
            for subject, _field, label in self._missing_field_entries(report)
            if subject not in subjects
        ]

    # --- impact -----------------------------------------------------------

    def _affected_figures(
        self, issues: IssueCollector, report: ScheduleFaReport | None
    ) -> dict[ErrorCode, tuple[str, ...]]:
        """Which reported figures each condition stands in the way of.

        An issue that names the fields it concerns (in its ``fields`` context)
        is matched to exactly those; anything else is matched to every
        unfillable field of its subject, which is the most that can be said
        about it. The narrowing matters: two conditions on the same account
        would otherwise both claim all of that account's blanks, and a user
        following the worklist would fix one and find the list unchanged.
        """
        if report is None:
            return {}

        by_subject: dict[str, list[tuple[str, str]]] = defaultdict(list)
        for subject, field_name, label in self._missing_field_entries(report):
            by_subject[subject].append((field_name, label))

        affected: dict[ErrorCode, list[str]] = defaultdict(list)
        for item in issues:
            declared = _declared_fields(item)
            for field_name, label in by_subject.get(item.subject, ()):
                if declared is not None and field_name not in declared:
                    continue
                entry = f"{item.subject}: {label}"
                if entry not in affected[item.code]:
                    affected[item.code].append(entry)
        return {code: tuple(labels) for code, labels in affected.items()}

    # --- grouping ---------------------------------------------------------

    def _build_groups(
        self,
        issues: IssueCollector,
        affected: dict[ErrorCode, tuple[str, ...]],
    ) -> list[IssueGroup]:
        buckets: dict[ErrorCode, list[ValidationIssue]] = defaultdict(list)
        for item in issues:
            buckets[item.code].append(item)

        groups = [
            IssueGroup(
                code=code,
                action=definition(code).action,
                severity=members[0].severity,
                issues=tuple(members),
                affected_figures=affected.get(code, ()),
            )
            for code, members in buckets.items()
        ]
        return sorted(groups, key=_worklist_order)

    # --- verdict ----------------------------------------------------------

    def _blocking_reasons(
        self, groups: list[IssueGroup], report: ScheduleFaReport | None
    ) -> list[str]:
        reasons: list[str] = []
        if report is not None:
            reasons.extend(report.blocking_reasons)

        for group in groups:
            if not group.is_blocking:
                continue
            subjects = ", ".join(group.subjects[:5])
            more = (
                f" and {len(group.subjects) - 5} more"
                if len(group.subjects) > 5
                else ""
            )
            reasons.append(
                f"{group.title} ({subjects}{more}). {group.action.label}."
            )
        return reasons

    def _qualifications(
        self, issues: IssueCollector, report: ScheduleFaReport | None
    ) -> list[str]:
        notes: list[str] = []
        if report is not None and not report.rule_verified:
            notes.append(
                f"the tax rules used for assessment year {report.assessment_year} "
                f"({report.rule_version}) have not been verified against the "
                f"published form. Every figure is labelled accordingly."
            )
        # Grouped, not listed. One condition seen on two hundred dates is one
        # thing to know about; printed two hundred times it hides the rest.
        open_warnings: dict[ErrorCode, list[ValidationIssue]] = defaultdict(list)
        for item in issues.warnings:
            if item.status is IssueStatus.OPEN:
                open_warnings[item.code].append(item)
        for code, members in open_warnings.items():
            subjects = tuple(dict.fromkeys(m.subject for m in members))
            if len(subjects) == 1:
                notes.append(f"{definition(code).title} ({subjects[0]})")
            else:
                shown = ", ".join(subjects[:3])
                notes.append(
                    f"{definition(code).title} - {len(members)} occurrence(s) "
                    f"across {len(subjects)} subject(s), e.g. {shown}"
                )
        if report is not None:
            # The same caveat on four holdings is one thing to read, not four.
            by_caveat: dict[str, list[str]] = {}
            for row in report.table_a3:
                for caveat in row.all_caveats():
                    by_caveat.setdefault(caveat, []).append(row.symbol)
            for caveat, symbols in by_caveat.items():
                notes.append(f"{', '.join(symbols)}: {caveat}")
        return notes

    def _readiness(
        self, result: ValidationReport, report: ScheduleFaReport | None
    ) -> FilingReadiness:
        if result.blocking_reasons:
            return FilingReadiness.BLOCKED
        if report is not None and not report.is_filable:
            return FilingReadiness.BLOCKED
        if result.qualifications:
            return FilingReadiness.READY_WITH_QUALIFICATIONS
        return FilingReadiness.READY


_ACCOUNT_FIELDS = frozenset(
    {"account_number", "account_status", "account_opening_date"}
)

_SEVERITY_ORDER = {Severity.ERROR: 0, Severity.WARNING: 1, Severity.INFO: 2}


def _declared_fields(item: ValidationIssue) -> frozenset[str] | None:
    """The form fields an issue says it is about, if it says."""
    declared = item.context.get("fields")
    if not declared:
        return None
    if isinstance(declared, str):
        return frozenset(part.strip() for part in declared.split(",") if part.strip())
    return frozenset(str(part) for part in declared)


def _worklist_order(group: IssueGroup) -> tuple:
    """Order the worklist by what a user gets for the effort.

    Blocking work first, because nothing else can be filed until it is done.
    Within that, the groups standing in the way of the most reported figures
    come first: a warning between the user and four holdings is worth more of
    their attention than an error on one holding. Settled groups sink, since
    they need no work. Severity breaks the remaining ties.
    """
    return (
        0 if group.is_blocking else 1,
        1 if group.is_settled else 0,
        -len(group.affected_figures),
        _SEVERITY_ORDER[group.severity],
        -group.count,
        str(group.code),
    )
