"""Content-addressed blob storage.

Uploaded statements and generated workpapers are written under a key derived
from their content hash, so the same bytes are stored once and a key can be
verified against what it claims to hold.

The interface is deliberately narrow — put, get, delete, exists — so that
swapping the local backend for S3 later is a new implementation rather than a
change to every caller.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from ..core.config import Settings, get_settings
from ..core.hashing import hash_bytes


class StorageError(RuntimeError):
    """Raised when a blob cannot be written or read."""


def storage_key(prefix: str, content_hash: str, *, suffix: str = "") -> str:
    """Build a key from a content hash.

    Fanned out over two characters so a directory listing stays usable after
    a few hundred thousand objects, which is a filesystem concern the S3
    backend will simply ignore.
    """
    digest = content_hash.split(":", 1)[-1]
    if len(digest) < 4:
        raise StorageError(f"implausible content hash {content_hash!r}")
    return f"{prefix}/{digest[:2]}/{digest[2:4]}/{digest}{suffix}"


class BlobStore(ABC):
    @abstractmethod
    def put(self, key: str, content: bytes) -> str: ...

    @abstractmethod
    def get(self, key: str) -> bytes: ...

    @abstractmethod
    def exists(self, key: str) -> bool: ...

    @abstractmethod
    def delete(self, key: str) -> None: ...


class LocalBlobStore(BlobStore):
    """Files under a configured root, with the root enforced."""

    def __init__(self, root: Path | None = None, settings: Settings | None = None) -> None:
        settings = settings or get_settings()
        self.root = Path(root or settings.storage_root).resolve()

    def _path(self, key: str) -> Path:
        # Keys are generated internally today, but they arrive from the
        # database and a corrupted or crafted one must not be able to write
        # outside the root. Checked against the resolved path rather than by
        # scanning the key for "..", which misses symlinks and absolute keys.
        candidate = (self.root / key).resolve()
        if not candidate.is_relative_to(self.root):
            raise StorageError(f"storage key escapes the storage root: {key!r}")
        return candidate

    def put(self, key: str, content: bytes) -> str:
        path = self._path(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        # Written to a temporary name and moved into place so that a crash
        # mid-write cannot leave a truncated file under a key that claims a
        # particular content hash.
        temporary = path.with_suffix(path.suffix + ".partial")
        temporary.write_bytes(content)
        temporary.replace(path)
        return key

    def get(self, key: str) -> bytes:
        path = self._path(key)
        if not path.exists():
            raise StorageError(f"no stored object for key {key!r}")
        return path.read_bytes()

    def exists(self, key: str) -> bool:
        return self._path(key).exists()

    def delete(self, key: str) -> None:
        self._path(key).unlink(missing_ok=True)


def put_content(
    store: BlobStore, prefix: str, content: bytes, *, suffix: str = ""
) -> tuple[str, str]:
    """Store bytes under their own hash. Returns ``(key, content_hash)``."""
    digest = hash_bytes(content)
    key = storage_key(prefix, digest, suffix=suffix)
    if not store.exists(key):
        store.put(key, content)
    return key, digest


def get_verified(store: BlobStore, key: str, expected_hash: str) -> bytes:
    """Read a blob and confirm it is what the database says it is.

    Cheap, and the alternative is serving a silently corrupted workpaper as
    though it were the filed one.
    """
    content = store.get(key)
    actual = hash_bytes(content)
    if actual != expected_hash:
        raise StorageError(
            f"stored object {key!r} does not match its recorded hash: "
            f"expected {expected_hash}, found {actual}"
        )
    return content


def get_store(settings: Settings | None = None) -> BlobStore:
    settings = settings or get_settings()
    if settings.storage_backend != "local":
        raise StorageError(
            f"storage backend {settings.storage_backend!r} is not implemented; "
            f"only 'local' is available"
        )
    return LocalBlobStore(settings=settings)
