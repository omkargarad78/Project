"""Alembic environment.

The URL comes from the application settings rather than ``alembic.ini``, so
there is one place a connection string is configured and no chance of a
migration running against a different database from the app.
"""

from __future__ import annotations

from alembic import context
from sqlalchemy import pool

from backend.app.core.config import get_settings
from backend.app.db.base import Base
from backend.app.db.session import build_engine

# Imported for the side effect of registering every table on the metadata.
# Without it autogenerate sees an empty schema and writes a migration that
# drops everything.
import backend.app.db.models  # noqa: F401

config = context.config
target_metadata = Base.metadata


def run_migrations_offline() -> None:
    context.configure(
        url=get_settings().database_url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        # Needed on SQLite, where most ALTERs are unsupported and Alembic has
        # to rebuild the table instead.
        render_as_batch=True,
        compare_type=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    engine = build_engine(get_settings())
    with engine.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            render_as_batch=connection.dialect.name == "sqlite",
            compare_type=True,
            poolclass=pool.NullPool,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
