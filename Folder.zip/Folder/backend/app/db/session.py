"""Engine and session construction.

SQLite is the local default so the platform runs with no services to install;
PostgreSQL is the deployment target. The two differ in ways that bite, so the
differences are handled here rather than in every call site: SQLite needs
foreign keys switched on explicitly, and its default isolation leaves
transactions open in a way that silently loses writes under a web server.
"""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from functools import lru_cache
from pathlib import Path

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from ..core.config import Settings, get_settings
from .base import Base


def _prepare_sqlite(url: str) -> None:
    """Make sure the directory for a file-backed SQLite database exists."""
    prefix = "sqlite+pysqlite:///"
    if not url.startswith(prefix) or url.endswith(":memory:"):
        return
    Path(url[len(prefix) :]).parent.mkdir(parents=True, exist_ok=True)


def build_engine(settings: Settings | None = None) -> Engine:
    settings = settings or get_settings()
    url = settings.database_url
    _prepare_sqlite(url)

    kwargs: dict = {"echo": settings.database_echo, "future": True}
    if url.startswith("sqlite"):
        # check_same_thread is a SQLite-only guard that assumes one thread per
        # connection; the pool already guarantees exclusive checkout.
        kwargs["connect_args"] = {"check_same_thread": False}
    else:
        kwargs["pool_pre_ping"] = True

    engine = create_engine(url, **kwargs)

    if url.startswith("sqlite"):

        @event.listens_for(engine, "connect")
        def _enable_foreign_keys(connection, _record) -> None:  # noqa: ANN001
            # Off by default in SQLite, which means every ON DELETE CASCADE in
            # the schema would silently do nothing and orphan rows instead.
            cursor = connection.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

    return engine


@lru_cache
def get_engine() -> Engine:
    return build_engine()


def build_session_factory(engine: Engine | None = None) -> sessionmaker[Session]:
    return sessionmaker(
        bind=engine or get_engine(),
        autoflush=False,
        # Objects stay usable after the request's commit. Without this, every
        # attribute read on a returned model re-queries a closed session.
        expire_on_commit=False,
        class_=Session,
    )


@lru_cache
def get_session_factory() -> sessionmaker[Session]:
    return build_session_factory()


@contextmanager
def session_scope(factory: sessionmaker[Session] | None = None) -> Iterator[Session]:
    """A transaction that commits on success and rolls back on any error.

    Used by background jobs and the CLI. The API uses its own dependency so
    that the rollback happens before the error handler builds a response.
    """
    session = (factory or get_session_factory())()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def create_all(engine: Engine | None = None) -> None:
    """Create the schema directly, for tests and first local run.

    Not a substitute for migrations. Alembic owns the deployed schema; this
    exists so a developer can start without running one, and so tests can
    build a database in memory.
    """
    Base.metadata.create_all(engine or get_engine())
