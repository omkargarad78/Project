"""Declarative base and the column conventions every table follows.

Two decisions are enforced here rather than remembered per-model.

**Constraints are named.** Alembic cannot drop an unnamed constraint on
PostgreSQL, so an unnamed one is a migration that works going forward and
fails going back. The naming convention below makes every constraint
reversible.

**Money is never a float.** A ``Numeric`` column without a Python-side type
comes back as a float on some drivers, which would undo the precision
guarantee the whole platform rests on. :class:`Money` and :class:`Quantity`
pin the type at both ends.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from decimal import Decimal

from sqlalchemy import DateTime, MetaData, Numeric, String, TypeDecorator
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

NAMING_CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class UtcDateTime(TypeDecorator):
    """A timestamp that is always timezone-aware and always UTC.

    SQLite discards the offset, so a value written as aware comes back naive
    and compares unequal to itself. Every audit record and every retention
    decision depends on these comparing correctly.
    """

    impl = DateTime(timezone=True)
    cache_ok = True

    def process_bind_param(self, value: datetime | None, dialect) -> datetime | None:  # noqa: ANN001
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("naive datetimes are not stored; attach a timezone")
        return value.astimezone(UTC)

    def process_result_value(self, value: datetime | None, dialect) -> datetime | None:  # noqa: ANN001
        if value is None:
            return None
        return value if value.tzinfo else value.replace(tzinfo=UTC)


class Money(TypeDecorator):
    """A monetary amount, stored and returned as an exact ``Decimal``."""

    impl = Numeric(28, 8)
    cache_ok = True

    def process_result_value(self, value, dialect) -> Decimal | None:  # noqa: ANN001
        if value is None:
            return None
        return value if isinstance(value, Decimal) else Decimal(str(value))


#: Same storage, different name at the call site. A quantity is not an amount
#: and reading a column typed ``Money`` as shares is how the two get confused.
Quantity = Money


def new_id() -> str:
    """A random identifier for rows the user creates.

    Distinct from the content-derived ids the pipeline produces: a workspace
    is not a function of its inputs, so hashing it would be dishonest.
    """
    return uuid.uuid4().hex


def utcnow() -> datetime:
    return datetime.now(UTC)


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING_CONVENTION)


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        UtcDateTime, default=utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        UtcDateTime, default=utcnow, onupdate=utcnow, nullable=False
    )


class IdMixin:
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
