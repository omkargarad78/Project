"""The persisted schema.

The shape follows one rule: **a calculation run is immutable and complete.**

A run records not only its figures but the version of every input that
produced them — the tax rules, the exchange-rate dataset, the market-data
snapshot, the parser, and the hash of every uploaded file. Re-running with a
newer rate dataset produces a new run rather than updating the old one, so a
figure that was filed can still be reproduced after the inputs have moved on.
Storing only the latest would make last year's return unexplainable.

Everything a user owns hangs off a workspace, and every query in the API is
scoped by workspace membership. Nothing is scoped by user id alone, because
that pattern stops working the first time two people share a filing and the
usual fix is to weaken the check.
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Date,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.types import JSON

from .base import Base, IdMixin, Money, Quantity, TimestampMixin, UtcDateTime


class Role(StrEnum):
    """What a member may do in a workspace.

    Deliberately short. A role that nobody can describe in one sentence gets
    granted by default, which is how authorisation bugs are made.
    """

    #: Full control, including deleting the workspace and managing members.
    OWNER = "OWNER"
    #: Can upload, calculate and record decisions.
    EDITOR = "EDITOR"
    #: Can read everything and download reports. Cannot change a figure.
    VIEWER = "VIEWER"

    @property
    def can_write(self) -> bool:
        return self in (Role.OWNER, Role.EDITOR)

    @property
    def can_administer(self) -> bool:
        return self is Role.OWNER


class RunStatus(StrEnum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    #: Finished and produced figures. Says nothing about whether they are
    #: filable; that is the readiness verdict, which is a separate question.
    COMPLETED = "COMPLETED"
    #: Stopped on an internal error. Distinct from a run that completed and
    #: found the data unusable, which is a normal outcome, not a fault.
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"

    @property
    def is_terminal(self) -> bool:
        return self in (RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.CANCELLED)


class ArtifactKind(StrEnum):
    WORKPAPER_XLSX = "WORKPAPER_XLSX"
    WORKPAPER_CSV = "WORKPAPER_CSV"


class User(Base, IdMixin, TimestampMixin):
    __tablename__ = "users"

    email: Mapped[str] = mapped_column(String(320), unique=True, nullable=False)
    #: An argon2id hash. The column is named for what it holds so that nobody
    #: writing a query mistakes it for something reversible.
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    display_name: Mapped[str] = mapped_column(String(120), nullable=False, default="")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    last_login_at: Mapped[datetime | None] = mapped_column(UtcDateTime)

    memberships: Mapped[list[Membership]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )


class Workspace(Base, IdMixin, TimestampMixin):
    """One taxpayer's filing space. The unit of authorisation."""

    __tablename__ = "workspaces"

    name: Mapped[str] = mapped_column(String(160), nullable=False)
    #: The assessment year this workspace files for. Kept here because almost
    #: every downstream default depends on it.
    assessment_year: Mapped[str] = mapped_column(String(9), nullable=False)
    residency_note: Mapped[str] = mapped_column(Text, nullable=False, default="")

    memberships: Mapped[list[Membership]] = relationship(
        back_populates="workspace", cascade="all, delete-orphan"
    )
    source_files: Mapped[list[SourceFile]] = relationship(
        back_populates="workspace", cascade="all, delete-orphan"
    )
    runs: Mapped[list[CalculationRun]] = relationship(
        back_populates="workspace", cascade="all, delete-orphan"
    )


class Membership(Base, IdMixin, TimestampMixin):
    __tablename__ = "memberships"
    __table_args__ = (
        UniqueConstraint("user_id", "workspace_id", name="uq_memberships_user_id"),
    )

    user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    workspace_id: Mapped[str] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), nullable=False, index=True
    )
    role: Mapped[Role] = mapped_column(String(16), nullable=False)

    user: Mapped[User] = relationship(back_populates="memberships")
    workspace: Mapped[Workspace] = relationship(back_populates="memberships")


class SourceFile(Base, IdMixin, TimestampMixin):
    """An uploaded statement, recorded by content hash.

    The bytes live in object storage; this row is the metadata and the audit
    trail. Re-uploading identical bytes is recognised here rather than
    producing a second copy, because the content hash is what every derived
    identifier is built from.
    """

    __tablename__ = "source_files"
    __table_args__ = (
        UniqueConstraint(
            "workspace_id", "file_hash", name="uq_source_files_workspace_id"
        ),
        Index("ix_source_files_workspace_created", "workspace_id", "created_at"),
    )

    workspace_id: Mapped[str] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), nullable=False
    )
    uploaded_by: Mapped[str | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    file_name: Mapped[str] = mapped_column(String(255), nullable=False)
    file_hash: Mapped[str] = mapped_column(String(80), nullable=False)
    file_type: Mapped[str] = mapped_column(String(16), nullable=False)
    size_bytes: Mapped[int] = mapped_column(Integer, nullable=False)
    #: Where the bytes are in the storage backend, not a filesystem path the
    #: client ever sees.
    storage_key: Mapped[str] = mapped_column(String(255), nullable=False)
    broker_id: Mapped[str | None] = mapped_column(String(64))
    parser_version: Mapped[str | None] = mapped_column(String(64))
    #: Set when the user deletes the file. The row survives because runs that
    #: cite it must stay explainable.
    deleted_at: Mapped[datetime | None] = mapped_column(UtcDateTime)

    workspace: Mapped[Workspace] = relationship(back_populates="source_files")


class CalculationRun(Base, IdMixin, TimestampMixin):
    """One execution of the pipeline, with every input version it used."""

    __tablename__ = "calculation_runs"
    __table_args__ = (
        Index("ix_calculation_runs_workspace_created", "workspace_id", "created_at"),
    )

    workspace_id: Mapped[str] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), nullable=False
    )
    requested_by: Mapped[str | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    status: Mapped[RunStatus] = mapped_column(
        String(16), nullable=False, default=RunStatus.QUEUED
    )
    assessment_year: Mapped[str] = mapped_column(String(9), nullable=False)

    # --- the inputs, pinned ------------------------------------------------
    # Without these a figure cannot be reproduced once a dataset is updated,
    # and "the rate changed" becomes indistinguishable from "the code changed".
    rule_version: Mapped[str] = mapped_column(String(64), nullable=False)
    rule_verified: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    fx_dataset: Mapped[str | None] = mapped_column(String(128))
    fx_dataset_version: Mapped[str | None] = mapped_column(String(64))
    market_dataset: Mapped[str | None] = mapped_column(String(128))
    market_data_synthetic: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )
    #: The full calculation policy as applied: allocation method, valuation
    #: point, peak frequency, rounding. Two runs differing only here produce
    #: different figures, and this is what tells them apart.
    policy: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    source_file_hashes: Mapped[list] = mapped_column(JSON, nullable=False, default=list)

    # --- the verdict --------------------------------------------------------
    readiness: Mapped[str | None] = mapped_column(String(32))
    is_filable: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    blocking_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    error_message: Mapped[str | None] = mapped_column(Text)
    started_at: Mapped[datetime | None] = mapped_column(UtcDateTime)
    finished_at: Mapped[datetime | None] = mapped_column(UtcDateTime)

    workspace: Mapped[Workspace] = relationship(back_populates="runs")
    rows: Mapped[list[ScheduleFaRow]] = relationship(
        back_populates="run", cascade="all, delete-orphan"
    )
    issues: Mapped[list[RunIssue]] = relationship(
        back_populates="run", cascade="all, delete-orphan"
    )
    artifacts: Mapped[list[Artifact]] = relationship(
        back_populates="run", cascade="all, delete-orphan"
    )


class ScheduleFaRow(Base, IdMixin, TimestampMixin):
    """One reported row, stored as the figures plus their derivation.

    The figures are columns because they are queried and totalled. The
    per-field reasoning is JSON because its shape is owned by the rule
    version, and normalising it would mean a migration every time a form
    column changes.
    """

    __tablename__ = "schedule_fa_rows"
    __table_args__ = (
        UniqueConstraint(
            "run_id", "table_name", "serial_number", name="uq_schedule_fa_rows_run_id"
        ),
        CheckConstraint("table_name IN ('A2','A3')", name="table_name"),
    )

    run_id: Mapped[str] = mapped_column(
        ForeignKey("calculation_runs.id", ondelete="CASCADE"), nullable=False
    )
    table_name: Mapped[str] = mapped_column(String(2), nullable=False)
    serial_number: Mapped[int] = mapped_column(Integer, nullable=False)
    subject: Mapped[str] = mapped_column(String(64), nullable=False)

    country_code: Mapped[str | None] = mapped_column(String(8))
    entity_name: Mapped[str | None] = mapped_column(String(255))
    acquisition_date: Mapped[date | None] = mapped_column(Date)

    initial_value_inr: Mapped[Decimal | None] = mapped_column(Money)
    peak_value_inr: Mapped[Decimal | None] = mapped_column(Money)
    closing_value_inr: Mapped[Decimal | None] = mapped_column(Money)
    income_credited_inr: Mapped[Decimal | None] = mapped_column(Money)
    gross_proceeds_inr: Mapped[Decimal | None] = mapped_column(Money)
    closing_quantity: Mapped[Decimal | None] = mapped_column(Quantity)

    is_complete: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    #: One entry per figure: status, native amount, rate, rate date, formula,
    #: explanation, caveats. A null money column above means the figure was
    #: not computed, and this says why.
    derivation: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)

    run: Mapped[CalculationRun] = relationship(back_populates="rows")


class RunIssue(Base, IdMixin, TimestampMixin):
    """An issue as a specific run generated it."""

    __tablename__ = "run_issues"
    __table_args__ = (
        UniqueConstraint("run_id", "issue_id", name="uq_run_issues_run_id"),
        Index("ix_run_issues_run_severity", "run_id", "severity"),
    )

    run_id: Mapped[str] = mapped_column(
        ForeignKey("calculation_runs.id", ondelete="CASCADE"), nullable=False
    )
    issue_id: Mapped[str] = mapped_column(String(32), nullable=False)
    #: Identifies the *condition*, not this occurrence of it. This is what a
    #: recorded decision is stored against, so that it survives a re-run.
    resolution_key: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(64), nullable=False)
    severity: Mapped[str] = mapped_column(String(16), nullable=False)
    scope: Mapped[str] = mapped_column(String(32), nullable=False)
    subject: Mapped[str] = mapped_column(String(255), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False)
    is_blocking: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    context: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)

    run: Mapped[CalculationRun] = relationship(back_populates="issues")


class IssueResolution(Base, IdMixin, TimestampMixin):
    """A decision a user recorded, kept at workspace level.

    Not attached to a run. A run is regenerated constantly and the decision
    has to outlive it; that is the whole point of keying on the condition
    rather than on the occurrence.
    """

    __tablename__ = "issue_resolutions"
    __table_args__ = (
        UniqueConstraint(
            "workspace_id", "resolution_key", name="uq_issue_resolutions_workspace_id"
        ),
    )

    workspace_id: Mapped[str] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), nullable=False
    )
    resolution_key: Mapped[str] = mapped_column(String(32), nullable=False)
    #: ACKNOWLEDGED or RESOLVED. The two behave differently on the next run:
    #: an acknowledgement is carried, a claimed fix is verified and reopened
    #: if the condition is still there.
    status: Mapped[str] = mapped_column(String(16), nullable=False)
    code: Mapped[str] = mapped_column(String(64), nullable=False)
    subject: Mapped[str] = mapped_column(String(255), nullable=False)
    #: Required, not optional. An acknowledgement with no stated reason is
    #: indistinguishable from a mis-click a year later.
    note: Mapped[str] = mapped_column(Text, nullable=False)
    #: The issue's wording when the decision was made, so a re-run can tell
    #: whether the user is still accepting the same statement.
    message: Mapped[str] = mapped_column(Text, nullable=False, default="")
    decided_by: Mapped[str | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    decided_at: Mapped[datetime] = mapped_column(UtcDateTime, nullable=False)


class Artifact(Base, IdMixin, TimestampMixin):
    """A generated workpaper, addressed by content hash."""

    __tablename__ = "artifacts"

    run_id: Mapped[str] = mapped_column(
        ForeignKey("calculation_runs.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    kind: Mapped[ArtifactKind] = mapped_column(String(32), nullable=False)
    file_name: Mapped[str] = mapped_column(String(255), nullable=False)
    storage_key: Mapped[str] = mapped_column(String(255), nullable=False)
    content_hash: Mapped[str] = mapped_column(String(80), nullable=False)
    size_bytes: Mapped[int] = mapped_column(Integer, nullable=False)
    #: What the writer had to alter to make the file safe to open. Surfaced
    #: on download rather than left in a log.
    sanitisation_notes: Mapped[list] = mapped_column(
        JSON, nullable=False, default=list
    )

    run: Mapped[CalculationRun] = relationship(back_populates="artifacts")


class AuditEvent(Base, IdMixin):
    """An append-only record of who did what.

    No ``updated_at`` and no update path: an audit trail that can be edited
    is not one. Retention is enforced by deleting whole rows past the
    configured horizon, which is a different operation from amending them.
    """

    __tablename__ = "audit_events"
    __table_args__ = (
        Index("ix_audit_events_workspace_at", "workspace_id", "at"),
    )

    at: Mapped[datetime] = mapped_column(UtcDateTime, nullable=False, index=True)
    workspace_id: Mapped[str | None] = mapped_column(String(32), index=True)
    actor_id: Mapped[str | None] = mapped_column(String(32))
    actor_email: Mapped[str] = mapped_column(String(320), nullable=False, default="")
    action: Mapped[str] = mapped_column(String(64), nullable=False)
    #: Type and id of what was acted on, denormalised. The target row may be
    #: gone by the time anyone reads this, and the record still has to mean
    #: something.
    target_type: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    target_id: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    detail: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    ip_address: Mapped[str | None] = mapped_column(String(64))
