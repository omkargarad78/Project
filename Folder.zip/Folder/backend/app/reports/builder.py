"""Assembling the workpaper from what the pipeline produced.

The ordering of the sheets is the argument the document makes. A reviewer
opens it and reads, in order: what this is and what it does not claim; the two
tables as the form wants them; how every figure in those tables was arrived
at; the evidence behind the conversions; the underlying data; and finally what
is wrong with it. Putting the figures first and the caveats last would be a
sales document. Putting the verdict on the cover is the point.

Nothing here recomputes anything. Every number comes from the stage that owns
it, because a workpaper that derives its own figures can disagree with the
system it is supposed to document.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from decimal import Decimal

from ..core.money import decimal_to_str
from ..fx.resolver import FxResolver
from ..lots.engine import LotBook
from ..marketdata.dataset import MarketDataSnapshot
from ..schedulefa.models import (
    ComputedFigure,
    FigureStatus,
    ScheduleFaReport,
    TableA2Row,
    TableA3Row,
    TextField,
)
from ..securities.resolver import ResolutionReport
from ..transactions.ledger import TransactionLedger
from ..validation.engine import ValidationReport
from ..validation.issues import IssueCollector
from .models import (
    Cell,
    CellKind,
    Column,
    Sheet,
    Workpaper,
    blank,
    day,
    money,
    number,
    quantity,
    rate,
    text,
    unavailable,
)


@dataclass(slots=True)
class WorkpaperInputs:
    """Everything the workpaper is built from.

    Grouped into one object rather than a long parameter list so that adding
    a section later does not change every call site, and so that what a
    workpaper depends on is readable in one place.
    """

    schedule_fa: ScheduleFaReport
    validation: ValidationReport
    issues: IssueCollector
    fx: FxResolver
    ledger: TransactionLedger
    lots: LotBook
    securities: ResolutionReport
    market_data: MarketDataSnapshot | None = None
    #: ``(file name, sha256)`` for every uploaded file, for the audit trail.
    source_files: list[tuple[str, str]] = field(default_factory=list)
    broker: str | None = None
    parser_version: str | None = None
    generated_at: datetime | None = None
    generated_by: str | None = None


class WorkpaperBuilder:
    """Turns a completed run into the document a preparer reads."""

    def build(self, inputs: WorkpaperInputs) -> Workpaper:
        report = inputs.schedule_fa
        paper = Workpaper(
            title=f"Schedule FA workpaper - assessment year {report.assessment_year}",
            generated_at=inputs.generated_at or datetime.now(UTC),
            warning=self._warning(inputs),
        )

        paper.add(self._cover(inputs))
        paper.add(self._methodology(inputs))
        paper.add(self._table_a2(report))
        paper.add(self._table_a3(report))
        paper.add(self._derivation(report))
        paper.add(self._peak_detail(report))
        paper.add(self._rates_used(inputs.fx))
        paper.add(self._transactions(inputs.ledger))
        paper.add(self._lots(inputs.lots))
        paper.add(self._disposals(inputs.lots))
        paper.add(self._securities(inputs.securities))
        paper.add(self._worklist(inputs.validation))
        paper.add(self._issues(inputs.issues))
        return paper

    # --- cover and methodology -------------------------------------------

    def _warning(self, inputs: WorkpaperInputs) -> str | None:
        validation = inputs.validation
        if validation.is_filable:
            if inputs.schedule_fa.rule_verified:
                return None
            return (
                "The tax rules used here have not been verified against the "
                "published form for this assessment year. Check the reporting "
                "period and the exchange-rate conventions on the Methodology "
                "sheet before filing."
            )
        return (
            f"DO NOT FILE FROM THIS DOCUMENT AS IT STANDS. "
            f"{len(validation.blocking_reasons)} condition(s) prevent Schedule FA "
            f"from being completed. They are listed on the Worklist sheet. "
            f"Figures shown as \u201cNOT AVAILABLE\u201d could not be computed and "
            f"are not zero."
        )

    def _cover(self, inputs: WorkpaperInputs) -> Sheet:
        report = inputs.schedule_fa
        validation = inputs.validation
        sheet = Sheet(
            name="Cover",
            columns=[Column("Item", 34), Column("Detail", 90, wrap=True)],
            preamble=[
                "This workpaper documents how each Schedule FA figure was "
                "produced. It is working papers, not a filed return, and not "
                "tax advice.",
            ],
        )

        def row(label: str, value: Cell) -> None:
            sheet.add(text(label), value)

        row("Assessment year", text(report.assessment_year))
        row("Reporting period", text(
            f"{report.period_start.isoformat()} to {report.period_end.isoformat()}"
        ))
        row("Reporting period basis", text(report.period_description))
        row("Tax rule version", text(report.rule_version))
        row(
            "Rule verification status",
            text(
                "verified against the published form"
                if report.rule_verified
                else "NOT VERIFIED - see the Methodology sheet"
            ),
        )
        row("Filing readiness", text(validation.readiness.label))
        row("Blocking conditions", number(len(validation.blocking_reasons)))
        row("Qualifications to read", number(len(validation.qualifications)))
        row(
            "Issue counts",
            text(
                f"errors {validation.counts.get('ERROR', 0)}, "
                f"warnings {validation.counts.get('WARNING', 0)}, "
                f"info {validation.counts.get('INFO', 0)}"
            ),
        )
        row("Holdings reported (Table A3)", number(len(report.table_a3)))
        row("Accounts reported (Table A2)", number(len(report.table_a2)))
        row("Broker", text(inputs.broker or "not recorded"))
        row("Parser version", text(inputs.parser_version or "not recorded"))
        row("Generated at (UTC)", Cell(
            inputs.generated_at or datetime.now(UTC), CellKind.DATE
        ))
        row("Generated by", text(inputs.generated_by or "not recorded"))

        for name, digest in inputs.source_files:
            row(f"Source file: {name}", text(digest))

        sheet.footnotes = [
            "Every figure on the Schedule FA sheets is traceable to a row on "
            "the Figure Derivation sheet, and from there to the exchange rate "
            "and the transactions behind it.",
            "A figure shown as NOT AVAILABLE could not be computed. It is not "
            "zero, and the reason is given on the Figure Derivation sheet.",
        ]
        return sheet

    def _methodology(self, inputs: WorkpaperInputs) -> Sheet:
        report = inputs.schedule_fa
        sheet = Sheet(
            name="Methodology",
            columns=[
                Column("Decision", 34),
                Column("Applied", 26),
                Column("Why this is a decision", 90, wrap=True),
            ],
            preamble=[
                "Choices the platform made that a reviewer may wish to change. "
                "These are configuration, not statutory rules, and are recorded "
                "on every run so that two runs producing different figures can "
                "be told apart.",
            ],
        )
        for label, value in report.calculation_policy.items():
            sheet.add(text(label), text(value), blank())

        sheet.add(
            text("Reporting period"),
            text(
                f"{report.period_start.isoformat()} to "
                f"{report.period_end.isoformat()}"
            ),
            text(report.period_description),
        )
        if not report.rule_verified:
            sheet.add(
                text("Rule verification"),
                text("NOT VERIFIED"),
                text(
                    f"The rules in version {report.rule_version} were transcribed "
                    f"from the official materials but have not been confirmed "
                    f"against the published form and instructions for assessment "
                    f"year {report.assessment_year}. The reporting period and the "
                    f"exchange-rate convention for each column are the two things "
                    f"to check first, because both have changed between years."
                ),
            )
        if inputs.market_data is not None:
            snapshot = inputs.market_data
            sheet.add(
                text("Market-data snapshot"),
                text(snapshot.dataset_name),
                text(
                    f"Adjustment basis: {snapshot.adjustment_basis}. "
                    + (
                        "SYNTHETIC DATA - these are not real market prices and "
                        "must not be used to value a real holding."
                        if snapshot.synthetic
                        else "Prices are used exactly as supplied; none are "
                        "interpolated."
                    )
                ),
            )
        if inputs.fx.dataset is not None:
            dataset = inputs.fx.dataset
            sheet.add(
                text("Exchange-rate dataset"),
                text(dataset.version_label),
                text(
                    f"{dataset.source_tier.label}. Each rate this run actually "
                    f"applied is listed on the Exchange Rates Used sheet with "
                    f"the reason it was selected."
                ),
            )
        return sheet

    # --- the form itself --------------------------------------------------

    def _table_a2(self, report: ScheduleFaReport) -> Sheet:
        sheet = Sheet(
            name="Schedule FA A2",
            columns=[
                Column("S. No.", 8),
                Column("Country/Region Name", 22),
                Column("Country/Region Code", 18),
                Column("Name of Financial Institution", 32),
                Column("Address of Financial Institution", 40, wrap=True),
                Column("ZIP Code", 12),
                Column("Account Number", 20),
                Column("Status", 14),
                Column("Account Opening Date", 18),
                Column("Peak Balance (INR)", 20),
                Column("Closing Balance (INR)", 20),
                Column("Gross Amount Credited (INR)", 24),
                Column("Nature of Amount", 30, wrap=True),
                Column("Row Complete", 14),
            ],
            preamble=[
                "Foreign custodial accounts. This table reports the cash "
                "account only; the value of the securities held in it is "
                "reported in Table A3 and is deliberately not added here, "
                "which would report the same wealth twice.",
            ],
            empty_message="No custodial account was reported for this period.",
        )
        for row in report.table_a2:
            sheet.add(
                number(row.serial_number),
                _field(row.country_name),
                _field(row.country_code),
                _field(row.institution_name),
                _field(row.institution_address),
                _field(row.zip_code),
                _field(row.account_number),
                _field(row.account_status),
                _field(row.account_opening_date),
                _figure(row.peak_balance),
                _figure(row.closing_balance),
                _figure(row.gross_amount_credited),
                _field(row.gross_amount_nature),
                text("yes" if row.is_complete else "NO"),
            )
        sheet.footnotes = _row_footnotes(report.table_a2)
        return sheet

    def _table_a3(self, report: ScheduleFaReport) -> Sheet:
        sheet = Sheet(
            name="Schedule FA A3",
            columns=[
                Column("S. No.", 8),
                Column("Ticker", 12),
                Column("Country/Region Name", 22),
                Column("Country/Region Code", 18),
                Column("Name of Entity", 32),
                Column("Address of Entity", 40, wrap=True),
                Column("ZIP Code", 12),
                Column("Nature of Entity", 20),
                Column("Date of Acquiring the Interest", 22),
                Column("Initial Value (INR)", 20),
                Column("Peak Value (INR)", 20),
                Column("Closing Value (INR)", 20),
                Column("Gross Amount Credited (INR)", 24),
                Column("Gross Proceeds (INR)", 20),
                Column("Row Complete", 14),
            ],
            preamble=[
                "Foreign equity and debt interests held at any time during the "
                "reporting period, including any disposed of before the period "
                "ended.",
                "The ticker column is working-paper context and is not part of "
                "the form.",
            ],
            empty_message="No foreign equity or debt interest was held in this period.",
        )
        for row in report.table_a3:
            sheet.add(
                number(row.serial_number),
                text(row.symbol),
                _field(row.country_name),
                _field(row.country_code),
                _field(row.entity_name),
                _field(row.entity_address),
                _field(row.zip_code),
                _field(row.nature_of_entity),
                _field(row.acquisition_date),
                _figure(row.initial_value),
                _figure(row.peak_value),
                _figure(row.closing_value),
                _figure(row.income_credited),
                _figure(row.gross_proceeds),
                text("yes" if row.is_complete else "NO"),
            )
        sheet.footnotes = _row_footnotes(report.table_a3)
        return sheet

    # --- how each figure was reached --------------------------------------

    def _derivation(self, report: ScheduleFaReport) -> Sheet:
        sheet = Sheet(
            name="Figure Derivation",
            columns=[
                Column("Subject", 16),
                Column("Field", 30),
                Column("Status", 14),
                Column("Native Amount", 18),
                Column("Currency", 10),
                Column("Rate Date", 14),
                Column("Rate", 14),
                Column("Rate Type", 14),
                Column("INR Amount", 18),
                Column("Arithmetic", 60, wrap=True),
                Column("Explanation", 80, wrap=True),
                Column("Qualifications", 80, wrap=True),
            ],
            preamble=[
                "One row per reported money figure, with the reasoning that "
                "produced it. A figure may have to be defended years after "
                "filing, and the amount on its own cannot be.",
            ],
        )
        for row in (*report.table_a3, *report.table_a2):
            for figure in row.figures():
                _derivation_row(sheet, row.subject, figure)
        return sheet

    def _peak_detail(self, report: ScheduleFaReport) -> Sheet:
        sheet = Sheet(
            name="Peak Valuation",
            columns=[
                Column("Ticker", 12),
                Column("Valuation Date", 16),
                Column("Quantity", 16),
                Column("Price", 16),
                Column("Currency", 10),
                Column("Value (native)", 18),
                Column("Price Taken From", 18),
                Column("Days Carried Forward", 20),
                Column("Selected as Peak", 16),
            ],
            preamble=[
                "Every valuation considered when searching for the peak. The "
                "peak is selected on the rupee value of each date, not on the "
                "foreign-currency value: a holding can reach its highest "
                "dollar value in one month and its highest rupee value in "
                "another, and the form asks for a rupee figure.",
                "Only the selected date's conversion appears here as a rupee "
                "amount; it is on the Figure Derivation sheet.",
            ],
            empty_message="No peak valuation detail was produced.",
        )
        for row in report.table_a3:
            figure = row.peak_value
            chosen = _peak_date(figure)
            for point in figure.valuation_points:
                sheet.add(
                    text(row.symbol),
                    day(point.valuation_date),
                    quantity(point.quantity),
                    rate(point.price_native),
                    text(point.currency),
                    money(point.value_native),
                    day(point.price_date),
                    number(point.price_carried_forward_days),
                    text("yes" if point.valuation_date == chosen else ""),
                )
        return sheet

    # --- evidence ----------------------------------------------------------

    def _rates_used(self, fx: FxResolver) -> Sheet:
        rows = fx.evidence_rows()
        headings = _headings(rows) or [
            "Currency",
            "Rate Date",
            "Rate Type",
            "Value",
            "Why This Rate",
        ]
        sheet = Sheet(
            name="Exchange Rates Used",
            columns=[
                Column(h, 60, wrap=True) if h == "Why This Rate" else Column(h, 18)
                for h in headings
            ],
            preamble=[
                "Every exchange rate this run applied, with its source and the "
                "reason it was the applicable rate. Rates the dataset contains "
                "but the run did not use are not listed.",
            ],
            empty_message="No exchange rate was applied in this run.",
        )
        for row in rows:
            sheet.add(*(text(row.get(h, "")) for h in headings))
        return sheet

    def _transactions(self, ledger: TransactionLedger) -> Sheet:
        sheet = Sheet(
            name="Transactions",
            columns=[
                Column("Date", 14),
                Column("Type", 20),
                Column("Ticker", 12),
                Column("Quantity", 16),
                Column("Price", 16),
                Column("Gross Amount", 16),
                Column("Fees", 12),
                Column("Taxes", 12),
                Column("Net Amount", 16),
                Column("Currency", 10),
                Column("Cash Effect", 16),
                Column("Broker Activity Label", 26),
                Column("Description", 40, wrap=True),
                Column("Source", 34),
                Column("Transaction ID", 22),
            ],
            preamble=[
                "The normalised ledger. Every row records where in the "
                "uploaded file it came from, so any figure can be traced back "
                "to a cell in the broker's own export.",
                "Amounts are non-negative magnitudes; the direction is carried "
                "by the transaction type and shown in the cash-effect column.",
            ],
            empty_message="The uploaded files contained no transactions.",
        )
        for item in ledger.ordered():
            sheet.add(
                day(item.transaction_date),
                text(str(item.transaction_type)),
                text(item.ticker or ""),
                quantity(item.quantity) if item.quantity is not None else blank(),
                rate(item.price_native) if item.price_native is not None else blank(),
                money(item.gross_amount_native)
                if item.gross_amount_native is not None
                else blank(),
                money(item.fees_native) if item.fees_native is not None else blank(),
                money(item.taxes_native) if item.taxes_native is not None else blank(),
                money(item.net_amount_native)
                if item.net_amount_native is not None
                else blank(),
                text(item.currency),
                money(item.cash_delta_native),
                text(item.raw_activity or ""),
                text(item.description or ""),
                text(item.source_reference),
                text(item.transaction_id),
            )
        return sheet

    def _lots(self, book: LotBook) -> Sheet:
        sheet = Sheet(
            name="Lots",
            columns=[
                Column("Ticker", 12),
                Column("Lot ID", 22),
                Column("Origin", 20),
                Column("Acquisition Date", 18),
                Column("Original Quantity", 18),
                Column("Remaining Quantity", 18),
                Column("Total Cost", 16),
                Column("Fees", 12),
                Column("Cost Per Share", 16),
                Column("Currency", 10),
                Column("Corporate Actions Applied", 40, wrap=True),
                Column("Source", 34),
                Column("Notes", 50, wrap=True),
            ],
            preamble=[
                f"Acquisition lots reconstructed from the ledger, allocated "
                f"{book.allocation_method}. {book.method_note}",
                "An inferred lot is one the uploaded files do not contain an "
                "acquisition for: a disposal proved the shares were held, so "
                "the quantity is recorded as a lower bound with no cost and no "
                "acquisition date.",
            ],
            empty_message="No holdings were reconstructed.",
        )
        for symbol in book.symbols():
            for lot in book.positions[symbol].lots:
                sheet.add(
                    text(symbol),
                    text(lot.lot_id),
                    text(str(lot.origin)),
                    day(lot.acquisition_date) if lot.acquisition_date else unavailable(),
                    quantity(lot.original_quantity),
                    quantity(lot.remaining_quantity),
                    money(lot.total_cost_native),
                    money(lot.fees_native) if lot.fees_native is not None else blank(),
                    rate(lot.cost_per_share),
                    text(lot.currency),
                    text(
                        "; ".join(
                            f"{a.ex_date.isoformat()} {a.description} "
                            f"({decimal_to_str(a.quantity_before)} -> "
                            f"{decimal_to_str(a.quantity_after)})"
                            for a in lot.adjustments
                        )
                    ),
                    text(lot.source_reference or ""),
                    text("; ".join(lot.notes)),
                )
        return sheet

    def _disposals(self, book: LotBook) -> Sheet:
        sheet = Sheet(
            name="Disposals",
            columns=[
                Column("Ticker", 12),
                Column("Disposal Date", 16),
                Column("Quantity", 16),
                Column("Gross Proceeds", 18),
                Column("Fees", 12),
                Column("Cost Basis", 18),
                Column("Gain/Loss (native)", 20),
                Column("Currency", 10),
                Column("Lots Consumed", 50, wrap=True),
                Column("Uses Inferred Lots", 20),
            ],
            preamble=[
                "Disposals matched against acquisition lots. The gain shown is "
                "in the foreign currency and is working-paper context only: "
                "Schedule FA asks for gross proceeds, not a capital gain, and "
                "a capital-gains computation is a different schedule.",
            ],
            empty_message="Nothing was disposed of in this period.",
        )
        for symbol in book.symbols():
            for disposal in book.positions[symbol].disposals:
                basis = disposal.cost_basis_native
                sheet.add(
                    text(symbol),
                    day(disposal.disposal_date),
                    quantity(disposal.quantity),
                    money(disposal.gross_proceeds_native),
                    money(disposal.fees_native)
                    if disposal.fees_native is not None
                    else blank(),
                    money(basis),
                    money(disposal.gain_native()),
                    text(disposal.currency),
                    text(
                        "; ".join(
                            f"{a.lot_id} x{decimal_to_str(a.quantity)}"
                            for a in disposal.allocations
                        )
                    ),
                    text("yes" if disposal.uses_inferred_lots else "no"),
                )
        return sheet

    def _securities(self, resolution: ResolutionReport) -> Sheet:
        sheet = Sheet(
            name="Securities",
            columns=[
                Column("Ticker", 12),
                Column("Transactions", 14),
                Column("Resolved", 12),
                Column("Security ID", 20),
                Column("Legal Entity Name", 32),
                Column("Still Missing for Schedule FA", 40, wrap=True),
                Column("How It Was Resolved", 70, wrap=True),
            ],
            preamble=[
                "How each ticker in the file was resolved to a legal entity. "
                "The entity's name, address and country are never derived from "
                "the ticker symbol or from the broker's display name.",
            ],
            empty_message="No securities appeared in the uploaded files.",
        )
        for symbol in sorted(resolution.resolutions):
            resolved = resolution.resolutions[symbol]
            security = resolved.security
            sheet.add(
                text(symbol),
                number(resolution.symbol_counts.get(symbol, 0)),
                text("yes" if resolved.resolved else "NO"),
                text(security.security_id if security else ""),
                text(security.legal_entity_name if security else "")
                if security and security.has_entity_name
                else unavailable(),
                text(", ".join(resolved.missing_fields())),
                text(resolved.explanation),
            )
        return sheet

    # --- what is wrong with it --------------------------------------------

    def _worklist(self, validation: ValidationReport) -> Sheet:
        sheet = Sheet(
            name="Worklist",
            columns=[
                Column("Priority", 10),
                Column("Blocks Filing", 14),
                Column("Severity", 12),
                Column("Condition", 40, wrap=True),
                Column("What To Do", 30),
                Column("Occurrences", 14),
                Column("Subjects", 34, wrap=True),
                Column("Figures It Blocks", 40, wrap=True),
                Column("Can Be Accepted", 16),
                Column("Remediation", 70, wrap=True),
            ],
            preamble=[
                "What to do, in the order worth doing it. Issues are grouped "
                "by the action that clears them, because the unit of work is "
                "the action: many occurrences of one condition are usually one "
                "task.",
                "\u201cCan be accepted\u201d means acknowledging the condition "
                "is enough to file. Where it says no, the figure does not exist "
                "until the data is supplied, and no acceptance produces it.",
            ],
            empty_message="Nothing needs attention.",
        )
        for index, group in enumerate(validation.groups, start=1):
            sheet.add(
                number(index),
                text("YES" if group.is_blocking else "no"),
                text(str(group.severity)),
                text(group.title),
                text(group.action.label),
                number(group.count),
                text(", ".join(group.subjects[:12])),
                text("; ".join(group.affected_figures[:12])),
                text("yes" if group.is_waivable else "no"),
                text(group.remediation),
            )

        sheet.footnotes = [f"Filing readiness: {validation.readiness.label}."]
        sheet.footnotes.extend(
            f"Blocking: {reason}" for reason in validation.blocking_reasons
        )
        sheet.footnotes.extend(
            f"Qualification: {note}" for note in validation.qualifications
        )
        return sheet

    def _issues(self, issues: IssueCollector) -> Sheet:
        rows = issues.to_rows()
        headings = _headings(rows) or ["Issue ID", "Severity", "Message"]
        wide = {"Message", "Explanation", "Remediation"}
        sheet = Sheet(
            name="Issues",
            columns=[
                Column(h, 70 if h in wide else 18, wrap=h in wide) for h in headings
            ],
            preamble=[
                "Every condition raised during the run, including ones already "
                "accepted. An accepted condition keeps its recorded reason so "
                "that a reviewer can see what was decided and by whom.",
            ],
            empty_message="No conditions were raised.",
        )
        for row in rows:
            sheet.add(*(text(row.get(h, "")) for h in headings))
        return sheet


# --- helpers --------------------------------------------------------------


def _headings(rows: list[dict[str, str]]) -> list[str]:
    """Column order taken from the first row, which is insertion-ordered."""
    return list(rows[0]) if rows else []


def _field(item: TextField) -> Cell:
    return text(item.value) if item.available else unavailable()


def _figure(figure: ComputedFigure) -> Cell:
    """A reported amount, or an explicit statement that there is not one.

    A nil figure is a real zero and is written as one. An unavailable figure
    is neither zero nor blank, and writing it as either would be the single
    most misleading thing this module could do.
    """
    if figure.status is FigureStatus.UNAVAILABLE:
        return unavailable()
    if figure.inr_amount is None:
        return money(Decimal(0))
    return money(figure.inr_amount)


def _derivation_row(sheet: Sheet, subject: str, figure: ComputedFigure) -> None:
    sheet.add(
        text(subject),
        text(figure.label),
        text(str(figure.status)),
        money(figure.native_amount) if figure.native_amount is not None else blank(),
        text(figure.currency or ""),
        day(figure.rate_date),
        rate(figure.rate_value) if figure.rate_value is not None else blank(),
        text(figure.rate_type or ""),
        _figure(figure),
        text(figure.formula),
        text(figure.explanation),
        text(" | ".join(figure.caveats)),
    )


def _peak_date(figure: ComputedFigure):  # noqa: ANN202 - date | None
    """The valuation date the peak was taken from.

    Recovered by matching the reported native amount against the points
    considered, rather than by parsing the explanation text.
    """
    if figure.native_amount is None:
        return None
    for point in figure.valuation_points:
        if point.value_native == figure.native_amount:
            return point.valuation_date
    return None


def _row_footnotes(rows: list[TableA2Row] | list[TableA3Row]) -> list[str]:
    notes: list[str] = []
    for row in rows:
        label = getattr(row, "symbol", None) or row.subject
        missing = row.missing_fields()
        if missing:
            notes.append(
                f"Row {row.serial_number} ({label}) is incomplete: "
                f"{', '.join(missing)}. See the Worklist sheet."
            )
        for caveat in row.all_caveats():
            notes.append(f"Row {row.serial_number} ({label}): {caveat}")
    return notes
