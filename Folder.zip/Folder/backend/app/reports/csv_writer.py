"""Writing a workpaper as a bundle of CSV files.

One file per sheet, plus a manifest. CSV exists here because it diffs, it
opens anywhere, and it can be read by a script; the xlsx exists because it is
what a person actually reads.

Values that a spreadsheet would evaluate as formulas are prefixed with an
apostrophe. This is the only mitigation that works in a format with no type
system, and it means the CSV does not contain byte-for-byte what the source
did. Rather than do that quietly, every affected cell is counted and listed in
the manifest, and the xlsx keeps the untouched text.
"""

from __future__ import annotations

import csv
import io
from dataclasses import dataclass

from .models import Sheet, Workpaper
from .safety import SanitisationLog, neutralise_for_csv, truncate_cell

#: Written at the top of every CSV. Excel and LibreOffice both honour it and
#: it stops a UTF-8 file being read as the system's legacy codepage, which is
#: what turns a company name into mojibake.
_BOM = "\ufeff"


@dataclass(frozen=True, slots=True)
class CsvFile:
    """One rendered CSV, ready to write to disk or a zip."""

    file_name: str
    content: bytes


class CsvWorkpaperWriter:
    """Renders a :class:`Workpaper` to a set of CSV files."""

    def __init__(self) -> None:
        self.log = SanitisationLog()

    def write(self, paper: Workpaper) -> list[CsvFile]:
        files = [
            CsvFile(_file_name(index, sheet.name), self._render(sheet, paper))
            for index, sheet in enumerate(paper.sheets, start=1)
        ]
        # Built last so it can report what rendering the sheets had to change.
        files.insert(0, CsvFile("00-manifest.csv", self._manifest(paper, files)))
        return files

    def _render(self, sheet: Sheet, paper: Workpaper) -> bytes:
        buffer = io.StringIO()
        buffer.write(_BOM)
        writer = csv.writer(buffer, lineterminator="\n", quoting=csv.QUOTE_MINIMAL)

        writer.writerow([self._safe(paper.title, sheet.name, "", 0)])
        if paper.warning:
            writer.writerow([self._safe(paper.warning, sheet.name, "", 0)])
        writer.writerow([])

        for note in sheet.preamble:
            writer.writerow([self._safe(note, sheet.name, "", 0)])
        if sheet.preamble:
            writer.writerow([])

        writer.writerow(
            [self._safe(h, sheet.name, h, 0) for h in sheet.headings]
        )

        if sheet.is_empty:
            writer.writerow([self._safe(sheet.empty_message, sheet.name, "", 0)])
        else:
            for number, row in enumerate(sheet.rows, start=1):
                writer.writerow(
                    [
                        self._safe(
                            cell.as_text(),
                            sheet.name,
                            sheet.columns[index].heading
                            if index < len(sheet.columns)
                            else "",
                            number,
                        )
                        for index, cell in enumerate(row)
                    ]
                )

        if sheet.footnotes:
            writer.writerow([])
            for note in sheet.footnotes:
                writer.writerow([self._safe(note, sheet.name, "", 0)])

        return buffer.getvalue().encode("utf-8")

    def _manifest(self, paper: Workpaper, files: list[CsvFile]) -> bytes:
        buffer = io.StringIO()
        buffer.write(_BOM)
        writer = csv.writer(buffer, lineterminator="\n")

        writer.writerow(["Workpaper", paper.title])
        writer.writerow(
            ["Generated At (UTC)", paper.generated_at.isoformat(timespec="seconds")]
        )
        if paper.warning:
            writer.writerow(["Warning", paper.warning])
        writer.writerow([])

        writer.writerow(["File", "Section", "Rows", "Columns"])
        for csv_file, sheet in zip(files, paper.sheets, strict=True):
            writer.writerow(
                [
                    csv_file.file_name,
                    sheet.name,
                    str(len(sheet.rows)),
                    str(len(sheet.columns)),
                ]
            )

        writer.writerow([])
        writer.writerow(["Notes on this CSV bundle"])
        notes = self.log.notes() or [
            "No cell required alteration to be safe in a spreadsheet."
        ]
        for note in notes:
            writer.writerow([note])
        writer.writerow(
            [
                "Where a value was prefixed with an apostrophe, the .xlsx "
                "version of this workpaper carries the original text unchanged."
            ]
        )
        return buffer.getvalue().encode("utf-8")

    def _safe(self, raw: str, sheet: str, column: str, row: int) -> str:
        cleaned, was_truncated = truncate_cell(raw)
        if was_truncated:
            self.log.record_truncated(sheet, column, row)
        safe, changed = neutralise_for_csv(cleaned)
        if changed:
            self.log.record_neutralised(sheet, column, row)
        return safe


def _file_name(index: int, sheet_name: str) -> str:
    slug = "".join(
        character if character.isalnum() else "-" for character in sheet_name.lower()
    )
    while "--" in slug:
        slug = slug.replace("--", "-")
    return f"{index:02d}-{slug.strip('-')}.csv"


def write_csv_bundle(paper: Workpaper) -> tuple[list[CsvFile], SanitisationLog]:
    writer = CsvWorkpaperWriter()
    return writer.write(paper), writer.log
