"""What a workpaper contains, independent of how it is written out.

The XLSX and the CSV bundle are the same document in two formats. Describing
the content once and rendering it twice is not only less code -- it is the
only way the two can be guaranteed to agree, and a preparer who reconciles the
CSV against the workbook and finds a difference has no way to tell which one
is wrong.

Cells keep their type. A rupee figure is a :class:`Decimal` all the way to the
writer, so the XLSX can hold the exact digits rather than a rendering of them,
and the distinction between "zero" and "not available" survives into the
output instead of both arriving as an empty cell.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum

from ..core.money import decimal_to_str


class CellKind(StrEnum):
    """How a value should be presented, and whether it is a value at all."""

    TEXT = "TEXT"
    NUMBER = "NUMBER"
    MONEY = "MONEY"
    QUANTITY = "QUANTITY"
    RATE = "RATE"
    DATE = "DATE"
    #: The figure genuinely could not be produced. Rendered as words, never as
    #: a blank and never as zero: a blank reads as "nothing to report" and a
    #: zero reads as a number, and this is neither.
    UNAVAILABLE = "UNAVAILABLE"
    #: Genuinely nothing to report.
    NIL = "NIL"


#: What an unavailable figure says in the output. Long enough that nobody
#: mistakes it for a value and short enough to fit a column.
UNAVAILABLE_TEXT = "NOT AVAILABLE"


@dataclass(frozen=True, slots=True)
class Cell:
    """One value with enough type information to render it faithfully."""

    value: str | Decimal | date | datetime | int | None = None
    kind: CellKind = CellKind.TEXT

    @property
    def is_numeric(self) -> bool:
        return self.kind in (
            CellKind.NUMBER,
            CellKind.MONEY,
            CellKind.QUANTITY,
            CellKind.RATE,
        )

    def as_text(self) -> str:
        """The value as it should read in a text-only format."""
        if self.kind is CellKind.UNAVAILABLE:
            return UNAVAILABLE_TEXT
        if self.value is None:
            return ""
        if isinstance(self.value, Decimal):
            return decimal_to_str(self.value) or ""
        if isinstance(self.value, datetime):
            return self.value.isoformat(timespec="seconds")
        if isinstance(self.value, date):
            return self.value.isoformat()
        return str(self.value)


def text(value: str | None) -> Cell:
    return Cell(value or "", CellKind.TEXT)


def money(value: Decimal | None) -> Cell:
    """A rupee or foreign-currency amount, or an explicit unavailability."""
    if value is None:
        return Cell(None, CellKind.UNAVAILABLE)
    return Cell(value, CellKind.MONEY)


def quantity(value: Decimal | None) -> Cell:
    if value is None:
        return Cell(None, CellKind.UNAVAILABLE)
    return Cell(value, CellKind.QUANTITY)


def rate(value: Decimal | None) -> Cell:
    if value is None:
        return Cell(None, CellKind.UNAVAILABLE)
    return Cell(value, CellKind.RATE)


def day(value: date | None) -> Cell:
    if value is None:
        return Cell("", CellKind.TEXT)
    return Cell(value, CellKind.DATE)


def number(value: int | Decimal | None) -> Cell:
    if value is None:
        return Cell("", CellKind.TEXT)
    return Cell(value, CellKind.NUMBER)


def blank() -> Cell:
    return Cell("", CellKind.TEXT)


def unavailable() -> Cell:
    return Cell(None, CellKind.UNAVAILABLE)


@dataclass(frozen=True, slots=True)
class Column:
    """A column heading and how wide it wants to be."""

    heading: str
    width: int = 18
    #: Long prose columns wrap rather than run off the page.
    wrap: bool = False


@dataclass(slots=True)
class Sheet:
    """One tab of the workpaper."""

    name: str
    #: Shown above the table, explaining what the reader is looking at and
    #: what it does and does not assert.
    preamble: list[str] = field(default_factory=list)
    columns: list[Column] = field(default_factory=list)
    rows: list[list[Cell]] = field(default_factory=list)
    #: Notes printed below the table.
    footnotes: list[str] = field(default_factory=list)
    #: Sheets with no rows still appear, saying so, because an absent tab is
    #: ambiguous between "nothing to report" and "this was not produced".
    empty_message: str = "Nothing to report in this section."

    def add(self, *cells: Cell) -> None:
        self.rows.append(list(cells))

    @property
    def headings(self) -> list[str]:
        return [column.heading for column in self.columns]

    @property
    def is_empty(self) -> bool:
        return not self.rows


@dataclass(slots=True)
class Workpaper:
    """The whole document."""

    title: str
    generated_at: datetime
    sheets: list[Sheet] = field(default_factory=list)
    #: A prominent banner, used when the run must not be filed as it stands.
    warning: str | None = None

    def add(self, sheet: Sheet) -> Sheet:
        self.sheets.append(sheet)
        return sheet

    def sheet(self, name: str) -> Sheet:
        for item in self.sheets:
            if item.name == name:
                return item
        raise KeyError(f"no sheet named {name!r} in this workpaper")

    @property
    def sheet_names(self) -> list[str]:
        return [sheet.name for sheet in self.sheets]
