"""Making untrusted text safe to put in a spreadsheet.

Almost every string in a workpaper came out of a file the platform did not
write: a ticker, a security name, a broker's free-text description. A cell
whose text begins with ``=``, ``+``, ``-``, ``@`` or a control character is
treated by Excel, LibreOffice and Google Sheets as a formula, and formulas in
those products can reach outside the document -- ``=cmd|'/c calc'!A1`` and
``=HYPERLINK`` and ``=WEBSERVICE`` are the well-known ones. A tax workpaper is
a document people email to their accountant, which is precisely the path this
attack is designed for.

The two output formats need different fixes, and only one of them is free:

*XLSX* has a type system. A cell can be declared a string, and a string cell
is never evaluated no matter what it contains. So the value is written
untouched and simply typed correctly. This is the honest fix: nothing is
altered, and the cell shows exactly what the broker's file said.

*CSV* has no type system. There is nowhere to record "this is text", and
quoting does not help -- Excel strips the quotes and evaluates what is inside.
The only effective mitigation is to change the value so it no longer starts
with a trigger character, which means the CSV genuinely does not contain what
the source did. That is a real cost, so it is applied only to cells that need
it, counted, and reported on the output rather than done quietly.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

#: Characters that make a spreadsheet treat the rest of the cell as a formula.
FORMULA_TRIGGERS = ("=", "+", "-", "@")

#: Control characters some spreadsheets treat as the start of a formula
#: context, plus the ones that corrupt a CSV row outright.
_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

#: The marker prefixed to a neutralised CSV value. A leading apostrophe is the
#: convention spreadsheets understand as "the rest is literal text".
CSV_TEXT_MARKER = "'"


def is_formula_like(text: str) -> bool:
    """Whether a spreadsheet would try to evaluate this cell.

    Leading whitespace counts: spreadsheets trim it before deciding, so
    ``" =1+1"`` is a formula too.
    """
    stripped = text.lstrip("\t\r\n ")
    return bool(stripped) and stripped[0] in FORMULA_TRIGGERS


def strip_control_characters(text: str) -> str:
    """Remove characters that are illegal in XLSX XML or break a CSV row.

    Tab, newline and carriage return survive: they are legitimate inside a
    quoted CSV field and inside an Excel cell, and a broker description
    genuinely can contain a line break.
    """
    return _CONTROL.sub("", text)


def neutralise_for_csv(text: str) -> tuple[str, bool]:
    """Return CSV-safe text and whether it had to be changed.

    A value that is merely negative -- ``-1234.00`` -- starts with a trigger
    character but is not an attack, and prefixing it would turn a number into
    text in every consumer of the file. Numeric-looking values are therefore
    left alone: a spreadsheet parses them as numbers, not formulas.
    """
    cleaned = strip_control_characters(text)
    if not is_formula_like(cleaned) or _is_plain_number(cleaned):
        return cleaned, cleaned != text
    return CSV_TEXT_MARKER + cleaned, True


_NUMBER = re.compile(r"^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$")


def _is_plain_number(text: str) -> bool:
    return bool(_NUMBER.match(text.strip()))


#: Excel's own limits. Exceeding either produces a file Excel refuses to open,
#: so they are enforced here rather than discovered by the user.
MAX_CELL_LENGTH = 32767
SHEET_NAME_LIMIT = 31


def truncate_cell(text: str) -> tuple[str, bool]:
    """Clip a value to what a spreadsheet cell can physically hold."""
    if len(text) <= MAX_CELL_LENGTH:
        return text, False
    marker = " [truncated]"
    return text[: MAX_CELL_LENGTH - len(marker)] + marker, True


@dataclass(slots=True)
class SanitisationLog:
    """What had to be changed to make the output safe, and where.

    Recorded rather than silently applied. A figure that reads differently in
    the workpaper from the broker's file is exactly the kind of discrepancy a
    reviewer is supposed to notice, so the workpaper says where it happened.
    """

    neutralised: list[str] = field(default_factory=list)
    truncated: list[str] = field(default_factory=list)

    def record_neutralised(self, sheet: str, column: str, row: int) -> None:
        self.neutralised.append(f"{sheet}!{column} row {row}")

    def record_truncated(self, sheet: str, column: str, row: int) -> None:
        self.truncated.append(f"{sheet}!{column} row {row}")

    @property
    def clean(self) -> bool:
        return not self.neutralised and not self.truncated

    def notes(self) -> list[str]:
        notes: list[str] = []
        if self.neutralised:
            shown = ", ".join(self.neutralised[:5])
            more = (
                f" and {len(self.neutralised) - 5} more"
                if len(self.neutralised) > 5
                else ""
            )
            notes.append(
                f"{len(self.neutralised)} cell(s) began with a character a "
                f"spreadsheet would treat as a formula and were prefixed with an "
                f"apostrophe in the CSV output so they display as text. The XLSX "
                f"output carries the original text unchanged. Affected: "
                f"{shown}{more}."
            )
        if self.truncated:
            shown = ", ".join(self.truncated[:5])
            more = (
                f" and {len(self.truncated) - 5} more"
                if len(self.truncated) > 5
                else ""
            )
            notes.append(
                f"{len(self.truncated)} cell(s) exceeded the {MAX_CELL_LENGTH} "
                f"character limit a spreadsheet cell can hold and were clipped. "
                f"Affected: {shown}{more}."
            )
        return notes


def safe_sheet_name(name: str, *, taken: set[str] | None = None) -> str:
    """A sheet name Excel will accept, unique within the workbook."""
    cleaned = re.sub(r"[\[\]:*?/\\]", " ", name).strip() or "Sheet"
    cleaned = cleaned[:SHEET_NAME_LIMIT]
    if taken is None:
        return cleaned
    candidate = cleaned
    suffix = 2
    while candidate in taken:
        tail = f" ({suffix})"
        candidate = cleaned[: SHEET_NAME_LIMIT - len(tail)] + tail
        suffix += 1
    taken.add(candidate)
    return candidate
