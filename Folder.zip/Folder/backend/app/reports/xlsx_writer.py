"""Writing a workpaper as an .xlsx file.

The one thing this module must get right is that no value from an uploaded
file is ever written as a formula. openpyxl decides a cell is a formula by
looking at the string: assign ``"=1+1"`` to ``cell.value`` and it writes a
formula cell. Since almost every string here originated in a broker's export,
every text cell is written with an explicit string type instead, which openpyxl
honours without inspecting the content.

Numbers are written as numbers so the recipient can total a column, and as
``Decimal`` rather than ``float`` so the file holds the exact digits the
platform computed rather than a binary approximation of them.
"""

from __future__ import annotations

import io
from datetime import date, datetime
from decimal import Decimal

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from .models import Cell as ReportCell
from .models import CellKind, Sheet, Workpaper
from .safety import (
    SanitisationLog,
    safe_sheet_name,
    strip_control_characters,
    truncate_cell,
)

#: Number formats. Rupee figures are whole numbers by the time they reach
#: here, so the format is presentational only and does not round anything.
_FORMATS = {
    CellKind.MONEY: "#,##0.########",
    CellKind.QUANTITY: "#,##0.########",
    CellKind.RATE: "#,##0.0000####",
    CellKind.NUMBER: "#,##0",
    CellKind.DATE: "yyyy-mm-dd",
}

_HEADER_FILL = PatternFill("solid", fgColor="1F3864")
_WARNING_FILL = PatternFill("solid", fgColor="C00000")
_UNAVAILABLE_FILL = PatternFill("solid", fgColor="FFF2CC")


class XlsxWorkpaperWriter:
    """Renders a :class:`Workpaper` to xlsx bytes."""

    def __init__(self) -> None:
        self.log = SanitisationLog()

    def write(self, paper: Workpaper) -> bytes:
        workbook = Workbook()
        workbook.remove(workbook.active)
        taken: set[str] = set()

        for sheet in paper.sheets:
            worksheet = workbook.create_sheet(safe_sheet_name(sheet.name, taken=taken))
            self._write_sheet(worksheet, sheet, paper)

        buffer = io.BytesIO()
        workbook.save(buffer)
        return buffer.getvalue()

    # --- one sheet --------------------------------------------------------

    def _write_sheet(
        self, worksheet: Worksheet, sheet: Sheet, paper: Workpaper
    ) -> None:
        line = 1

        line = self._write_title(worksheet, sheet, paper, line)
        line = self._write_preamble(worksheet, sheet, line)

        header_row = line
        for index, column in enumerate(sheet.columns, start=1):
            cell = worksheet.cell(row=header_row, column=index)
            self._set_text(cell, column.heading, sheet.name, column.heading, header_row)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = _HEADER_FILL
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            worksheet.column_dimensions[get_column_letter(index)].width = column.width
        line += 1

        if sheet.is_empty:
            cell = worksheet.cell(row=line, column=1)
            self._set_text(cell, sheet.empty_message, sheet.name, "", line)
            cell.font = Font(italic=True)
            line += 2
        else:
            for row in sheet.rows:
                for index, value in enumerate(row, start=1):
                    column = (
                        sheet.columns[index - 1]
                        if index <= len(sheet.columns)
                        else None
                    )
                    self._write_cell(
                        worksheet.cell(row=line, column=index),
                        value,
                        sheet_name=sheet.name,
                        column_name=column.heading if column else "",
                        row_number=line,
                        wrap=bool(column and column.wrap),
                    )
                line += 1
            line += 1

        for note in sheet.footnotes:
            cell = worksheet.cell(row=line, column=1)
            self._set_text(cell, note, sheet.name, "", line)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            line += 1

        worksheet.freeze_panes = worksheet.cell(row=header_row + 1, column=1)

    def _write_title(
        self, worksheet: Worksheet, sheet: Sheet, paper: Workpaper, line: int
    ) -> int:
        cell = worksheet.cell(row=line, column=1)
        self._set_text(cell, paper.title, sheet.name, "", line)
        cell.font = Font(bold=True, size=14)
        line += 1

        if paper.warning:
            warning = worksheet.cell(row=line, column=1)
            self._set_text(warning, paper.warning, sheet.name, "", line)
            warning.font = Font(bold=True, color="FFFFFF")
            warning.fill = _WARNING_FILL
            warning.alignment = Alignment(vertical="top", wrap_text=True)
            worksheet.row_dimensions[line].height = 44
            line += 1
        return line + 1

    def _write_preamble(self, worksheet: Worksheet, sheet: Sheet, line: int) -> int:
        for note in sheet.preamble:
            cell = worksheet.cell(row=line, column=1)
            self._set_text(cell, note, sheet.name, "", line)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            line += 1
        return line + 1 if sheet.preamble else line

    # --- one cell ---------------------------------------------------------

    def _write_cell(
        self,
        cell,  # noqa: ANN001 - openpyxl Cell
        value: ReportCell,
        *,
        sheet_name: str,
        column_name: str,
        row_number: int,
        wrap: bool,
    ) -> None:
        if wrap:
            cell.alignment = Alignment(vertical="top", wrap_text=True)

        if value.kind is CellKind.UNAVAILABLE:
            self._set_text(
                cell, value.as_text(), sheet_name, column_name, row_number
            )
            cell.fill = _UNAVAILABLE_FILL
            cell.font = Font(italic=True)
            return

        if value.value is None:
            self._set_text(cell, "", sheet_name, column_name, row_number)
            return

        if isinstance(value.value, datetime):
            cell.value = value.value.replace(tzinfo=None)
            cell.number_format = "yyyy-mm-dd hh:mm:ss"
            return

        if isinstance(value.value, date):
            cell.value = value.value
            cell.number_format = _FORMATS[CellKind.DATE]
            return

        if isinstance(value.value, Decimal | int) and value.is_numeric:
            # Written as Decimal: openpyxl serialises it digit for digit, so
            # the file records the exact figure rather than a float's nearest
            # representation of it.
            cell.value = value.value
            cell.number_format = _FORMATS.get(value.kind, "General")
            return

        self._set_text(cell, value.as_text(), sheet_name, column_name, row_number)

    def _set_text(
        self,
        cell,  # noqa: ANN001 - openpyxl Cell
        raw: str,
        sheet_name: str,
        column_name: str,
        row_number: int,
    ) -> None:
        """Write a string that will never be evaluated as a formula.

        Assigning the value makes openpyxl guess, and its guess for anything
        starting with ``=`` is a formula. Forcing the type back to ``s``
        afterwards is what stops the guess reaching the file: the cell is
        serialised as shared text, with no ``<f>`` element for a spreadsheet
        to evaluate on open. The text itself is left exactly as it was, apart
        from control characters that XLSX's XML cannot carry at all.
        """
        cleaned = strip_control_characters(raw)
        cleaned, was_truncated = truncate_cell(cleaned)
        if was_truncated:
            self.log.record_truncated(sheet_name, column_name, row_number)
        if not cleaned:
            # openpyxl stores an empty string as no value at all; declaring it
            # text as well would write a string cell with nothing in it, which
            # some readers reject. Leave it genuinely empty.
            return
        cell.value = cleaned
        cell.data_type = "s"


def write_xlsx(paper: Workpaper) -> tuple[bytes, SanitisationLog]:
    writer = XlsxWorkpaperWriter()
    return writer.write(paper), writer.log
