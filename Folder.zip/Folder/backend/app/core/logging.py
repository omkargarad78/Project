"""Structured logging with hard redaction of sensitive fields.

The uploaded files contain financial and personally identifiable information,
so the log pipeline is built as an allow-list: a fixed set of operational keys
is emitted, and anything whose key matches a sensitive pattern is replaced with
a placeholder before it reaches a handler. User and workspace identifiers are
pseudonymized to a keyed digest so that logs can be correlated without
carrying the real identifiers.
"""

from __future__ import annotations

import hashlib
import logging
import re
import sys
from typing import Any

import structlog

from .config import get_settings

#: Keys that must never appear in a log record, matched case-insensitively as
#: substrings so that ``broker_account_number`` is caught by ``account``.
SENSITIVE_KEY_PATTERNS: tuple[str, ...] = (
    "account",
    "pan",
    "aadhaar",
    "address",
    "zip",
    "postal",
    "bank",
    "ifsc",
    "tax_id",
    "taxpayer",
    "tin",
    "ssn",
    "password",
    "secret",
    "token",
    "authorization",
    "cookie",
    "api_key",
    "filename",
    "file_name",
    "raw",
    "cell",
    "row_data",
    "email",
    "phone",
    "name",
    "ticker",
    "amount",
    "quantity",
    "price",
    "balance",
    "proceeds",
    "dividend",
    "value_inr",
    "value_native",
)

#: Operational keys that are explicitly safe even though they match a pattern
#: above (for example ``operation`` contains no sensitive substring, but
#: ``dataset_name`` contains "name").
SAFE_KEY_ALLOWLIST: frozenset[str] = frozenset(
    {
        "dataset_name",
        "broker_name",
        "sheet_name",
        "rule_name",
        "policy_name",
        "job_name",
        "logger",
        "event",
        "level",
        "timestamp",
    }
)

REDACTED = "[redacted]"

_PAN_RE = re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b")
_LONG_DIGITS_RE = re.compile(r"\b\d{9,}\b")
_EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.]+\b")


def _is_sensitive(key: str) -> bool:
    lowered = key.lower()
    if lowered in SAFE_KEY_ALLOWLIST:
        return False
    return any(pattern in lowered for pattern in SENSITIVE_KEY_PATTERNS)


def _scrub_text(text: str) -> str:
    text = _PAN_RE.sub(REDACTED, text)
    text = _EMAIL_RE.sub(REDACTED, text)
    return _LONG_DIGITS_RE.sub(REDACTED, text)


def redact_processor(
    _logger: Any, _method: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Drop sensitive values and scrub identifier-shaped text from messages."""
    for key in list(event_dict):
        if _is_sensitive(key):
            event_dict[key] = REDACTED
        elif isinstance(event_dict[key], str):
            event_dict[key] = _scrub_text(event_dict[key])
    return event_dict


def pseudonymize(value: str | None) -> str | None:
    """Return a stable keyed digest of an identifier for log correlation."""
    if value is None:
        return None
    key = get_settings().secret_key.encode("utf-8")
    digest = hashlib.blake2s(value.encode("utf-8"), key=key[:32], digest_size=8)
    return f"pid_{digest.hexdigest()}"


def pseudonymize_ids_processor(
    _logger: Any, _method: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Replace ``user_id`` / ``workspace_id`` with pseudonymous digests."""
    for key in ("user_id", "workspace_id", "owner_id"):
        if key in event_dict and isinstance(event_dict[key], str):
            event_dict[key] = pseudonymize(event_dict[key])
    return event_dict


def configure_logging(*, level: int = logging.INFO, json_output: bool | None = None) -> None:
    """Install the structured logging pipeline for the process."""
    settings = get_settings()
    if json_output is None:
        json_output = settings.is_production

    renderer: Any = (
        structlog.processors.JSONRenderer()
        if json_output
        else structlog.dev.ConsoleRenderer(colors=False)
    )

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            pseudonymize_ids_processor,
            redact_processor,
            structlog.processors.StackInfoRenderer(),
            renderer,
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str) -> Any:
    """Return a bound structured logger."""
    return structlog.get_logger(name)


def bind_request_context(
    *,
    request_id: str | None = None,
    user_id: str | None = None,
    workspace_id: str | None = None,
    calculation_id: str | None = None,
    job_id: str | None = None,
) -> None:
    """Bind the operational identifiers carried on every log line."""
    context = {
        "request_id": request_id,
        "user_id": user_id,
        "workspace_id": workspace_id,
        "calculation_id": calculation_id,
        "job_id": job_id,
    }
    structlog.contextvars.bind_contextvars(**{k: v for k, v in context.items() if v is not None})


def clear_request_context() -> None:
    """Clear the bound request context."""
    structlog.contextvars.clear_contextvars()
