"""High-precision decimal arithmetic for all monetary and quantity values.

Binary floating point is never used for financial values anywhere in this
platform. Every amount, price, rate and quantity is a :class:`decimal.Decimal`
carried at full internal precision; rounding happens only at an explicit
presentation or reporting boundary via :func:`round_for_output`.
"""

from __future__ import annotations

from decimal import Decimal, InvalidOperation, localcontext
from enum import StrEnum
from typing import Any

# Internal working precision. Wide enough that chained multiply/divide on
# quantities (fractional shares to 8dp) x prices (4dp) x FX rates (6dp) never
# loses a significant digit before the explicit output rounding step.
INTERNAL_PRECISION = 34

# Canonical internal scales. Values are stored at these scales so that equality
# and hashing are stable across a save/load round trip.
QUANTITY_SCALE = 8
PRICE_SCALE = 8
RATE_SCALE = 8
AMOUNT_SCALE = 8

ZERO = Decimal(0)


class Rounding(StrEnum):
    """Rounding rules referenced by name in calculation and report output."""

    HALF_UP = "ROUND_HALF_UP"
    HALF_EVEN = "ROUND_HALF_EVEN"
    DOWN = "ROUND_DOWN"
    UP = "ROUND_UP"


class MoneyError(ValueError):
    """Raised when a value cannot be represented as an exact decimal."""


def to_decimal(value: Any, *, field: str = "value") -> Decimal:
    """Convert broker/source input to an exact :class:`Decimal`.

    Accepts ``Decimal``, ``int`` and ``str``. ``float`` is rejected: a float has
    already lost the source's decimal representation by the time it reaches
    here, so accepting one would silently admit binary rounding error into the
    ledger. Readers must hand over the source's original digit string instead.
    """
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise MoneyError(f"{field}: non-finite decimal {value!r}")
        return value
    if isinstance(value, bool):
        raise MoneyError(f"{field}: boolean is not a numeric value")
    if isinstance(value, int):
        return Decimal(value)
    if isinstance(value, float):
        raise MoneyError(
            f"{field}: float is not accepted for financial values; "
            "pass the original digit string to preserve the source representation"
        )
    if isinstance(value, str):
        text = normalize_numeric_text(value)
        if text is None:
            raise MoneyError(f"{field}: empty numeric value")
        try:
            parsed = Decimal(text)
        except InvalidOperation as exc:
            raise MoneyError(f"{field}: cannot parse {value!r} as a decimal") from exc
        if not parsed.is_finite():
            raise MoneyError(f"{field}: non-finite decimal {value!r}")
        return parsed
    raise MoneyError(f"{field}: unsupported numeric type {type(value).__name__}")


#: Longest first, so that "Rs." is not left with a trailing dot by "Rs".
_CURRENCY_SYMBOLS = (
    "USD",
    "INR",
    "Rs.",
    "Rs",
    "$",
    "\u20b9",
    "\u20ac",
    "\u00a3",
    "\u00a5",
)


def _strip_currency_symbol(text: str) -> str:
    for symbol in _CURRENCY_SYMBOLS:
        if text.startswith(symbol):
            return text[len(symbol) :].strip()
    return text


def normalize_numeric_text(value: str) -> str | None:
    """Normalize a broker-supplied numeric string without changing its value.

    Handles the presentation noise brokers put in exported cells: currency
    symbols, thousands separators, unicode minus signs, and accounting-style
    parentheses for negatives. Returns ``None`` for a blank value.
    """
    text = value.strip()
    if not text:
        return None

    # Stripped in a loop because the two wrappers nest in either order:
    # Excel's accounting format writes "$(1,234.56)" while a hand-typed cell
    # is more often "($1,234.56)". Handling only one order rejects half the
    # negative amounts in a real export.
    negative = False
    while True:
        if text.startswith("(") and text.endswith(")"):
            negative = True
            text = text[1:-1].strip()
            continue
        stripped = _strip_currency_symbol(text)
        if stripped != text:
            text = stripped
            continue
        break

    text = text.replace("\u2212", "-").replace("\u2013", "-")
    text = text.replace(",", "").replace("\u00a0", "").replace(" ", "")

    if text.endswith("%"):
        raise MoneyError(f"percentage value {value!r} is not a monetary amount")
    if text in {"-", "--", "."}:
        return None
    if negative and not text.startswith("-"):
        text = "-" + text
    return text or None


def opt_decimal(value: Any, *, field: str = "value") -> Decimal | None:
    """Like :func:`to_decimal` but maps blank/None input to ``None``.

    Missing data stays missing. It is never coerced to zero, because a blank
    fee column and a genuinely zero fee are different facts for reconciliation.
    """
    if value is None:
        return None
    if isinstance(value, str) and normalize_numeric_text(value) is None:
        return None
    return to_decimal(value, field=field)


def quantize(value: Decimal, scale: int, rounding: Rounding = Rounding.HALF_EVEN) -> Decimal:
    """Quantize ``value`` to ``scale`` decimal places under the wide context."""
    with localcontext() as ctx:
        ctx.prec = INTERNAL_PRECISION
        return value.quantize(Decimal(1).scaleb(-scale), rounding=rounding.value)


def as_quantity(value: Any, *, field: str = "quantity") -> Decimal:
    """Normalize a share quantity, preserving fractional-share precision."""
    return quantize(to_decimal(value, field=field), QUANTITY_SCALE)


def as_amount(value: Any, *, field: str = "amount") -> Decimal:
    """Normalize a monetary amount to the internal amount scale."""
    return quantize(to_decimal(value, field=field), AMOUNT_SCALE)


def as_price(value: Any, *, field: str = "price") -> Decimal:
    """Normalize a per-unit price to the internal price scale."""
    return quantize(to_decimal(value, field=field), PRICE_SCALE)


def as_rate(value: Any, *, field: str = "rate") -> Decimal:
    """Normalize an exchange rate to the internal rate scale."""
    return quantize(to_decimal(value, field=field), RATE_SCALE)


def multiply(*factors: Decimal) -> Decimal:
    """Multiply decimals under the wide internal context without rounding."""
    with localcontext() as ctx:
        ctx.prec = INTERNAL_PRECISION
        result = Decimal(1)
        for factor in factors:
            result *= factor
        return +result


def divide(numerator: Decimal, denominator: Decimal) -> Decimal:
    """Divide under the wide internal context."""
    if denominator == 0:
        raise MoneyError("division by zero in financial calculation")
    with localcontext() as ctx:
        ctx.prec = INTERNAL_PRECISION
        return +(numerator / denominator)


def add(*terms: Decimal) -> Decimal:
    """Sum decimals under the wide internal context."""
    with localcontext() as ctx:
        ctx.prec = INTERNAL_PRECISION
        total = Decimal(0)
        for term in terms:
            total += term
        return +total


def convert(
    native_amount: Decimal,
    fx_rate: Decimal,
    *,
    rate_unit: int = 1,
) -> Decimal:
    """Convert a native-currency amount to INR.

    ``INR_VALUE = FOREIGN_CURRENCY_AMOUNT x APPLICABLE_RATE / RATE_UNIT``

    ``rate_unit`` supports published rates quoted per 100 units (JPY is
    commonly published this way); it is carried on the rate record rather than
    assumed to be 1.
    """
    if rate_unit <= 0:
        raise MoneyError(f"rate_unit must be positive, got {rate_unit}")
    product = multiply(native_amount, fx_rate)
    if rate_unit == 1:
        return product
    return divide(product, Decimal(rate_unit))


def round_for_output(
    value: Decimal,
    *,
    scale: int = 0,
    rounding: Rounding = Rounding.HALF_UP,
) -> Decimal:
    """Round at the presentation/output boundary only.

    Schedule FA money columns are reported in whole rupees, hence the default
    scale of 0. The rounding rule used is recorded alongside every reported
    figure in the calculation-details workpaper.
    """
    return quantize(value, scale, rounding)


def decimal_to_str(value: Decimal | None) -> str | None:
    """Serialize a decimal to a plain (non-exponent) string for storage/JSON."""
    if value is None:
        return None
    normalized = value.normalize() if value == value.to_integral_value() else value
    return format(normalized, "f")


def is_effectively_zero(value: Decimal, *, scale: int = QUANTITY_SCALE) -> bool:
    """True when a residual quantity is zero at the canonical quantity scale.

    Lot allocation leaves sub-scale residuals when a broker reports fractional
    quantities; those residuals are not real open positions.
    """
    return quantize(value, scale) == 0
