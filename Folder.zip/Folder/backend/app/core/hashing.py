"""Content hashing and deterministic identifier derivation.

Identifiers for derived objects (lots, issues, calculation runs) are hashes of
their defining inputs rather than random values. Re-running the pipeline on
identical inputs therefore produces byte-identical identifiers, which is what
makes the determinism requirement testable and makes reprocessing idempotent.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable, Mapping
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

HASH_ALGORITHM = "sha256"
_CHUNK = 1024 * 1024


def hash_bytes(data: bytes) -> str:
    """Return the prefixed SHA-256 digest of ``data``."""
    return f"{HASH_ALGORITHM}:{hashlib.sha256(data).hexdigest()}"


def hash_file(path: str | Path) -> str:
    """Stream a file from disk and return its prefixed SHA-256 digest."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(_CHUNK):
            digest.update(chunk)
    return f"{HASH_ALGORITHM}:{digest.hexdigest()}"


def _canonical(value: Any) -> Any:
    """Coerce a value into a JSON-canonical, order-stable representation."""
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, Decimal):
        # Normalize so that 1.50 and 1.5 hash identically.
        return format(value.normalize(), "f")
    if isinstance(value, float):
        raise TypeError("float values are not hashable in this platform; use Decimal")
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Mapping):
        return {str(k): _canonical(value[k]) for k in sorted(value, key=str)}
    if isinstance(value, (list, tuple)):
        return [_canonical(v) for v in value]
    if isinstance(value, (set, frozenset)):
        return sorted((_canonical(v) for v in value), key=repr)
    if hasattr(value, "model_dump"):
        return _canonical(value.model_dump())
    return str(value)


def canonical_json(payload: Any) -> str:
    """Serialize ``payload`` deterministically: sorted keys, no whitespace drift."""
    return json.dumps(
        _canonical(payload),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


def hash_payload(payload: Any) -> str:
    """Return the prefixed SHA-256 digest of a canonically serialized payload."""
    return hash_bytes(canonical_json(payload).encode("utf-8"))


def derive_id(prefix: str, *parts: Any, length: int = 16) -> str:
    """Derive a short, stable, human-referenceable id from ``parts``.

    Example: ``LOT-3f9a1c2b7d5e4081``. The digest is truncated because these
    identifiers are namespaced within a workspace, not global secrets.
    """
    digest = hash_payload(list(parts)).split(":", 1)[1]
    return f"{prefix}-{digest[:length]}"


def fingerprint(parts: Iterable[Any]) -> str:
    """Return a duplicate-detection fingerprint over the supplied parts."""
    return hash_payload(list(parts))
