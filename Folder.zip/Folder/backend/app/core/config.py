"""Application settings, loaded from the environment.

No secret has a usable default. Where a default exists it is a development-only
value that the settings validator refuses to accept when ``environment`` is
``production``.
"""

from __future__ import annotations

from enum import StrEnum
from functools import lru_cache
from pathlib import Path

from pydantic import field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

REPO_ROOT = Path(__file__).resolve().parents[3]


class Environment(StrEnum):
    LOCAL = "local"
    TEST = "test"
    STAGING = "staging"
    PRODUCTION = "production"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="FA_",
        extra="ignore",
    )

    environment: Environment = Environment.LOCAL
    app_name: str = "Schedule FA Platform"

    # --- database -----------------------------------------------------------
    # SQLite is the zero-dependency local default so the pipeline is runnable
    # without Docker; PostgreSQL is the deployment target and the schema is
    # written against it.
    database_url: str = f"sqlite+pysqlite:///{(REPO_ROOT / 'var' / 'local.db').as_posix()}"
    database_echo: bool = False

    # --- auth ---------------------------------------------------------------
    # An obviously-invalid placeholder. The production guard below refuses to
    # start if it is still in place, so it can never become a real key.
    secret_key: str = "dev-only-insecure-secret-change-me"  # noqa: S105
    access_token_ttl_seconds: int = 3600
    download_url_ttl_seconds: int = 300

    # --- storage ------------------------------------------------------------
    storage_backend: str = "local"
    storage_root: Path = REPO_ROOT / "var" / "storage"
    max_upload_bytes: int = 25 * 1024 * 1024
    allowed_upload_extensions: tuple[str, ...] = (".xlsx", ".xls", ".csv", ".pdf")

    # --- datasets -----------------------------------------------------------
    data_root: Path = REPO_ROOT / "data"

    # --- frontend -----------------------------------------------------------
    # Served by this process so there is one origin, which means no CORS
    # exemption and no third-party host holding a session token. Set to a
    # non-existent path to disable and serve the API alone.
    frontend_root: Path = REPO_ROOT / "frontend"
    serve_frontend: bool = True

    # --- retention ----------------------------------------------------------
    uploaded_file_retention_days: int = 365
    audit_retention_days: int = 2555

    # --- jobs ---------------------------------------------------------------
    redis_url: str | None = None
    job_backend: str = "inline"

    # --- outbound network ---------------------------------------------------
    # Ingestion of external datasets is a controlled, operator-initiated action.
    # It is off by default so that no user calculation can trigger a live fetch.
    allow_outbound_ingestion: bool = False
    ingestion_allowed_hosts: tuple[str, ...] = (
        "raw.githubusercontent.com",
        "github.com",
        "sbi.co.in",
        "www.sbi.co.in",
    )

    # --- rate limiting ------------------------------------------------------
    rate_limit_requests_per_minute: int = 120
    upload_rate_limit_per_hour: int = 40

    @field_validator("storage_root", "data_root", "frontend_root", mode="after")
    @classmethod
    def _expand(cls, value: Path) -> Path:
        return value.expanduser().resolve()

    @model_validator(mode="after")
    def _production_guards(self) -> Settings:
        if self.environment is Environment.PRODUCTION:
            if self.secret_key.startswith("dev-only"):
                raise ValueError("FA_SECRET_KEY must be set to a real secret in production")
            if self.database_url.startswith("sqlite"):
                raise ValueError("PostgreSQL is required in production; set FA_DATABASE_URL")
        if self.max_upload_bytes <= 0:
            raise ValueError("FA_MAX_UPLOAD_BYTES must be positive")
        return self

    @property
    def is_production(self) -> bool:
        return self.environment is Environment.PRODUCTION


@lru_cache
def get_settings() -> Settings:
    """Return the process-wide settings instance."""
    return Settings()
