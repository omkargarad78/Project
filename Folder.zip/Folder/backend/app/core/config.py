"""Application settings, loaded from the environment.

No secret has a usable default. Where a default exists it is a development-only
value that the settings validator refuses to accept when ``environment`` is
``production``.
"""

from __future__ import annotations

from enum import StrEnum
from functools import lru_cache
from pathlib import Path

from pydantic import field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

REPO_ROOT = Path(__file__).resolve().parents[3]


class Environment(StrEnum):
    LOCAL = "local"
    TEST = "test"
    STAGING = "staging"
    PRODUCTION = "production"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="FA_",
        extra="ignore",
    )

    environment: Environment = Environment.LOCAL
    app_name: str = "Schedule FA Platform"

    # --- database -----------------------------------------------------------
    # SQLite is the zero-dependency local default so the pipeline is runnable
    # without Docker; PostgreSQL is the deployment target and the schema is
    # written against it.
    database_url: str = f"sqlite+pysqlite:///{(REPO_ROOT / 'var' / 'local.db').as_posix()}"
    database_echo: bool = False

    # --- auth ---------------------------------------------------------------
    # An obviously-invalid placeholder. The production guard below refuses to
    # start if it is still in place, so it can never become a real key.
    secret_key: str = "dev-only-insecure-secret-change-me"  # noqa: S105
    access_token_ttl_seconds: int = 3600
    download_url_ttl_seconds: int = 300

    # --- storage ------------------------------------------------------------
    storage_backend: str = "local"
    storage_root: Path = REPO_ROOT / "var" / "storage"
    max_upload_bytes: int = 25 * 1024 * 1024
    allowed_upload_extensions: tuple[str, ...] = (".xlsx", ".xls", ".csv", ".pdf")

    # --- datasets -----------------------------------------------------------
    data_root: Path = REPO_ROOT / "data"

    # --- frontend -----------------------------------------------------------
    # Served by this process so there is one origin, which means no CORS
    # exemption and no third-party host holding a session token. Set to a
    # non-existent path to disable and serve the API alone.
    frontend_root: Path = REPO_ROOT / "frontend"
    serve_frontend: bool = True

    # --- retention ----------------------------------------------------------
    uploaded_file_retention_days: int = 365
    audit_retention_days: int = 2555

    # --- jobs ---------------------------------------------------------------
    redis_url: str | None = None
    job_backend: str = "inline"

    # --- outbound network ---------------------------------------------------
    # Retrieval of external datasets. On by default so a fresh install can
    # calculate without a manual import step.
    #
    # The guarantee this does *not* weaken: a calculation still reads only
    # from a stored, immutable dataset version. Retrieval writes a snapshot to
    # disk first, and the run pins the name and version of that snapshot. So
    # re-running a past calculation never touches the network and never picks
    # up restated data. Turn this off to require manual imports instead.
    allow_outbound_ingestion: bool = True
    ingestion_allowed_hosts: tuple[str, ...] = (
        "raw.githubusercontent.com",
        "github.com",
        "sbi.co.in",
        "www.sbi.co.in",
        # Daily OHLC for US equities, no API key. Used to snapshot the
        # prices needed for peak and closing values.
        "query1.finance.yahoo.com",
        "query2.finance.yahoo.com",
    )

    #: Path to a PEM bundle for outbound HTTPS. Needed on a network that
    #: inspects TLS, where the proxy's root is in the operating system store
    #: but not in the bundle httpx ships with. Verification is never
    #: disabled; this only says which roots to trust.
    ca_bundle: Path | None = None

    # --- automatic provisioning ---------------------------------------------
    # Download and install the reference data the engine needs, rather than
    # making the user run the import commands by hand.
    #
    # Refresh happens at startup, in the background, so a slow or absent
    # network delays nothing. A failure leaves the previously installed
    # dataset in place and is reported on the health endpoint.
    auto_bootstrap_datasets: bool = True
    #: Re-download the rate dataset if the installed copy is older than this.
    #: Rates for past dates never change, so this only needs to be frequent
    #: enough to pick up recently published days.
    fx_refresh_after_hours: int = 12
    #: Fetch and snapshot the prices a statement needs, when it is uploaded.
    auto_fetch_prices: bool = True
    #: Start a calculation as soon as a statement finishes uploading.
    auto_run_on_upload: bool = True

    # --- rate limiting ------------------------------------------------------
    rate_limit_requests_per_minute: int = 120
    upload_rate_limit_per_hour: int = 40

    @field_validator("storage_root", "data_root", "frontend_root", mode="after")
    @classmethod
    def _expand(cls, value: Path) -> Path:
        return value.expanduser().resolve()

    @model_validator(mode="after")
    def _no_network_under_test(self) -> Settings:
        """A test must never depend on a third party being reachable.

        Forced rather than left to each test's configuration: a suite that
        silently starts downloading is slow, flaky, and produces different
        results on a train. Tests that exercise provisioning pass an explicit
        stub instead.
        """
        if self.environment is Environment.TEST:
            object.__setattr__(self, "auto_bootstrap_datasets", False)
            object.__setattr__(self, "auto_fetch_prices", False)
            object.__setattr__(self, "allow_outbound_ingestion", False)
        return self

    @model_validator(mode="after")
    def _production_guards(self) -> Settings:
        if self.environment is Environment.PRODUCTION:
            if self.secret_key.startswith("dev-only"):
                raise ValueError("FA_SECRET_KEY must be set to a real secret in production")
            if self.database_url.startswith("sqlite"):
                raise ValueError("PostgreSQL is required in production; set FA_DATABASE_URL")
        if self.max_upload_bytes <= 0:
            raise ValueError("FA_MAX_UPLOAD_BYTES must be positive")
        return self

    @property
    def is_production(self) -> bool:
        return self.environment is Environment.PRODUCTION


@lru_cache
def get_settings() -> Settings:
    """Return the process-wide settings instance."""
    return Settings()
