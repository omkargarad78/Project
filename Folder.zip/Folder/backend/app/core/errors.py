"""Platform error-code catalogue.

Every condition the pipeline can raise or flag has a stable code, a severity, a
human-readable explanation and remediation instructions. Codes are part of the
API contract and appear in the validation report sheet of generated workpapers,
so they must not be renamed without a migration note.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import StrEnum


class Severity(StrEnum):
    """Validation severity levels.

    ERROR   - calculation cannot be safely completed.
    WARNING - calculation can be completed but user review is required.
    INFO    - informational condition.
    """

    ERROR = "ERROR"
    WARNING = "WARNING"
    INFO = "INFO"


class ErrorCode(StrEnum):
    """Stable machine-readable condition codes."""

    # --- FX ---
    FX_RATE_MISSING = "FX_RATE_MISSING"
    FX_RATE_UNVERIFIED = "FX_RATE_UNVERIFIED"
    FX_RATE_TYPE_MISMATCH = "FX_RATE_TYPE_MISMATCH"
    FX_DATASET_MISSING = "FX_DATASET_MISSING"
    FX_RATE_AMBIGUOUS = "FX_RATE_AMBIGUOUS"

    # --- securities ---
    SECURITY_UNRESOLVED = "SECURITY_UNRESOLVED"
    SECURITY_AMBIGUOUS = "SECURITY_AMBIGUOUS"
    SECURITY_DETAILS_UNCONFIRMED = "SECURITY_DETAILS_UNCONFIRMED"
    SECURITY_NAME_MISMATCH = "SECURITY_NAME_MISMATCH"
    SECURITY_ENTITY_NAME_MISSING = "SECURITY_ENTITY_NAME_MISSING"
    SECURITY_ADDRESS_MISSING = "SECURITY_ADDRESS_MISSING"
    SECURITY_ZIP_MISSING = "SECURITY_ZIP_MISSING"
    SECURITY_COUNTRY_MISSING = "SECURITY_COUNTRY_MISSING"
    SECURITY_NATURE_MISSING = "SECURITY_NATURE_MISSING"

    # --- transactions / lots ---
    ACQUISITION_DATE_MISSING = "ACQUISITION_DATE_MISSING"
    ACQUISITION_COST_MISSING = "ACQUISITION_COST_MISSING"
    MARKET_PRICE_MISSING = "MARKET_PRICE_MISSING"
    MARKET_PRICE_STALE = "MARKET_PRICE_STALE"
    MARKET_PRICE_CURRENCY_MISMATCH = "MARKET_PRICE_CURRENCY_MISMATCH"
    PRICE_ADJUSTMENT_BASIS_UNKNOWN = "PRICE_ADJUSTMENT_BASIS_UNKNOWN"
    PRICE_ADJUSTMENT_BASIS_MISMATCH = "PRICE_ADJUSTMENT_BASIS_MISMATCH"
    MARKET_DATA_DATASET_MISSING = "MARKET_DATA_DATASET_MISSING"
    CORPORATE_ACTION_MISSING = "CORPORATE_ACTION_MISSING"
    CORPORATE_ACTION_UNVERIFIED = "CORPORATE_ACTION_UNVERIFIED"
    LOT_RECONCILIATION_FAILED = "LOT_RECONCILIATION_FAILED"
    CASH_RECONCILIATION_FAILED = "CASH_RECONCILIATION_FAILED"
    OVERSOLD_POSITION = "OVERSOLD_POSITION"
    DUPLICATE_TRANSACTION = "DUPLICATE_TRANSACTION"
    UNSUPPORTED_TRANSACTION = "UNSUPPORTED_TRANSACTION"
    MISSING_HISTORICAL_DATA = "MISSING_HISTORICAL_DATA"

    # --- source files / parsing ---
    SOURCE_FILE_CORRUPT = "SOURCE_FILE_CORRUPT"
    SOURCE_FILE_UNSUPPORTED = "SOURCE_FILE_UNSUPPORTED"
    BROKER_UNIDENTIFIED = "BROKER_UNIDENTIFIED"
    BROKER_FORMAT_CHANGED = "BROKER_FORMAT_CHANGED"
    SCHEMA_VALIDATION_FAILED = "SCHEMA_VALIDATION_FAILED"
    SOURCE_FILE_DUPLICATE = "SOURCE_FILE_DUPLICATE"

    # --- tax rules / periods ---
    REPORTING_PERIOD_INVALID = "REPORTING_PERIOD_INVALID"
    TAX_RULE_VERSION_MISSING = "TAX_RULE_VERSION_MISSING"
    TAX_RULE_UNVERIFIED = "TAX_RULE_UNVERIFIED"
    FORM_SCHEMA_MISSING = "FORM_SCHEMA_MISSING"
    VALUATION_POLICY_MISSING = "VALUATION_POLICY_MISSING"

    # --- overrides / provenance ---
    MANUAL_OVERRIDE_PRESENT = "MANUAL_OVERRIDE_PRESENT"
    SECONDARY_SOURCE_USED = "SECONDARY_SOURCE_USED"
    NON_EXCHANGE_PRICE_SOURCE = "NON_EXCHANGE_PRICE_SOURCE"
    CALCULATION_INCOMPLETE = "CALCULATION_INCOMPLETE"

    # --- account details the user must supply ---
    ACCOUNT_DETAILS_MISSING = "ACCOUNT_DETAILS_MISSING"
    INSTITUTION_DETAILS_MISSING = "INSTITUTION_DETAILS_MISSING"


class ResolutionAction(StrEnum):
    """What a user has to do to clear a condition.

    Issues are grouped by this in the worklist, because the unit of work is
    the action, not the issue. Two hundred missing-rate issues are one trip to
    import a rate dataset, and presenting them as two hundred tasks would
    misrepresent the effort and bury the other five things that need doing.
    """

    IMPORT_FX_DATASET = "IMPORT_FX_DATASET"
    IMPORT_PRICE_DATA = "IMPORT_PRICE_DATA"
    UPLOAD_EARLIER_STATEMENT = "UPLOAD_EARLIER_STATEMENT"
    CORRECT_SOURCE_FILE = "CORRECT_SOURCE_FILE"
    SUPPLY_ENTITY_DETAILS = "SUPPLY_ENTITY_DETAILS"
    SUPPLY_ACCOUNT_DETAILS = "SUPPLY_ACCOUNT_DETAILS"
    CONFIRM_TAX_RULES = "CONFIRM_TAX_RULES"
    EXTEND_BROKER_SUPPORT = "EXTEND_BROKER_SUPPORT"
    #: Nothing to fix; the user decides whether to accept it.
    ACKNOWLEDGE = "ACKNOWLEDGE"
    #: Informational, or a consequence of other issues rather than its own task.
    REVIEW_ONLY = "REVIEW_ONLY"

    @property
    def label(self) -> str:
        return _ACTION_LABELS[self]


_ACTION_LABELS: dict[ResolutionAction, str] = {
    ResolutionAction.IMPORT_FX_DATASET: "Import exchange-rate data",
    ResolutionAction.IMPORT_PRICE_DATA: "Import market-price data",
    ResolutionAction.UPLOAD_EARLIER_STATEMENT: "Upload an earlier broker statement",
    ResolutionAction.CORRECT_SOURCE_FILE: "Correct or re-export the source file",
    ResolutionAction.SUPPLY_ENTITY_DETAILS: "Supply the entity's reporting details",
    ResolutionAction.SUPPLY_ACCOUNT_DETAILS: "Supply the account's reporting details",
    ResolutionAction.CONFIRM_TAX_RULES: "Confirm the tax rules for this year",
    ResolutionAction.EXTEND_BROKER_SUPPORT: "Extend broker support",
    ResolutionAction.ACKNOWLEDGE: "Review and accept",
    ResolutionAction.REVIEW_ONLY: "Review only",
}


@dataclass(frozen=True, slots=True)
class ErrorDefinition:
    """Static metadata for an :class:`ErrorCode`."""

    code: ErrorCode
    default_severity: Severity
    title: str
    explanation: str
    remediation: str
    #: What the user must do about it. Set from ``_WORKFLOW`` below.
    action: ResolutionAction = ResolutionAction.REVIEW_ONLY
    #: Whether accepting the condition is enough to let a filing proceed.
    #: False means the figure genuinely does not exist until the data arrives,
    #: so no amount of acknowledgement can produce it.
    waivable: bool = True


def _d(
    code: ErrorCode,
    severity: Severity,
    title: str,
    explanation: str,
    remediation: str,
) -> tuple[ErrorCode, ErrorDefinition]:
    return code, ErrorDefinition(code, severity, title, explanation, remediation)


_CATALOG: dict[ErrorCode, ErrorDefinition] = dict(
    [
        _d(
            ErrorCode.FX_RATE_MISSING,
            Severity.ERROR,
            "SBI TT buying rate not available",
            "No SBI telegraphic transfer buying rate is present in the imported rate "
            "dataset for the currency and date this figure requires. The platform does "
            "not substitute a different rate or a different date's rate on its own.",
            "Import an SBI rate dataset that covers this date, or record a manual rate "
            "override on the Review Issues page with the supporting SBI rate document.",
        ),
        _d(
            ErrorCode.FX_RATE_UNVERIFIED,
            Severity.WARNING,
            "Exchange rate could not be verified against an official SBI document",
            "A rate was found but its provenance chain does not reach an official SBI "
            "publication, so it is carried as sourced data pending verification.",
            "Attach the SBI rate document reference to the rate dataset, or confirm that "
            "the secondary historical dataset is acceptable for your review.",
        ),
        _d(
            ErrorCode.FX_RATE_TYPE_MISMATCH,
            Severity.ERROR,
            "Exchange rate is not a TT buying rate",
            "The rate selected for this figure is not an SBI telegraphic transfer buying "
            "rate. TT selling, bill buying, bill selling, card and market mid rates are "
            "different rate types and are not interchangeable.",
            "Import a dataset containing the TT buying rate for this currency and date.",
        ),
        _d(
            ErrorCode.FX_DATASET_MISSING,
            Severity.ERROR,
            "No exchange-rate dataset selected",
            "The calculation run has no FX dataset version bound to it, so no rate "
            "lookup can be performed or reproduced.",
            "Import an SBI TTBR dataset and select its version for this workspace.",
        ),
        _d(
            ErrorCode.FX_RATE_AMBIGUOUS,
            Severity.ERROR,
            "More than one candidate exchange rate for the same date",
            "The dataset contains multiple TT buying rates for this currency and date "
            "and the configured selection policy could not choose between them "
            "deterministically.",
            "Review the rate records for this date and configure an explicit selection "
            "policy, or resolve the rate manually with source evidence.",
        ),
        _d(
            ErrorCode.SECURITY_UNRESOLVED,
            Severity.ERROR,
            "Security identity unresolved",
            "The ticker in the broker file could not be resolved to a security master "
            "entry, so the reported entity details for this holding are unknown.",
            "Confirm the security's legal entity name and country on the Security Master "
            "page. The platform will not infer an entity from a ticker symbol.",
        ),
        _d(
            ErrorCode.SECURITY_AMBIGUOUS,
            Severity.ERROR,
            "A ticker symbol matches more than one security",
            "The same symbol names different securities on different exchanges, and "
            "more than one security master entry claims it for this date. Choosing "
            "between them arbitrarily would put a confident but wrong entity name and "
            "country on the return.",
            "Open the Security Master page and set the exchange for this holding, or "
            "narrow the validity dates on the entries that should not apply.",
        ),
        _d(
            ErrorCode.SECURITY_DETAILS_UNCONFIRMED,
            Severity.WARNING,
            "Security identity not confirmed against an official source",
            "A security master entry supplied the entity name or country, but nobody "
            "has checked it against the company's filings. The platform calculates "
            "with it and labels it, rather than blocking or silently trusting it.",
            "Open the Security Master page, compare the entry against the company's "
            "official filings, and mark it confirmed with the source reference.",
        ),
        _d(
            ErrorCode.SECURITY_NAME_MISMATCH,
            Severity.WARNING,
            "Broker display name differs from the recorded legal entity name",
            "The broker's display string for this ticker does not match the legal "
            "entity name in the security master. Either the master entry is for the "
            "wrong company, or the broker abbreviates the name. Only a human can tell "
            "which, and the report uses the master's legal name either way.",
            "Confirm on the Security Master page that the entry is the right company "
            "for this ticker.",
        ),
        _d(
            ErrorCode.SECURITY_ENTITY_NAME_MISSING,
            Severity.ERROR,
            "Legal entity name missing",
            "Schedule FA reports the name of the entity, which is not the same as the "
            "broker's ticker symbol or display name.",
            "Enter the legal entity name for this security in the security master.",
        ),
        _d(
            ErrorCode.SECURITY_ADDRESS_MISSING,
            Severity.WARNING,
            "Entity address unavailable",
            "The broker export does not contain the entity's address and no security "
            "master entry supplies one. The platform does not invent an address.",
            "Add the entity address from the company's official filings, or leave it "
            "blank and confirm the omission with your tax professional.",
        ),
        _d(
            ErrorCode.SECURITY_ZIP_MISSING,
            Severity.WARNING,
            "Entity ZIP/postal code unavailable",
            "No ZIP or postal code is available for this entity from the broker data or "
            "the security master.",
            "Add the ZIP/postal code in the security master if your filing requires it.",
        ),
        _d(
            ErrorCode.SECURITY_COUNTRY_MISSING,
            Severity.ERROR,
            "Entity country missing",
            "Schedule FA requires a country name and country code for each reported "
            "foreign interest.",
            "Set the country of incorporation for this security in the security master.",
        ),
        _d(
            ErrorCode.SECURITY_NATURE_MISSING,
            Severity.WARNING,
            "Nature of entity not set",
            "The nature of the entity (for example, a listed company or an exchange "
            "traded fund) has not been confirmed for this security.",
            "Set the nature of entity in the security master.",
        ),
        _d(
            ErrorCode.ACQUISITION_DATE_MISSING,
            Severity.ERROR,
            "Acquisition date missing for a reported holding",
            "A position was held during the reporting period but the uploaded files do "
            "not contain the transaction that acquired it, so its date of acquiring the "
            "interest and its initial value are unknown.",
            "Upload the earlier broker statement covering the acquisition, or enter the "
            "acquisition date, quantity and cost manually; the entry is recorded in the "
            "audit trail as a manual input.",
        ),
        _d(
            ErrorCode.ACQUISITION_COST_MISSING,
            Severity.ERROR,
            "Acquisition cost missing for a reported holding",
            "The acquisition transaction for this lot has no usable cost amount, so the "
            "initial value of the investment cannot be calculated.",
            "Provide the acquisition cost from the broker statement or a manual entry.",
        ),
        _d(
            ErrorCode.MARKET_PRICE_MISSING,
            Severity.ERROR,
            "Market price missing for a valuation date",
            "A peak or closing valuation requires a market price for this security and "
            "date, and none is present in the selected market-data snapshot.",
            "Import market prices covering the reporting period for this security, or "
            "enter the price manually with its source.",
        ),
        _d(
            ErrorCode.MARKET_PRICE_STALE,
            Severity.WARNING,
            "Price carried forward from an earlier trading day",
            "No price was published for this security on the valuation date, so the "
            "most recent earlier price was used. On a weekend or an exchange holiday "
            "this is the normal convention and the last traded price is the correct "
            "value. Over a longer gap it may instead mean the data is incomplete or "
            "the security stopped trading.",
            "Check the gap length shown against the exchange calendar. If the security "
            "was trading on those days, import a more complete price dataset.",
        ),
        _d(
            ErrorCode.MARKET_PRICE_CURRENCY_MISMATCH,
            Severity.ERROR,
            "Price is quoted in a different currency from the holding",
            "The price found for this security is denominated in a currency that does "
            "not match the security's trading currency. Converting it as though the "
            "currencies matched would misstate the value by the whole exchange rate.",
            "Import a price series quoted in the security's trading currency, or "
            "correct the trading currency in the security master.",
        ),
        _d(
            ErrorCode.PRICE_ADJUSTMENT_BASIS_UNKNOWN,
            Severity.ERROR,
            "Price series adjustment basis not stated",
            "The dataset does not say whether its prices are adjusted for splits. A "
            "split-adjusted price multiplied by the share count you actually held "
            "before the split understates the holding by the whole split ratio, and "
            "nothing in the numbers reveals the error.",
            "Set the adjustment basis when importing the dataset. If the provider does "
            "not state it, check a security that split during the period: an adjusted "
            "series shows no price jump on the ex-date.",
        ),
        _d(
            ErrorCode.PRICE_ADJUSTMENT_BASIS_MISMATCH,
            Severity.ERROR,
            "Price adjustment basis does not match the share quantities",
            "Adjusted prices were paired with unadjusted historical share counts, or "
            "the reverse. The two must be on the same basis: either raw prices with "
            "the shares actually held on each date, or adjusted prices with adjusted "
            "share counts.",
            "Use an unadjusted price series, or enable quantity adjustment so the "
            "share counts are restated onto the same basis as the prices.",
        ),
        _d(
            ErrorCode.MARKET_DATA_DATASET_MISSING,
            Severity.ERROR,
            "No market-data snapshot selected",
            "Peak and closing valuation need a market-data snapshot, and none is "
            "attached to this calculation.",
            "Import a price dataset covering the reporting period and select it for "
            "this workspace.",
        ),
        _d(
            ErrorCode.CORPORATE_ACTION_UNVERIFIED,
            Severity.WARNING,
            "Corporate action not confirmed against an official source",
            "A split, merger or similar event is recorded but has not been checked "
            "against the company's announcement. Its ratio changes every share count "
            "after the ex-date.",
            "Confirm the ratio and ex-date against the company's filing or the "
            "exchange notice, then mark the action verified.",
        ),
        _d(
            ErrorCode.CORPORATE_ACTION_MISSING,
            Severity.ERROR,
            "Possible unrecorded corporate action",
            "The share quantity or price series for this security implies a split, "
            "merger or similar event that is not present in the corporate-action data. "
            "Valuing the holding without it can produce a materially wrong peak value.",
            "Add the corporate action, or confirm that the price series and quantity "
            "ledger are on the same adjustment basis.",
        ),
        _d(
            ErrorCode.LOT_RECONCILIATION_FAILED,
            Severity.ERROR,
            "Reconstructed holdings do not reconcile",
            "The quantity derived from the transaction ledger does not match the closing "
            "holdings reported by the broker.",
            "Check for missing statements, unsupported transaction types or duplicate "
            "transactions, then re-run the calculation.",
        ),
        _d(
            ErrorCode.CASH_RECONCILIATION_FAILED,
            Severity.ERROR,
            "Cash ledger does not reconcile",
            "Opening cash plus credits less debits does not equal the closing cash "
            "balance reported by the broker.",
            "Check for missing cash transactions, fees or transfers in the uploaded "
            "statements.",
        ),
        _d(
            ErrorCode.OVERSOLD_POSITION,
            Severity.ERROR,
            "Disposal exceeds available quantity",
            "A sale or transfer out is larger than the quantity the ledger shows as held "
            "on that date, which usually means an earlier acquisition statement is "
            "missing.",
            "Upload the earlier statement containing the missing acquisition, or record "
            "the opening position manually.",
        ),
        _d(
            ErrorCode.DUPLICATE_TRANSACTION,
            Severity.WARNING,
            "Potential duplicate transaction",
            "Two transactions share the same fingerprint of broker, account, date, "
            "ticker, activity, quantity and amount. Duplicates are flagged, never "
            "removed automatically.",
            "Confirm whether these are two genuinely identical transactions or the same "
            "transaction imported twice, then mark the issue resolved.",
        ),
        _d(
            ErrorCode.UNSUPPORTED_TRANSACTION,
            Severity.WARNING,
            "Transaction type not recognised by the parser",
            "The broker statement contains an activity label the parser does not map to "
            "a canonical transaction type. It is retained as UNKNOWN and excluded from "
            "calculations.",
            "Review the transaction. If it affects holdings or cash, it must be mapped "
            "before the report can be relied on.",
        ),
        _d(
            ErrorCode.MISSING_HISTORICAL_DATA,
            Severity.ERROR,
            "Earlier statement appears to be missing",
            "A security had activity during the reporting period that implies it was "
            "held before the earliest uploaded statement.",
            "Upload the broker statements for the earlier periods.",
        ),
        _d(
            ErrorCode.SOURCE_FILE_CORRUPT,
            Severity.ERROR,
            "Uploaded file could not be read",
            "The file is not a readable workbook or delimited file, or its internal "
            "structure is damaged.",
            "Re-download the statement from the broker and upload it again.",
        ),
        _d(
            ErrorCode.SOURCE_FILE_UNSUPPORTED,
            Severity.ERROR,
            "File type not supported",
            "The uploaded file's type is not among the accepted statement formats.",
            "Upload the broker's transaction statement as .xlsx, .xls or .csv.",
        ),
        _d(
            ErrorCode.BROKER_UNIDENTIFIED,
            Severity.ERROR,
            "Broker could not be identified",
            "No registered broker parser recognised the structure of this file, so no "
            "best-effort parse is attempted.",
            "Confirm the file is an unmodified broker export. If the broker is not yet "
            "supported, a parser module is required before it can be processed.",
        ),
        _d(
            ErrorCode.BROKER_FORMAT_CHANGED,
            Severity.ERROR,
            "Broker export format differs from the supported layout",
            "The file was identified as this broker's export but required columns are "
            "missing or renamed, which means the export format has changed.",
            "Report the format change so the parser can be updated. The platform stops "
            "rather than guessing which column holds which value.",
        ),
        _d(
            ErrorCode.SCHEMA_VALIDATION_FAILED,
            Severity.ERROR,
            "Parsed rows failed schema validation",
            "One or more parsed rows contain values that are not valid for their field, "
            "such as an unparseable date or a non-numeric quantity.",
            "Inspect the flagged rows in the parser report and correct the source file.",
        ),
        _d(
            ErrorCode.SOURCE_FILE_DUPLICATE,
            Severity.INFO,
            "File already uploaded",
            "A file with an identical cryptographic hash is already present in this "
            "workspace, so it was not processed again.",
            "No action needed. Create an explicit new file version if you intend to "
            "process the same content a second time.",
        ),
        _d(
            ErrorCode.REPORTING_PERIOD_INVALID,
            Severity.ERROR,
            "Reporting period could not be established",
            "The Schedule FA reporting period for the selected assessment year is not "
            "configured, so no period-bounded figure can be calculated.",
            "Configure the reporting period for this assessment year from the official "
            "form instructions.",
        ),
        _d(
            ErrorCode.TAX_RULE_VERSION_MISSING,
            Severity.ERROR,
            "No tax rule version for the selected assessment year",
            "The rule registry has no active rule version covering the selected "
            "assessment year. Another year's rules are never substituted.",
            "Add a tax rule version for this assessment year, citing the official form "
            "and instructions.",
        ),
        _d(
            ErrorCode.TAX_RULE_UNVERIFIED,
            Severity.WARNING,
            "Tax rule version not yet verified against the official source",
            "A rule version exists for this assessment year, but its reporting period, "
            "exchange-rate convention and form schema have not been confirmed against "
            "the Income Tax Department's published form and instructions for that year. "
            "The platform will calculate using the configured rule and label every "
            "affected figure, rather than substituting another year's rules.",
            "Open the Methodology page, compare the configured rule against the official "
            "form and instructions for this assessment year, and mark the rule version "
            "verified with the source document reference.",
        ),
        _d(
            ErrorCode.FORM_SCHEMA_MISSING,
            Severity.ERROR,
            "No Schedule FA form schema for the selected assessment year",
            "Output columns are driven by the official form schema for the assessment "
            "year, and no schema is registered for this year.",
            "Register the form schema for this assessment year before generating output.",
        ),
        _d(
            ErrorCode.VALUATION_POLICY_MISSING,
            Severity.ERROR,
            "No valuation policy configured",
            "Peak and closing valuation require an explicit price valuation policy; the "
            "platform does not pick one implicitly.",
            "Select a price valuation policy for this workspace.",
        ),
        _d(
            ErrorCode.MANUAL_OVERRIDE_PRESENT,
            Severity.WARNING,
            "Manual override used",
            "One or more figures in this calculation rely on a manual override rather "
            "than sourced data. Each override is recorded with its original value, new "
            "value, reason, user and timestamp.",
            "Review the overrides listed in the Assumptions & Review sheet before filing.",
        ),
        _d(
            ErrorCode.SECONDARY_SOURCE_USED,
            Severity.WARNING,
            "Rate came from a secondary historical dataset",
            "The exchange rate was taken from a maintained historical dataset rather "
            "than a retrieved official SBI publication. The dataset is treated as "
            "sourced data, not as statutory authority.",
            "Verify the rate against the SBI rate document for that date if your review "
            "requires a primary source.",
        ),
        _d(
            ErrorCode.NON_EXCHANGE_PRICE_SOURCE,
            Severity.WARNING,
            "Market-price source is not official exchange data",
            "Prices used for valuation came from a market-data provider rather than the "
            "listing exchange's official record.",
            "Confirm the price source is acceptable for your review, or import exchange "
            "data.",
        ),
        _d(
            ErrorCode.CALCULATION_INCOMPLETE,
            Severity.ERROR,
            "Calculation incomplete",
            "Essential inputs are missing, so this calculation run is not in a state "
            "where a final report can be generated.",
            "Resolve the blocking issues on the Review Issues page and re-run.",
        ),
        _d(
            ErrorCode.ACCOUNT_DETAILS_MISSING,
            Severity.ERROR,
            "Account details required by the form are not available",
            "Schedule FA Table A2 asks for the account number, the ownership status "
            "and the account opening date. A transaction export does not contain any "
            "of these, and none of them can be derived from it: the earliest "
            "transaction in a file is not the date the account was opened, because the "
            "file may simply begin later than the account does.",
            "Enter the account number, status and opening date from your account "
            "statement or the broker's account-opening confirmation.",
        ),
        _d(
            ErrorCode.INSTITUTION_DETAILS_MISSING,
            Severity.ERROR,
            "Financial institution's reporting details are not confirmed",
            "Schedule FA Table A2 asks for the name, address and country of the "
            "financial institution holding the account. The app or brand an account "
            "was opened through, the introducing broker and the clearing custodian "
            "are frequently three different legal entities, and the platform will "
            "not guess which of them the form is asking about.",
            "Confirm from your account statement which institution holds the "
            "account, and record its legal name, address and country in the "
            "institution master.",
        ),
    ]
)


#: What the user must do about each condition, and whether accepting it is
#: enough to file.
#:
#: Kept as one table rather than spread through the catalogue above, because
#: the question it answers -- "which errors can be waived?" -- is a safety
#: question that has to be reviewable in one place. A waiver is the only way
#: the platform's guard rails can be stepped around, so the full list of
#: what is steppable has to be short and readable.
#:
#: The distinction is not severity. It is whether the figure can still be
#: produced correctly. A missing exchange rate is not waivable because there
#: is no rupee figure to report without it, no matter who accepts what. A
#: holding that disagrees with the broker's stated closing balance *is*
#: waivable, because every figure is computed and the user may legitimately
#: know the broker's own number is stale.
_WORKFLOW: dict[ErrorCode, tuple[ResolutionAction, bool]] = {
    # Exchange rates: without a rate there is no rupee figure at all.
    ErrorCode.FX_RATE_MISSING: (ResolutionAction.IMPORT_FX_DATASET, False),
    ErrorCode.FX_DATASET_MISSING: (ResolutionAction.IMPORT_FX_DATASET, False),
    ErrorCode.FX_RATE_TYPE_MISMATCH: (ResolutionAction.IMPORT_FX_DATASET, False),
    ErrorCode.FX_RATE_AMBIGUOUS: (ResolutionAction.IMPORT_FX_DATASET, False),
    ErrorCode.FX_RATE_UNVERIFIED: (ResolutionAction.ACKNOWLEDGE, True),
    ErrorCode.SECONDARY_SOURCE_USED: (ResolutionAction.ACKNOWLEDGE, True),
    # Entity identity: the form has a box for each of these and it must be filled.
    ErrorCode.SECURITY_UNRESOLVED: (ResolutionAction.SUPPLY_ENTITY_DETAILS, False),
    ErrorCode.SECURITY_AMBIGUOUS: (ResolutionAction.SUPPLY_ENTITY_DETAILS, False),
    ErrorCode.SECURITY_ENTITY_NAME_MISSING: (
        ResolutionAction.SUPPLY_ENTITY_DETAILS,
        False,
    ),
    ErrorCode.SECURITY_COUNTRY_MISSING: (ResolutionAction.SUPPLY_ENTITY_DETAILS, False),
    ErrorCode.SECURITY_ADDRESS_MISSING: (ResolutionAction.SUPPLY_ENTITY_DETAILS, True),
    ErrorCode.SECURITY_ZIP_MISSING: (ResolutionAction.SUPPLY_ENTITY_DETAILS, True),
    ErrorCode.SECURITY_NATURE_MISSING: (ResolutionAction.SUPPLY_ENTITY_DETAILS, True),
    ErrorCode.SECURITY_DETAILS_UNCONFIRMED: (
        ResolutionAction.SUPPLY_ENTITY_DETAILS,
        True,
    ),
    ErrorCode.SECURITY_NAME_MISMATCH: (ResolutionAction.SUPPLY_ENTITY_DETAILS, True),
    ErrorCode.ACCOUNT_DETAILS_MISSING: (ResolutionAction.SUPPLY_ACCOUNT_DETAILS, False),
    ErrorCode.INSTITUTION_DETAILS_MISSING: (
        ResolutionAction.SUPPLY_ACCOUNT_DETAILS,
        False,
    ),
    # Missing acquisition history: only an earlier statement supplies it.
    ErrorCode.ACQUISITION_DATE_MISSING: (
        ResolutionAction.UPLOAD_EARLIER_STATEMENT,
        False,
    ),
    ErrorCode.ACQUISITION_COST_MISSING: (
        ResolutionAction.UPLOAD_EARLIER_STATEMENT,
        False,
    ),
    ErrorCode.MISSING_HISTORICAL_DATA: (
        ResolutionAction.UPLOAD_EARLIER_STATEMENT,
        False,
    ),
    ErrorCode.OVERSOLD_POSITION: (ResolutionAction.UPLOAD_EARLIER_STATEMENT, False),
    # Market data.
    ErrorCode.MARKET_PRICE_MISSING: (ResolutionAction.IMPORT_PRICE_DATA, False),
    ErrorCode.MARKET_PRICE_CURRENCY_MISMATCH: (
        ResolutionAction.IMPORT_PRICE_DATA,
        False,
    ),
    ErrorCode.PRICE_ADJUSTMENT_BASIS_UNKNOWN: (
        ResolutionAction.IMPORT_PRICE_DATA,
        False,
    ),
    ErrorCode.PRICE_ADJUSTMENT_BASIS_MISMATCH: (
        ResolutionAction.IMPORT_PRICE_DATA,
        False,
    ),
    ErrorCode.MARKET_DATA_DATASET_MISSING: (ResolutionAction.IMPORT_PRICE_DATA, False),
    ErrorCode.CORPORATE_ACTION_MISSING: (ResolutionAction.IMPORT_PRICE_DATA, False),
    ErrorCode.MARKET_PRICE_STALE: (ResolutionAction.ACKNOWLEDGE, True),
    ErrorCode.CORPORATE_ACTION_UNVERIFIED: (ResolutionAction.ACKNOWLEDGE, True),
    ErrorCode.NON_EXCHANGE_PRICE_SOURCE: (ResolutionAction.ACKNOWLEDGE, True),
    # Reconciliation: every figure exists, but it disagrees with the broker.
    ErrorCode.LOT_RECONCILIATION_FAILED: (ResolutionAction.CORRECT_SOURCE_FILE, True),
    ErrorCode.CASH_RECONCILIATION_FAILED: (ResolutionAction.CORRECT_SOURCE_FILE, True),
    ErrorCode.DUPLICATE_TRANSACTION: (ResolutionAction.CORRECT_SOURCE_FILE, True),
    # Source files.
    ErrorCode.SOURCE_FILE_CORRUPT: (ResolutionAction.CORRECT_SOURCE_FILE, False),
    ErrorCode.SOURCE_FILE_UNSUPPORTED: (ResolutionAction.CORRECT_SOURCE_FILE, False),
    ErrorCode.BROKER_FORMAT_CHANGED: (ResolutionAction.EXTEND_BROKER_SUPPORT, False),
    ErrorCode.BROKER_UNIDENTIFIED: (ResolutionAction.EXTEND_BROKER_SUPPORT, False),
    ErrorCode.SCHEMA_VALIDATION_FAILED: (ResolutionAction.EXTEND_BROKER_SUPPORT, False),
    ErrorCode.UNSUPPORTED_TRANSACTION: (ResolutionAction.EXTEND_BROKER_SUPPORT, True),
    ErrorCode.SOURCE_FILE_DUPLICATE: (ResolutionAction.REVIEW_ONLY, True),
    # Rules and policy.
    ErrorCode.REPORTING_PERIOD_INVALID: (ResolutionAction.CONFIRM_TAX_RULES, False),
    ErrorCode.TAX_RULE_VERSION_MISSING: (ResolutionAction.CONFIRM_TAX_RULES, False),
    ErrorCode.FORM_SCHEMA_MISSING: (ResolutionAction.CONFIRM_TAX_RULES, False),
    ErrorCode.VALUATION_POLICY_MISSING: (ResolutionAction.CONFIRM_TAX_RULES, False),
    ErrorCode.TAX_RULE_UNVERIFIED: (ResolutionAction.CONFIRM_TAX_RULES, True),
    # Consequences of other issues rather than tasks of their own.
    ErrorCode.CALCULATION_INCOMPLETE: (ResolutionAction.REVIEW_ONLY, False),
    ErrorCode.MANUAL_OVERRIDE_PRESENT: (ResolutionAction.ACKNOWLEDGE, True),
}

_UNROUTED = set(ErrorCode) - set(_WORKFLOW)
if _UNROUTED:  # pragma: no cover - guards catalogue drift at import time
    raise RuntimeError(
        "every error code needs a resolution action and a waivable decision; "
        f"missing: {', '.join(sorted(_UNROUTED))}"
    )

ERROR_CATALOG: dict[ErrorCode, ErrorDefinition] = {
    code: replace(
        entry, action=_WORKFLOW[code][0], waivable=_WORKFLOW[code][1]
    )
    for code, entry in _CATALOG.items()
}


def definition(code: ErrorCode) -> ErrorDefinition:
    """Return the catalogue entry for ``code``."""
    try:
        return ERROR_CATALOG[code]
    except KeyError as exc:  # pragma: no cover - guards catalogue drift
        raise KeyError(f"error code {code} has no catalogue definition") from exc


class PlatformError(Exception):
    """Base exception carrying an :class:`ErrorCode`."""

    def __init__(self, code: ErrorCode, detail: str | None = None) -> None:
        self.code = code
        self.definition = definition(code)
        self.detail = detail
        super().__init__(f"{code}: {detail or self.definition.title}")


class ParseError(PlatformError):
    """Raised when a source file cannot be parsed safely."""


class RuleError(PlatformError):
    """Raised when an applicable tax rule or form schema cannot be established."""


class RateError(PlatformError):
    """Raised when an exchange rate cannot be established."""


class PriceError(PlatformError):
    """Raised when a required market price cannot be established."""
