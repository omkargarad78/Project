"""Controlled retrieval of external rate datasets.

This is an operator-initiated maintenance action, never part of a calculation.
Nothing in the tax engine can reach this module: a calculation reads only from
a stored, versioned dataset, so the same inputs produce the same result whether
or not the network exists.

Retrieval is disabled unless ``FA_ALLOW_OUTBOUND_INGESTION`` is true, and every
request is checked against an explicit host allow-list, must use HTTPS, must
not resolve to a private or loopback address, and must not redirect off the
allow-list. Those four checks together are what keeps a URL-ingestion feature
from becoming an SSRF primitive.
"""

from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urlparse

from ..core.config import Settings, get_settings
from ..core.errors import ErrorCode, PlatformError
from ..core.hashing import hash_bytes

MAX_DOWNLOAD_BYTES = 64 * 1024 * 1024
REQUEST_TIMEOUT_SECONDS = 30


class IngestionNotPermitted(PlatformError):
    """Raised when a retrieval is blocked by configuration or policy."""

    def __init__(self, detail: str) -> None:
        super().__init__(ErrorCode.FX_DATASET_MISSING, detail)


@dataclass(frozen=True, slots=True)
class FetchedDocument:
    """A retrieved document plus the provenance needed to cite it later."""

    url: str
    content: bytes
    content_hash: str
    retrieved_at: datetime
    content_type: str | None
    #: Value of the server's ``Last-Modified`` header, when supplied.
    last_modified: str | None = None

    def save(self, directory: Path, file_name: str) -> Path:
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / file_name
        path.write_bytes(self.content)
        return path


def assert_host_allowed(url: str, settings: Settings | None = None) -> str:
    """Validate a URL against the ingestion policy, returning its hostname."""
    settings = settings or get_settings()
    parsed = urlparse(url)

    if parsed.scheme != "https":
        raise IngestionNotPermitted(
            f"only https URLs may be ingested; {url!r} uses {parsed.scheme or 'no'} scheme"
        )
    host = parsed.hostname
    if not host:
        raise IngestionNotPermitted(f"{url!r} has no hostname")
    if parsed.port not in (None, 443):
        raise IngestionNotPermitted(
            f"only the default https port may be used; {url!r} requests port {parsed.port}"
        )
    if host.lower() not in {h.lower() for h in settings.ingestion_allowed_hosts}:
        allowed = ", ".join(sorted(settings.ingestion_allowed_hosts))
        raise IngestionNotPermitted(
            f"host {host!r} is not on the ingestion allow-list. Allowed hosts: {allowed}"
        )

    # Resolve and reject anything that points inside the network the app runs
    # in. Checking after the allow-list catches a DNS entry that has been
    # repointed at an internal address.
    try:
        infos = socket.getaddrinfo(host, 443, proto=socket.IPPROTO_TCP)
    except OSError as exc:
        raise IngestionNotPermitted(f"cannot resolve host {host!r}: {exc}") from exc

    for info in infos:
        address = ipaddress.ip_address(info[4][0])
        if (
            address.is_private
            or address.is_loopback
            or address.is_link_local
            or address.is_multicast
            or address.is_reserved
            or address.is_unspecified
        ):
            raise IngestionNotPermitted(
                f"host {host!r} resolves to the non-public address {address}, which is "
                f"not permitted for ingestion"
            )
    return host


def fetch_document(url: str, *, settings: Settings | None = None) -> FetchedDocument:
    """Retrieve one document under the ingestion policy.

    Redirects are followed manually so that each hop is re-validated against
    the allow-list; a 302 to an internal address is otherwise the easiest way
    to defeat a host check.
    """
    settings = settings or get_settings()
    if not settings.allow_outbound_ingestion:
        raise IngestionNotPermitted(
            "outbound dataset ingestion is disabled. Set FA_ALLOW_OUTBOUND_INGESTION=true "
            "to enable it for a maintenance run, or import the dataset from local files "
            "with the ingest-fx command instead."
        )

    import httpx

    current = url
    for _hop in range(5):
        assert_host_allowed(current, settings)
        with httpx.Client(
            timeout=REQUEST_TIMEOUT_SECONDS,
            follow_redirects=False,
            headers={"User-Agent": f"{settings.app_name}/dataset-ingestion"},
        ) as client:
            response = client.get(current)

        if response.status_code in (301, 302, 303, 307, 308):
            location = response.headers.get("location")
            if not location:
                raise IngestionNotPermitted(
                    f"{current} returned {response.status_code} without a Location header"
                )
            current = str(httpx.URL(current).join(location))
            continue

        if response.status_code != 200:
            raise IngestionNotPermitted(
                f"{current} returned HTTP {response.status_code}"
            )

        content = response.content
        if len(content) > MAX_DOWNLOAD_BYTES:
            raise IngestionNotPermitted(
                f"{current} returned {len(content)} bytes, over the "
                f"{MAX_DOWNLOAD_BYTES}-byte ingestion limit"
            )
        return FetchedDocument(
            url=current,
            content=content,
            content_hash=hash_bytes(content),
            retrieved_at=datetime.now(UTC),
            content_type=response.headers.get("content-type"),
            last_modified=response.headers.get("last-modified"),
        )

    raise IngestionNotPermitted(f"too many redirects starting from {url}")
