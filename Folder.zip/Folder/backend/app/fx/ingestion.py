"""Ingestion of historical SBI exchange-rate datasets.

Ingestion is a controlled, operator-initiated process, never something a user
calculation triggers. A source file is profiled first, then mapped, then
validated, then frozen into an immutable :class:`FxDatasetVersion`.

Three rules shape this module:

* **The rate type is never guessed.** A column is only read as a TT buying rate
  when the mapping says so. An unrecognised rate column is reported, not
  assumed, because importing a TT *selling* column as TT buying would corrupt
  every downstream figure silently.
* **Dates are never guessed.** An ambiguous day/month ordering fails the import
  rather than picking a convention.
* **Provenance travels with every record.** A community dataset is imported at
  tier 4 and stays labelled tier 4 all the way into the output workbook.
"""

from __future__ import annotations

import csv
import io
from collections import Counter, defaultdict
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import UTC, date, datetime
from decimal import Decimal
from pathlib import Path

from ..core.errors import ErrorCode, ParseError
from ..core.hashing import hash_bytes
from ..core.money import MoneyError, normalize_numeric_text, to_decimal
from ..io.dates import parse_with_format, resolve_date_format
from ..tax.rules.models import FxRateType, SourceTier
from .models import FxDatasetVersion, FxRateRecord, RateStatus

#: Header aliases used to locate the date column. Matching is case-insensitive
#: and ignores punctuation, but it is still only a *proposal*: the detected
#: mapping is reported and must be accepted before records are built.
DATE_COLUMN_ALIASES: tuple[str, ...] = (
    "date",
    "ratedate",
    "asondate",
    "effectivedate",
    "day",
    "valuedate",
)

CURRENCY_COLUMN_ALIASES: tuple[str, ...] = (
    "currency",
    "currencycode",
    "ccy",
    "curr",
    "foreigncurrency",
)

#: Aliases per rate type. Deliberately narrow: a column that does not clearly
#: state which rate it holds is left unmapped and reported.
RATE_COLUMN_ALIASES: Mapping[FxRateType, tuple[str, ...]] = {
    FxRateType.TT_BUY: (
        "ttbuy",
        "ttbuying",
        "ttbuyrate",
        "ttbuyingrate",
        "telegraphictransferbuying",
        "telegraphictransferbuyingrate",
        "ttbr",
        "buyingratett",
    ),
    FxRateType.TT_SELL: (
        "ttsell",
        "ttselling",
        "ttsellrate",
        "ttsellingrate",
        "telegraphictransferselling",
    ),
    FxRateType.BILL_BUY: ("billbuy", "billbuying", "billbuyingrate"),
    FxRateType.BILL_SELL: ("billsell", "billselling", "billsellingrate"),
    FxRateType.CARD_RATE: ("cardrate", "cardrates", "travelcardrate"),
    FxRateType.CASH_BUY: ("cashbuy", "cashbuying", "cashbuyingrate"),
    FxRateType.CASH_SELL: ("cashsell", "cashselling", "cashsellingrate"),
}

PUBLISHED_AT_ALIASES: tuple[str, ...] = (
    "publishedat",
    "publicationtime",
    "publishtime",
    "timestamp",
    "ratetime",
    "time",
    "effectivetime",
)

UNIT_COLUMN_ALIASES: tuple[str, ...] = ("unit", "rateunit", "per", "perunits", "units")

#: Accepted date layouts. Ordering matters only for reporting; an input that
#: parses under two layouts with different results is rejected as ambiguous.
DATE_FORMATS: tuple[tuple[str, str], ...] = (
    ("%Y-%m-%d", "ISO 8601 (YYYY-MM-DD)"),
    ("%d-%m-%Y", "day-month-year (DD-MM-YYYY)"),
    ("%m-%d-%Y", "month-day-year (MM-DD-YYYY)"),
    ("%d/%m/%Y", "day/month/year (DD/MM/YYYY)"),
    ("%m/%d/%Y", "month/day/year (MM/DD/YYYY)"),
    ("%Y/%m/%d", "year/month/day (YYYY/MM/DD)"),
    ("%d-%b-%Y", "day-abbreviated month-year (DD-Mon-YYYY)"),
    ("%d %b %Y", "day abbreviated month year (DD Mon YYYY)"),
    ("%d-%B-%Y", "day-full month-year"),
    ("%b %d, %Y", "abbreviated month day, year"),
)


def normalize_header(text: str) -> str:
    """Reduce a header to comparable form: lowercase alphanumerics only."""
    return "".join(ch for ch in text.lower() if ch.isalnum())


@dataclass(frozen=True, slots=True)
class ColumnMapping:
    """How a source file's columns map onto rate-record fields.

    Produced by detection and then either accepted or corrected by the
    operator. Passing an explicit mapping bypasses detection entirely, which is
    how a dataset whose headers are unclear is imported safely.
    """

    date_column: str
    #: Column holding the currency code, when the file is long-format.
    currency_column: str | None = None
    #: Fixed currency, when the file covers exactly one currency.
    fixed_currency: str | None = None
    #: Rate columns, keyed by the rate type each one holds.
    rate_columns: Mapping[FxRateType, str] = field(default_factory=dict)
    published_at_column: str | None = None
    unit_column: str | None = None
    fixed_unit: int = 1
    date_format: str | None = None

    def __post_init__(self) -> None:
        if not self.rate_columns:
            raise ValueError("a column mapping must map at least one rate column")
        if self.currency_column is None and self.fixed_currency is None:
            raise ValueError(
                "a column mapping needs either a currency column or a fixed currency"
            )


@dataclass(frozen=True, slots=True)
class DatasetProfile:
    """What was found in a source file, before anything is imported.

    This is the rate-dataset equivalent of the broker parser report: it exists
    so that a human can see the actual structure of the file rather than
    trusting a silent auto-detection.
    """

    file_name: str
    file_hash: str
    delimiter: str
    row_count: int
    columns: tuple[str, ...]
    detected_date_column: str | None
    detected_date_format: str | None
    detected_date_format_label: str | None
    detected_currency_column: str | None
    detected_rate_columns: Mapping[FxRateType, str]
    unmapped_columns: tuple[str, ...]
    sample_rows: tuple[Mapping[str, str], tuple, ...] | tuple = ()
    warnings: tuple[str, ...] = ()

    @property
    def has_tt_buying(self) -> bool:
        return FxRateType.TT_BUY in self.detected_rate_columns

    def summary(self) -> str:
        lines = [
            f"file: {self.file_name}",
            f"hash: {self.file_hash}",
            f"delimiter: {self.delimiter!r}",
            f"rows: {self.row_count}",
            f"columns ({len(self.columns)}): {', '.join(self.columns)}",
            f"date column: {self.detected_date_column or 'NOT DETECTED'}"
            + (
                f" [{self.detected_date_format_label}]"
                if self.detected_date_format_label
                else ""
            ),
            "currency column: "
            + (self.detected_currency_column or "not present (single-currency file?)"),
            "rate columns:",
        ]
        if self.detected_rate_columns:
            for rate_type, column in sorted(
                self.detected_rate_columns.items(), key=lambda kv: str(kv[0])
            ):
                lines.append(f"  {rate_type.label} <- {column!r}")
        else:
            lines.append("  NONE DETECTED")
        if self.unmapped_columns:
            lines.append(f"unmapped columns: {', '.join(self.unmapped_columns)}")
        for warning in self.warnings:
            lines.append(f"warning: {warning}")
        return "\n".join(lines)


@dataclass(frozen=True, slots=True)
class IngestionReport:
    """Outcome of an ingestion run."""

    profile: DatasetProfile
    dataset: FxDatasetVersion | None
    records_imported: int
    rows_skipped: int
    #: Row-level problems, as ``(row number, reason)``.
    row_errors: tuple[tuple[int, str], ...]
    #: Dates carrying more than one record for the same currency and rate type.
    multi_record_dates: tuple[tuple[str, str, int], ...]
    warnings: tuple[str, ...]

    def summary(self) -> str:
        lines = [
            self.profile.summary(),
            "",
            f"records imported: {self.records_imported}",
            f"rows skipped: {self.rows_skipped}",
        ]
        if self.dataset is not None:
            for key, value in self.dataset.describe().items():
                lines.append(f"{key}: {value}")
        if self.multi_record_dates:
            lines.append(
                f"dates with multiple rate records: {len(self.multi_record_dates)} "
                f"(selection between them is a rule-version policy, not a default)"
            )
        for row_number, reason in self.row_errors[:20]:
            lines.append(f"row {row_number}: {reason}")
        if len(self.row_errors) > 20:
            lines.append(f"... and {len(self.row_errors) - 20} more row errors")
        for warning in self.warnings:
            lines.append(f"warning: {warning}")
        return "\n".join(lines)


def _sniff_delimiter(sample: str) -> str:
    try:
        return csv.Sniffer().sniff(sample, delimiters=",;\t|").delimiter
    except csv.Error:
        # A single-column file is legitimate and defaults to comma.
        return ","


def _match_alias(columns: Sequence[str], aliases: Iterable[str]) -> str | None:
    normalized = {normalize_header(column): column for column in columns}
    for alias in aliases:
        if alias in normalized:
            return normalized[alias]
    # Fall back to a containment match so that "USD TT Buying Rate" is found.
    for alias in aliases:
        for norm, original in normalized.items():
            if alias in norm:
                return original
    return None


def detect_date_format(values: Sequence[str]) -> tuple[str | None, str | None, list[str]]:
    """Infer the date layout, refusing to choose when it is ambiguous.

    A thin wrapper over the shared resolver in ``io.dates``, which broker
    parsers use as well, so a rate file and a broker statement are held to the
    same rule: ``01/02/2024`` is 1 February under one convention and 2 January
    under another, and when two layouts both parse every sample but disagree,
    the layout is undetermined and the operator must state it explicitly.
    """
    resolution = resolve_date_format(values, candidates=DATE_FORMATS)
    if resolution.resolved:
        return resolution.format, resolution.label, []
    return None, None, [resolution.reason or "the date layout could not be determined"]


def profile_csv(
    content: bytes,
    *,
    file_name: str,
    sample_size: int = 200,
) -> DatasetProfile:
    """Read a delimited rate file and report what it contains."""
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ParseError(
            ErrorCode.SOURCE_FILE_CORRUPT,
            f"{file_name} is not valid UTF-8 text: {exc}",
        ) from exc

    delimiter = _sniff_delimiter(text[:8192])
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    columns = tuple(reader.fieldnames or ())
    if not columns:
        raise ParseError(
            ErrorCode.SOURCE_FILE_CORRUPT, f"{file_name} has no header row"
        )

    rows = list(reader)
    warnings: list[str] = []

    date_column = _match_alias(columns, DATE_COLUMN_ALIASES)
    currency_column = _match_alias(columns, CURRENCY_COLUMN_ALIASES)

    rate_columns: dict[FxRateType, str] = {}
    for rate_type, aliases in RATE_COLUMN_ALIASES.items():
        match = _match_alias(columns, aliases)
        if match is not None and match not in rate_columns.values():
            rate_columns[rate_type] = match

    date_format: str | None = None
    date_format_label: str | None = None
    if date_column is not None:
        samples = [str(row.get(date_column) or "") for row in rows[:sample_size]]
        date_format, date_format_label, date_warnings = detect_date_format(samples)
        warnings.extend(date_warnings)
    else:
        warnings.append(
            "no date column was detected; supply an explicit column mapping"
        )

    if FxRateType.TT_BUY not in rate_columns:
        warnings.append(
            "no telegraphic transfer BUYING rate column was detected. Schedule FA "
            "valuation requires the TT buying rate; importing another rate type in "
            "its place is not permitted, so an explicit mapping is required."
        )

    mapped = {date_column, currency_column, *rate_columns.values()}
    unmapped = tuple(column for column in columns if column not in mapped)
    if unmapped:
        warnings.append(
            f"{len(unmapped)} column(s) were not mapped and will be ignored: "
            f"{', '.join(unmapped)}"
        )

    return DatasetProfile(
        file_name=file_name,
        file_hash=hash_bytes(content),
        delimiter=delimiter,
        row_count=len(rows),
        columns=columns,
        detected_date_column=date_column,
        detected_date_format=date_format,
        detected_date_format_label=date_format_label,
        detected_currency_column=currency_column,
        detected_rate_columns=dict(rate_columns),
        unmapped_columns=unmapped,
        sample_rows=tuple(dict(row) for row in rows[:5]),
        warnings=tuple(warnings),
    )


def mapping_from_profile(
    profile: DatasetProfile,
    *,
    fixed_currency: str | None = None,
    rate_types: Iterable[FxRateType] | None = None,
) -> ColumnMapping:
    """Build a mapping from a profile, failing when detection was inconclusive."""
    if profile.detected_date_column is None:
        raise ParseError(
            ErrorCode.SCHEMA_VALIDATION_FAILED,
            f"{profile.file_name}: no date column could be detected; supply an "
            f"explicit ColumnMapping",
        )
    if profile.detected_date_format is None:
        raise ParseError(
            ErrorCode.SCHEMA_VALIDATION_FAILED,
            f"{profile.file_name}: the date layout could not be determined "
            f"unambiguously; supply ColumnMapping.date_format explicitly. "
            f"{'; '.join(profile.warnings)}",
        )
    wanted = set(rate_types) if rate_types else {FxRateType.TT_BUY}
    available = {
        rate_type: column
        for rate_type, column in profile.detected_rate_columns.items()
        if rate_type in wanted
    }
    missing = wanted - set(available)
    if missing:
        raise ParseError(
            ErrorCode.SCHEMA_VALIDATION_FAILED,
            f"{profile.file_name}: no column was detected for "
            f"{', '.join(sorted(str(m) for m in missing))}. The rate type is never "
            f"inferred from an unlabelled column; supply an explicit ColumnMapping.",
        )
    if profile.detected_currency_column is None and fixed_currency is None:
        raise ParseError(
            ErrorCode.SCHEMA_VALIDATION_FAILED,
            f"{profile.file_name}: no currency column was detected and no fixed "
            f"currency was supplied",
        )
    return ColumnMapping(
        date_column=profile.detected_date_column,
        currency_column=profile.detected_currency_column,
        fixed_currency=fixed_currency,
        rate_columns=available,
        date_format=profile.detected_date_format,
    )


class SbiRateIngestor:
    """Builds immutable rate dataset versions from delimited source files."""

    def __init__(
        self,
        *,
        source_id: str,
        source_name: str,
        source_tier: SourceTier,
        dataset_name: str,
        source_document_url: str | None = None,
        source_document_reference: str | None = None,
        default_status: RateStatus | None = None,
    ) -> None:
        self.source_id = source_id
        self.source_name = source_name
        self.source_tier = source_tier
        self.dataset_name = dataset_name
        self.source_document_url = source_document_url
        self.source_document_reference = source_document_reference
        # A record's default status follows its source's authority: only a
        # statutory-tier publication is imported as VERIFIED.
        self.default_status = default_status or (
            RateStatus.VERIFIED if source_tier.is_statutory else RateStatus.UNVERIFIED
        )

    def ingest_csv(
        self,
        content: bytes,
        *,
        file_name: str,
        version: str,
        mapping: ColumnMapping | None = None,
        currencies: Iterable[str] | None = None,
        rate_types: Iterable[FxRateType] | None = None,
        fixed_currency: str | None = None,
        imported_at: datetime | None = None,
        notes: str | None = None,
    ) -> IngestionReport:
        """Profile, map, validate and freeze a delimited rate file."""
        profile = profile_csv(content, file_name=file_name)
        if mapping is None:
            mapping = mapping_from_profile(
                profile, fixed_currency=fixed_currency, rate_types=rate_types
            )

        text = content.decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(text), delimiter=profile.delimiter)

        wanted_currencies = {c.upper() for c in currencies} if currencies else None
        records: list[FxRateRecord] = []
        row_errors: list[tuple[int, str]] = []
        skipped = 0
        retrieved_at = imported_at or datetime.now(UTC)

        for offset, row in enumerate(reader, start=2):
            try:
                rate_date = self._parse_date(row.get(mapping.date_column), mapping)
            except ParseError as exc:
                row_errors.append((offset, str(exc.detail or exc)))
                skipped += 1
                continue

            currency = (
                (row.get(mapping.currency_column) or "").strip().upper()
                if mapping.currency_column
                else (mapping.fixed_currency or "").upper()
            )
            if not currency:
                row_errors.append((offset, "no currency code on this row"))
                skipped += 1
                continue
            if wanted_currencies is not None and currency not in wanted_currencies:
                skipped += 1
                continue

            unit = mapping.fixed_unit
            if mapping.unit_column:
                raw_unit = normalize_numeric_text(row.get(mapping.unit_column) or "")
                if raw_unit:
                    try:
                        unit = int(Decimal(raw_unit))
                    except (ArithmeticError, ValueError):
                        row_errors.append((offset, f"unreadable rate unit {raw_unit!r}"))
                        skipped += 1
                        continue

            published_at = None
            if mapping.published_at_column:
                published_at = self._parse_timestamp(
                    row.get(mapping.published_at_column), rate_date
                )

            row_had_value = False
            for rate_type, column in mapping.rate_columns.items():
                raw = row.get(column)
                if raw is None or normalize_numeric_text(str(raw)) is None:
                    continue
                try:
                    value = to_decimal(str(raw), field=column)
                except MoneyError as exc:
                    row_errors.append((offset, f"{column}: {exc}"))
                    continue
                if value <= 0:
                    row_errors.append(
                        (offset, f"{column}: non-positive rate {raw!r} rejected")
                    )
                    continue
                records.append(
                    FxRateRecord(
                        currency=currency,
                        rate_date=rate_date,
                        rate_type=rate_type,
                        value=value,
                        unit=unit,
                        source_id=self.source_id,
                        source_name=self.source_name,
                        source_tier=self.source_tier,
                        source_document_reference=self.source_document_reference
                        or f"{file_name} row {offset}",
                        source_document_url=self.source_document_url,
                        source_document_hash=profile.file_hash,
                        published_at=published_at,
                        retrieved_at=retrieved_at,
                        status=self.default_status,
                    )
                )
                row_had_value = True
            if not row_had_value:
                skipped += 1

        dataset = (
            FxDatasetVersion.build(
                dataset_name=self.dataset_name,
                version=version,
                source_id=self.source_id,
                source_tier=self.source_tier,
                imported_at=retrieved_at,
                records=records,
                source_file_hashes=[profile.file_hash],
                notes=notes,
            )
            if records
            else None
        )

        multi = self._multi_record_dates(records)
        warnings = list(profile.warnings)
        if not self.source_tier.is_statutory:
            warnings.append(
                f"This dataset is {self.source_tier.label}. Every rate taken from it "
                f"is flagged SECONDARY_SOURCE_USED and must not be presented as an "
                f"official SBI publication."
            )
        if multi:
            warnings.append(
                f"{len(multi)} currency/date combinations carry more than one rate "
                f"record. Which one applies is decided by the rule version's "
                f"multiple-rate policy, which defaults to FAIL rather than picking one."
            )
        if not records:
            warnings.append("no usable rate records were found in this file")

        return IngestionReport(
            profile=profile,
            dataset=dataset,
            records_imported=len(records),
            rows_skipped=skipped,
            row_errors=tuple(row_errors),
            multi_record_dates=multi,
            warnings=tuple(warnings),
        )

    def ingest_path(
        self,
        path: str | Path,
        *,
        version: str,
        **kwargs: object,
    ) -> IngestionReport:
        file_path = Path(path)
        return self.ingest_csv(
            file_path.read_bytes(),
            file_name=file_path.name,
            version=version,
            **kwargs,  # type: ignore[arg-type]
        )

    def ingest_directory(
        self,
        directory: str | Path,
        *,
        version: str,
        pattern: str = "*.csv",
        mapping: ColumnMapping | None = None,
        currencies: Iterable[str] | None = None,
        rate_types: Iterable[FxRateType] | None = None,
        imported_at: datetime | None = None,
        notes: str | None = None,
    ) -> IngestionReport:
        """Ingest every matching file in a directory into one dataset version.

        Historical rate archives are commonly split one file per year, and they
        must land in a single version so that a calculation binds to one
        immutable dataset rather than to a collection that can drift.
        """
        root = Path(directory)
        paths = sorted(root.glob(pattern))
        if not paths:
            raise ParseError(
                ErrorCode.FX_DATASET_MISSING,
                f"no files matching {pattern!r} under {root}",
            )

        all_records: list[FxRateRecord] = []
        all_errors: list[tuple[int, str]] = []
        all_warnings: list[str] = []
        file_hashes: list[str] = []
        skipped = 0
        first_profile: DatasetProfile | None = None
        retrieved_at = imported_at or datetime.now(UTC)

        for path in paths:
            report = self.ingest_csv(
                path.read_bytes(),
                file_name=path.name,
                version=version,
                mapping=mapping,
                currencies=currencies,
                rate_types=rate_types,
                imported_at=retrieved_at,
            )
            first_profile = first_profile or report.profile
            if report.dataset is not None:
                all_records.extend(report.dataset.records)
            all_errors.extend((n, f"{path.name}: {r}") for n, r in report.row_errors)
            all_warnings.extend(f"{path.name}: {w}" for w in report.warnings)
            file_hashes.append(report.profile.file_hash)
            skipped += report.rows_skipped

        assert first_profile is not None
        dataset = (
            FxDatasetVersion.build(
                dataset_name=self.dataset_name,
                version=version,
                source_id=self.source_id,
                source_tier=self.source_tier,
                imported_at=retrieved_at,
                records=all_records,
                source_file_hashes=file_hashes,
                notes=notes or f"ingested {len(paths)} file(s) from {root.name}",
            )
            if all_records
            else None
        )
        return IngestionReport(
            profile=first_profile,
            dataset=dataset,
            records_imported=len(all_records),
            rows_skipped=skipped,
            row_errors=tuple(all_errors),
            multi_record_dates=self._multi_record_dates(all_records),
            warnings=tuple(dict.fromkeys(all_warnings)),
        )

    # --- helpers ------------------------------------------------------------

    def _parse_date(self, raw: str | None, mapping: ColumnMapping) -> date:
        text = (raw or "").strip()
        if not text:
            raise ParseError(ErrorCode.SCHEMA_VALIDATION_FAILED, "empty date value")
        if mapping.date_format:
            parsed = parse_with_format(text, mapping.date_format)
            if parsed is None:
                raise ParseError(
                    ErrorCode.SCHEMA_VALIDATION_FAILED,
                    f"{text!r} does not match the declared date format "
                    f"{mapping.date_format!r}",
                )
            return parsed
        raise ParseError(
            ErrorCode.SCHEMA_VALIDATION_FAILED,
            "no date format was declared for this mapping",
        )

    def _parse_timestamp(self, raw: str | None, fallback_date: date) -> datetime | None:
        """Read a rate's publication time.

        Left deliberately naive. SBI publishes several rate cards a day and
        states the time in Indian local time without a zone; stamping it UTC
        would shift it by five and a half hours and could reorder the day's
        cards. The value is only ever used to order rates published on the
        same date, which naive comparison does correctly.
        """
        text = (raw or "").strip()
        if not text:
            return None
        for fmt in ("%H:%M:%S", "%H:%M", "%I:%M %p", "%I:%M:%S %p"):
            try:
                parsed = datetime.strptime(text, fmt).time()
            except ValueError:
                continue
            return datetime.combine(fallback_date, parsed)
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%d-%m-%Y %H:%M"):
            try:
                return datetime.strptime(text, fmt)
            except ValueError:
                continue
        return None

    @staticmethod
    def _multi_record_dates(
        records: Sequence[FxRateRecord],
    ) -> tuple[tuple[str, str, int], ...]:
        counter: Counter[tuple[str, date, FxRateType]] = Counter(
            (r.currency, r.rate_date, r.rate_type) for r in records
        )
        return tuple(
            (currency, rate_date.isoformat(), count)
            for (currency, rate_date, _rate_type), count in sorted(
                counter.items(), key=lambda kv: (kv[0][0], kv[0][1])
            )
            if count > 1
        )


def coverage_report(
    dataset: FxDatasetVersion,
    *,
    currency: str,
    rate_type: FxRateType,
    start: date,
    end: date,
) -> dict[str, object]:
    """Describe a dataset's coverage of a period.

    Gaps are expected: SBI does not publish on weekends or Indian holidays.
    This distinguishes weekend gaps from weekday gaps, because a missing
    weekday is a data problem while a missing Saturday is normal.
    """
    from datetime import timedelta

    available = set(dataset.dates_for(currency, rate_type))
    span = (end - start).days
    all_days = [start + timedelta(days=offset) for offset in range(span + 1)]

    weekday_gaps = [d for d in all_days if d not in available and d.weekday() < 5]
    weekend_gaps = [d for d in all_days if d not in available and d.weekday() >= 5]
    covered = [d for d in all_days if d in available]

    by_month: dict[str, int] = defaultdict(int)
    for day in covered:
        by_month[f"{day.year}-{day.month:02d}"] += 1

    return {
        "currency": currency,
        "rate_type": str(rate_type),
        "period": f"{start.isoformat()} to {end.isoformat()}",
        "days_in_period": len(all_days),
        "days_covered": len(covered),
        "weekday_gaps": len(weekday_gaps),
        "weekend_gaps": len(weekend_gaps),
        "first_weekday_gaps": [d.isoformat() for d in weekday_gaps[:20]],
        "coverage_by_month": dict(sorted(by_month.items())),
    }
