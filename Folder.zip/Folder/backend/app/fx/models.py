"""Exchange-rate records and immutable rate dataset versions.

A rate is never just a number. Every record carries the currency, the date, the
*rate type*, the source it came from, that source's authority tier, the
document reference and hash where available, the publication timestamp when the
publisher supplies one, the value, the unit and the retrieval timestamp. The
provenance chain

    calculation -> rate record -> dataset version -> source record -> document

is what lets a figure be explained years later without the original source
still being reachable.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum

from ..core.hashing import derive_id, hash_payload
from ..core.money import as_rate, decimal_to_str
from ..tax.rules.models import FxRateType, SourceTier


class RateStatus(StrEnum):
    """Confidence in a rate record."""

    #: Sourced from a statutory-tier publication with a retrievable document.
    VERIFIED = "VERIFIED"
    #: Sourced from a dataset below statutory tier, or without a document
    #: reference. Usable, and every use is flagged.
    UNVERIFIED = "UNVERIFIED"
    #: Entered by a user resolving a missing rate, with evidence recorded.
    MANUAL_OVERRIDE = "MANUAL_OVERRIDE"
    #: Present in the dataset but rejected, for example wrong rate type.
    REJECTED = "REJECTED"


@dataclass(frozen=True, slots=True)
class FxRateRecord:
    """One published exchange rate for one currency, date and rate type."""

    currency: str
    rate_date: date
    rate_type: FxRateType
    value: Decimal
    #: Number of foreign-currency units the rate is quoted for. Some
    #: currencies (notably JPY) are published per 100 units, so this is carried
    #: on the record instead of being assumed to be 1.
    unit: int = 1
    quote_currency: str = "INR"

    # --- provenance ---------------------------------------------------------
    source_id: str = "UNKNOWN"
    source_name: str = "unknown"
    source_tier: SourceTier = SourceTier.COMMUNITY_DATASET
    source_document_reference: str | None = None
    source_document_url: str | None = None
    source_document_hash: str | None = None
    #: When the publisher published the rate sheet, if stated.
    published_at: datetime | None = None
    #: When this installation obtained the value.
    retrieved_at: datetime | None = None
    status: RateStatus = RateStatus.UNVERIFIED

    #: Set on manual overrides.
    override_original_value: Decimal | None = None
    override_reason: str | None = None
    override_user: str | None = None
    override_at: datetime | None = None
    override_evidence: str | None = None

    def __post_init__(self) -> None:
        if self.value <= 0:
            raise ValueError(
                f"exchange rate must be positive, got {self.value} for "
                f"{self.currency} on {self.rate_date}"
            )
        if self.unit <= 0:
            raise ValueError(f"rate unit must be positive, got {self.unit}")
        if len(self.currency) != 3 or not self.currency.isupper():
            raise ValueError(f"currency must be a 3-letter ISO 4217 code, got {self.currency!r}")
        object.__setattr__(self, "value", as_rate(self.value))

    @property
    def rate_id(self) -> str:
        return derive_id(
            "FX",
            self.currency,
            self.rate_date,
            self.rate_type,
            decimal_to_str(self.value),
            self.unit,
            self.source_id,
            self.published_at,
        )

    @property
    def is_tt_buying(self) -> bool:
        return self.rate_type is FxRateType.TT_BUY

    @property
    def quote_label(self) -> str:
        if self.unit == 1:
            return f"INR {self.value} per 1 {self.currency}"
        return f"INR {self.value} per {self.unit} {self.currency}"

    def to_row(self) -> dict[str, str]:
        return {
            "Rate ID": self.rate_id,
            "Date": self.rate_date.isoformat(),
            "Currency": self.currency,
            "Rate Type": self.rate_type.label,
            "TT Buying Rate": decimal_to_str(self.value) or "",
            "Rate Unit": str(self.unit),
            "Quote Currency": self.quote_currency,
            "Source": self.source_name,
            "Source Tier": self.source_tier.label,
            "Source URL / Reference": self.source_document_url
            or self.source_document_reference
            or "",
            "Publication Date/Time": self.published_at.isoformat() if self.published_at else "",
            "Retrieved At": self.retrieved_at.isoformat() if self.retrieved_at else "",
            "Hash": self.source_document_hash or "",
            "Status": str(self.status),
        }


@dataclass(frozen=True, slots=True)
class FxDatasetVersion:
    """An immutable, versioned collection of rate records.

    Once a calculation has been published against a dataset version, that
    version's records never change. Re-importing a source that has since been
    corrected produces a new version, and the old calculation remains
    reproducible against the old one.
    """

    dataset_id: str
    dataset_name: str
    version: str
    source_id: str
    source_tier: SourceTier
    imported_at: datetime
    #: Hash over every record in the dataset, computed at construction.
    content_hash: str
    records: tuple[FxRateRecord, ...]
    #: Hash of the file(s) the dataset was imported from.
    source_file_hashes: tuple[str, ...] = ()
    notes: str | None = None

    @classmethod
    def build(
        cls,
        *,
        dataset_name: str,
        version: str,
        source_id: str,
        source_tier: SourceTier,
        imported_at: datetime,
        records: Iterable[FxRateRecord],
        source_file_hashes: Iterable[str] = (),
        notes: str | None = None,
    ) -> FxDatasetVersion:
        ordered = tuple(
            sorted(
                records,
                key=lambda r: (
                    r.currency,
                    r.rate_date,
                    str(r.rate_type),
                    r.published_at or datetime.min,
                    decimal_to_str(r.value) or "",
                ),
            )
        )
        content_hash = hash_payload(
            [
                [
                    r.currency,
                    r.rate_date,
                    str(r.rate_type),
                    decimal_to_str(r.value),
                    r.unit,
                    r.source_id,
                    r.published_at,
                ]
                for r in ordered
            ]
        )
        return cls(
            dataset_id=derive_id("FXDS", dataset_name, version, content_hash),
            dataset_name=dataset_name,
            version=version,
            source_id=source_id,
            source_tier=source_tier,
            imported_at=imported_at,
            content_hash=content_hash,
            records=ordered,
            source_file_hashes=tuple(source_file_hashes),
            notes=notes,
        )

    @property
    def version_label(self) -> str:
        return f"{self.dataset_name}@{self.version}"

    def currencies(self) -> list[str]:
        return sorted({r.currency for r in self.records})

    def rate_types(self) -> list[FxRateType]:
        return sorted({r.rate_type for r in self.records}, key=str)

    def date_range(self) -> tuple[date, date] | None:
        if not self.records:
            return None
        dates = [r.rate_date for r in self.records]
        return min(dates), max(dates)

    def index(self) -> Mapping[tuple[str, date, FxRateType], tuple[FxRateRecord, ...]]:
        """Group records by currency, date and rate type.

        A date can legitimately carry more than one published rate sheet, so
        the value is a tuple and the selection between them is a policy
        decision made in the resolver, never an implicit "first row wins".
        """
        grouped: dict[tuple[str, date, FxRateType], list[FxRateRecord]] = {}
        for record in self.records:
            grouped.setdefault((record.currency, record.rate_date, record.rate_type), []).append(
                record
            )
        return {key: tuple(value) for key, value in grouped.items()}

    def dates_for(self, currency: str, rate_type: FxRateType) -> list[date]:
        return sorted(
            {
                r.rate_date
                for r in self.records
                if r.currency == currency and r.rate_type is rate_type
            }
        )

    def with_records(
        self,
        extra: Sequence[FxRateRecord],
        *,
        version: str,
        imported_at: datetime,
        notes: str | None = None,
    ) -> FxDatasetVersion:
        """Return a new version containing the existing records plus ``extra``."""
        return FxDatasetVersion.build(
            dataset_name=self.dataset_name,
            version=version,
            source_id=self.source_id,
            source_tier=self.source_tier,
            imported_at=imported_at,
            records=[*self.records, *extra],
            source_file_hashes=self.source_file_hashes,
            notes=notes or self.notes,
        )

    def describe(self) -> dict[str, str]:
        span = self.date_range()
        return {
            "Dataset ID": self.dataset_id,
            "Dataset": self.version_label,
            "Source ID": self.source_id,
            "Source Tier": self.source_tier.label,
            "Imported At": self.imported_at.isoformat(),
            "Content Hash": self.content_hash,
            "Record Count": str(len(self.records)),
            "Currencies": ", ".join(self.currencies()),
            "Rate Types": ", ".join(str(t) for t in self.rate_types()),
            "Date Range": f"{span[0].isoformat()} to {span[1].isoformat()}" if span else "empty",
            "Source File Hashes": ", ".join(self.source_file_hashes),
            "Notes": self.notes or "",
        }


@dataclass(frozen=True, slots=True)
class RateResolution:
    """The outcome of resolving one rate lookup, kept with the figure it fed.

    ``requested_date`` and ``rate_date`` differ when the rule version permitted
    a carry-back to the preceding publication date. Keeping both is what makes
    a weekend or holiday conversion explainable.
    """

    currency: str
    requested_date: date
    rate_type: FxRateType
    record: FxRateRecord | None
    dataset_id: str | None
    dataset_version: str | None
    #: Which missing-rate rule produced this record, for the audit trail.
    selection_rule: str = "SAME_DATE"
    #: Number of calendar days between the requested date and the rate's date.
    gap_days: int = 0
    #: Populated when resolution failed.
    failure_reason: str | None = None
    notes: tuple[str, ...] = field(default_factory=tuple)

    @property
    def found(self) -> bool:
        return self.record is not None

    @property
    def rate_date(self) -> date | None:
        return self.record.rate_date if self.record else None

    @property
    def value(self) -> Decimal | None:
        return self.record.value if self.record else None

    @property
    def unit(self) -> int:
        return self.record.unit if self.record else 1

    @property
    def is_statutory_source(self) -> bool:
        return bool(self.record and self.record.source_tier.is_statutory)

    @property
    def source_label(self) -> str:
        if self.record is None:
            return "none"
        return f"{self.record.source_name} ({self.record.source_tier.label})"

    def explain(self) -> str:
        """Plain-language statement of which rate was used and why."""
        if self.record is None:
            return (
                f"No {self.rate_type.label} was available for {self.currency} on "
                f"{self.requested_date.isoformat()}. {self.failure_reason or ''}".strip()
            )
        base = (
            f"{self.rate_type.label} for {self.currency} on "
            f"{self.record.rate_date.isoformat()}: {self.record.quote_label}, "
            f"from {self.source_label}"
        )
        if self.record.rate_date != self.requested_date:
            base += (
                f". The relevant date was {self.requested_date.isoformat()}, on which no "
                f"rate was published; the rule version in force permits using the "
                f"{self.selection_rule} rate, {self.gap_days} day(s) away."
            )
        if self.record.status is RateStatus.MANUAL_OVERRIDE:
            base += f". This rate is a manual override: {self.record.override_reason or ''}"
        return base
