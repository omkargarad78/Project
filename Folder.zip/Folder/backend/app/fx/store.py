"""Persistence for immutable FX dataset versions, and manual rate overrides.

A dataset version, once written, is never modified. Writing the same version
name with different content is refused: the correction becomes a new version so
that a calculation published against the old one stays reproducible.
"""

from __future__ import annotations

import json
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

from ..core.errors import ErrorCode, RateError
from ..core.money import decimal_to_str, to_decimal
from ..tax.rules.models import FxRateType, SourceTier
from .models import FxDatasetVersion, FxRateRecord, RateStatus

DATASET_FILE_SUFFIX = ".fxdataset.json"
SERIALIZATION_VERSION = 1


def _dt(value: str | None) -> datetime | None:
    return datetime.fromisoformat(value) if value else None


def record_to_dict(record: FxRateRecord) -> dict[str, Any]:
    return {
        "currency": record.currency,
        "rate_date": record.rate_date.isoformat(),
        "rate_type": str(record.rate_type),
        "value": decimal_to_str(record.value),
        "unit": record.unit,
        "quote_currency": record.quote_currency,
        "source_id": record.source_id,
        "source_name": record.source_name,
        "source_tier": int(record.source_tier),
        "source_document_reference": record.source_document_reference,
        "source_document_url": record.source_document_url,
        "source_document_hash": record.source_document_hash,
        "published_at": record.published_at.isoformat() if record.published_at else None,
        "retrieved_at": record.retrieved_at.isoformat() if record.retrieved_at else None,
        "status": str(record.status),
        "override_original_value": decimal_to_str(record.override_original_value),
        "override_reason": record.override_reason,
        "override_user": record.override_user,
        "override_at": record.override_at.isoformat() if record.override_at else None,
        "override_evidence": record.override_evidence,
    }


def record_from_dict(payload: dict[str, Any]) -> FxRateRecord:
    original = payload.get("override_original_value")
    return FxRateRecord(
        currency=payload["currency"],
        rate_date=date.fromisoformat(payload["rate_date"]),
        rate_type=FxRateType(payload["rate_type"]),
        value=to_decimal(payload["value"], field="value"),
        unit=int(payload.get("unit", 1)),
        quote_currency=payload.get("quote_currency", "INR"),
        source_id=payload.get("source_id", "UNKNOWN"),
        source_name=payload.get("source_name", "unknown"),
        source_tier=SourceTier(payload.get("source_tier", int(SourceTier.COMMUNITY_DATASET))),
        source_document_reference=payload.get("source_document_reference"),
        source_document_url=payload.get("source_document_url"),
        source_document_hash=payload.get("source_document_hash"),
        published_at=_dt(payload.get("published_at")),
        retrieved_at=_dt(payload.get("retrieved_at")),
        status=RateStatus(payload.get("status", str(RateStatus.UNVERIFIED))),
        override_original_value=to_decimal(original, field="override_original_value")
        if original
        else None,
        override_reason=payload.get("override_reason"),
        override_user=payload.get("override_user"),
        override_at=_dt(payload.get("override_at")),
        override_evidence=payload.get("override_evidence"),
    )


def dataset_to_dict(dataset: FxDatasetVersion) -> dict[str, Any]:
    return {
        "serialization_version": SERIALIZATION_VERSION,
        "dataset_id": dataset.dataset_id,
        "dataset_name": dataset.dataset_name,
        "version": dataset.version,
        "source_id": dataset.source_id,
        "source_tier": int(dataset.source_tier),
        "imported_at": dataset.imported_at.isoformat(),
        "content_hash": dataset.content_hash,
        "source_file_hashes": list(dataset.source_file_hashes),
        "notes": dataset.notes,
        "records": [record_to_dict(record) for record in dataset.records],
    }


def dataset_from_dict(payload: dict[str, Any]) -> FxDatasetVersion:
    dataset = FxDatasetVersion.build(
        dataset_name=payload["dataset_name"],
        version=payload["version"],
        source_id=payload["source_id"],
        source_tier=SourceTier(payload["source_tier"]),
        imported_at=datetime.fromisoformat(payload["imported_at"]),
        records=[record_from_dict(item) for item in payload["records"]],
        source_file_hashes=payload.get("source_file_hashes", []),
        notes=payload.get("notes"),
    )
    stored_hash = payload.get("content_hash")
    if stored_hash and stored_hash != dataset.content_hash:
        raise RateError(
            ErrorCode.FX_DATASET_MISSING,
            f"dataset {payload['dataset_name']}@{payload['version']} failed its "
            f"integrity check: stored content hash {stored_hash} does not match the "
            f"hash of the records it contains ({dataset.content_hash}). The file has "
            f"been modified since it was written.",
        )
    return dataset


@dataclass(frozen=True, slots=True)
class StoredDataset:
    path: Path
    dataset: FxDatasetVersion


class FxDatasetStore:
    """File-backed, append-only store of FX dataset versions."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root)

    def _path_for(self, dataset_name: str, version: str) -> Path:
        safe_name = _safe_component(dataset_name)
        safe_version = _safe_component(version)
        return self.root / f"{safe_name}__{safe_version}{DATASET_FILE_SUFFIX}"

    def save(self, dataset: FxDatasetVersion, *, allow_existing: bool = True) -> Path:
        """Write a dataset version.

        Re-writing an existing version with identical content is a no-op, which
        makes imports idempotent. Re-writing it with *different* content is
        refused, because a published calculation may already reference it.
        """
        path = self._path_for(dataset.dataset_name, dataset.version)
        if path.exists():
            existing = dataset_from_dict(json.loads(path.read_text(encoding="utf-8")))
            if existing.content_hash == dataset.content_hash:
                return path
            if not allow_existing:
                raise RateError(
                    ErrorCode.FX_DATASET_MISSING,
                    f"dataset version {dataset.version_label} already exists",
                )
            raise RateError(
                ErrorCode.FX_DATASET_MISSING,
                f"dataset version {dataset.version_label} already exists with "
                f"different content (stored {existing.content_hash}, new "
                f"{dataset.content_hash}). Dataset versions are immutable; import the "
                f"corrected data as a new version instead.",
            )
        self.root.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(dataset_to_dict(dataset), indent=2, sort_keys=True),
            encoding="utf-8",
        )
        return path

    def load(self, dataset_name: str, version: str) -> FxDatasetVersion:
        path = self._path_for(dataset_name, version)
        if not path.exists():
            raise RateError(
                ErrorCode.FX_DATASET_MISSING,
                f"no stored FX dataset {dataset_name}@{version} under {self.root}",
            )
        return dataset_from_dict(json.loads(path.read_text(encoding="utf-8")))

    def load_by_id(self, dataset_id: str) -> FxDatasetVersion:
        for stored in self.list():
            if stored.dataset.dataset_id == dataset_id:
                return stored.dataset
        raise RateError(
            ErrorCode.FX_DATASET_MISSING,
            f"no stored FX dataset with id {dataset_id}",
        )

    def list(self) -> list[StoredDataset]:
        if not self.root.exists():
            return []
        stored: list[StoredDataset] = []
        for path in sorted(self.root.glob(f"*{DATASET_FILE_SUFFIX}")):
            stored.append(
                StoredDataset(
                    path=path,
                    dataset=dataset_from_dict(json.loads(path.read_text(encoding="utf-8"))),
                )
            )
        return stored

    def latest(self, dataset_name: str | None = None) -> FxDatasetVersion:
        candidates = [
            stored.dataset
            for stored in self.list()
            if dataset_name is None or stored.dataset.dataset_name == dataset_name
        ]
        if not candidates:
            raise RateError(
                ErrorCode.FX_DATASET_MISSING,
                "no stored FX datasets"
                + (f" named {dataset_name!r}" if dataset_name else "")
                + f" under {self.root}",
            )
        return max(candidates, key=lambda d: (d.imported_at, d.version))


def _safe_component(text: str) -> str:
    """Sanitize a path component: no traversal, no separators, no surprises."""
    cleaned = "".join(ch if ch.isalnum() or ch in "-._" else "_" for ch in text)
    cleaned = cleaned.strip("._") or "unnamed"
    if cleaned in {".", ".."}:
        return "unnamed"
    return cleaned[:120]


def create_override_record(
    *,
    currency: str,
    rate_date: date,
    rate_type: FxRateType,
    value: Decimal | str,
    user: str,
    reason: str,
    evidence: str,
    source_tier: SourceTier = SourceTier.STATUTORY,
    source_name: str = "manual entry by workspace user",
    original_value: Decimal | None = None,
    unit: int = 1,
    at: datetime | None = None,
) -> FxRateRecord:
    """Build a manual rate override.

    Every override records the original value, the new value, the reason, the
    user, the timestamp and a reference to the source evidence. An override
    without a reason or evidence is refused at construction, so the audit trail
    cannot end up with an unexplained number in it.
    """
    if not reason.strip():
        raise ValueError("a manual rate override requires a reason")
    if not evidence.strip():
        raise ValueError(
            "a manual rate override requires a reference to the source evidence, "
            "for example the SBI rate sheet for that date"
        )
    if not user.strip():
        raise ValueError("a manual rate override requires the acting user")
    return FxRateRecord(
        currency=currency.upper(),
        rate_date=rate_date,
        rate_type=rate_type,
        value=to_decimal(value, field="override value"),
        unit=unit,
        source_id="USER-SUPPLIED-EVIDENCE",
        source_name=source_name,
        source_tier=source_tier,
        source_document_reference=evidence,
        published_at=None,
        retrieved_at=at or datetime.now(UTC),
        status=RateStatus.MANUAL_OVERRIDE,
        override_original_value=original_value,
        override_reason=reason,
        override_user=user,
        override_at=at or datetime.now(UTC),
        override_evidence=evidence,
    )


def merge_overrides(
    dataset: FxDatasetVersion,
    overrides: Iterable[FxRateRecord],
    *,
    version: str,
    at: datetime | None = None,
) -> FxDatasetVersion:
    """Produce a new dataset version that includes manual overrides.

    The overrides are added rather than replacing the sourced records, so the
    original value remains visible next to the override in the evidence export.
    """
    return dataset.with_records(
        list(overrides),
        version=version,
        imported_at=at or datetime.now(UTC),
        notes=(
            f"{dataset.notes + '; ' if dataset.notes else ''}"
            f"includes manual overrides applied at "
            f"{(at or datetime.now(UTC)).isoformat()}"
        ),
    )
