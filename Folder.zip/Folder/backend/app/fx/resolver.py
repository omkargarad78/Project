"""Deterministic rate selection and native-to-INR conversion.

The resolver is the only place in the platform that decides which exchange rate
applies to a figure. It refuses to substitute a different rate type, refuses to
carry a rate across dates unless the rule version in force permits it, and
refuses to pick arbitrarily between two rates published on the same date.

When a rate cannot be established the resolver returns a failed
:class:`RateResolution` rather than raising, so the pipeline can flag
``FX_RATE_MISSING`` against the exact currency and date and still collect every
other missing input in the same pass.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal

from ..core.errors import ErrorCode
from ..core.money import (
    ZERO,
    Rounding,
    as_amount,
    convert,
    decimal_to_str,
    round_for_output,
)
from ..tax.rules.models import (
    FieldValuationRule,
    FxRateType,
    MissingRatePolicy,
    MultipleRatePolicy,
    RelevantDateRule,
    SourceTier,
)
from ..validation.issues import IssueCollector, IssueScope
from .models import FxDatasetVersion, FxRateRecord, RateResolution, RateStatus

INR = "INR"

#: Synthetic resolution used when the amount is already in rupees.
_IDENTITY_RULE = "IDENTITY_INR"


@dataclass(frozen=True, slots=True)
class ConversionResult:
    """A native amount, the rate that converted it, and the INR result.

    Both the original foreign amount and the converted value are retained. The
    native amount is never overwritten anywhere in the platform.
    """

    native_amount: Decimal
    currency: str
    resolution: RateResolution
    inr_amount: Decimal | None
    formula: str
    rounding_rule: Rounding
    output_decimal_places: int

    @property
    def succeeded(self) -> bool:
        return self.inr_amount is not None

    @property
    def rate_value(self) -> Decimal | None:
        return self.resolution.value

    @property
    def inr_rounded(self) -> Decimal | None:
        if self.inr_amount is None:
            return None
        return round_for_output(
            self.inr_amount,
            scale=self.output_decimal_places,
            rounding=self.rounding_rule,
        )

    def explain(self) -> str:
        if not self.succeeded:
            return (
                f"{self.currency} {decimal_to_str(self.native_amount)} could not be "
                f"converted to INR. {self.resolution.explain()}"
            )
        return (
            f"{self.currency} {decimal_to_str(self.native_amount)} x "
            f"{decimal_to_str(self.rate_value)}"
            + (f" / {self.resolution.unit}" if self.resolution.unit != 1 else "")
            + f" = INR {decimal_to_str(self.inr_rounded)}. {self.resolution.explain()}"
        )


def relevant_date_for(
    rule: FieldValuationRule,
    *,
    transaction_date: date | None = None,
    valuation_date: date | None = None,
    period_end_date: date | None = None,
) -> date:
    """Resolve a rule's prescribed relevant date against the supplied context."""
    if rule.relevant_date is RelevantDateRule.TRANSACTION_DATE:
        if transaction_date is None:
            raise ValueError("rule requires a transaction date, none supplied")
        return transaction_date
    if rule.relevant_date is RelevantDateRule.VALUATION_DATE:
        if valuation_date is None:
            raise ValueError("rule requires a valuation date, none supplied")
        return valuation_date
    if rule.relevant_date is RelevantDateRule.PERIOD_END_DATE:
        if period_end_date is None:
            raise ValueError("rule requires a period end date, none supplied")
        return period_end_date
    # PRECEDING_MONTH_END
    anchor = valuation_date or transaction_date or period_end_date
    if anchor is None:
        raise ValueError("rule requires an anchor date, none supplied")
    first_of_month = anchor.replace(day=1)
    return first_of_month - timedelta(days=1)


class FxResolver:
    """Resolves rates out of one immutable dataset version, plus overrides."""

    def __init__(
        self,
        dataset: FxDatasetVersion | None,
        *,
        multiple_rate_policy: MultipleRatePolicy = MultipleRatePolicy.FAIL,
        overrides: Iterable[FxRateRecord] = (),
        allow_secondary_source: bool = True,
    ) -> None:
        self.dataset = dataset
        self.multiple_rate_policy = multiple_rate_policy
        self.allow_secondary_source = allow_secondary_source
        self._overrides: dict[tuple[str, date, FxRateType], FxRateRecord] = {}
        for record in overrides:
            self._overrides[(record.currency, record.rate_date, record.rate_type)] = record
        self._by_key: Mapping[tuple[str, date, FxRateType], tuple[FxRateRecord, ...]] = (
            dataset.index() if dataset else {}
        )
        self._dates: dict[tuple[str, FxRateType], list[date]] = {}
        #: Every resolution performed, in call order, for the evidence export.
        self.used: dict[str, RateResolution] = {}

    # --- candidate lookup ---------------------------------------------------

    def _available_dates(self, currency: str, rate_type: FxRateType) -> list[date]:
        key = (currency, rate_type)
        if key not in self._dates:
            dataset_dates = (
                self.dataset.dates_for(currency, rate_type) if self.dataset else []
            )
            override_dates = [
                d for (c, d, t) in self._overrides if c == currency and t is rate_type
            ]
            self._dates[key] = sorted(set(dataset_dates) | set(override_dates))
        return self._dates[key]

    def _candidates(
        self, currency: str, day: date, rate_type: FxRateType
    ) -> tuple[FxRateRecord, ...]:
        override = self._overrides.get((currency, day, rate_type))
        if override is not None:
            # A manual override supersedes the dataset for that exact key.
            return (override,)
        records = self._by_key.get((currency, day, rate_type), ())
        return tuple(r for r in records if r.status is not RateStatus.REJECTED)

    def _select(
        self, candidates: tuple[FxRateRecord, ...]
    ) -> tuple[FxRateRecord | None, str | None]:
        """Apply the configured policy when a date has several rate sheets."""
        if not candidates:
            return None, None
        if len(candidates) == 1:
            return candidates[0], None
        policy = self.multiple_rate_policy
        if policy is MultipleRatePolicy.FAIL:
            return None, (
                f"{len(candidates)} rate records exist for this currency, date and rate "
                f"type, and the rule version's multiple-rate policy is FAIL, so no rate "
                f"is selected automatically."
            )
        if policy is MultipleRatePolicy.EARLIEST_PUBLICATION:
            ordered = sorted(candidates, key=lambda r: (r.published_at or datetime.max, r.rate_id))
            return ordered[0], None
        if policy is MultipleRatePolicy.LATEST_PUBLICATION:
            ordered = sorted(
                candidates,
                key=lambda r: (r.published_at or datetime.min, r.rate_id),
                reverse=True,
            )
            return ordered[0], None
        if policy is MultipleRatePolicy.HIGHEST_RATE:
            return max(candidates, key=lambda r: (r.value, r.rate_id)), None
        return min(candidates, key=lambda r: (r.value, r.rate_id)), None

    # --- resolution ---------------------------------------------------------

    def resolve(
        self,
        currency: str,
        requested_date: date,
        rule: FieldValuationRule,
    ) -> RateResolution:
        """Resolve the applicable rate for ``currency`` on ``requested_date``."""
        rate_type = rule.fx_rate_type

        if currency == INR:
            resolution = RateResolution(
                currency=INR,
                requested_date=requested_date,
                rate_type=rate_type,
                record=FxRateRecord(
                    currency=INR,
                    rate_date=requested_date,
                    rate_type=rate_type,
                    value=Decimal(1),
                    source_id="IDENTITY",
                    source_name="identity (amount already in INR)",
                    source_tier=SourceTier.STATUTORY,
                    status=RateStatus.VERIFIED,
                ),
                dataset_id=self.dataset.dataset_id if self.dataset else None,
                dataset_version=self.dataset.version_label if self.dataset else None,
                selection_rule=_IDENTITY_RULE,
            )
            return self._remember(resolution)

        if self.dataset is None and not self._overrides:
            return self._remember(
                RateResolution(
                    currency=currency,
                    requested_date=requested_date,
                    rate_type=rate_type,
                    record=None,
                    dataset_id=None,
                    dataset_version=None,
                    failure_reason=(
                        "No exchange-rate dataset is bound to this calculation, so no "
                        "rate lookup is possible."
                    ),
                )
            )

        exact, ambiguity = self._select(self._candidates(currency, requested_date, rate_type))
        if exact is not None:
            return self._remember(
                RateResolution(
                    currency=currency,
                    requested_date=requested_date,
                    rate_type=rate_type,
                    record=exact,
                    dataset_id=self.dataset.dataset_id if self.dataset else None,
                    dataset_version=self.dataset.version_label if self.dataset else None,
                    selection_rule="SAME_DATE",
                    gap_days=0,
                )
            )
        if ambiguity is not None:
            return self._remember(
                RateResolution(
                    currency=currency,
                    requested_date=requested_date,
                    rate_type=rate_type,
                    record=None,
                    dataset_id=self.dataset.dataset_id if self.dataset else None,
                    dataset_version=self.dataset.version_label if self.dataset else None,
                    selection_rule="AMBIGUOUS",
                    failure_reason=ambiguity,
                )
            )

        return self._remember(self._resolve_missing(currency, requested_date, rule))

    def _resolve_missing(
        self, currency: str, requested_date: date, rule: FieldValuationRule
    ) -> RateResolution:
        """Apply the rule version's missing-rate policy.

        A carry-back or carry-forward only happens because the rule version in
        force selected that treatment, and it is bounded by
        ``max_rate_gap_days`` so a sparse dataset cannot silently reach for a
        rate weeks away.
        """
        rate_type = rule.fx_rate_type
        policy = rule.missing_rate_policy
        dataset_id = self.dataset.dataset_id if self.dataset else None
        dataset_version = self.dataset.version_label if self.dataset else None

        def fail(reason: str, selection_rule: str = str(policy)) -> RateResolution:
            return RateResolution(
                currency=currency,
                requested_date=requested_date,
                rate_type=rate_type,
                record=None,
                dataset_id=dataset_id,
                dataset_version=dataset_version,
                selection_rule=selection_rule,
                failure_reason=reason,
            )

        if policy is MissingRatePolicy.FAIL:
            return fail(
                f"No {rate_type.label} is published for {currency} on "
                f"{requested_date.isoformat()}, and the rule version in force does not "
                f"permit using another date's rate.",
                selection_rule="FAIL",
            )

        available = self._available_dates(currency, rate_type)
        if not available:
            return fail(
                f"The dataset contains no {rate_type.label} for {currency} at all.",
            )

        before = [d for d in available if d < requested_date]
        after = [d for d in available if d > requested_date]

        candidates: list[tuple[date, str]] = []
        if policy is MissingRatePolicy.LAST_PUBLISHED_ON_OR_BEFORE and before:
            candidates.append((before[-1], "LAST_PUBLISHED_ON_OR_BEFORE"))
        elif policy is MissingRatePolicy.NEXT_PUBLISHED_ON_OR_AFTER and after:
            candidates.append((after[0], "NEXT_PUBLISHED_ON_OR_AFTER"))
        elif policy is MissingRatePolicy.NEAREST_PUBLISHED:
            options: list[tuple[int, date, str]] = []
            if before:
                options.append(
                    ((requested_date - before[-1]).days, before[-1], "NEAREST_PUBLISHED_BEFORE")
                )
            if after:
                options.append(
                    ((after[0] - requested_date).days, after[0], "NEAREST_PUBLISHED_AFTER")
                )
            if options:
                # Ties resolve to the earlier date so the choice is deterministic.
                options.sort(key=lambda o: (o[0], o[1]))
                candidates.append((options[0][1], options[0][2]))

        if not candidates:
            return fail(
                f"No {rate_type.label} for {currency} exists on the side of "
                f"{requested_date.isoformat()} that the rule version's "
                f"{policy} policy permits."
            )

        chosen_date, selection_rule = candidates[0]
        gap = abs((chosen_date - requested_date).days)
        if gap > rule.max_rate_gap_days:
            return fail(
                f"The nearest permitted {rate_type.label} for {currency} is "
                f"{chosen_date.isoformat()}, {gap} days from the relevant date "
                f"{requested_date.isoformat()}, which exceeds the {rule.max_rate_gap_days}-day "
                f"limit set by the rule version.",
                selection_rule=selection_rule,
            )

        record, ambiguity = self._select(self._candidates(currency, chosen_date, rate_type))
        if record is None:
            return fail(
                ambiguity
                or f"No usable rate record on {chosen_date.isoformat()} for {currency}.",
                selection_rule=selection_rule,
            )

        return RateResolution(
            currency=currency,
            requested_date=requested_date,
            rate_type=rate_type,
            record=record,
            dataset_id=dataset_id,
            dataset_version=dataset_version,
            selection_rule=selection_rule,
            gap_days=gap,
            notes=(
                f"{requested_date.isoformat()} is not a publication date for this rate; "
                f"the rule version permits the {selection_rule} rate.",
            ),
        )

    def _remember(self, resolution: RateResolution) -> RateResolution:
        if resolution.record is not None and resolution.selection_rule != _IDENTITY_RULE:
            self.used[resolution.record.rate_id] = resolution
        return resolution

    # --- conversion ---------------------------------------------------------

    def convert(
        self,
        native_amount: Decimal,
        currency: str,
        requested_date: date,
        rule: FieldValuationRule,
        *,
        rounding: Rounding = Rounding.HALF_UP,
        decimal_places: int = 0,
    ) -> ConversionResult:
        """Convert a native amount to INR under ``rule``.

        ``INR_VALUE = FOREIGN_CURRENCY_AMOUNT x APPLICABLE_SBI_TTBR``, with the
        rate unit applied when the rate is published per 100 units.
        """
        resolution = self.resolve(currency, requested_date, rule)
        if resolution.record is None or resolution.value is None:
            return ConversionResult(
                native_amount=as_amount(native_amount),
                currency=currency,
                resolution=resolution,
                inr_amount=None,
                formula=(
                    f"{currency} {decimal_to_str(native_amount)} x "
                    f"[{rule.fx_rate_type.label} on {requested_date.isoformat()} - UNAVAILABLE]"
                ),
                rounding_rule=rounding,
                output_decimal_places=decimal_places,
            )

        inr = convert(native_amount, resolution.value, rate_unit=resolution.unit)
        unit_text = f" / {resolution.unit}" if resolution.unit != 1 else ""
        return ConversionResult(
            native_amount=as_amount(native_amount),
            currency=currency,
            resolution=resolution,
            inr_amount=inr,
            formula=(
                f"{currency} {decimal_to_str(native_amount)} x "
                f"{decimal_to_str(resolution.value)}{unit_text} "
                f"({rule.fx_rate_type.label}, {resolution.record.rate_date.isoformat()})"
            ),
            rounding_rule=rounding,
            output_decimal_places=decimal_places,
        )

    # --- issue reporting ----------------------------------------------------

    def report(
        self,
        result: ConversionResult,
        issues: IssueCollector,
        *,
        subject: str,
        context_label: str,
    ) -> ConversionResult:
        """Raise the appropriate issues for one conversion.

        Missing rates become ``FX_RATE_MISSING`` naming the exact currency and
        date. Rates below statutory tier become ``SECONDARY_SOURCE_USED``.
        Manual overrides become ``MANUAL_OVERRIDE_PRESENT``.
        """
        resolution = result.resolution
        if not result.succeeded:
            issues.report(
                ErrorCode.FX_RATE_AMBIGUOUS
                if resolution.selection_rule == "AMBIGUOUS"
                else ErrorCode.FX_RATE_MISSING,
                scope=IssueScope.FX_RATE,
                subject=f"{resolution.currency}:{resolution.requested_date.isoformat()}",
                message=(
                    f"{context_label} for {subject} needs the "
                    f"{resolution.rate_type.label} for {resolution.currency} on "
                    f"{resolution.requested_date.isoformat()}. "
                    f"{resolution.failure_reason or ''}"
                ).strip(),
                currency=resolution.currency,
                rate_date=resolution.requested_date.isoformat(),
                rate_type=str(resolution.rate_type),
                dataset=resolution.dataset_version,
                context=context_label,
            )
            return result

        record = resolution.record
        assert record is not None
        if record.status is RateStatus.MANUAL_OVERRIDE:
            issues.report(
                ErrorCode.MANUAL_OVERRIDE_PRESENT,
                scope=IssueScope.FX_RATE,
                subject=f"{record.currency}:{record.rate_date.isoformat()}",
                message=(
                    f"{context_label} for {subject} used a manually entered "
                    f"{record.rate_type.label} of {record.quote_label} on "
                    f"{record.rate_date.isoformat()}, entered by "
                    f"{record.override_user or 'a user'} because: "
                    f"{record.override_reason or 'no reason recorded'}."
                ),
                currency=record.currency,
                rate_date=record.rate_date.isoformat(),
            )
        elif not record.source_tier.is_statutory:
            issues.report(
                ErrorCode.SECONDARY_SOURCE_USED,
                scope=IssueScope.FX_RATE,
                subject=f"{record.currency}:{record.rate_date.isoformat()}",
                message=(
                    f"The {record.rate_type.label} for {record.currency} on "
                    f"{record.rate_date.isoformat()} came from {record.source_name}, "
                    f"which is {record.source_tier.label}. It is treated as sourced "
                    f"historical data, not as a statutory publication."
                ),
                currency=record.currency,
                rate_date=record.rate_date.isoformat(),
                source_tier=int(record.source_tier),
                source=record.source_name,
            )

        if record.rate_type is not FxRateType.TT_BUY:
            issues.report(
                ErrorCode.FX_RATE_TYPE_MISMATCH,
                scope=IssueScope.FX_RATE,
                subject=f"{record.currency}:{record.rate_date.isoformat()}",
                message=(
                    f"{context_label} for {subject} used a {record.rate_type.label} "
                    f"rather than a telegraphic transfer buying rate."
                ),
                rate_type=str(record.rate_type),
            )
        return result

    def convert_and_report(
        self,
        native_amount: Decimal,
        currency: str,
        requested_date: date,
        rule: FieldValuationRule,
        issues: IssueCollector,
        *,
        subject: str,
        context_label: str,
        rounding: Rounding = Rounding.HALF_UP,
        decimal_places: int = 0,
    ) -> ConversionResult:
        result = self.convert(
            native_amount,
            currency,
            requested_date,
            rule,
            rounding=rounding,
            decimal_places=decimal_places,
        )
        return self.report(result, issues, subject=subject, context_label=context_label)

    # --- evidence export ----------------------------------------------------

    def used_records(self) -> list[FxRateRecord]:
        return sorted(
            (r.record for r in self.used.values() if r.record is not None),
            key=lambda r: (r.currency, r.rate_date, str(r.rate_type)),
        )

    def evidence_rows(self) -> list[dict[str, str]]:
        """Rows for the "SBI TTBR Used" sheet, including why each was selected."""
        rows: list[dict[str, str]] = []
        for rate_id, resolution in sorted(self.used.items(), key=lambda kv: kv[0]):
            record = resolution.record
            if record is None:
                continue
            row = record.to_row()
            row["Dataset Version"] = resolution.dataset_version or ""
            row["Requested Date"] = resolution.requested_date.isoformat()
            row["Selection Rule"] = resolution.selection_rule
            row["Gap (days)"] = str(resolution.gap_days)
            row["Why This Rate"] = resolution.explain()
            row["Rate ID"] = rate_id
            rows.append(row)
        return rows

    def total_converted(self, results: Iterable[ConversionResult]) -> Decimal:
        total = ZERO
        for result in results:
            if result.inr_amount is not None:
                total += result.inr_amount
        return as_amount(total)
