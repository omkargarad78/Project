/*
  Workspace list, and the workspace screen: statements in, calculation runs
  out, plus who else can see it.
*/

import { api } from "./api.js";
import { badge, banner, bytes, el, guard, mount, table, when } from "./dom.js";
import { crumbs, go } from "./app.js";

const RUN_TONE = { SUCCEEDED: "good", FAILED: "bad", RUNNING: "warn", QUEUED: "plain" };

export async function workspaceList() {
  crumbs([["Workspaces", null]]);
  const workspaces = await api.workspaces();

  const create = guard(async (event) => {
    const data = Object.fromEntries(new FormData(event.target));
    const created = await api.createWorkspace({
      name: data.name,
      assessment_year: data.assessment_year,
      residency_note: data.residency_note || "",
    });
    go(`/w/${created.id}`);
  });

  mount(
    el(
      "div",
      {},
      el("h1", {}, "Workspaces"),
      el(
        "p",
        { class: "lede" },
        "A workspace holds one filer's statements and calculations for one assessment year.",
      ),
      workspaces.length
        ? el(
            "ul",
            { class: "cardlist" },
            workspaces.map((w) =>
              el(
                "li",
                { class: "card" },
                el("a", { href: `#/w/${w.id}` }, w.name),
                badge(`AY ${w.assessment_year}`, "plain"),
                badge(w.role, w.role === "VIEWER" ? "plain" : "good"),
                el("span", { class: "spacer" }),
                el("span", { class: "muted" }, when(w.created_at)),
              ),
            ),
          )
        : el("p", { class: "empty" }, "No workspaces yet. Create one below to get started."),
      el("h2", {}, "New workspace"),
      el(
        "form",
        { onsubmit: create },
        el("label", {}, "Name", el("input", { name: "name", required: true, maxlength: 160, placeholder: "e.g. Omkar — FY 2024-25" })),
        el(
          "label",
          {},
          "Assessment year",
          el("input", { name: "assessment_year", required: true, pattern: "\\d{4}-\\d{2}", placeholder: "2025-26" }),
          // Worth spelling out: this trips up almost everyone the first time.
          el(
            "span",
            { class: "hint" },
            "The assessment year, not the financial year. Income earned April 2024 to March 2025 is assessed in 2025-26.",
          ),
        ),
        el(
          "label",
          {},
          "Residency note (optional)",
          el("textarea", { name: "residency_note", maxlength: 2000, placeholder: "Basis for treating the filer as a resident for this year." }),
          el(
            "span",
            { class: "hint" },
            "Schedule FA applies to residents. Recording why you concluded the filer is one keeps that judgement with the workpaper.",
          ),
        ),
        el("div", { class: "row" }, el("button", { type: "submit" }, "Create workspace")),
      ),
    ),
  );
}

export async function workspaceDetail(workspaceId) {
  crumbs([["Workspaces", "#/workspaces"], ["\u2026", null]]);

  const [workspace, files, runs, members] = await Promise.all([
    api.workspace(workspaceId),
    api.files(workspaceId),
    api.runs(workspaceId),
    api.members(workspaceId),
  ]);
  crumbs([["Workspaces", "#/workspaces"], [workspace.name, null]]);

  const writable = workspace.role !== "VIEWER";
  const reload = () => workspaceDetail(workspaceId);

  mount(
    el(
      "div",
      {},
      el("h1", {}, workspace.name),
      el("p", { class: "lede" }, `Assessment year ${workspace.assessment_year} \u00b7 your role: ${workspace.role}`),
      filesPanel(workspaceId, files, writable, reload),
      runsPanel(workspaceId, workspace, runs, files, writable, reload),
      membersPanel(workspaceId, workspace, members, reload),
    ),
  );
}

/* --- statements --------------------------------------------------------- */

function filesPanel(workspaceId, files, writable, reload) {
  const upload = guard(async (event) => {
    const input = event.target.querySelector('input[type="file"]');
    if (!input.files.length) throw new Error("Choose a file first.");
    for (const file of input.files) {
      await api.upload(workspaceId, file);
    }
    await reload();
  });

  return el(
    "section",
    {},
    el("h2", {}, "Statements"),
    el(
      "p",
      { class: "lede" },
      "Upload the transaction statement your broker exports. The original file is stored unchanged and every figure stays traceable to it by content hash.",
    ),
    table(
      [
        { label: "File", cell: (f) => f.file_name },
        { label: "Type", cell: (f) => f.file_type },
        { label: "Broker", cell: (f) => f.broker_id || el("span", { class: "muted" }, "not detected") },
        { label: "Parser", cell: (f) => f.parser_version || "\u2014" },
        { label: "Size", class: "num", cell: (f) => bytes(f.size_bytes) },
        // Shown truncated but in full on hover: this is how you prove the
        // file behind a filed figure is the file you still have.
        {
          label: "Content hash",
          cell: (f) => el("code", { title: f.file_hash }, f.file_hash.slice(0, 12)),
        },
        { label: "Uploaded", cell: (f) => when(f.created_at) },
        {
          label: "",
          cell: (f) =>
            writable
              ? el(
                  "button",
                  {
                    class: "link",
                    onclick: async () => {
                      banner(null);
                      try {
                        await api.deleteFile(workspaceId, f.id);
                        await reload();
                      } catch (error) {
                        banner(error.message);
                      }
                    },
                  },
                  "Remove",
                )
              : null,
        },
      ],
      files,
      { empty: "No statements uploaded yet." },
    ),
    writable
      ? el(
          "form",
          { onsubmit: upload, class: "wide" },
          el("div", { class: "row" }, el("input", { type: "file", multiple: true, accept: ".csv,.xlsx,.xls" }), el("button", { type: "submit" }, "Upload")),
          el("span", { class: "hint" }, "CSV or Excel. Re-uploading the same file is recognised by its hash and not stored twice."),
        )
      : null,
  );
}

/* --- runs --------------------------------------------------------------- */

function runsPanel(workspaceId, workspace, runs, files, writable, reload) {
  return el(
    "section",
    {},
    el("h2", {}, "Calculations"),
    table(
      [
        { label: "Run", cell: (r) => el("a", { href: `#/w/${workspaceId}/runs/${r.id}` }, r.id.slice(0, 10)) },
        { label: "Status", cell: (r) => badge(r.status, RUN_TONE[r.status] || "plain") },
        { label: "AY", cell: (r) => r.assessment_year },
        {
          label: "Rules",
          cell: (r) =>
            // A rule version that has not been verified against the official
            // form is usable but has to say so on every screen it appears on.
            el("span", {}, r.rule_version, " ", r.rule_verified ? badge("verified", "good") : badge("unverified", "warn")),
        },
        { label: "Readiness", cell: (r) => (r.readiness ? badge(r.readiness, r.is_filable ? "good" : "warn") : "\u2014") },
        { label: "Blocking", class: "num", cell: (r) => String(r.blocking_count) },
        { label: "Started", cell: (r) => when(r.created_at) },
        { label: "Finished", cell: (r) => when(r.finished_at) },
        { label: "", cell: (r) => (r.error_message ? el("span", { class: "figure unavailable", title: r.error_message }, "FAILED") : null) },
      ],
      runs,
      { empty: "No calculations run yet." },
    ),
    writable ? newRunForm(workspaceId, workspace, files, reload) : null,
  );
}

function newRunForm(workspaceId, workspace, files, reload) {
  const container = el("div", {}, el("p", { class: "muted" }, "Loading options\u2026"));

  (async () => {
    const [fx, market, options] = await Promise.all([
      api.fxDatasets(),
      api.marketDatasets(),
      api.runOptions(),
    ]);

    const start = guard(async (event) => {
      const data = Object.fromEntries(new FormData(event.target));
      const [name, version] = data.fx.split("\u0000");
      await api.startRun(workspaceId, {
        fx_dataset: name,
        fx_dataset_version: version,
        assessment_year: workspace.assessment_year,
        lot_allocation_method: data.lot_allocation_method,
        price_valuation_point: data.price_valuation_point,
        peak_valuation_frequency: data.peak_valuation_frequency,
        multiple_rate_policy: data.multiple_rate_policy,
        market_dataset: data.market_dataset || null,
        account_number: data.account_number || null,
      });
      await reload();
    });

    const choose = (name, label, hint) =>
      el(
        "label",
        {},
        label,
        el(
          "select",
          { name },
          options[name].map((value) => el("option", { value, selected: value === options.defaults[name] }, value)),
        ),
        hint ? el("span", { class: "hint" }, hint) : null,
      );

    container.textContent = "";
    container.appendChild(
      !files.length
        ? el("p", { class: "empty" }, "Upload a statement before running a calculation.")
        : !fx.length
          ? el(
              "p",
              { class: "empty" },
              "No exchange-rate dataset is installed. See the README for importing SBI TTBR rates — a run cannot proceed without one, and the system will not invent a rate.",
            )
          : el(
              "form",
              { onsubmit: start, class: "wide" },
              el("h3", {}, "Run a calculation"),
              el(
                "div",
                { class: "grid" },
                el(
                  "label",
                  {},
                  "Exchange-rate dataset",
                  el(
                    "select",
                    { name: "fx", required: true },
                    fx.map((d) =>
                      el(
                        "option",
                        { value: `${d.dataset_name}\u0000${d.version}` },
                        `${d.dataset_name} @ ${d.version} \u2014 ${d.record_count} rates, ${d.first_date || "?"} to ${d.last_date || "?"}`,
                      ),
                    ),
                  ),
                  el("span", { class: "hint" }, "Immutable once imported, and pinned onto the run so this calculation stays reproducible."),
                ),
                el(
                  "label",
                  {},
                  "Price dataset",
                  el(
                    "select",
                    { name: "market_dataset" },
                    el("option", { value: "" }, "None \u2014 report market values as unavailable"),
                    market.map((name) => el("option", { value: name }, name)),
                  ),
                  el("span", { class: "hint" }, "Needed for peak and closing values. Without it those figures are reported as NOT AVAILABLE, never as zero."),
                ),
                choose("lot_allocation_method", "Lot allocation", "How sales are matched to purchases. A policy choice, not a statutory rule — it is recorded on the run."),
                choose("price_valuation_point", "Valuation point", "Which point of the daily price values a holding."),
                choose("peak_valuation_frequency", "Peak search", "How often the holding is revalued when looking for the peak. Month-end is cheaper and materially different."),
                choose("multiple_rate_policy", "Duplicate rates", "What to do when a date has more than one published rate sheet."),
                el("label", {}, "Account number (optional)", el("input", { name: "account_number", maxlength: 64 }), el("span", { class: "hint" }, "Reported in Table A3 where the form asks for it.")),
              ),
              el("div", { class: "row" }, el("button", { type: "submit" }, "Run calculation")),
            ),
    );
  })().catch((error) => {
    container.textContent = "";
    container.appendChild(el("p", { class: "empty" }, error.message));
  });

  return container;
}

/* --- members ------------------------------------------------------------ */

function membersPanel(workspaceId, workspace, members, reload) {
  const administers = workspace.role === "OWNER";

  const invite = guard(async (event) => {
    const data = Object.fromEntries(new FormData(event.target));
    await api.invite(workspaceId, { email: data.email, role: data.role });
    await reload();
  });

  return el(
    "section",
    {},
    el("h2", {}, "People"),
    table(
      [
        { label: "Email", cell: (m) => m.email },
        { label: "Name", cell: (m) => m.display_name || el("span", { class: "muted" }, "\u2014") },
        { label: "Role", cell: (m) => badge(m.role, m.role === "VIEWER" ? "plain" : "good") },
        {
          label: "",
          cell: (m) =>
            administers
              ? el(
                  "button",
                  {
                    class: "link",
                    onclick: async () => {
                      banner(null);
                      try {
                        await api.revoke(workspaceId, m.user_id);
                        await reload();
                      } catch (error) {
                        // The server refuses to remove the last owner. Shown
                        // as written rather than reworded, because it names
                        // the fix: promote someone else first.
                        banner(error.message);
                      }
                    },
                  },
                  "Remove",
                )
              : null,
        },
      ],
      members,
    ),
    administers
      ? el(
          "form",
          { onsubmit: invite },
          el("h3", {}, "Add someone"),
          el("label", {}, "Email of an existing account", el("input", { type: "email", name: "email", required: true })),
          el(
            "label",
            {},
            "Role",
            el(
              "select",
              { name: "role" },
              el("option", { value: "VIEWER" }, "Viewer \u2014 read only"),
              el("option", { value: "EDITOR" }, "Editor \u2014 upload and run calculations"),
              el("option", { value: "OWNER" }, "Owner \u2014 also manages people"),
            ),
          ),
          el("div", { class: "row" }, el("button", { type: "submit", class: "secondary" }, "Add")),
        )
      : null,
  );
}
