/*
  The HTTP client.

  Two decisions worth knowing about:

  1. The access token lives in sessionStorage, not localStorage. It dies with
     the tab, which is the right lifetime for something that unlocks a year
     of someone's financial statements on a possibly shared computer.

  2. Money is never parsed. The server sends every rupee amount as a decimal
     string precisely because JSON numbers are IEEE doubles in every browser,
     and `JSON.parse` would round a long figure before it was ever displayed.
     Amounts travel from the response to the text node as strings, untouched.
     Nothing in this file calls Number() on a money field.
*/

const BASE = "/api/v1";
const TOKEN_KEY = "fa.access_token";
const EXPIRY_KEY = "fa.access_expires";

export class ApiError extends Error {
  constructor(status, code, message, detail) {
    super(message);
    this.status = status;
    this.code = code;
    this.detail = detail || {};
  }
}

export const session = {
  get token() {
    const token = sessionStorage.getItem(TOKEN_KEY);
    if (!token) return null;
    const expires = sessionStorage.getItem(EXPIRY_KEY);
    // Expired tokens are dropped here rather than sent and rejected, so the
    // user gets the sign-in screen instead of a confusing error.
    if (expires && Date.parse(expires) <= Date.now()) {
      session.clear();
      return null;
    }
    return token;
  },
  save(token, expiresAt) {
    sessionStorage.setItem(TOKEN_KEY, token);
    if (expiresAt) sessionStorage.setItem(EXPIRY_KEY, expiresAt);
  },
  clear() {
    sessionStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(EXPIRY_KEY);
  },
  get signedIn() {
    return session.token !== null;
  },
};

async function request(method, path, { body, form, raw } = {}) {
  const headers = {};
  const token = session.token;
  if (token) headers.Authorization = `Bearer ${token}`;

  let payload;
  if (form) {
    // Left as FormData so the browser sets the multipart boundary itself.
    payload = form;
  } else if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }

  const response = await fetch(BASE + path, { method, headers, body: payload });

  if (response.status === 401) {
    session.clear();
    throw new ApiError(401, "NOT_AUTHENTICATED", "Your session has ended. Sign in again.");
  }
  if (response.status === 204) return null;

  if (!response.ok) {
    let code = "ERROR";
    let message = `${response.status} ${response.statusText}`;
    let detail = {};
    try {
      const parsed = await response.json();
      code = parsed.code || code;
      message = parsed.message || message;
      detail = parsed.detail || {};
    } catch {
      // A non-JSON error body means something upstream of the app failed,
      // such as a proxy. The status line is the only reliable information.
    }
    throw new ApiError(response.status, code, message, detail);
  }

  if (raw) return response;
  return response.json();
}

export const api = {
  health: () => request("GET", "/health"),

  register: (body) => request("POST", "/auth/register", { body }),
  login: (body) => request("POST", "/auth/login", { body }),
  me: () => request("GET", "/auth/me"),

  fxDatasets: () => request("GET", "/reference/fx-datasets"),
  marketDatasets: () => request("GET", "/reference/market-datasets"),
  runOptions: () => request("GET", "/reference/run-options"),

  workspaces: () => request("GET", "/workspaces"),
  createWorkspace: (body) => request("POST", "/workspaces", { body }),
  workspace: (id) => request("GET", `/workspaces/${id}`),
  members: (id) => request("GET", `/workspaces/${id}/members`),
  invite: (id, body) => request("POST", `/workspaces/${id}/members`, { body }),
  revoke: (id, memberId) => request("DELETE", `/workspaces/${id}/members/${memberId}`),

  files: (id) => request("GET", `/workspaces/${id}/files`),
  upload: (id, file) => {
    const form = new FormData();
    form.append("file", file, file.name);
    return request("POST", `/workspaces/${id}/files`, { form });
  },
  deleteFile: (id, fileId) => request("DELETE", `/workspaces/${id}/files/${fileId}`),

  runs: (id) => request("GET", `/workspaces/${id}/runs`),
  startRun: (id, body) => request("POST", `/workspaces/${id}/runs`, { body }),
  run: (id, runId) => request("GET", `/workspaces/${id}/runs/${runId}`),

  issues: (id, runId) => request("GET", `/workspaces/${id}/runs/${runId}/issues`),
  worklist: (id, runId) => request("GET", `/workspaces/${id}/runs/${runId}/worklist`),
  decisions: (id) => request("GET", `/workspaces/${id}/decisions`),
  decide: (id, body) => request("PUT", `/workspaces/${id}/decisions`, { body }),
  withdraw: (id, key) =>
    request("DELETE", `/workspaces/${id}/decisions/${encodeURIComponent(key)}`),

  artifacts: (id, runId) => request("GET", `/workspaces/${id}/runs/${runId}/artifacts`),

  /*
    Downloads take two round trips on purpose.

    The download endpoint wants both the session header and a single-artifact
    token, so a leaked URL from a browser history or a proxy log is useless on
    its own. That also means a plain link cannot work — a browser navigation
    sends no Authorization header — so the bytes are fetched here and handed
    to the user as a blob.
  */
  async download(id, artifact) {
    const ticket = await request("POST", `/workspaces/${id}/artifacts/${artifact.id}/ticket`);
    const response = await request(
      "GET",
      `/workspaces/${id}/artifacts/${artifact.id}/download?token=${encodeURIComponent(ticket.token)}`,
      { raw: true },
    );
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = artifact.file_name;
    document.body.appendChild(link);
    link.click();
    link.remove();
    // Revoked on a delay: revoking synchronously races the browser's own
    // read of the blob in some versions.
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  },
};
