/*
  Minimal DOM helpers.

  `innerHTML` is not used anywhere in this application. Every value that
  reaches the page — a security name from a broker file, an issue message, a
  filename — goes through `document.createTextNode`, so a statement
  containing markup is displayed rather than executed. That is the same
  concern the XLSX writer handles by forcing string cell types: untrusted
  text from an upload must never become code.
*/

/** Build an element. Children may be nodes, strings, or null (skipped). */
export function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === null || value === undefined || value === false) continue;
    if (key === "class") node.className = value;
    else if (key === "dataset") Object.assign(node.dataset, value);
    else if (key.startsWith("on")) node.addEventListener(key.slice(2), value);
    else if (value === true) node.setAttribute(key, "");
    else node.setAttribute(key, value);
  }
  append(node, children);
  return node;
}

function append(parent, children) {
  for (const child of children.flat(4)) {
    if (child === null || child === undefined || child === false) continue;
    parent.appendChild(child instanceof Node ? child : document.createTextNode(String(child)));
  }
}

export const frag = (...children) => {
  const f = document.createDocumentFragment();
  append(f, children);
  return f;
};

export function clear(node) {
  while (node.firstChild) node.removeChild(node.firstChild);
  return node;
}

export function mount(node) {
  const view = document.getElementById("view");
  clear(view).appendChild(node);
  window.scrollTo(0, 0);
}

/** A table from an array of {label, class, cell(row)} column descriptors. */
export function table(columns, rows, { empty = "Nothing here yet." } = {}) {
  if (!rows.length) return el("p", { class: "empty" }, empty);
  return el(
    "div",
    { class: "scroller" },
    el(
      "table",
      {},
      el("thead", {}, el("tr", {}, columns.map((c) => el("th", { class: c.class }, c.label)))),
      el(
        "tbody",
        {},
        rows.map((row) => el("tr", {}, columns.map((c) => el("td", { class: c.class }, c.cell(row))))),
      ),
    ),
  );
}

export const badge = (text, tone = "plain") => el("span", { class: `badge ${tone}` }, text);

/** Dates are shown in ISO form; a localised format is ambiguous across regions. */
export const day = (value) => (value ? String(value).slice(0, 10) : "\u2014");

export const when = (value) => (value ? String(value).replace("T", " ").slice(0, 19) : "\u2014");

export function bytes(count) {
  if (count < 1024) return `${count} B`;
  if (count < 1024 * 1024) return `${(count / 1024).toFixed(1)} KB`;
  return `${(count / 1048576).toFixed(1)} MB`;
}

/** Show an error across the top of the page. */
export function banner(message, tone = "error") {
  const node = document.getElementById("banner");
  clear(node);
  if (!message) {
    node.hidden = true;
    return;
  }
  node.className = tone === "info" ? "banner info" : "banner";
  node.appendChild(document.createTextNode(message));
  node.hidden = false;
}

/** Wrap a submit handler so a thrown ApiError becomes a banner, not a crash. */
export function guard(handler) {
  return async (event) => {
    event.preventDefault();
    banner(null);
    const submit = event.target.querySelector?.('button[type="submit"]');
    if (submit) submit.disabled = true;
    try {
      await handler(event);
    } catch (error) {
      banner(error.message || String(error));
    } finally {
      if (submit) submit.disabled = false;
    }
  };
}
