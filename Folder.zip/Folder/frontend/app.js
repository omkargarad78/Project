/*
  Router and application shell.

  Routing is hash-based so the app can be served as static files from any
  path without a server-side rewrite rule. Each route is a function that
  fetches what it needs and mounts a view; there is no client-side store and
  nothing is cached, because a stale rupee figure is worse than a spinner.
*/

import { api, ApiError, session } from "./api.js";
import { banner, el, guard, mount } from "./dom.js";
import { workspaceDetail, workspaceList } from "./workspace.js";
import { runDetail } from "./run.js";

const ROUTES = [
  [/^\/?$/, () => go(session.signedIn ? "/workspaces" : "/signin")],
  [/^\/signin$/, () => signIn(false)],
  [/^\/register$/, () => signIn(true)],
  [/^\/workspaces$/, workspaceList],
  [/^\/w\/([\w-]+)$/, workspaceDetail],
  [/^\/w\/([\w-]+)\/runs\/([\w-]+)$/, runDetail],
];

export function go(path) {
  if (location.hash === "#" + path) render();
  else location.hash = "#" + path;
}

async function render() {
  const path = location.hash.replace(/^#/, "") || "/";
  banner(null);

  for (const [pattern, view] of ROUTES) {
    const match = pattern.exec(path);
    if (!match) continue;
    if (view !== signIn && !session.signedIn && !path.startsWith("/signin") && !path.startsWith("/register")) {
      go("/signin");
      return;
    }
    try {
      await view(...match.slice(1));
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        refreshIdentity();
        go("/signin");
        return;
      }
      mount(
        el(
          "div",
          {},
          el("h1", {}, "Something went wrong"),
          el("p", { class: "lede" }, error.message || String(error)),
          el("button", { class: "secondary", onclick: render }, "Try again"),
        ),
      );
    }
    return;
  }

  mount(el("div", {}, el("h1", {}, "Not found"), el("p", { class: "lede" }, path)));
}

/* --- sign in ------------------------------------------------------------ */

function signIn(registering) {
  const fields = [
    el("label", {}, "Email", el("input", { type: "email", name: "email", required: true, autocomplete: "username" })),
    el(
      "label",
      {},
      "Password",
      el("input", {
        type: "password",
        name: "password",
        required: true,
        minlength: registering ? 12 : 1,
        autocomplete: registering ? "new-password" : "current-password",
      }),
      // Stated up front rather than as a rejection after the fact. The
      // minimum is a server rule; repeating it here saves a round trip.
      registering ? el("span", { class: "hint" }, "At least 12 characters.") : null,
    ),
    registering
      ? el("label", {}, "Your name (optional)", el("input", { type: "text", name: "display_name", maxlength: 120 }))
      : null,
  ];

  const submit = guard(async (event) => {
    const data = Object.fromEntries(new FormData(event.target));
    if (registering) {
      await api.register({
        email: data.email,
        password: data.password,
        display_name: data.display_name || "",
      });
    }
    const token = await api.login({ email: data.email, password: data.password });
    session.save(token.access_token, token.expires_at);
    await refreshIdentity();
    go("/workspaces");
  });

  mount(
    el(
      "div",
      {},
      el("h1", {}, registering ? "Create an account" : "Sign in"),
      el(
        "p",
        { class: "lede" },
        registering
          ? "One account can hold several workspaces — typically one per assessment year, or one per person whose return you prepare."
          : "Sign in to your workspaces.",
      ),
      el("form", { onsubmit: submit }, fields, el("div", { class: "row" }, el("button", { type: "submit" }, registering ? "Create account" : "Sign in"))),
      el(
        "p",
        { class: "hint" },
        registering ? "Already registered? " : "No account yet? ",
        el("a", { href: registering ? "#/signin" : "#/register" }, registering ? "Sign in" : "Create one"),
      ),
    ),
  );
}

/* --- chrome ------------------------------------------------------------- */

export async function refreshIdentity() {
  const who = document.getElementById("whoami");
  const out = document.getElementById("signout");
  if (!session.signedIn) {
    who.textContent = "";
    out.hidden = true;
    return;
  }
  try {
    const user = await api.me();
    who.textContent = user.display_name || user.email;
    out.hidden = false;
  } catch {
    // A failure here only means the header is blank; it must not stop the
    // page the user actually asked for from rendering.
    who.textContent = "";
    out.hidden = true;
  }
}

/** Set the breadcrumb trail. Each entry is [label, hash or null]. */
export function crumbs(entries) {
  const nav = document.getElementById("breadcrumbs");
  nav.textContent = "";
  entries.forEach(([label, href], index) => {
    if (index) nav.appendChild(document.createTextNode("  /  "));
    nav.appendChild(href ? el("a", { href }, label) : document.createTextNode(label));
  });
}

document.getElementById("signout").addEventListener("click", () => {
  session.clear();
  refreshIdentity();
  go("/signin");
});

window.addEventListener("hashchange", render);
refreshIdentity().then(render);
