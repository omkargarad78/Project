/*
  One calculation run: the reported figures, why each one is what it is, and
  what still has to be decided before the return can be filed.

  The rule this screen exists to enforce visually: a figure the engine could
  not compute is shown as the words NOT AVAILABLE, never as a blank cell and
  never as 0. A blank in a Schedule FA cell reads as "I held nothing", which
  is a filing position the taxpayer did not take.
*/

import { api } from "./api.js";
import { badge, banner, bytes, day, el, guard, mount, table, when } from "./dom.js";
import { crumbs } from "./app.js";

const SEVERITY_TONE = { BLOCKING: "bad", ERROR: "bad", WARNING: "warn", INFO: "plain" };
const POLL_MS = 2000;

let pollTimer = null;

export async function runDetail(workspaceId, runId) {
  clearTimeout(pollTimer);
  crumbs([["Workspaces", "#/workspaces"], ["Workspace", `#/w/${workspaceId}`], [runId.slice(0, 10), null]]);

  const run = await api.run(workspaceId, runId);

  // Nothing to show until the engine finishes, so poll rather than making
  // the user refresh. Re-entering the route cancels the previous timer.
  if (run.status === "QUEUED" || run.status === "RUNNING") {
    mount(
      el(
        "div",
        {},
        el("h1", {}, "Calculation in progress"),
        el("p", { class: "lede" }, "Reading the statements, resolving rates and valuing each holding. This page updates itself."),
        el("p", {}, badge(run.status, "warn")),
      ),
    );
    pollTimer = setTimeout(() => runDetail(workspaceId, runId), POLL_MS);
    return;
  }

  if (run.status === "FAILED") {
    mount(
      el(
        "div",
        {},
        el("h1", {}, "Calculation failed"),
        el("p", { class: "lede" }, "No figures were produced. The run is kept, with the reason, so the attempt is on the record."),
        el("pre", { class: "panel" }, run.error_message || "No reason was recorded."),
        el("p", {}, el("a", { href: `#/w/${workspaceId}` }, "Back to the workspace")),
      ),
    );
    return;
  }

  const [worklist, issues, artifacts, decisions] = await Promise.all([
    api.worklist(workspaceId, runId),
    api.issues(workspaceId, runId),
    api.artifacts(workspaceId, runId),
    api.decisions(workspaceId),
  ]);

  const reload = () => runDetail(workspaceId, runId);

  mount(
    el(
      "div",
      {},
      header(run),
      inputsPanel(run),
      faTable("Table A3 \u2014 Foreign equity and debt interest", run.table_a3),
      faTable("Table A2 \u2014 Foreign custodial accounts", run.table_a2),
      worklistPanel(workspaceId, worklist, issues, decisions, reload),
      issuesTable(issues),
      artifactsPanel(workspaceId, artifacts),
    ),
  );
}

/* --- header ------------------------------------------------------------- */

function header(run) {
  return el(
    "div",
    {},
    el("h1", {}, "Schedule FA figures"),
    el(
      "p",
      { class: "lede" },
      `Assessment year ${run.assessment_year} \u00b7 completed ${when(run.finished_at)}`,
    ),
    el(
      "div",
      { class: "row" },
      run.is_filable ? badge("READY TO FILE", "good") : badge("NOT READY TO FILE", "bad"),
      run.readiness ? badge(run.readiness, run.is_filable ? "good" : "warn") : null,
      run.blocking_count ? badge(`${run.blocking_count} blocking`, "bad") : null,
      run.rule_verified ? badge("rules verified", "good") : badge("rules unverified", "warn"),
    ),
    run.blocking_reasons.length
      ? el(
          "div",
          { class: "panel" },
          el("h3", {}, "Why this cannot be filed yet"),
          el("ul", {}, run.blocking_reasons.map((reason) => el("li", {}, reason))),
        )
      : null,
    run.qualifications.length
      ? el(
          "div",
          { class: "panel" },
          // Qualifications do not block filing, but they change what the
          // figures mean, so they are stated next to them rather than buried.
          el("h3", {}, "Qualifications on these figures"),
          el("ul", {}, run.qualifications.map((note) => el("li", {}, note))),
        )
      : null,
  );
}

function inputsPanel(run) {
  const rows = [
    ["Rule version", run.rule_version + (run.rule_verified ? "" : " (not yet verified against the published form)")],
    ["Exchange-rate dataset", run.fx_dataset ? `${run.fx_dataset} @ ${run.fx_dataset_version}` : "none"],
    ["Price dataset", run.market_dataset || "none \u2014 market values reported as unavailable"],
    ...Object.entries(run.policy).map(([key, value]) => [key.replace(/_/g, " "), String(value)]),
  ];

  return el(
    "section",
    {},
    el("h2", {}, "What produced these figures"),
    el(
      "p",
      { class: "lede" },
      "Every input is pinned to this run. Later rate corrections or policy changes create a new run; they never alter this one.",
    ),
    run.market_data_synthetic
      ? el(
          "div",
          { class: "panel" },
          el("h3", {}, "Placeholder prices"),
          el(
            "p",
            {},
            "This run used synthetic prices. The valuations are illustrative and must not be filed. Import a real price dataset and run again.",
          ),
        )
      : null,
    table(
      [
        { label: "Input", cell: (r) => r[0] },
        { label: "Value", cell: (r) => r[1] },
      ],
      rows,
    ),
    el(
      "details",
      {},
      el("summary", {}, `Source statements (${run.source_file_hashes.length})`),
      el("ul", {}, run.source_file_hashes.map((hash) => el("li", {}, el("code", {}, hash)))),
    ),
  );
}

/* --- the form tables ---------------------------------------------------- */

function faTable(heading, rows) {
  if (!rows.length) {
    return el("section", {}, el("h2", {}, heading), el("p", { class: "empty" }, "No rows. Nothing reportable was found for this table."));
  }

  // Column order comes from the engine, which orders figures as the form
  // asks for them. Reordering them here would silently misalign a column
  // with its heading the moment the form changes.
  const labels = rows[0].figures.map((f) => f.label);

  const head = el(
    "thead",
    {},
    el(
      "tr",
      {},
      el("th", {}, "#"),
      el("th", {}, "Asset"),
      el("th", {}, "Country"),
      el("th", {}, "Acquired"),
      labels.map((label) => el("th", { class: "num" }, label)),
      el("th", {}, ""),
    ),
  );

  const body = el("tbody", {});
  for (const row of rows) {
    body.appendChild(
      el(
        "tr",
        {},
        el("td", {}, String(row.serial_number)),
        el("td", {}, el("strong", {}, row.subject), row.entity_name ? el("div", { class: "muted" }, row.entity_name) : null),
        el("td", {}, row.country_code || "\u2014"),
        el("td", {}, day(row.acquisition_date)),
        row.figures.map((figure) => el("td", { class: "num" }, amount(figure))),
        el("td", {}, row.is_complete ? badge("complete", "good") : badge("incomplete", "warn")),
      ),
    );
    body.appendChild(
      el(
        "tr",
        {},
        el(
          "td",
          { colspan: String(labels.length + 5) },
          el("details", {}, el("summary", {}, `How row ${row.serial_number} (${row.subject}) was derived`), derivation(row)),
        ),
      ),
    );
  }

  return el("section", {}, el("h2", {}, heading), el("div", { class: "scroller" }, el("table", {}, head, body)));
}

/**
 * Render one money figure.
 *
 * `inr_amount` is printed verbatim. It arrives as a decimal string from the
 * engine and is not parsed, formatted, rounded or grouped anywhere on the
 * way to this text node.
 */
function amount(figure) {
  if (figure.status === "UNAVAILABLE" || figure.inr_amount === null) {
    return el(
      "span",
      { class: "figure unavailable", title: figure.explanation || "Could not be computed." },
      "NOT AVAILABLE",
    );
  }
  const classes = figure.status === "QUALIFIED" ? "figure qualified" : "figure";
  return el("span", { class: classes, title: figure.explanation || "" }, figure.inr_amount);
}

function derivation(row) {
  const list = el("dl", { class: "derivation" });
  for (const figure of row.figures) {
    list.appendChild(el("dt", {}, `${figure.label} \u2014 ${figure.status}`));
    const parts = [];
    if (figure.native_amount) parts.push(`${figure.currency || ""} ${figure.native_amount}`.trim());
    if (figure.rate_value) parts.push(`at ${figure.rate_value} INR on ${day(figure.rate_date)}`);
    if (parts.length) list.appendChild(el("dd", {}, parts.join(" ")));
    if (figure.formula) list.appendChild(el("dd", {}, el("code", {}, figure.formula)));
    if (figure.explanation) list.appendChild(el("dd", {}, figure.explanation));
    for (const caveat of figure.caveats) {
      list.appendChild(el("dd", {}, badge("caveat", "warn"), " ", caveat));
    }
  }
  if (row.missing_fields.length) {
    list.appendChild(el("dt", {}, "Missing"));
    list.appendChild(el("dd", {}, row.missing_fields.join(", ")));
  }
  return list;
}

/* --- worklist ----------------------------------------------------------- */

function worklistPanel(workspaceId, groups, issues, decisions, reload) {
  if (!groups.length) {
    return el("section", {}, el("h2", {}, "Worklist"), el("p", { class: "empty" }, "Nothing outstanding."));
  }

  const decided = new Map(decisions.map((d) => [d.resolution_key, d]));

  // A resolution key is an opaque content-derived id, not something a client
  // can construct. The findings carry theirs, so decisions are keyed off the
  // findings rather than rebuilt from the group's code and subject — which
  // would produce a key that matches nothing.
  const byCode = new Map();
  for (const issue of issues) {
    if (!byCode.has(issue.code)) byCode.set(issue.code, []);
    byCode.get(issue.code).push(issue);
  }

  return el(
    "section",
    {},
    el("h2", {}, "Worklist"),
    el(
      "p",
      { class: "lede" },
      "Each entry is something the engine could not settle on its own. Decisions are recorded against the workspace and carried into later runs, so fixing a statement does not mean re-deciding everything.",
    ),
    el(
      "div",
      { class: "cardlist" },
      groups.map((group) => groupPanel(workspaceId, group, byCode.get(group.code) || [], decided, reload)),
    ),
  );
}

function groupPanel(workspaceId, group, groupIssues, decided, reload) {
  const body = el(
    "div",
    { class: "panel" },
    el(
      "div",
      { class: "row" },
      el("strong", {}, group.title),
      badge(group.severity, SEVERITY_TONE[group.severity] || "plain"),
      group.is_blocking ? badge("blocks filing", "bad") : null,
      badge(`${group.count} affected`, "plain"),
      el("code", {}, group.code),
    ),
    el("p", {}, group.action),
    group.remediation ? el("p", { class: "hint" }, group.remediation) : null,
    group.affected_figures.length ? el("p", { class: "hint" }, `Affects: ${group.affected_figures.join(", ")}`) : null,
    el("p", { class: "hint" }, `Subjects: ${group.subjects.join(", ")}`),
  );

  if (group.is_waivable) {
    body.appendChild(decisionForm(workspaceId, groupIssues, decided, reload));
  } else {
    body.appendChild(
      el(
        "p",
        { class: "hint" },
        // Some conditions genuinely cannot be waived — an unavailable rate is
        // not a judgement call, it is missing data.
        "This cannot be waived. It has to be fixed in the source data or by importing the missing reference data.",
      ),
    );
  }
  return body;
}

function decisionForm(workspaceId, groupIssues, decided, reload) {
  // The worklist groups by code, but a decision is recorded per condition, so
  // each finding in the group is decided separately.
  const container = el("div", {});

  // Several findings can share one condition — the same missing rate hit from
  // three holdings. Deciding it once should settle all of them, so the form
  // is drawn once per resolution key.
  const seen = new Set();

  for (const issue of groupIssues) {
    if (seen.has(issue.resolution_key)) continue;
    seen.add(issue.resolution_key);

    const decision = decided.get(issue.resolution_key);
    if (decision) {
      container.appendChild(
        el(
          "div",
          { class: "row" },
          badge(decision.status, "good"),
          el("span", {}, issue.subject),
          el("span", { class: "muted" }, decision.note),
          el("span", { class: "muted" }, when(decision.decided_at)),
          el(
            "button",
            {
              class: "link",
              onclick: async () => {
                banner(null);
                try {
                  await api.withdraw(workspaceId, issue.resolution_key);
                  await reload();
                } catch (error) {
                  banner(error.message);
                }
              },
            },
            "Withdraw",
          ),
        ),
      );
      continue;
    }

    const submit = guard(async (event) => {
      const data = Object.fromEntries(new FormData(event.target));
      await api.decide(workspaceId, {
        resolution_key: data.resolution_key,
        status: data.status,
        note: data.note,
      });
      await reload();
    });

    container.appendChild(
      el(
        "form",
        { onsubmit: submit, class: "wide" },
        el("input", { type: "hidden", name: "resolution_key", value: issue.resolution_key }),
        el(
          "div",
          { class: "row" },
          el("span", { title: issue.message }, issue.subject),
          el(
            "select",
            { name: "status" },
            el("option", { value: "ACKNOWLEDGED" }, "Acknowledge \u2014 accept as it stands"),
            el("option", { value: "RESOLVED" }, "Resolved \u2014 the data was corrected"),
          ),
          el("input", {
            name: "note",
            required: true,
            minlength: 3,
            maxlength: 2000,
            placeholder: "Why \u2014 required",
            size: 44,
          }),
          el("button", { type: "submit", class: "secondary" }, "Record"),
        ),
        el(
          "span",
          { class: "hint" },
          "A reason is required. An acknowledgement with no stated reason is indistinguishable from a mis-click a year later.",
        ),
      ),
    );
  }
  return container;
}

function issuesTable(issues) {
  if (!issues.length) return null;
  return el(
    "section",
    {},
    el("h2", {}, "All findings"),
    el(
      "details",
      {},
      el("summary", {}, `${issues.length} finding${issues.length === 1 ? "" : "s"} in full`),
      table(
        [
          { label: "Severity", cell: (i) => badge(i.severity, SEVERITY_TONE[i.severity] || "plain") },
          { label: "Code", cell: (i) => el("code", {}, i.code) },
          { label: "Scope", cell: (i) => i.scope },
          { label: "Subject", cell: (i) => i.subject },
          { label: "Finding", cell: (i) => i.message },
          { label: "Status", cell: (i) => i.status },
          { label: "Blocking", cell: (i) => (i.is_blocking ? badge("yes", "bad") : "no") },
        ],
        issues,
      ),
    ),
  );
}

/* --- artifacts ---------------------------------------------------------- */

function artifactsPanel(workspaceId, artifacts) {
  return el(
    "section",
    {},
    el("h2", {}, "Workpapers"),
    el(
      "p",
      { class: "lede" },
      "The workbook documents every figure above: the transactions behind it, the rate used, the formula and the caveats. It is the file to keep, and the file to hand to a reviewer.",
    ),
    table(
      [
        { label: "File", cell: (a) => a.file_name },
        { label: "Kind", cell: (a) => a.kind },
        { label: "Size", class: "num", cell: (a) => bytes(a.size_bytes) },
        { label: "Content hash", cell: (a) => el("code", { title: a.content_hash }, a.content_hash.slice(0, 12)) },
        {
          label: "Alterations",
          cell: (a) =>
            // An altered cell is exactly what a reviewer is meant to notice,
            // so the writer's sanitisation notes are surfaced rather than
            // left in a log file.
            a.sanitisation_notes.length
              ? el("details", {}, el("summary", {}, badge(`${a.sanitisation_notes.length}`, "warn")), el("ul", {}, a.sanitisation_notes.map((n) => el("li", {}, n))))
              : el("span", { class: "muted" }, "none"),
        },
        { label: "Created", cell: (a) => when(a.created_at) },
        {
          label: "",
          cell: (a) =>
            el(
              "button",
              {
                class: "secondary",
                onclick: async (event) => {
                  banner(null);
                  event.target.disabled = true;
                  try {
                    await api.download(workspaceId, a);
                  } catch (error) {
                    banner(error.message);
                  } finally {
                    event.target.disabled = false;
                  }
                },
              },
              "Download",
            ),
        },
      ],
      artifacts,
      { empty: "No workpapers were produced for this run." },
    ),
  );
}
