"""The same input must produce the same output. All of it, every time.

This is the property the whole platform rests on. A figure that changes
between two runs of identical data cannot be defended, a recorded decision
keyed on an unstable identifier silently disappears, and a workpaper that
differs from the one filed last week cannot be compared with it.

It is also the property that is easiest to lose by accident, because the
usual causes -- a wall-clock timestamp, a set iteration, a dictionary ordered
by a randomised hash -- leave no trace in the output that anything is wrong.
They just make it different.

These tests exist because a defect of exactly this kind did get in: the
fixture workbook embedded the wall clock in its ZIP entries, so "the same
file" was different bytes depending on which second it was built in, and
every derived identifier moved with it. Nothing failed loudly. One test about
resolution carry-forward went intermittently red and the cause looked like
anything but a timestamp.
"""

from __future__ import annotations

import io
from dataclasses import replace
from datetime import UTC, datetime

import pytest

from backend.app.brokers.vested.parser import VestedParser
from backend.app.core.hashing import hash_bytes
from backend.app.fx.resolver import FxResolver
from backend.app.io.loader import load_source
from backend.app.lots.engine import LotEngine, reconcile
from backend.app.marketdata.dataset import MarketDataSnapshot
from backend.app.marketdata.models import AdjustmentBasis
from backend.app.marketdata.provider import PriceResolver
from backend.app.reports.builder import WorkpaperBuilder, WorkpaperInputs
from backend.app.reports.csv_writer import write_csv_bundle
from backend.app.schedulefa.engine import ScheduleFaEngine
from backend.app.securities.master import SecurityMaster
from backend.app.securities.resolver import SecurityResolver
from backend.app.tax.periods import AssessmentYear
from backend.app.tax.rules.models import MultipleRatePolicy
from backend.app.validation.engine import ValidationEngine
from tests.fixtures.builders import build_xlsx, text
from tests.fixtures.marketdata.builder import nvda_split_action, unadjusted_records
from tests.fixtures.vested.builder import (
    build_renamed_column_workbook,
    build_unrecognised_workbook,
    build_vested_workbook,
)

GENERATED_AT = datetime(2026, 3, 1, 10, 0, tzinfo=UTC)


def run_pipeline(repo_root, rule_registry, fx_dataset, raw: bytes):  # noqa: ANN001, ANN201
    """One complete run, from bytes to workpaper.

    Written as a plain function rather than a fixture because these tests
    need to invoke it twice and compare, which is the opposite of what a
    cached fixture is for.
    """
    source = load_source(raw, file_name="v.xlsx")
    parser = VestedParser()
    parsed = parser.parse(source)
    issues = parsed.issues

    master = SecurityMaster.from_directory(repo_root / "data" / "securities")
    resolution = SecurityResolver(master).resolve_ledger(parsed.ledger, issues)
    book = LotEngine().build(parsed.ledger, issues)
    reconcile(
        book, parser.broker_closing_holdings(parser.parse_sections(source)), issues
    )

    snapshot = MarketDataSnapshot(
        unadjusted_records(),
        [nvda_split_action()],
        dataset_name="synthetic",
        adjustment_basis=AdjustmentBasis.UNADJUSTED,
        synthetic=True,
    )
    rule = rule_registry.rule_for("2026-27")
    fx = FxResolver(
        fx_dataset, multiple_rate_policy=MultipleRatePolicy.LATEST_PUBLICATION
    )
    report = ScheduleFaEngine(
        rule=rule,
        period=rule.schedule_fa.reporting_period.resolve(
            AssessmentYear.parse("2026-27")
        ),
        fx=fx,
        market_data=snapshot,
        price_resolver=PriceResolver(snapshot, expected_currency="USD"),
    ).build(parsed.ledger, book, resolution, issues)
    validation = ValidationEngine().assess(issues, report)

    paper = WorkpaperBuilder().build(
        WorkpaperInputs(
            schedule_fa=report,
            validation=validation,
            issues=issues,
            fx=fx,
            ledger=parsed.ledger,
            lots=book,
            securities=resolution,
            market_data=snapshot,
            source_files=[(source.file_name, source.file_hash)],
            broker=parsed.report.broker_name,
            parser_version=parsed.report.parser_version,
            generated_at=GENERATED_AT,
        )
    )
    return source, parsed, book, report, validation, issues, paper


@pytest.fixture(scope="module")
def twice(repo_root, rule_registry, fx_dataset_usd_2025):
    """Two independent runs over bytes built by two separate calls."""
    first = run_pipeline(
        repo_root, rule_registry, fx_dataset_usd_2025, build_vested_workbook()
    )
    second = run_pipeline(
        repo_root, rule_registry, fx_dataset_usd_2025, build_vested_workbook()
    )
    return first, second


# --- the fixtures themselves ---------------------------------------------


@pytest.mark.parametrize(
    "builder",
    [
        build_vested_workbook,
        build_renamed_column_workbook,
        build_unrecognised_workbook,
    ],
)
def test_a_fixture_builder_returns_the_same_bytes_every_time(builder) -> None:
    """The test data has to be as deterministic as the code under test.

    A fixture that varies makes every downstream assertion about identifiers
    a coin toss, and the resulting failures point everywhere except here.
    """
    assert builder() == builder()


def test_two_builds_of_the_same_workbook_have_the_same_hash() -> None:
    assert hash_bytes(build_vested_workbook()) == hash_bytes(build_vested_workbook())


def test_a_different_workbook_has_a_different_hash() -> None:
    """The inverse, so the test above cannot pass by hashing a constant."""
    assert hash_bytes(build_vested_workbook()) != hash_bytes(
        build_vested_workbook(include_duplicate=False)
    )


def test_no_wall_clock_leaks_into_a_built_workbook() -> None:
    """Asserted on the ZIP metadata, which is where it got in last time."""
    import zipfile

    with zipfile.ZipFile(io.BytesIO(build_xlsx({"S": [[text("a")]]}))) as archive:
        stamps = {info.date_time for info in archive.infolist()}

    assert len(stamps) == 1
    assert datetime(*stamps.pop()).year == 2025


def test_moving_the_clock_does_not_move_the_bytes(monkeypatch) -> None:
    """The regression test for the defect this module was written after.

    Calling the builder twice in a row would not have caught it: the
    timestamp only changes when the two calls fall in different seconds, so
    the test would have passed almost always and failed occasionally, which
    is exactly how the defect behaved. Moving the clock deliberately turns an
    intermittent failure into a reliable one.
    """
    import time

    clock = [time.struct_time((2025, 6, 1, 12, 0, 0, 0, 152, 0))]
    monkeypatch.setattr(time, "localtime", lambda *_: clock[0])
    early = build_vested_workbook()

    clock[0] = time.struct_time((2031, 11, 9, 3, 45, 17, 0, 313, 0))
    later = build_vested_workbook()

    assert early == later


# --- identifiers ----------------------------------------------------------


def test_transaction_ids_are_identical_across_two_runs(twice) -> None:
    """Every recorded decision is keyed on these."""
    first, second = twice

    assert [t.transaction_id for t in first[1].ledger.ordered()] == [
        t.transaction_id for t in second[1].ledger.ordered()
    ]


def test_the_source_file_id_is_identical_across_two_runs(twice) -> None:
    first, second = twice

    assert first[0].source_file_id == second[0].source_file_id
    assert first[0].file_hash == second[0].file_hash


def test_lot_ids_are_identical_across_two_runs(twice) -> None:
    first, second = twice

    assert _lot_ids(first[2]) == _lot_ids(second[2])


def test_issue_ids_and_resolution_keys_are_identical_across_two_runs(twice) -> None:
    """The resolution key is what makes an acknowledgement survive a re-run."""
    first, second = twice

    assert [i.issue_id for i in first[5]] == [i.issue_id for i in second[5]]
    assert [i.resolution_key for i in first[5]] == [
        i.resolution_key for i in second[5]
    ]


# --- figures --------------------------------------------------------------


def test_every_schedule_fa_figure_is_identical_across_two_runs(twice) -> None:
    first, second = twice

    assert _figures(first[3]) == _figures(second[3])


def test_every_explanation_is_identical_across_two_runs(twice) -> None:
    """Wording drift between runs makes two workpapers impossible to diff."""
    first, second = twice

    assert _explanations(first[3]) == _explanations(second[3])


def test_the_filing_verdict_is_identical_across_two_runs(twice) -> None:
    first, second = twice

    assert first[4].readiness is second[4].readiness
    assert first[4].blocking_reasons == second[4].blocking_reasons
    assert first[4].qualifications == second[4].qualifications


def test_the_worklist_order_is_identical_across_two_runs(twice) -> None:
    """Ordering is grouped and sorted, which is where a set would show up."""
    first, second = twice

    assert [(g.code, g.count, g.subjects) for g in first[4].groups] == [
        (g.code, g.count, g.subjects) for g in second[4].groups
    ]


# --- the document ---------------------------------------------------------


def test_the_csv_workpaper_is_byte_identical_across_two_runs(twice) -> None:
    """The strongest form of the property: compare the delivered artefact.

    CSV rather than XLSX because an XLSX is a ZIP, and comparing two of those
    would test the archive format rather than this platform.
    """
    first, second = twice
    left, _ = write_csv_bundle(first[6])
    right, _ = write_csv_bundle(second[6])

    assert [(f.file_name, f.content) for f in left] == [
        (f.file_name, f.content) for f in right
    ]


def test_the_generation_timestamp_is_the_only_thing_that_moves(
    repo_root, rule_registry, fx_dataset_usd_2025, twice
) -> None:
    """A real run stamps the current time, and nothing else should vary.

    Without this, the test above could pass simply because both runs pinned
    the clock, leaving a genuine source of drift untested.
    """
    first, _ = twice
    live = run_pipeline(
        repo_root, rule_registry, fx_dataset_usd_2025, build_vested_workbook()
    )
    paper = replace(live[6], generated_at=GENERATED_AT)

    left, _ = write_csv_bundle(first[6])
    right, _ = write_csv_bundle(paper)
    assert [f.content for f in left] == [f.content for f in right]


# --- a corrected file is a different file ---------------------------------


def test_a_changed_file_changes_the_figures(
    repo_root, rule_registry, fx_dataset_usd_2025, twice
) -> None:
    """The guard against a determinism test that passes by ignoring input."""
    first, _ = twice
    without = run_pipeline(
        repo_root,
        rule_registry,
        fx_dataset_usd_2025,
        build_vested_workbook(include_duplicate=False),
    )

    assert _figures(first[3]) != _figures(without[3])


def _lot_ids(book) -> list[str]:  # noqa: ANN001
    return [
        lot.lot_id for symbol in book.symbols() for lot in book.positions[symbol].lots
    ]


def _figures(report) -> list[tuple]:  # noqa: ANN001
    return [
        (
            row.subject,
            figure.field_name,
            str(figure.status),
            figure.native_amount,
            figure.inr_amount,
            figure.rate_date,
            figure.rate_value,
        )
        for row in (*report.table_a3, *report.table_a2)
        for figure in row.figures()
    ]


def _explanations(report) -> list[tuple[str, str, str, tuple[str, ...]]]:  # noqa: ANN001
    return [
        (row.subject, figure.field_name, figure.explanation, figure.caveats)
        for row in (*report.table_a3, *report.table_a2)
        for figure in row.figures()
    ]
