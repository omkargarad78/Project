"""The worklist against a real run of the whole pipeline.

Unit tests can assert that grouping and ordering behave. Only a full run can
assert the property that matters most: that every blank box in the produced
Schedule FA has something in the worklist telling the user how to fill it.
That property spans every stage, so it can only be tested here.
"""

from __future__ import annotations

from datetime import UTC, date, datetime

import pytest

from backend.app.brokers.vested.parser import VestedParser
from backend.app.core.errors import ErrorCode, ResolutionAction
from backend.app.fx.resolver import FxResolver
from backend.app.io.loader import load_source
from backend.app.lots.engine import LotEngine, reconcile
from backend.app.marketdata.dataset import MarketDataSnapshot
from backend.app.marketdata.models import AdjustmentBasis
from backend.app.marketdata.provider import PricePolicy, PriceResolver
from backend.app.schedulefa.engine import ScheduleFaEngine
from backend.app.securities.master import SecurityMaster
from backend.app.securities.resolver import SecurityResolver
from backend.app.tax.periods import AssessmentYear
from backend.app.tax.rules.models import MultipleRatePolicy
from backend.app.validation.engine import FilingReadiness, ValidationEngine
from backend.app.validation.issues import IssueCollector, IssueStatus
from backend.app.validation.resolutions import CarryOutcome, ResolutionStore
from tests.fixtures.marketdata.builder import nvda_split_action, unadjusted_records
from tests.fixtures.vested.builder import build_vested_workbook

NOW = datetime(2026, 2, 1, 9, 30, tzinfo=UTC)


@pytest.fixture(scope="module")
def run(repo_root, rule_registry, fx_dataset_usd_2025):
    """One full pipeline run, shared as an immutable snapshot.

    The run is expensive, so it happens once. What it returns is a tuple of
    issues rather than the live collector: recording a decision mutates a
    collector, and a shared mutable one would let one test's acknowledgement
    silently change what the next test sees.
    """
    source = load_source(build_vested_workbook(), file_name="v.xlsx")
    parser = VestedParser()
    parsed = parser.parse(source)
    issues = parsed.issues

    master = SecurityMaster.from_directory(repo_root / "data" / "securities")
    resolution = SecurityResolver(master).resolve_ledger(parsed.ledger, issues)
    book = LotEngine().build(parsed.ledger, issues)

    stated = parser.broker_closing_holdings(parser.parse_sections(source))
    reconcile(book, stated, issues)

    snapshot = MarketDataSnapshot(
        unadjusted_records(),
        [nvda_split_action()],
        dataset_name="synthetic",
        adjustment_basis=AdjustmentBasis.UNADJUSTED,
        synthetic=True,
    )
    rule = rule_registry.rule_for("2026-27")
    engine = ScheduleFaEngine(
        rule=rule,
        period=rule.schedule_fa.reporting_period.resolve(
            AssessmentYear.parse("2026-27")
        ),
        fx=FxResolver(
            fx_dataset_usd_2025,
            multiple_rate_policy=MultipleRatePolicy.LATEST_PUBLICATION,
        ),
        market_data=snapshot,
        price_resolver=PriceResolver(snapshot, expected_currency="USD"),
    )
    report = engine.build(parsed.ledger, book, resolution, issues)
    # Assessment can raise issues of its own; do it once here so the snapshot
    # is the full set every test starts from.
    ValidationEngine().assess(issues, report)
    return parsed.ledger, tuple(issues), report


@pytest.fixture()
def ledger(run):
    return run[0]


@pytest.fixture()
def issues(run):
    """A fresh collector per test, populated from the shared snapshot."""
    return IssueCollector(list(run[1]))


@pytest.fixture()
def report(run):
    return run[2]


def test_every_blank_box_has_something_in_the_worklist(issues, report) -> None:
    """The property this module exists for.

    A gap in the form with no issue behind it is the worst outcome available:
    the user sees an empty box and finds nothing telling them how to fill it.
    """
    result = ValidationEngine().assess(issues, report)

    assert report.incomplete_rows(), "the fixture is meant to be incomplete"
    assert result.unexplained_gaps == []


def test_the_run_is_blocked_and_says_why(issues, report) -> None:
    result = ValidationEngine().assess(issues, report)

    assert result.readiness is FilingReadiness.BLOCKED
    assert not result.is_filable
    assert result.blocking_reasons


def test_the_account_details_appear_as_their_own_task(issues, report) -> None:
    """Table A2 needs three things no transaction export contains."""
    result = ValidationEngine().assess(issues, report)

    group = next(
        g for g in result.groups if g.code is ErrorCode.ACCOUNT_DETAILS_MISSING
    )
    assert group.action is ResolutionAction.SUPPLY_ACCOUNT_DETAILS
    assert group.is_blocking
    assert group.is_waivable is False


def test_the_missing_entity_details_are_one_task_not_four(issues, report) -> None:
    """VOO needs a name, an address, a ZIP and a country code: one visit."""
    result = ValidationEngine().assess(issues, report)

    entity_work = [
        g
        for g in result.groups
        if g.action is ResolutionAction.SUPPLY_ENTITY_DETAILS
    ]
    assert entity_work
    clustered = result.by_action()[ResolutionAction.SUPPLY_ENTITY_DETAILS]
    assert clustered == entity_work


def test_groups_know_which_figures_they_stand_in_the_way_of(issues, report) -> None:
    result = ValidationEngine().assess(issues, report)

    with_impact = [g for g in result.groups if g.affected_figures]
    assert with_impact
    for group in with_impact:
        for entry in group.affected_figures:
            subject = entry.split(":")[0]
            assert subject in group.subjects


def test_two_conditions_on_one_account_claim_different_blanks(
    issues, report
) -> None:
    """Over-claiming impact would make the worklist appear not to move.

    Both conditions concern the same account. If each claimed all of that
    account's blank fields, a user would supply the account number, watch the
    count stay where it was, and stop trusting the list.
    """
    result = ValidationEngine().assess(issues, report)
    account = next(
        g for g in result.groups if g.code is ErrorCode.ACCOUNT_DETAILS_MISSING
    )
    institution = next(
        g for g in result.groups if g.code is ErrorCode.INSTITUTION_DETAILS_MISSING
    )

    assert set(account.affected_figures).isdisjoint(institution.affected_figures)
    assert any("Account Number" in f for f in account.affected_figures)
    assert any(
        "Name of the Financial Institution" in f
        for f in institution.affected_figures
    )
    assert not any("Account Number" in f for f in institution.affected_figures)


def test_one_condition_seen_many_times_is_one_qualification(issues, report) -> None:
    """The synthetic rate dataset is tier 4, so every rate raises a warning."""
    result = ValidationEngine().assess(issues, report)

    secondary = [q for q in result.qualifications if "secondary historical" in q]
    assert len(secondary) == 1
    assert "occurrence(s) across" in secondary[0]


def test_the_missing_msft_history_is_named_as_an_upload(issues, report) -> None:
    result = ValidationEngine().assess(issues, report)

    uploads = [
        g
        for g in result.groups
        if g.action is ResolutionAction.UPLOAD_EARLIER_STATEMENT
    ]
    assert uploads
    assert any("MSFT" in g.subjects for g in uploads)


def test_the_unverified_rules_are_a_qualification_not_a_blocker(issues, report) -> None:
    result = ValidationEngine().assess(issues, report)

    assert any("have not been verified" in q for q in result.qualifications)
    assert not any(
        "not been verified" in reason for reason in result.blocking_reasons
    )


def test_the_summary_leads_with_the_verdict_then_the_work(issues, report) -> None:
    text = ValidationEngine().assess(issues, report).summary()

    assert text.startswith("=== Not ready to file ===")
    assert "what stops this being filed:" in text
    assert "worklist, most valuable first" in text
    assert "figures missing with no issue raised" not in text


def test_reconciliation_can_be_accepted_but_missing_data_cannot(issues, report) -> None:
    """The two kinds of error behave differently, on real issues."""
    store = ResolutionStore()

    reconciliation = issues.by_code(ErrorCode.LOT_RECONCILIATION_FAILED)
    unwaivable = issues.by_code(ErrorCode.ACQUISITION_COST_MISSING)
    assert reconciliation and unwaivable

    store.acknowledge(
        reconciliation[0],
        note="the duplicated row is a known export defect",
        user="omkar",
        at=NOW,
    )
    store.acknowledge(
        unwaivable[0], note="filing without the cost basis", user="omkar", at=NOW
    )
    store.apply(issues)

    accepted = {i.resolution_key: i for i in issues}
    assert accepted[reconciliation[0].resolution_key].is_blocking is False
    assert accepted[unwaivable[0].resolution_key].is_blocking is True


def test_accepting_the_reconciliation_break_changes_the_worklist(issues, report) -> None:
    before = ValidationEngine().assess(issues, report)

    fresh = IssueCollector(list(issues))
    store = ResolutionStore()
    for item in fresh.by_code(ErrorCode.LOT_RECONCILIATION_FAILED):
        store.acknowledge(item, note="known export defect", user="omkar", at=NOW)
    carried = store.apply(fresh)
    after = ValidationEngine().assess(fresh, report)

    assert all(r.outcome is CarryOutcome.CARRIED for r in carried)
    assert len(after.blocking_reasons) < len(before.blocking_reasons)
    assert after.readiness is FilingReadiness.BLOCKED


def test_decisions_survive_a_rerun_of_the_whole_pipeline(issues, tmp_path) -> None:
    """Re-parsing the same file must not discard recorded decisions.

    Issue ids are regenerated from scratch on every run, so this is the test
    that the persistence key is stable across a real re-run rather than only
    across a hand-built pair of issues.
    """
    store = ResolutionStore()
    for item in issues.by_code(ErrorCode.DUPLICATE_TRANSACTION):
        store.acknowledge(item, note="both trades are real", user="omkar", at=NOW)
    assert len(store) >= 1
    path = tmp_path / "resolutions.json"
    store.save(path)

    rerun = VestedParser().parse(
        load_source(build_vested_workbook(), file_name="v.xlsx")
    )
    carried = ResolutionStore.load(path).apply(rerun.issues)

    assert carried
    assert all(r.outcome is CarryOutcome.CARRIED for r in carried)
    duplicates = rerun.issues.by_code(ErrorCode.DUPLICATE_TRANSACTION)
    assert duplicates
    assert all(i.status is IssueStatus.ACKNOWLEDGED for i in duplicates)
    assert all(i.resolution_note == "both trades are real" for i in duplicates)


def test_a_corrected_file_makes_the_decision_obsolete(issues) -> None:
    """The decision is not carried onto data it was never about."""
    store = ResolutionStore()
    for item in issues.by_code(ErrorCode.DUPLICATE_TRANSACTION):
        store.acknowledge(item, note="both trades are real", user="omkar", at=NOW)

    corrected = VestedParser().parse(
        load_source(
            build_vested_workbook(include_duplicate=False), file_name="v.xlsx"
        )
    )
    carried = store.apply(corrected.issues)

    assert carried
    assert all(r.outcome is CarryOutcome.OBSOLETE for r in carried)
    assert not corrected.issues.by_code(ErrorCode.DUPLICATE_TRANSACTION)


def test_a_clean_period_with_no_holdings_is_ready(
    rule_registry, fx_dataset_usd_2025
) -> None:
    """The verdict must be reachable, or it means nothing.

    A run with nothing to report and no issues should say READY rather than
    finding something to complain about.
    """
    issues = IssueCollector()
    rule = rule_registry.rule_for("2026-27")
    snapshot = MarketDataSnapshot(
        unadjusted_records(),
        dataset_name="synthetic",
        adjustment_basis=AdjustmentBasis.UNADJUSTED,
        synthetic=True,
    )
    engine = ScheduleFaEngine(
        rule=rule,
        period=rule.schedule_fa.reporting_period.resolve(
            AssessmentYear.parse("2026-27")
        ),
        fx=FxResolver(fx_dataset_usd_2025),
        market_data=snapshot,
        price_resolver=PriceResolver(
            snapshot, policy=PricePolicy(), expected_currency="USD"
        ),
    )
    from backend.app.lots.engine import LotBook
    from backend.app.securities.resolver import ResolutionReport
    from backend.app.transactions.ledger import TransactionLedger

    report = engine.build(
        TransactionLedger(),
        LotBook(),
        ResolutionReport(),
        issues,
        include_cash_account=False,
    )
    result = ValidationEngine().assess(issues, report)

    assert report.table_a3 == []
    # The only thing left to say is that the rules are unconfirmed.
    assert result.readiness is FilingReadiness.READY_WITH_QUALIFICATIONS
    assert result.is_filable
    assert [g.code for g in result.groups] == [ErrorCode.TAX_RULE_UNVERIFIED]


def test_a_date_outside_the_period_is_not_reported(ledger, report) -> None:
    """Guards the fixture assumption the other tests rest on."""
    assert report.period_start == date(2025, 1, 1)
    assert all(t.transaction_date.year == 2025 for t in ledger.ordered())
