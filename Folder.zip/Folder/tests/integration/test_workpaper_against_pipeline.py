"""The workpaper against a real run of the whole pipeline.

The unit tests prove the writers behave. Only a full run can prove the thing
the document exists for: that what a preparer reads in the file is what the
engines actually computed, digit for digit, with nothing rounded on the way
out and nothing unavailable quietly turned into a zero.
"""

from __future__ import annotations

import csv
import io
from datetime import UTC, date, datetime
from decimal import Decimal

import pytest
from openpyxl import load_workbook

from backend.app.brokers.vested.parser import VestedParser
from backend.app.fx.resolver import FxResolver
from backend.app.io.loader import load_source
from backend.app.lots.engine import LotEngine, reconcile
from backend.app.marketdata.dataset import MarketDataSnapshot
from backend.app.marketdata.models import AdjustmentBasis
from backend.app.marketdata.provider import PriceResolver
from backend.app.reports.builder import WorkpaperBuilder, WorkpaperInputs
from backend.app.reports.csv_writer import write_csv_bundle
from backend.app.reports.models import UNAVAILABLE_TEXT
from backend.app.reports.xlsx_writer import write_xlsx
from backend.app.schedulefa.engine import ScheduleFaEngine
from backend.app.schedulefa.models import FigureStatus
from backend.app.securities.master import SecurityMaster
from backend.app.securities.resolver import SecurityResolver
from backend.app.tax.periods import AssessmentYear
from backend.app.tax.rules.models import MultipleRatePolicy
from backend.app.validation.engine import ValidationEngine
from tests.fixtures.marketdata.builder import nvda_split_action, unadjusted_records
from tests.fixtures.vested.builder import build_vested_workbook

GENERATED_AT = datetime(2026, 3, 1, 10, 0, tzinfo=UTC)

EXPECTED_SHEETS = [
    "Cover",
    "Methodology",
    "Schedule FA A2",
    "Schedule FA A3",
    "Figure Derivation",
    "Peak Valuation",
    "Exchange Rates Used",
    "Transactions",
    "Lots",
    "Disposals",
    "Securities",
    "Worklist",
    "Issues",
]


@pytest.fixture(scope="module")
def built(repo_root, rule_registry, fx_dataset_usd_2025):
    """One full pipeline run, carried through to a finished workpaper."""
    source = load_source(build_vested_workbook(), file_name="v.xlsx")
    parser = VestedParser()
    parsed = parser.parse(source)
    issues = parsed.issues

    master = SecurityMaster.from_directory(repo_root / "data" / "securities")
    resolution = SecurityResolver(master).resolve_ledger(parsed.ledger, issues)
    book = LotEngine().build(parsed.ledger, issues)
    reconcile(
        book, parser.broker_closing_holdings(parser.parse_sections(source)), issues
    )

    snapshot = MarketDataSnapshot(
        unadjusted_records(),
        [nvda_split_action()],
        dataset_name="synthetic",
        adjustment_basis=AdjustmentBasis.UNADJUSTED,
        synthetic=True,
    )
    rule = rule_registry.rule_for("2026-27")
    fx = FxResolver(
        fx_dataset_usd_2025,
        multiple_rate_policy=MultipleRatePolicy.LATEST_PUBLICATION,
    )
    report = ScheduleFaEngine(
        rule=rule,
        period=rule.schedule_fa.reporting_period.resolve(
            AssessmentYear.parse("2026-27")
        ),
        fx=fx,
        market_data=snapshot,
        price_resolver=PriceResolver(snapshot, expected_currency="USD"),
    ).build(parsed.ledger, book, resolution, issues)
    validation = ValidationEngine().assess(issues, report)

    paper = WorkpaperBuilder().build(
        WorkpaperInputs(
            schedule_fa=report,
            validation=validation,
            issues=issues,
            fx=fx,
            ledger=parsed.ledger,
            lots=book,
            securities=resolution,
            market_data=snapshot,
            source_files=[(source.file_name, source.file_hash)],
            broker=parser.broker_name,
            parser_version=parser.parser_version,
            generated_at=GENERATED_AT,
            generated_by="integration test",
        )
    )
    return paper, report, validation, parsed.ledger, book


@pytest.fixture(scope="module")
def paper(built):
    return built[0]


@pytest.fixture(scope="module")
def workbook(built):
    content, _log = write_xlsx(built[0])
    return load_workbook(io.BytesIO(content))


@pytest.fixture(scope="module")
def csv_files(built):
    files, _log = write_csv_bundle(built[0])
    return {f.file_name: f.content.decode("utf-8-sig") for f in files}


# --- the document is complete --------------------------------------------


def test_every_expected_sheet_is_present_and_in_order(paper) -> None:
    assert [sheet.name for sheet in paper.sheets] == EXPECTED_SHEETS


def test_the_xlsx_has_the_same_sheets(workbook) -> None:
    assert workbook.sheetnames == EXPECTED_SHEETS


def test_the_csv_bundle_has_one_file_per_sheet_plus_a_manifest(csv_files) -> None:
    assert len(csv_files) == len(EXPECTED_SHEETS) + 1
    assert "00-manifest.csv" in csv_files


def test_the_csv_file_names_are_ordered_like_the_sheets(csv_files) -> None:
    """Sorting the folder has to reproduce the reading order."""
    ordered = sorted(csv_files)
    assert ordered[0] == "00-manifest.csv"
    assert "cover" in ordered[1]
    assert "issues" in ordered[-1]


# --- what it says matches what was computed ------------------------------


def test_the_reported_rupee_figures_are_the_engine_figures_exactly(
    built, workbook
) -> None:
    """No rounding, no float, no reformatting between engine and file."""
    _paper, report, *_ = built
    table = _Table(workbook["Schedule FA A3"])
    headings = {
        "initial_value": "Initial Value (INR)",
        "peak_value": "Peak Value (INR)",
        "closing_value": "Closing Value (INR)",
        "income_credited": "Gross Amount Credited (INR)",
        "gross_proceeds": "Gross Proceeds (INR)",
    }

    for a3 in report.table_a3:
        row = table.find(Ticker=a3.symbol)
        for attribute, heading in headings.items():
            figure = getattr(a3, attribute)
            value = table.value(row, heading)
            if figure.status is FigureStatus.UNAVAILABLE:
                assert value == UNAVAILABLE_TEXT
            else:
                assert value == (figure.inr_amount or Decimal(0))
                assert isinstance(value, Decimal | int)


def test_an_unavailable_figure_is_never_written_as_zero(built, workbook) -> None:
    """The failure that would matter: a blank read as a nil holding."""
    _paper, report, *_ = built
    unavailable = [
        (row.symbol, figure.label)
        for row in report.table_a3
        for figure in row.figures()
        if figure.status is FigureStatus.UNAVAILABLE
    ]
    assert unavailable, "the fixture is meant to have gaps"

    table = _Table(workbook["Figure Derivation"])
    for subject, label in unavailable:
        row = table.find(Subject=subject, Field=label)
        assert table.value(row, "INR Amount") == UNAVAILABLE_TEXT


def test_a_genuine_nil_is_written_as_a_number(built, workbook) -> None:
    """Nil and unknown must not look the same on the page."""
    _paper, report, *_ = built
    nils = [
        (row.symbol, figure.label)
        for row in report.table_a3
        for figure in row.figures()
        if figure.status is FigureStatus.NIL
    ]
    if not nils:
        pytest.skip("this fixture produced no nil figures")

    table = _Table(workbook["Figure Derivation"])
    subject, label = nils[0]
    cell = table.cell(table.find(Subject=subject, Field=label), "INR Amount")

    assert cell.value == 0
    assert cell.data_type == "n"


def test_every_reported_figure_has_a_derivation_row(built, workbook) -> None:
    _paper, report, *_ = built
    expected = sum(
        len(row.figures()) for row in (*report.table_a3, *report.table_a2)
    )

    assert len(_Table(workbook["Figure Derivation"])) == expected


def test_every_derivation_row_explains_itself(workbook) -> None:
    """A figure with no reasoning behind it cannot be defended later."""
    table = _Table(workbook["Figure Derivation"])
    for row in table.rows:
        assert table.value(row, "Explanation"), (
            f"{table.value(row, 'Subject')} "
            f"{table.value(row, 'Field')} has no explanation"
        )


def test_the_transaction_count_matches_the_ledger(built, workbook) -> None:
    _paper, _report, _validation, ledger, _book = built

    assert len(_Table(workbook["Transactions"])) == len(ledger.ordered())


def test_every_transaction_carries_its_source_reference(workbook) -> None:
    """The trace back to a cell in the broker's own export."""
    table = _Table(workbook["Transactions"])
    assert all(table.column("Source")), "a transaction with no source reference"


def test_the_worklist_matches_the_validation_report(built, workbook) -> None:
    _paper, _report, validation, *_ = built
    table = _Table(workbook["Worklist"])

    assert len(table) == len(validation.groups)
    assert table.column("Condition") == [g.title for g in validation.groups]


def test_the_peak_sheet_selects_exactly_one_date_per_computed_peak(
    built, workbook
) -> None:
    _paper, report, *_ = built
    table = _Table(workbook["Peak Valuation"])
    selected: dict[str, int] = {}
    for row in table.rows:
        if table.value(row, "Selected as Peak") == "yes":
            ticker = table.value(row, "Ticker")
            selected[ticker] = selected.get(ticker, 0) + 1

    for a3 in report.table_a3:
        if a3.peak_value.status is FigureStatus.UNAVAILABLE:
            continue
        if not a3.peak_value.valuation_points:
            continue
        assert selected.get(a3.symbol) == 1, f"{a3.symbol} peak date is ambiguous"


def test_the_peak_is_selected_on_the_rupee_value(built) -> None:
    """The dollar high and the rupee high can fall on different dates.

    Asserted here rather than in the engine tests because it is the claim
    the Peak Valuation sheet's preamble makes to the reader.
    """
    _paper, report, *_ = built
    for a3 in report.table_a3:
        figure = a3.peak_value
        if figure.status is FigureStatus.UNAVAILABLE or not figure.valuation_points:
            continue
        dollar_high = max(p.value_native for p in figure.valuation_points)
        assert figure.native_amount <= dollar_high
        assert "rupee" in figure.explanation.lower()


# --- the verdict is on the front page ------------------------------------


def test_a_blocked_run_says_so_before_any_figure(built, workbook) -> None:
    _paper, _report, validation, *_ = built
    assert not validation.is_filable

    cover = "\n".join(
        str(cell.value)
        for row in workbook["Cover"].iter_rows()
        for cell in row
        if cell.value is not None
    )
    assert "DO NOT FILE" in cover
    assert validation.readiness.label in cover


def test_the_cover_records_the_uploaded_file_and_its_hash(built, workbook) -> None:
    cover = "\n".join(
        str(cell.value)
        for row in workbook["Cover"].iter_rows()
        for cell in row
        if cell.value is not None
    )
    assert "Source file: v.xlsx" in cover
    assert "vested-parser-1.0.0" in cover


def test_unverified_rules_are_disclosed_on_the_methodology_sheet(
    built, workbook
) -> None:
    _paper, report, *_ = built
    if report.rule_verified:
        pytest.skip("rules are verified in this fixture")

    text = "\n".join(
        str(cell.value)
        for row in workbook["Methodology"].iter_rows()
        for cell in row
        if cell.value is not None
    )
    assert "NOT VERIFIED" in text


def test_synthetic_prices_are_disclosed(workbook) -> None:
    """The fixture's prices are invented; the document has to say so."""
    text = "\n".join(
        str(cell.value)
        for row in workbook["Methodology"].iter_rows()
        for cell in row
        if cell.value is not None
    )
    assert "SYNTHETIC DATA" in text


def test_incomplete_rows_are_footnoted_on_the_table_they_appear_on(
    built, paper
) -> None:
    _paper, report, *_ = built
    footnotes = "\n".join(
        next(s for s in paper.sheets if s.name == "Schedule FA A3").footnotes
    )

    for row in report.table_a3:
        if row.missing_fields():
            assert f"Row {row.serial_number} ({row.symbol}) is incomplete" in footnotes


# --- the two formats agree ------------------------------------------------


def test_the_csv_carries_the_same_figures_as_the_xlsx(built, csv_files) -> None:
    _paper, report, *_ = built
    name = next(n for n in csv_files if "schedule-fa-a3" in n)
    rows = list(csv.reader(io.StringIO(csv_files[name])))
    body = {row[1]: row for row in rows if row and row[0].isdigit()}

    for a3 in report.table_a3:
        row = body[a3.symbol]
        figure = a3.closing_value
        if figure.status is FigureStatus.UNAVAILABLE:
            assert row[11] == UNAVAILABLE_TEXT
        else:
            assert Decimal(row[11]) == (figure.inr_amount or Decimal(0))


def test_the_csv_rows_match_the_xlsx_rows_sheet_for_sheet(paper, csv_files) -> None:
    for sheet in paper.sheets:
        name = next(
            (n for n in csv_files if n != "00-manifest.csv" and _slug(sheet) in n),
            None,
        )
        assert name, f"no CSV file for {sheet.name}"
        rows = list(csv.reader(io.StringIO(csv_files[name])))
        data = [r for r in rows if r and r[0] not in ("", "#")]
        assert len(data) >= len(sheet.rows), sheet.name


def test_decimals_survive_the_csv_as_digit_strings(built, csv_files) -> None:
    """A rupee figure written through float() would lose its last digits."""
    _paper, report, *_ = built
    name = next(n for n in csv_files if "figure-derivation" in n)
    text = csv_files[name]

    for row in report.table_a3:
        for figure in row.figures():
            if figure.inr_amount is None:
                continue
            assert str(figure.inr_amount) in text


# --- nothing hostile got through -----------------------------------------


def test_no_cell_in_the_workbook_is_a_formula(workbook) -> None:
    """The broker file is untrusted input and every string here came from it."""
    for name in workbook.sheetnames:
        for row in workbook[name].iter_rows():
            for cell in row:
                assert cell.data_type != "f", f"{name}!{cell.coordinate}"


def test_no_csv_field_starts_with_a_trigger_character(csv_files) -> None:
    for name, content in csv_files.items():
        for row in csv.reader(io.StringIO(content)):
            for field in row:
                if field[:1] in ("=", "@") or field[:2] in ("+=", "-="):
                    raise AssertionError(f"{name}: {field!r}")


def test_dates_are_written_as_dates_not_strings(workbook) -> None:
    """So a preparer can sort and filter the ledger."""
    table = _Table(workbook["Transactions"])
    assert isinstance(table.value(table.rows[0], "Date"), date | datetime)


class _Table:
    """A sheet's data rows, addressed by column heading.

    Addressing by position would make these tests break, silently and in the
    wrong place, the first time a column is inserted. The heading is what a
    reader uses, so it is what the tests use.
    """

    def __init__(self, sheet) -> None:  # noqa: ANN001
        rows = list(sheet.iter_rows())
        heading_index = next(
            index
            for index, row in enumerate(rows)
            if sum(1 for cell in row if cell.value is not None) > 1
            and row[0].font is not None
            and row[0].font.bold
        )
        self.headings = [cell.value for cell in rows[heading_index]]
        self.rows = []
        for row in rows[heading_index + 1 :]:
            if all(cell.value is None for cell in row):
                break
            self.rows.append(row)

    def __len__(self) -> int:
        return len(self.rows)

    def cell(self, row, heading: str):  # noqa: ANN001, ANN202
        return row[self.headings.index(heading)]

    def value(self, row, heading: str):  # noqa: ANN001, ANN202
        return self.cell(row, heading).value

    def column(self, heading: str) -> list:
        return [self.value(row, heading) for row in self.rows]

    def find(self, **match: object):  # noqa: ANN201
        for row in self.rows:
            if all(
                self.value(row, heading.replace("_", " ")) == wanted
                for heading, wanted in match.items()
            ):
                return row
        raise AssertionError(f"no row matching {match}")


def _slug(sheet) -> str:  # noqa: ANN001
    return sheet.name.lower().replace(" ", "-")
