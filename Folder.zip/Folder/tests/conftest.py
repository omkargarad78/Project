"""Shared test fixtures.

All FX and market-price fixtures are synthetic, generated deterministically by
``scripts/make_synthetic_fixtures.py``. They are imported at community-dataset
tier so that any test asserting on provenance sees the same non-statutory
labelling a real community dataset would produce.
"""

from __future__ import annotations

import os
from datetime import UTC, datetime
from pathlib import Path

import pytest

os.environ.setdefault("FA_ENVIRONMENT", "test")

from backend.app.fx.ingestion import SbiRateIngestor  # noqa: E402
from backend.app.fx.models import FxDatasetVersion  # noqa: E402
from backend.app.tax.rules.models import FxRateType, SourceTier  # noqa: E402
from backend.app.tax.rules.registry import RuleRegistry  # noqa: E402

REPO_ROOT = Path(__file__).resolve().parents[1]
FIXTURES = Path(__file__).resolve().parent / "fixtures"

SYNTHETIC_FX_SOURCE_ID = "TEST-SYNTHETIC-FX"
SYNTHETIC_FX_SOURCE_NAME = "synthetic test fixture (not SBI data)"
IMPORTED_AT = datetime(2026, 1, 15, 10, 30, tzinfo=UTC)


@pytest.fixture(scope="session")
def repo_root() -> Path:
    return REPO_ROOT


@pytest.fixture(scope="session")
def fixtures_dir() -> Path:
    return FIXTURES


@pytest.fixture(scope="session")
def rule_registry() -> RuleRegistry:
    return RuleRegistry.from_directory(REPO_ROOT / "data" / "rules")


@pytest.fixture(scope="session")
def fx_fixture_2025_path() -> Path:
    path = FIXTURES / "fx" / "synthetic_ttbr_2025.csv"
    if not path.exists():
        pytest.skip("run scripts/make_synthetic_fixtures.py to generate FX fixtures")
    return path


@pytest.fixture(scope="session")
def fx_fixture_2024_path() -> Path:
    path = FIXTURES / "fx" / "synthetic_ttbr_2024.csv"
    if not path.exists():
        pytest.skip("run scripts/make_synthetic_fixtures.py to generate FX fixtures")
    return path


@pytest.fixture(scope="session")
def fx_fixture_2025_bytes(fx_fixture_2025_path: Path) -> bytes:
    return fx_fixture_2025_path.read_bytes()


@pytest.fixture(scope="session")
def synthetic_fx_ingestor() -> SbiRateIngestor:
    return SbiRateIngestor(
        source_id=SYNTHETIC_FX_SOURCE_ID,
        source_name=SYNTHETIC_FX_SOURCE_NAME,
        source_tier=SourceTier.COMMUNITY_DATASET,
        dataset_name="synthetic-ttbr",
    )


@pytest.fixture(scope="session")
def fx_dataset_usd_2025(
    synthetic_fx_ingestor: SbiRateIngestor, fx_fixture_2025_bytes: bytes
) -> FxDatasetVersion:
    """USD TT buying rates for the 2025 calendar year, from the synthetic file."""
    report = synthetic_fx_ingestor.ingest_csv(
        fx_fixture_2025_bytes,
        file_name="synthetic_ttbr_2025.csv",
        version="2025.test",
        rate_types=[FxRateType.TT_BUY],
        currencies=["USD"],
        imported_at=IMPORTED_AT,
    )
    assert report.dataset is not None
    return report.dataset


@pytest.fixture(scope="session")
def fx_dataset_multi_currency_2025(
    synthetic_fx_ingestor: SbiRateIngestor, fx_fixture_2025_bytes: bytes
) -> FxDatasetVersion:
    """USD, EUR and GBP TT buying rates, to exercise non-USD conversion."""
    report = synthetic_fx_ingestor.ingest_csv(
        fx_fixture_2025_bytes,
        file_name="synthetic_ttbr_2025.csv",
        version="2025.multi.test",
        rate_types=[FxRateType.TT_BUY],
        imported_at=IMPORTED_AT,
    )
    assert report.dataset is not None
    return report.dataset
