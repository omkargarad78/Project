"""Builders for synthetic .xlsx fixtures.

These construct the OOXML package by hand rather than through a spreadsheet
library, for two reasons. First, writing the sheet XML directly is the only way
to assert that the reader preserves an exact numeric digit string, since a
library would round-trip the value through a float before writing it. Second,
hostile fixtures (decompression bombs, entity expansion, unsafe entry paths)
cannot be produced by a well-behaved library at all.
"""

from __future__ import annotations

import zipfile
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from io import BytesIO

#: Every ZIP entry is stamped with this instead of the wall clock.
#:
#: ``ZipFile.writestr`` given a plain file name defaults the entry's timestamp
#: to ``time.localtime()``, so two calls a second apart produce different
#: bytes for the same logical workbook. Every identifier downstream is derived
#: from the file's content hash, so that difference propagates all the way to
#: transaction ids and makes the pipeline look non-deterministic when it is
#: the fixture that changed.
_FIXED_TIMESTAMP = (2025, 1, 1, 0, 0, 0)

CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
{sheet_overrides}
</Types>"""

ROOT_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <numFmts count="2">
    <numFmt numFmtId="164" formatCode="yyyy\\-mm\\-dd"/>
    <numFmt numFmtId="165" formatCode="&quot;$&quot;#,##0.0000"/>
  </numFmts>
  <cellXfs count="5">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
    <xf numFmtId="164" fontId="0" fillId="0" borderId="0" applyNumberFormat="1"/>
    <xf numFmtId="14" fontId="0" fillId="0" borderId="0" applyNumberFormat="1"/>
    <xf numFmtId="165" fontId="0" fillId="0" borderId="0" applyNumberFormat="1"/>
    <xf numFmtId="22" fontId="0" fillId="0" borderId="0" applyNumberFormat="1"/>
  </cellXfs>
</styleSheet>"""

#: Style indices matching STYLES above.
STYLE_GENERAL = 0
STYLE_DATE_CUSTOM = 1
STYLE_DATE_BUILTIN = 2
STYLE_CURRENCY = 3
STYLE_DATETIME = 4


@dataclass(frozen=True, slots=True)
class Cell:
    """A cell to write, with full control over the stored representation."""

    #: ``n`` number, ``s`` shared string, ``inline`` inline string,
    #: ``b`` boolean, ``e`` error, ``blank`` an explicitly empty cell.
    kind: str = "n"
    #: The exact text written into ``<v>``. For a number this is the digit
    #: string, preserved byte for byte by the reader.
    value: str | None = None
    style: int = STYLE_GENERAL
    #: Formula text. Written as ``<f>`` with ``value`` as the cached result.
    formula: str | None = None


def number(value: str, *, style: int = STYLE_GENERAL) -> Cell:
    return Cell(kind="n", value=value, style=style)


def text(value: str) -> Cell:
    return Cell(kind="inline", value=value)


def date_serial(serial: str, *, style: int = STYLE_DATE_CUSTOM) -> Cell:
    return Cell(kind="n", value=serial, style=style)


def formula(expression: str, cached: str, *, style: int = STYLE_GENERAL) -> Cell:
    return Cell(kind="n", value=cached, style=style, formula=expression)


def boolean(value: bool) -> Cell:
    return Cell(kind="b", value="1" if value else "0")


def error(code: str = "#N/A") -> Cell:
    return Cell(kind="e", value=code)


BLANK = Cell(kind="blank")


def _escape(value: str) -> str:
    return (
        value.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _column_letter(index: int) -> str:
    letters = ""
    current = index + 1
    while current > 0:
        current, remainder = divmod(current - 1, 26)
        letters = chr(ord("A") + remainder) + letters
    return letters


def _sheet_xml(rows: Sequence[Sequence[Cell]]) -> str:
    parts = [
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
        "<sheetData>",
    ]
    for row_index, row in enumerate(rows, start=1):
        parts.append(f'<row r="{row_index}">')
        for column_index, cell in enumerate(row):
            reference = f"{_column_letter(column_index)}{row_index}"
            if cell.kind == "blank":
                parts.append(f'<c r="{reference}" s="{cell.style}"/>')
                continue
            attributes = f'r="{reference}" s="{cell.style}"'
            if cell.kind == "inline":
                parts.append(
                    f'<c {attributes} t="inlineStr"><is><t>'
                    f"{_escape(cell.value or '')}</t></is></c>"
                )
                continue
            if cell.kind in ("b", "e", "s", "str"):
                attributes += f' t="{cell.kind}"'
            body = ""
            if cell.formula:
                body += f"<f>{_escape(cell.formula)}</f>"
            body += f"<v>{_escape(cell.value or '')}</v>"
            parts.append(f"<c {attributes}>{body}</c>")
        parts.append("</row>")
    parts.extend(["</sheetData>", "</worksheet>"])
    return "".join(parts)


def _add(archive: zipfile.ZipFile, name: str, data: str | bytes) -> None:
    """Add one entry with a frozen timestamp.

    Every fixture writes through here so that building the same workbook
    twice produces the same bytes, and therefore the same file hash and the
    same derived ids.
    """
    info = zipfile.ZipInfo(name, date_time=_FIXED_TIMESTAMP)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o600 << 16
    archive.writestr(info, data)


def build_xlsx(
    sheets: dict[str, Sequence[Sequence[Cell]]],
    *,
    date1904: bool = False,
    include_macros: bool = False,
    include_external_link: bool = False,
    hidden_sheets: Iterable[str] = (),
    shared_strings: Sequence[str] = (),
) -> bytes:
    """Assemble a valid .xlsx package from the supplied sheets."""
    hidden = set(hidden_sheets)
    buffer = BytesIO()

    sheet_overrides = "\n".join(
        f'  <Override PartName="/xl/worksheets/sheet{index}.xml" '
        f'ContentType="application/vnd.openxmlformats-officedocument.'
        f'spreadsheetml.worksheet+xml"/>'
        for index in range(1, len(sheets) + 1)
    )

    workbook_pr = ' <workbookPr date1904="1"/>' if date1904 else ""
    sheet_entries = "".join(
        f'<sheet name="{_escape(name)}" sheetId="{index}" r:id="rId{index}"'
        + (' state="hidden"' if name in hidden else "")
        + "/>"
        for index, name in enumerate(sheets, start=1)
    )
    workbook_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f"{workbook_pr}<sheets>{sheet_entries}</sheets></workbook>"
    )

    relationships = "".join(
        f'<Relationship Id="rId{index}" Type="http://schemas.openxmlformats.org/'
        f'officeDocument/2006/relationships/worksheet" '
        f'Target="worksheets/sheet{index}.xml"/>'
        for index in range(1, len(sheets) + 1)
    )
    next_id = len(sheets) + 1
    relationships += (
        f'<Relationship Id="rId{next_id}" Type="http://schemas.openxmlformats.org/'
        f'officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        f'<Relationship Id="rId{next_id + 1}" Type="http://schemas.openxmlformats.org/'
        f'officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>'
    )
    if include_external_link:
        relationships += (
            f'<Relationship Id="rId{next_id + 2}" Type="http://schemas.openxmlformats.org/'
            f'officeDocument/2006/relationships/externalLink" '
            f'Target="externalLinks/externalLink1.xml"/>'
        )

    workbook_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/'
        f'relationships">{relationships}</Relationships>'
    )

    shared_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        f'count="{len(shared_strings)}" uniqueCount="{len(shared_strings)}">'
        + "".join(f"<si><t>{_escape(s)}</t></si>" for s in shared_strings)
        + "</sst>"
    )

    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        _add(
            archive,
            "[Content_Types].xml",
            CONTENT_TYPES.format(sheet_overrides=sheet_overrides),
        )
        _add(archive, "_rels/.rels", ROOT_RELS)
        _add(archive, "xl/workbook.xml", workbook_xml)
        _add(archive, "xl/_rels/workbook.xml.rels", workbook_rels)
        _add(archive, "xl/styles.xml", STYLES)
        _add(archive, "xl/sharedStrings.xml", shared_xml)
        for index, rows in enumerate(sheets.values(), start=1):
            _add(archive, f"xl/worksheets/sheet{index}.xml", _sheet_xml(rows))
        if include_macros:
            _add(archive, "xl/vbaProject.bin", b"\x00fake macro payload")
        if include_external_link:
            _add(
                archive,
                "xl/externalLinks/externalLink1.xml",
                '<?xml version="1.0"?><externalLink/>',
            )

    return buffer.getvalue()


def build_xxe_xlsx() -> bytes:
    """A package whose sheet XML declares an external entity.

    A reader using the stdlib XML parser without hardening would attempt the
    entity substitution; the platform's reader must refuse the document.
    """
    sheet = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        "<!DOCTYPE foo [<!ENTITY xxe SYSTEM \"file:///etc/passwd\">]>"
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<sheetData><row r="1"><c r="A1" t="inlineStr"><is><t>&xxe;</t></is></c></row>'
        "</sheetData></worksheet>"
    )
    base = build_xlsx({"Sheet1": [[text("placeholder")]]})
    buffer = BytesIO()
    with zipfile.ZipFile(BytesIO(base)) as source, zipfile.ZipFile(
        buffer, "w", zipfile.ZIP_DEFLATED
    ) as target:
        for info in source.infolist():
            data = source.read(info.filename)
            if info.filename == "xl/worksheets/sheet1.xml":
                data = sheet.encode()
            target.writestr(info, data)
    return buffer.getvalue()


def build_billion_laughs_xlsx() -> bytes:
    """A package whose sheet XML is an entity-expansion bomb."""
    entities = "".join(
        f'<!ENTITY e{i} "&e{i - 1};&e{i - 1};&e{i - 1};&e{i - 1};&e{i - 1};">'
        for i in range(1, 12)
    )
    sheet = (
        '<?xml version="1.0"?>'
        f'<!DOCTYPE lolz [<!ENTITY e0 "expand">{entities}]>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<sheetData><row r="1"><c r="A1" t="inlineStr"><is><t>&e11;</t></is></c></row>'
        "</sheetData></worksheet>"
    )
    base = build_xlsx({"Sheet1": [[text("placeholder")]]})
    buffer = BytesIO()
    with zipfile.ZipFile(BytesIO(base)) as source, zipfile.ZipFile(
        buffer, "w", zipfile.ZIP_DEFLATED
    ) as target:
        for info in source.infolist():
            data = source.read(info.filename)
            if info.filename == "xl/worksheets/sheet1.xml":
                data = sheet.encode()
            target.writestr(info, data)
    return buffer.getvalue()


def build_zip_bomb_xlsx(*, uncompressed_mb: int = 400) -> bytes:
    """A package containing one highly compressible oversized entry."""
    base = build_xlsx({"Sheet1": [[text("placeholder")]]})
    buffer = BytesIO()
    with zipfile.ZipFile(BytesIO(base)) as source, zipfile.ZipFile(
        buffer, "w", zipfile.ZIP_DEFLATED
    ) as target:
        for info in source.infolist():
            target.writestr(info, source.read(info.filename))
        _add(target, "xl/padding.bin", b"\x00" * (uncompressed_mb * 1024 * 1024))
    return buffer.getvalue()


def build_unsafe_path_xlsx() -> bytes:
    """A package containing an entry that escapes the extraction root."""
    base = build_xlsx({"Sheet1": [[text("placeholder")]]})
    buffer = BytesIO()
    with zipfile.ZipFile(BytesIO(base)) as source, zipfile.ZipFile(
        buffer, "w", zipfile.ZIP_DEFLATED
    ) as target:
        for info in source.infolist():
            target.writestr(info, source.read(info.filename))
        _add(target, "../../escaped.txt", b"should never be written")
    return buffer.getvalue()
