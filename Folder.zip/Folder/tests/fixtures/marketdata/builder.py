"""Synthetic price series and corporate actions for testing.

SYNTHETIC TEST DATA. These are not real market prices and must never be used
to value a real holding.

The series are shaped to exercise the cases that matter:

* ``NVDA`` has a 4-for-1 split on 2025-06-10, and is generated on both an
  unadjusted and a split-adjusted basis from the same underlying path. Valuing
  a pre-split holding with the adjusted series understates it fourfold, which
  is exactly the mistake the engine has to refuse.
* ``AAPL`` and ``VOO`` trade normally throughout.
* Weekends are absent from every series, because no trading happens then.
* ``AAPL`` is additionally missing a run of weekdays in August, standing in for
  an incomplete dataset rather than a closed market.
"""

from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

from backend.app.marketdata.models import (
    AdjustmentBasis,
    CorporateAction,
    CorporateActionType,
    PriceProvenance,
    PriceRecord,
    PriceType,
)

SYNTHETIC_PROVENANCE = PriceProvenance(
    reference="SYNTHETIC TEST DATA - generated, not a real quotation",
)

#: NVDA's split.
SPLIT_EX_DATE = date(2025, 6, 10)
SPLIT_RATIO = Decimal(4)

#: A weekday run deliberately absent from the AAPL series.
AAPL_GAP_START = date(2025, 8, 11)
AAPL_GAP_END = date(2025, 8, 15)

START = date(2025, 1, 1)
END = date(2025, 12, 31)


def trading_days(start: date = START, end: date = END) -> list[date]:
    """Weekdays in the window. Weekends have no price because nothing trades."""
    days: list[date] = []
    current = start
    while current <= end:
        if current.weekday() < 5:
            days.append(current)
        current += timedelta(days=1)
    return days


def _path(base: Decimal, step: Decimal, day_index: int) -> Decimal:
    """A deterministic, gently rising price path.

    Deterministic rather than random so that a golden test can assert an exact
    figure, and monotonic enough that the peak is predictable.
    """
    return (base + step * Decimal(day_index)).quantize(Decimal("0.0001"))


def nvda_unadjusted_prices() -> list[PriceRecord]:
    """NVDA as it actually traded, including the fourfold drop at the split."""
    records: list[PriceRecord] = []
    for index, day in enumerate(trading_days()):
        raw = _path(Decimal("118.00"), Decimal("0.40"), index)
        price = (raw / SPLIT_RATIO).quantize(Decimal("0.0001")) if day >= SPLIT_EX_DATE else raw
        records.append(
            PriceRecord(
                symbol="NVDA",
                price_date=day,
                price_type=PriceType.CLOSE,
                price=price,
                currency="USD",
                adjustment_basis=AdjustmentBasis.UNADJUSTED,
                provenance=SYNTHETIC_PROVENANCE,
                synthetic=True,
            )
        )
    return records


def nvda_split_adjusted_prices() -> list[PriceRecord]:
    """The same path restated, so the split leaves no visible jump."""
    records: list[PriceRecord] = []
    for index, day in enumerate(trading_days()):
        raw = _path(Decimal("118.00"), Decimal("0.40"), index)
        records.append(
            PriceRecord(
                symbol="NVDA",
                price_date=day,
                price_type=PriceType.CLOSE,
                price=(raw / SPLIT_RATIO).quantize(Decimal("0.0001")),
                currency="USD",
                adjustment_basis=AdjustmentBasis.SPLIT_ADJUSTED,
                provenance=SYNTHETIC_PROVENANCE,
                synthetic=True,
            )
        )
    return records


def aapl_prices(
    *,
    with_gap: bool = True,
    basis: AdjustmentBasis = AdjustmentBasis.UNADJUSTED,
) -> list[PriceRecord]:
    records: list[PriceRecord] = []
    for index, day in enumerate(trading_days()):
        if with_gap and AAPL_GAP_START <= day <= AAPL_GAP_END:
            continue
        records.append(
            PriceRecord(
                symbol="AAPL",
                price_date=day,
                price_type=PriceType.CLOSE,
                price=_path(Decimal("182.00"), Decimal("0.06"), index),
                currency="USD",
                adjustment_basis=basis,
                provenance=SYNTHETIC_PROVENANCE,
                synthetic=True,
            )
        )
    return records


def voo_prices(
    *, basis: AdjustmentBasis = AdjustmentBasis.UNADJUSTED
) -> list[PriceRecord]:
    return [
        PriceRecord(
            symbol="VOO",
            price_date=day,
            price_type=PriceType.CLOSE,
            price=_path(Decimal("470.00"), Decimal("0.20"), index),
            currency="USD",
            adjustment_basis=basis,
            provenance=SYNTHETIC_PROVENANCE,
            synthetic=True,
        )
        for index, day in enumerate(trading_days())
    ]


def msft_prices(
    *, basis: AdjustmentBasis = AdjustmentBasis.UNADJUSTED
) -> list[PriceRecord]:
    return [
        PriceRecord(
            symbol="MSFT",
            price_date=day,
            price_type=PriceType.CLOSE,
            price=_path(Decimal("410.00"), Decimal("0.15"), index),
            currency="USD",
            adjustment_basis=basis,
            provenance=SYNTHETIC_PROVENANCE,
            synthetic=True,
        )
        for index, day in enumerate(trading_days())
    ]


def nvda_split_action(*, verified: bool = True) -> CorporateAction:
    return CorporateAction(
        action_id="CA-NVDA-SPLIT-2025",
        action_type=CorporateActionType.SPLIT,
        symbol="NVDA",
        ex_date=SPLIT_EX_DATE,
        ratio_to=SPLIT_RATIO,
        ratio_from=Decimal(1),
        reference="SYNTHETIC TEST DATA - not a real corporate action",
        verification_status="VERIFIED" if verified else "REQUIRES_CONFIRMATION",
        synthetic=True,
    )


def unadjusted_records() -> list[PriceRecord]:
    return [
        *nvda_unadjusted_prices(),
        *aapl_prices(),
        *voo_prices(),
        *msft_prices(),
    ]


def adjusted_records() -> list[PriceRecord]:
    """A whole snapshot on a split-adjusted basis.

    Every symbol carries the adjusted label, including those that never split.
    A provider's adjusted series is adjusted throughout; a stock with no
    splits simply has the same numbers either way, and mislabelling those as
    unadjusted would make the snapshot look internally inconsistent.
    """
    adjusted = AdjustmentBasis.SPLIT_ADJUSTED
    return [
        *nvda_split_adjusted_prices(),
        *aapl_prices(basis=adjusted),
        *voo_prices(basis=adjusted),
        *msft_prices(basis=adjusted),
    ]


def price_csv(records: list[PriceRecord]) -> bytes:
    """Render records as a provider-style CSV."""
    lines = ["Date,Symbol,Close,Currency"]
    lines.extend(
        f"{r.price_date.isoformat()},{r.symbol},{r.price},{r.currency}"
        for r in records
    )
    return ("\n".join(lines) + "\n").encode("utf-8")
