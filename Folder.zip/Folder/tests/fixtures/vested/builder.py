"""A synthetic Vested-shaped workbook for testing.

This is SYNTHETIC test data, not a real broker statement. It models the
investor scenario the specification asks for end to end:

* NVDA bought three times, then partially sold, with fractional shares
* NVDA paying dividends with US tax withheld at source
* AAPL bought once and then sold in full during the reporting year, so an
  interest that was held during the period but closed before it ended
* VOO held throughout, never sold, with no income
* MSFT held from before the reporting period with NO acquisition in the file,
  to exercise the missing-historical-data path
* cash deposits, a withdrawal, and a standalone account fee
* a deliberately unmapped activity label
* a deliberate duplicate row

Dates fall in calendar 2025, which is the Schedule FA reporting period for
assessment year 2026-27 under the registered rule version.
"""

from __future__ import annotations

from datetime import date

from tests.fixtures.builders import (
    STYLE_DATE_CUSTOM,
    Cell,
    build_xlsx,
    date_serial,
    number,
    text,
)

#: Serial for 1899-12-30 based 1900 date system.
_EPOCH_ORDINAL = date(1899, 12, 30).toordinal()


def serial(day: date) -> str:
    """Spreadsheet date serial for ``day`` in the 1900 date system."""
    return str(day.toordinal() - _EPOCH_ORDINAL)


def d(day: date) -> Cell:
    return date_serial(serial(day), style=STYLE_DATE_CUSTOM)


TRADE_HEADERS = [
    text("Transaction Date"),
    text("Settlement Date"),
    text("Activity"),
    text("Ticker"),
    text("Company Name"),
    text("Quantity"),
    text("Price Per Share"),
    text("Cash Amount"),
    text("Commission"),
    text("Currency"),
    text("Account"),
    text("Transaction ID"),
]

INCOME_HEADERS = [
    text("Transaction Date"),
    text("Activity"),
    text("Ticker"),
    text("Company Name"),
    text("Gross Amount"),
    text("Tax Withheld"),
    text("Net Amount"),
    text("Currency"),
    text("Account"),
    text("Transaction ID"),
]

TRANSFER_HEADERS = [
    text("Transaction Date"),
    text("Activity"),
    text("Cash Amount"),
    text("Currency"),
    text("Account"),
    text("Transaction ID"),
    text("Description"),
]

ACCOUNT_HEADERS = [
    text("Account"),
    text("As Of"),
    text("Cash Balance"),
    text("Ticker"),
    text("Company Name"),
    text("Quantity"),
    text("Currency"),
]

ACCOUNT_ID = "VST-0001"


def _trade(
    day: date,
    settle: date,
    activity: str,
    ticker: str,
    company: str,
    quantity: str,
    price: str,
    amount: str,
    commission: str,
    txn_id: str,
) -> list[Cell]:
    return [
        d(day),
        d(settle),
        text(activity),
        text(ticker),
        text(company),
        number(quantity),
        number(price),
        number(amount),
        number(commission),
        text("USD"),
        text(ACCOUNT_ID),
        text(txn_id),
    ]


def _income(
    day: date,
    activity: str,
    ticker: str,
    company: str,
    gross: str,
    tax: str,
    net: str,
    txn_id: str,
) -> list[Cell]:
    return [
        d(day),
        text(activity),
        text(ticker),
        text(company),
        number(gross),
        number(tax),
        number(net),
        text("USD"),
        text(ACCOUNT_ID),
        text(txn_id),
    ]


def _transfer(
    day: date, activity: str, amount: str, txn_id: str, description: str
) -> list[Cell]:
    return [
        d(day),
        text(activity),
        number(amount),
        text("USD"),
        text(ACCOUNT_ID),
        text(txn_id),
        text(description),
    ]


TRADE_ROWS: list[list[Cell]] = [
    # NVDA: three acquisitions including a fractional lot.
    _trade(
        date(2025, 2, 10), date(2025, 2, 12), "Buy", "NVDA", "NVIDIA Corporation",
        "10", "118.4000", "1184.00", "0.50", "T-1001",
    ),
    _trade(
        date(2025, 4, 15), date(2025, 4, 17), "Buy", "NVDA", "NVIDIA Corporation",
        "5.25", "132.7500", "696.94", "0.35", "T-1002",
    ),
    _trade(
        date(2025, 7, 8), date(2025, 7, 10), "Buy", "NVDA", "NVIDIA Corporation",
        "4", "141.2000", "564.80", "0.30", "T-1003",
    ),
    # NVDA: partial disposal.
    _trade(
        date(2025, 9, 22), date(2025, 9, 24), "Sell", "NVDA", "NVIDIA Corporation",
        "8", "155.6000", "1244.80", "0.80", "T-1004",
    ),
    # AAPL: acquired and fully disposed inside the reporting period.
    _trade(
        date(2025, 3, 5), date(2025, 3, 7), "Buy", "AAPL", "Apple Inc.",
        "12", "182.5000", "2190.00", "0.60", "T-1005",
    ),
    _trade(
        date(2025, 11, 14), date(2025, 11, 18), "Sell", "AAPL", "Apple Inc.",
        "12", "197.3000", "2367.60", "0.75", "T-1006",
    ),
    # VOO: held throughout, no income, never sold.
    _trade(
        date(2025, 1, 20), date(2025, 1, 22), "Buy", "VOO",
        "Vanguard S&P 500 ETF", "2.5", "472.1000", "1180.25", "0.40", "T-1007",
    ),
    # MSFT: a disposal with NO acquisition anywhere in the file, which means an
    # earlier statement is missing.
    _trade(
        date(2025, 6, 12), date(2025, 6, 16), "Sell", "MSFT", "Microsoft Corporation",
        "3", "412.8000", "1238.40", "0.65", "T-1008",
    ),
    # An activity label the mapping does not describe.
    _trade(
        date(2025, 8, 4), date(2025, 8, 6), "Fractional Share Liquidation", "NVDA",
        "NVIDIA Corporation", "0.1", "148.0000", "14.80", "0.00", "T-1009",
    ),
]

#: The same trade repeated verbatim, to exercise duplicate detection.
DUPLICATE_TRADE_ROW = _trade(
    date(2025, 7, 8), date(2025, 7, 10), "Buy", "NVDA", "NVIDIA Corporation",
    "4", "141.2000", "564.80", "0.30", "T-1003",
)

INCOME_ROWS: list[list[Cell]] = [
    # A $10 gross dividend with $1 withheld must never be recorded as $9 gross.
    _income(
        date(2025, 3, 20), "Dividend", "NVDA", "NVIDIA Corporation",
        "10.00", "1.00", "9.00", "I-2001",
    ),
    _income(
        date(2025, 6, 20), "Dividend", "NVDA", "NVIDIA Corporation",
        "12.50", "1.25", "11.25", "I-2002",
    ),
    _income(
        date(2025, 9, 19), "Dividend", "NVDA", "NVIDIA Corporation",
        "14.40", "1.44", "12.96", "I-2003",
    ),
    _income(
        date(2025, 5, 15), "Dividend", "AAPL", "Apple Inc.",
        "3.00", "0.30", "2.70", "I-2004",
    ),
    _income(
        date(2025, 12, 5), "Interest", "", "",
        "2.15", "0.00", "2.15", "I-2005",
    ),
]

TRANSFER_ROWS: list[list[Cell]] = [
    _transfer(date(2025, 1, 15), "Deposit", "5000.00", "X-3001", "Initial funding"),
    _transfer(date(2025, 4, 10), "Deposit", "1500.00", "X-3002", "Additional funding"),
    _transfer(date(2025, 10, 5), "Withdrawal", "800.00", "X-3003", "Withdrawal to bank"),
    _transfer(date(2025, 12, 1), "Fee", "5.00", "X-3004", "Annual account fee"),
]


def build_vested_workbook(
    *,
    include_duplicate: bool = True,
    include_unknown_activity: bool = True,
    include_account_sheet: bool = True,
    title_rows: bool = True,
) -> bytes:
    """Assemble the synthetic Vested workbook."""
    trade_rows = list(TRADE_ROWS)
    if not include_unknown_activity:
        trade_rows = [r for r in trade_rows if r[2].value != "Fractional Share Liquidation"]
    if include_duplicate:
        trade_rows.append(DUPLICATE_TRADE_ROW)

    preamble: list[list[Cell]] = []
    if title_rows:
        # Broker exports commonly put a title block above the real header.
        preamble = [
            [text("Vested Finance - Transaction Statement")],
            [text("SYNTHETIC TEST DATA - NOT A REAL STATEMENT")],
            [],
        ]

    sheets: dict[str, list[list[Cell]]] = {
        "Trades": [*preamble, TRADE_HEADERS, *trade_rows],
        "Income": [INCOME_HEADERS, *INCOME_ROWS],
        "Transfers": [TRANSFER_HEADERS, *TRANSFER_ROWS],
    }
    if include_account_sheet:
        sheets["My Account"] = [
            ACCOUNT_HEADERS,
            [
                text(ACCOUNT_ID),
                d(date(2025, 12, 31)),
                number("4699.47"),
                text("NVDA"),
                text("NVIDIA Corporation"),
                number("11.15"),
                text("USD"),
            ],
            [
                text(ACCOUNT_ID),
                d(date(2025, 12, 31)),
                number("4699.47"),
                text("VOO"),
                text("Vanguard S&P 500 ETF"),
                number("2.5"),
                text("USD"),
            ],
        ]

    return build_xlsx(sheets)


def build_renamed_column_workbook() -> bytes:
    """A workbook whose Trades sheet lost a required column.

    Models the broker changing its export format, which must raise
    BROKER_FORMAT_CHANGED rather than produce a partial parse.
    """
    headers = [c for c in TRADE_HEADERS if c.value != "Ticker"]
    rows = [[c for index, c in enumerate(row) if index != 3] for row in TRADE_ROWS]
    return build_xlsx({"Trades": [headers, *rows]})


def build_unrecognised_workbook() -> bytes:
    """A workbook no registered parser should claim."""
    return build_xlsx(
        {
            "Readme": [
                [text("Some Other Product")],
                [text("Column A"), text("Column B")],
                [text("x"), number("1")],
            ]
        }
    )
