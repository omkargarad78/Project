"""The formula-injection defence, checked against arbitrary text.

The unit tests use the published payload list. That list is a snapshot of
what attackers were doing when it was written, so on its own it tests memory
rather than the defence. These assert the invariant instead: whatever text a
broker file contains, the output is not something a spreadsheet will run.
"""

from __future__ import annotations

from hypothesis import given, settings
from hypothesis import strategies as st

from backend.app.reports.safety import (
    MAX_CELL_LENGTH,
    _is_plain_number,
    is_formula_like,
    neutralise_for_csv,
    safe_sheet_name,
    strip_control_characters,
    truncate_cell,
)

#: Biased towards the characters that matter, since uniform text almost never
#: produces a leading "=" and would test nothing.
hostile_text = st.text(
    alphabet=st.sampled_from(list("=+-@\t\r\n |'\"()0123456789ABcd,.$&!"),),
    max_size=40,
)


def is_safe_in_a_spreadsheet(value: str) -> bool:
    """Whether a spreadsheet opening this field would evaluate it.

    A leading ``-`` or ``+`` on something like ``-0`` or ``+1.5e3`` is a
    trigger character and also just a number, and every spreadsheet parses it
    as one. That is why the number exemption exists, and why the safety
    invariant has to be stated in terms of what gets evaluated rather than
    what starts with a trigger character.
    """
    return not is_formula_like(value) or _is_plain_number(value)


@settings(max_examples=400)
@given(st.one_of(hostile_text, st.text(max_size=60)))
def test_no_text_survives_csv_neutralisation_as_a_formula(value: str) -> None:
    """The invariant the whole module exists for."""
    safe, _changed = neutralise_for_csv(value)

    assert is_safe_in_a_spreadsheet(safe)


@settings(max_examples=400)
@given(st.one_of(hostile_text, st.text(max_size=60)))
def test_neutralisation_reports_whether_it_changed_anything(value: str) -> None:
    """Silently altering an uploaded value is worse than the injection."""
    safe, changed = neutralise_for_csv(value)

    assert changed == (safe != value)


@settings(max_examples=400)
@given(st.one_of(hostile_text, st.text(max_size=60)))
def test_neutralisation_is_idempotent(value: str) -> None:
    """Otherwise a re-exported file grows an apostrophe on every pass."""
    once, _ = neutralise_for_csv(value)
    twice, changed = neutralise_for_csv(once)

    assert twice == once
    assert not changed


@given(st.text(max_size=60))
def test_neutralisation_only_strips_and_prefixes(value: str) -> None:
    """The reader has to be able to recover the original.

    Two changes are permitted and no others: control characters are removed,
    because no format can carry them, and one apostrophe may be prefixed.
    Anything else would mean the workpaper reports a value the broker never
    wrote.
    """
    safe, _changed = neutralise_for_csv(value)
    body = strip_control_characters(value)

    assert safe in (body, "'" + body)


@given(st.text(max_size=200))
def test_stripping_control_characters_leaves_valid_xml_text(value: str) -> None:
    """XLSX cannot carry these at all; the file simply fails to open."""
    cleaned = strip_control_characters(value)

    forbidden = {c for c in cleaned if ord(c) < 0x20 and c not in "\t\n\r"}
    assert not forbidden
    assert len(cleaned) <= len(value)


@given(st.text(max_size=200))
def test_stripping_is_idempotent(value: str) -> None:
    once = strip_control_characters(value)

    assert strip_control_characters(once) == once


@given(st.integers(min_value=0, max_value=MAX_CELL_LENGTH + 500))
def test_a_cell_is_never_longer_than_excel_allows(length: int) -> None:
    clipped, was_clipped = truncate_cell("x" * length)

    assert len(clipped) <= MAX_CELL_LENGTH
    assert was_clipped == (length > MAX_CELL_LENGTH)


@given(st.lists(st.text(max_size=50), min_size=1, max_size=15))
def test_sheet_names_are_always_legal_and_never_collide(names: list[str]) -> None:
    """Excel rejects the whole workbook over one bad or repeated name."""
    taken: set[str] = set()
    produced = [safe_sheet_name(name, taken=taken) for name in names]

    assert len(set(produced)) == len(produced)
    for name in produced:
        assert 1 <= len(name) <= 31
        assert not set(name) & set(r"/\:*?[]")
