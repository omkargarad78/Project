"""Invariants of the money layer, checked against generated inputs.

The example-based tests assert what specific values do. These assert what
*every* value does, which is the useful question for arithmetic: a rounding
rule that is correct for 1.005 and wrong for 2.675 is not a rounding rule.

Hypothesis generates the awkward cases on its own -- values that are exactly
half, values whose decimal representation has no exact binary equivalent,
quantities below the canonical scale -- and reports the smallest input that
breaks an invariant rather than the first.
"""

from __future__ import annotations

from decimal import Decimal

from hypothesis import assume, given, settings
from hypothesis import strategies as st

from backend.app.core.money import (
    AMOUNT_SCALE,
    QUANTITY_SCALE,
    MoneyError,
    Rounding,
    add,
    as_amount,
    convert,
    decimal_to_str,
    divide,
    is_effectively_zero,
    multiply,
    normalize_numeric_text,
    round_for_output,
    to_decimal,
)

#: Amounts in the range a broker statement actually contains, at a precision
#: no broker exceeds. Unbounded generation would test Decimal, not this code.
amounts = st.decimals(
    min_value=Decimal("-1e9"),
    max_value=Decimal("1e9"),
    allow_nan=False,
    allow_infinity=False,
    places=8,
)
positive_amounts = st.decimals(
    min_value=Decimal("0.00000001"),
    max_value=Decimal("1e9"),
    allow_nan=False,
    allow_infinity=False,
    places=8,
)
rates = st.decimals(
    min_value=Decimal("0.000001"),
    max_value=Decimal("1000"),
    allow_nan=False,
    allow_infinity=False,
    places=6,
)


# --- floats never get in --------------------------------------------------


@given(st.floats(allow_nan=False, allow_infinity=False))
def test_no_float_is_ever_accepted(value: float) -> None:
    """The boundary the whole precision guarantee rests on.

    A float has already lost the source's decimal representation by the time
    it arrives, so accepting one would admit binary rounding error into the
    ledger with nothing to show for it afterwards.
    """
    try:
        to_decimal(value)
    except MoneyError as exc:
        assert "float is not accepted" in str(exc)
    else:
        raise AssertionError(f"{value!r} was accepted")


@given(st.booleans())
def test_a_boolean_is_not_a_number(value: bool) -> None:
    """``isinstance(True, int)`` is true, which is how this gets in."""
    try:
        to_decimal(value)
    except MoneyError:
        return
    raise AssertionError(f"{value!r} was accepted as a number")


# --- parsing round-trips --------------------------------------------------


@given(amounts)
def test_a_decimal_survives_the_string_round_trip(value: Decimal) -> None:
    """Storage and JSON go through this, so it must not lose a digit."""
    assert to_decimal(decimal_to_str(value)) == value


@given(amounts)
def test_thousands_separators_do_not_change_the_value(value: Decimal) -> None:
    """Brokers export ``1,234.56``; the commas are presentation, not data."""
    assert to_decimal(f"{value:,f}") == value


@given(amounts)
def test_currency_symbols_do_not_change_the_value(value: Decimal) -> None:
    """The same amount arrives decorated differently from different brokers."""
    plain = decimal_to_str(value)
    for symbol in ("$", "\u20b9", "USD", "Rs."):
        assert to_decimal(f"{symbol}{plain}") == value
        assert to_decimal(f"{symbol} {plain}") == value


@given(positive_amounts)
def test_accounting_parentheses_mean_negative(value: Decimal) -> None:
    """Both nestings occur: Excel writes one, a person types the other.

    Handling only ``($1,234.56)`` and not ``$(1,234.56)`` rejects every
    negative amount in a statement exported with Excel's accounting format,
    which is how this gap was found.
    """
    plain = decimal_to_str(value)

    assert to_decimal(f"({plain})") == -value
    assert to_decimal(f"$({plain})") == -value
    assert to_decimal(f"(${plain})") == -value
    assert to_decimal(f"(\u20b9 {plain})") == -value


@given(amounts)
def test_normalising_is_idempotent(value: Decimal) -> None:
    """Applied more than once in the reader path, so it has to settle."""
    once = normalize_numeric_text(decimal_to_str(value))
    assert normalize_numeric_text(once) == once


# --- arithmetic -----------------------------------------------------------


@given(st.lists(amounts, min_size=0, max_size=12))
def test_addition_does_not_depend_on_order(values: list[Decimal]) -> None:
    """Sums are accumulated in whatever order a ledger iterates in."""
    assert add(*values) == add(*reversed(values))


@given(st.lists(amounts, min_size=1, max_size=8))
def test_a_sum_splits_anywhere(values: list[Decimal]) -> None:
    """Subtotalling must not change a total; the workpaper shows both."""
    for cut in range(len(values) + 1):
        assert add(add(*values[:cut]), add(*values[cut:])) == add(*values)


@given(amounts, amounts)
def test_multiplication_does_not_depend_on_order(a: Decimal, b: Decimal) -> None:
    assert multiply(a, b) == multiply(b, a)


@given(positive_amounts, positive_amounts)
def test_dividing_then_multiplying_returns_the_value(
    a: Decimal, b: Decimal
) -> None:
    """Round-tripping through a division loses nothing that matters.

    Stated as relative error because that is what carrying 34 significant
    digits buys: the absolute error on a crore is larger than on a rupee, and
    a test written in absolute terms would either pass trivially or fail on
    the largest values for no real reason.
    """
    relative_error = abs(multiply(divide(a, b), b) - a) / a

    assert relative_error < Decimal("1e-30")


@given(amounts)
def test_dividing_by_zero_is_refused_not_infinite(value: Decimal) -> None:
    """Decimal would return Infinity, which would reach a tax figure."""
    try:
        divide(value, Decimal(0))
    except MoneyError:
        return
    raise AssertionError("division by zero produced a value")


# --- conversion -----------------------------------------------------------


@given(amounts, rates)
def test_conversion_is_the_documented_formula(
    native: Decimal, rate: Decimal
) -> None:
    assert convert(native, rate) == multiply(native, rate)


@given(amounts, rates)
def test_conversion_preserves_sign(native: Decimal, rate: Decimal) -> None:
    """A negative amount converts to a negative rupee amount, never zero."""
    result = convert(native, rate)
    if native > 0:
        assert result > 0
    elif native < 0:
        assert result < 0
    else:
        assert result == 0


@given(rates)
def test_converting_nothing_gives_nothing(rate: Decimal) -> None:
    assert convert(Decimal(0), rate) == 0


@given(amounts, rates, st.sampled_from([1, 100]))
def test_a_rate_quoted_per_hundred_divides_by_a_hundred(
    native: Decimal, rate: Decimal, unit: int
) -> None:
    """JPY is published per 100 units; assuming 1 would be off by 100x."""
    assert convert(native, rate, rate_unit=unit) == divide(
        multiply(native, rate), Decimal(unit)
    )


@given(amounts, rates, rates)
def test_a_higher_rate_never_gives_fewer_rupees(
    native: Decimal, low: Decimal, high: Decimal
) -> None:
    """Monotonicity. A violation here would be invisible in any one figure."""
    assume(native > 0)
    low, high = min(low, high), max(low, high)

    assert convert(native, low) <= convert(native, high)


# --- rounding -------------------------------------------------------------


@given(amounts)
def test_rounding_to_whole_rupees_moves_by_less_than_one(
    value: Decimal,
) -> None:
    """Schedule FA money columns are whole rupees."""
    assert abs(round_for_output(value) - value) < 1


@given(amounts)
def test_rounding_is_idempotent(value: Decimal) -> None:
    once = round_for_output(value)
    assert round_for_output(once) == once


@given(amounts)
def test_half_up_rounds_a_half_away_from_zero(value: Decimal) -> None:
    """The rule the platform records against every reported figure.

    Asserted on a constructed exact half rather than on arbitrary values,
    because a half is the only case where the rules disagree.
    """
    half = value.to_integral_value() + (Decimal("0.5") if value >= 0 else Decimal("-0.5"))
    rounded = round_for_output(half, rounding=Rounding.HALF_UP)

    assert abs(rounded) == abs(half) + Decimal("0.5")


@given(amounts)
def test_rounding_down_never_increases_the_magnitude(value: Decimal) -> None:
    assert abs(round_for_output(value, rounding=Rounding.DOWN)) <= abs(value)


@given(amounts)
def test_the_output_scale_is_exactly_what_was_asked_for(value: Decimal) -> None:
    for scale in (0, 2, 4):
        assert -round_for_output(value, scale=scale).as_tuple().exponent == scale


# --- scales and residuals -------------------------------------------------


@given(amounts)
def test_normalising_an_amount_is_stable(value: Decimal) -> None:
    """Equality and hashing across a save/load depend on this."""
    once = as_amount(value)
    assert as_amount(once) == once
    assert -once.as_tuple().exponent == AMOUNT_SCALE


@given(
    st.decimals(
        min_value=Decimal("-0.000000004"),
        max_value=Decimal("0.000000004"),
        allow_nan=False,
        allow_infinity=False,
        places=12,
    )
)
def test_a_sub_scale_residual_is_not_an_open_position(value: Decimal) -> None:
    """Fractional-share allocation leaves dust; dust is not a holding."""
    assert is_effectively_zero(value)


@given(positive_amounts)
def test_anything_at_or_above_the_scale_is_a_real_position(
    value: Decimal,
) -> None:
    assume(value >= Decimal(1).scaleb(-QUANTITY_SCALE))

    assert not is_effectively_zero(value)


@settings(max_examples=200)
@given(st.text(max_size=20))
def test_text_either_parses_to_its_own_value_or_is_refused(text: str) -> None:
    """Silently reading a garbled cell as zero is the failure to avoid.

    A parser that returns zero on confusion turns an unreadable fee column
    into a reported nil, and nothing downstream can tell the difference.
    """
    try:
        result = to_decimal(text)
    except MoneyError:
        return

    assert isinstance(result, Decimal)
    assert result.is_finite()
    # Whatever it parsed to must survive its own round trip, which rules out
    # a value invented from text that merely looked numeric.
    assert to_decimal(decimal_to_str(result)) == result
