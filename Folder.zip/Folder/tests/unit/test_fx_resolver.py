"""Rate selection, weekend/holiday handling and conversion arithmetic."""

from __future__ import annotations

from datetime import UTC, date, datetime
from decimal import Decimal

import pytest

from backend.app.core.errors import ErrorCode
from backend.app.fx.models import FxDatasetVersion, FxRateRecord, RateStatus
from backend.app.fx.resolver import FxResolver, relevant_date_for
from backend.app.fx.store import create_override_record
from backend.app.tax.rules.models import (
    FieldValuationRule,
    FxRateType,
    MissingRatePolicy,
    MultipleRatePolicy,
    RelevantDateRule,
    SourceTier,
)
from backend.app.validation.issues import IssueCollector

TXN_DATE = FieldValuationRule(relevant_date=RelevantDateRule.TRANSACTION_DATE)
TXN_DATE_CARRY_BACK = FieldValuationRule(
    relevant_date=RelevantDateRule.TRANSACTION_DATE,
    missing_rate_policy=MissingRatePolicy.LAST_PUBLISHED_ON_OR_BEFORE,
    max_rate_gap_days=7,
)
AT = datetime(2026, 1, 15, tzinfo=UTC)


def _record(
    day: date,
    value: str,
    *,
    currency: str = "USD",
    rate_type: FxRateType = FxRateType.TT_BUY,
    unit: int = 1,
    tier: SourceTier = SourceTier.STATUTORY,
    published_at: datetime | None = None,
) -> FxRateRecord:
    return FxRateRecord(
        currency=currency,
        rate_date=day,
        rate_type=rate_type,
        value=Decimal(value),
        unit=unit,
        source_id="TEST",
        source_name="test source",
        source_tier=tier,
        published_at=published_at,
        status=RateStatus.VERIFIED if tier.is_statutory else RateStatus.UNVERIFIED,
    )


def _dataset(*records: FxRateRecord, version: str = "t1") -> FxDatasetVersion:
    return FxDatasetVersion.build(
        dataset_name="test",
        version=version,
        source_id="TEST",
        source_tier=SourceTier.STATUTORY,
        imported_at=AT,
        records=records,
    )


# --- exact-date resolution -------------------------------------------------


def test_exact_date_rate_is_used_with_no_gap() -> None:
    resolver = FxResolver(_dataset(_record(date(2025, 6, 10), "83.5000")))

    resolution = resolver.resolve("USD", date(2025, 6, 10), TXN_DATE)

    assert resolution.found
    assert resolution.rate_date == date(2025, 6, 10)
    assert resolution.gap_days == 0
    assert resolution.selection_rule == "SAME_DATE"


def test_usd_conversion_multiplies_amount_by_ttbr() -> None:
    resolver = FxResolver(_dataset(_record(date(2025, 6, 10), "83.5000")))

    result = resolver.convert(Decimal("1000.00"), "USD", date(2025, 6, 10), TXN_DATE)

    assert result.succeeded
    assert result.inr_amount == Decimal("83500.000000000000")
    assert result.inr_rounded == Decimal("83500")
    assert "83.5" in result.formula


def test_non_usd_conversion_uses_that_currency_rate() -> None:
    resolver = FxResolver(
        _dataset(
            _record(date(2025, 6, 10), "83.5000", currency="USD"),
            _record(date(2025, 6, 10), "91.2500", currency="EUR"),
        )
    )

    result = resolver.convert(Decimal("100"), "EUR", date(2025, 6, 10), TXN_DATE)

    assert result.inr_rounded == Decimal("9125")
    assert result.resolution.currency == "EUR"


def test_rate_quoted_per_hundred_units_is_divided_by_its_unit() -> None:
    resolver = FxResolver(
        _dataset(_record(date(2025, 6, 10), "55.4000", currency="JPY", unit=100))
    )

    result = resolver.convert(Decimal("10000"), "JPY", date(2025, 6, 10), TXN_DATE)

    # 10000 JPY x 55.40 per 100 JPY = INR 5,540
    assert result.inr_rounded == Decimal("5540")


def test_inr_amounts_need_no_rate() -> None:
    resolver = FxResolver(None)

    result = resolver.convert(Decimal("1234.56"), "INR", date(2025, 6, 10), TXN_DATE)

    assert result.succeeded
    assert result.inr_rounded == Decimal("1235")


def test_native_amount_is_never_overwritten_by_conversion() -> None:
    resolver = FxResolver(_dataset(_record(date(2025, 6, 10), "83.5000")))

    result = resolver.convert(Decimal("1000.1234"), "USD", date(2025, 6, 10), TXN_DATE)

    assert result.native_amount == Decimal("1000.12340000")
    assert result.currency == "USD"


# --- missing rates --------------------------------------------------------


def test_missing_rate_fails_by_default_rather_than_substituting() -> None:
    resolver = FxResolver(_dataset(_record(date(2025, 6, 9), "83.4000")))

    resolution = resolver.resolve("USD", date(2025, 6, 10), TXN_DATE)

    assert not resolution.found
    assert resolution.selection_rule == "FAIL"
    assert "does not permit using another date's rate" in (resolution.failure_reason or "")


def test_weekend_date_carries_back_only_when_the_rule_permits(
    fx_dataset_usd_2025,
) -> None:
    saturday = date(2025, 6, 14)
    assert saturday.weekday() == 5

    strict = FxResolver(fx_dataset_usd_2025).resolve("USD", saturday, TXN_DATE)
    permissive = FxResolver(fx_dataset_usd_2025).resolve("USD", saturday, TXN_DATE_CARRY_BACK)

    assert not strict.found
    assert permissive.found
    assert permissive.rate_date == date(2025, 6, 13)
    assert permissive.gap_days == 1
    assert permissive.selection_rule == "LAST_PUBLISHED_ON_OR_BEFORE"


def test_holiday_gap_carries_back_to_the_prior_publication_date(
    fx_dataset_usd_2025,
) -> None:
    # The fixture deliberately omits 25 December 2025, a Thursday.
    missing = date(2025, 12, 25)
    resolution = FxResolver(fx_dataset_usd_2025).resolve("USD", missing, TXN_DATE_CARRY_BACK)

    assert resolution.found
    assert resolution.rate_date == date(2025, 12, 24)
    assert "not a publication date" in resolution.notes[0]


def test_period_end_on_a_non_publication_day_carries_back(fx_dataset_usd_2025) -> None:
    # 31 December 2025 is omitted from the fixture, which is the closing-value date.
    closing_rule = FieldValuationRule(
        relevant_date=RelevantDateRule.PERIOD_END_DATE,
        missing_rate_policy=MissingRatePolicy.LAST_PUBLISHED_ON_OR_BEFORE,
    )
    resolution = FxResolver(fx_dataset_usd_2025).resolve("USD", date(2025, 12, 31), closing_rule)

    assert resolution.found
    assert resolution.rate_date == date(2025, 12, 30)
    assert "the rule version in force permits" in resolution.explain()


def test_carry_back_is_bounded_by_the_rules_maximum_gap() -> None:
    rule = FieldValuationRule(
        relevant_date=RelevantDateRule.TRANSACTION_DATE,
        missing_rate_policy=MissingRatePolicy.LAST_PUBLISHED_ON_OR_BEFORE,
        max_rate_gap_days=3,
    )
    resolver = FxResolver(_dataset(_record(date(2025, 6, 1), "83.4000")))

    resolution = resolver.resolve("USD", date(2025, 6, 20), rule)

    assert not resolution.found
    assert "exceeds the 3-day limit" in (resolution.failure_reason or "")


def test_forward_fill_is_available_when_the_rule_selects_it() -> None:
    rule = FieldValuationRule(
        relevant_date=RelevantDateRule.TRANSACTION_DATE,
        missing_rate_policy=MissingRatePolicy.NEXT_PUBLISHED_ON_OR_AFTER,
        max_rate_gap_days=7,
    )
    resolver = FxResolver(_dataset(_record(date(2025, 6, 12), "83.4000")))

    resolution = resolver.resolve("USD", date(2025, 6, 10), rule)

    assert resolution.found
    assert resolution.rate_date == date(2025, 6, 12)
    assert resolution.selection_rule == "NEXT_PUBLISHED_ON_OR_AFTER"


def test_nearest_published_breaks_ties_toward_the_earlier_date() -> None:
    rule = FieldValuationRule(
        relevant_date=RelevantDateRule.TRANSACTION_DATE,
        missing_rate_policy=MissingRatePolicy.NEAREST_PUBLISHED,
        max_rate_gap_days=7,
    )
    resolver = FxResolver(
        _dataset(_record(date(2025, 6, 9), "83.0000"), _record(date(2025, 6, 11), "84.0000"))
    )

    resolution = resolver.resolve("USD", date(2025, 6, 10), rule)

    assert resolution.rate_date == date(2025, 6, 9)


def test_no_dataset_at_all_reports_a_usable_reason() -> None:
    resolution = FxResolver(None).resolve("USD", date(2025, 6, 10), TXN_DATE)

    assert not resolution.found
    assert "No exchange-rate dataset is bound" in (resolution.failure_reason or "")


# --- wrong rate type ------------------------------------------------------


def test_a_tt_selling_rate_does_not_satisfy_a_tt_buying_lookup() -> None:
    resolver = FxResolver(
        _dataset(_record(date(2025, 6, 10), "83.9000", rate_type=FxRateType.TT_SELL))
    )

    resolution = resolver.resolve("USD", date(2025, 6, 10), TXN_DATE)

    assert not resolution.found


# --- multiple rates on one date -------------------------------------------


def test_two_rate_sheets_on_one_date_fail_under_the_default_policy() -> None:
    dataset = _dataset(
        _record(date(2025, 6, 10), "83.4000", published_at=datetime(2025, 6, 10, 9, 0)),
        _record(date(2025, 6, 10), "83.6000", published_at=datetime(2025, 6, 10, 15, 0)),
    )
    resolution = FxResolver(dataset).resolve("USD", date(2025, 6, 10), TXN_DATE)

    assert not resolution.found
    assert resolution.selection_rule == "AMBIGUOUS"
    assert "multiple-rate policy is FAIL" in (resolution.failure_reason or "")


@pytest.mark.parametrize(
    ("policy", "expected"),
    [
        (MultipleRatePolicy.EARLIEST_PUBLICATION, Decimal("83.40000000")),
        (MultipleRatePolicy.LATEST_PUBLICATION, Decimal("83.60000000")),
        (MultipleRatePolicy.HIGHEST_RATE, Decimal("83.60000000")),
        (MultipleRatePolicy.LOWEST_RATE, Decimal("83.40000000")),
    ],
)
def test_multiple_rate_policies_select_deterministically(
    policy: MultipleRatePolicy, expected: Decimal
) -> None:
    dataset = _dataset(
        _record(date(2025, 6, 10), "83.4000", published_at=datetime(2025, 6, 10, 9, 0)),
        _record(date(2025, 6, 10), "83.6000", published_at=datetime(2025, 6, 10, 15, 0)),
    )
    resolver = FxResolver(dataset, multiple_rate_policy=policy)

    resolution = resolver.resolve("USD", date(2025, 6, 10), TXN_DATE)

    assert resolution.value == expected


# --- overrides ------------------------------------------------------------


def test_manual_override_supersedes_the_dataset_for_that_key() -> None:
    dataset = _dataset(_record(date(2025, 6, 10), "83.4000"))
    override = create_override_record(
        currency="USD",
        rate_date=date(2025, 6, 10),
        rate_type=FxRateType.TT_BUY,
        value="84.0000",
        user="ca@example.com",
        reason="corrected against the SBI rate sheet",
        evidence="SBI rate sheet 10 Jun 2025",
        original_value=Decimal("83.4000"),
    )
    resolver = FxResolver(dataset, overrides=[override])

    resolution = resolver.resolve("USD", date(2025, 6, 10), TXN_DATE)

    assert resolution.value == Decimal("84.00000000")
    assert resolution.record is not None
    assert resolution.record.status is RateStatus.MANUAL_OVERRIDE
    assert resolution.record.override_original_value == Decimal("83.4000")
    assert "manual override" in resolution.explain()


def test_override_fills_a_date_absent_from_the_dataset() -> None:
    dataset = _dataset(_record(date(2025, 6, 9), "83.4000"))
    override = create_override_record(
        currency="USD",
        rate_date=date(2025, 12, 31),
        rate_type=FxRateType.TT_BUY,
        value="84.5000",
        user="ca@example.com",
        reason="SBI published rate for 31 Dec 2025",
        evidence="SBI rate sheet 31 Dec 2025",
    )
    resolver = FxResolver(dataset, overrides=[override])

    resolution = resolver.resolve("USD", date(2025, 12, 31), TXN_DATE)

    assert resolution.found
    assert resolution.value == Decimal("84.50000000")


# --- issue reporting ------------------------------------------------------


def test_missing_rate_reports_the_exact_currency_and_date() -> None:
    issues = IssueCollector()
    resolver = FxResolver(_dataset(_record(date(2025, 6, 9), "83.4000")))

    resolver.convert_and_report(
        Decimal("100"),
        "USD",
        date(2025, 6, 10),
        TXN_DATE,
        issues,
        subject="NVDA",
        context_label="Closing value",
    )

    assert issues.has(ErrorCode.FX_RATE_MISSING)
    reported = issues.by_code(ErrorCode.FX_RATE_MISSING)[0]
    assert reported.subject == "USD:2025-06-10"
    assert issues.is_blocked


def test_community_tier_rate_raises_secondary_source_used() -> None:
    issues = IssueCollector()
    resolver = FxResolver(
        _dataset(_record(date(2025, 6, 10), "83.4000", tier=SourceTier.COMMUNITY_DATASET))
    )

    resolver.convert_and_report(
        Decimal("100"),
        "USD",
        date(2025, 6, 10),
        TXN_DATE,
        issues,
        subject="NVDA",
        context_label="Initial value",
    )

    assert issues.has(ErrorCode.SECONDARY_SOURCE_USED)
    assert not issues.is_blocked  # a warning, not blocking


def test_statutory_tier_rate_raises_no_provenance_warning() -> None:
    issues = IssueCollector()
    resolver = FxResolver(_dataset(_record(date(2025, 6, 10), "83.4000")))

    resolver.convert_and_report(
        Decimal("100"),
        "USD",
        date(2025, 6, 10),
        TXN_DATE,
        issues,
        subject="NVDA",
        context_label="Initial value",
    )

    assert len(issues) == 0


def test_override_use_raises_manual_override_present() -> None:
    issues = IssueCollector()
    override = create_override_record(
        currency="USD",
        rate_date=date(2025, 6, 10),
        rate_type=FxRateType.TT_BUY,
        value="84.0000",
        user="ca@example.com",
        reason="SBI sheet",
        evidence="SBI sheet 10 Jun 2025",
    )
    resolver = FxResolver(_dataset(_record(date(2025, 6, 10), "83.4000")), overrides=[override])

    resolver.convert_and_report(
        Decimal("100"),
        "USD",
        date(2025, 6, 10),
        TXN_DATE,
        issues,
        subject="NVDA",
        context_label="Initial value",
    )

    assert issues.has(ErrorCode.MANUAL_OVERRIDE_PRESENT)


# --- evidence export ------------------------------------------------------


def test_evidence_rows_explain_why_each_rate_was_selected(fx_dataset_usd_2025) -> None:
    resolver = FxResolver(fx_dataset_usd_2025)
    resolver.convert(Decimal("100"), "USD", date(2025, 6, 13), TXN_DATE)
    resolver.convert(Decimal("100"), "USD", date(2025, 6, 14), TXN_DATE_CARRY_BACK)

    rows = resolver.evidence_rows()

    assert len(rows) == 1  # both lookups resolved to the same 13 June record
    row = rows[0]
    assert row["Rate Type"] == "Telegraphic Transfer Buying Rate (TTBR)"
    assert row["Source Tier"].startswith("Tier 4")
    assert row["Dataset Version"] == "synthetic-ttbr@2025.test"
    assert row["Why This Rate"]


# --- relevant-date rules --------------------------------------------------


def test_relevant_date_rules_pick_the_right_anchor() -> None:
    transaction = date(2025, 3, 20)
    valuation = date(2025, 7, 4)
    period_end = date(2025, 12, 31)

    def rule(kind: RelevantDateRule) -> FieldValuationRule:
        return FieldValuationRule(relevant_date=kind)

    assert (
        relevant_date_for(
            rule(RelevantDateRule.TRANSACTION_DATE),
            transaction_date=transaction,
            valuation_date=valuation,
            period_end_date=period_end,
        )
        == transaction
    )
    assert (
        relevant_date_for(
            rule(RelevantDateRule.VALUATION_DATE),
            transaction_date=transaction,
            valuation_date=valuation,
        )
        == valuation
    )
    assert (
        relevant_date_for(
            rule(RelevantDateRule.PERIOD_END_DATE), period_end_date=period_end
        )
        == period_end
    )
    assert relevant_date_for(
        rule(RelevantDateRule.PRECEDING_MONTH_END), valuation_date=date(2025, 7, 4)
    ) == date(2025, 6, 30)


def test_relevant_date_rule_without_its_anchor_raises() -> None:
    with pytest.raises(ValueError):
        relevant_date_for(FieldValuationRule(relevant_date=RelevantDateRule.VALUATION_DATE))
