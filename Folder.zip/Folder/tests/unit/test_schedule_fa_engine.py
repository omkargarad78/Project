"""Schedule FA A2 and A3 computation.

These tests run the whole pipeline: parse the synthetic Vested workbook,
resolve securities, reconstruct lots, then compute the tables against the
synthetic FX and price fixtures. That is deliberate. A Schedule FA figure is
the product of every stage, and the failures worth catching are the ones that
only appear when the stages are combined -- an adjusted price series meeting
unadjusted quantities, or a peak found in dollars instead of rupees.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal

import pytest

from backend.app.brokers.vested.parser import VestedParser
from backend.app.core.errors import ErrorCode
from backend.app.fx.resolver import FxResolver
from backend.app.io.loader import load_source
from backend.app.lots.engine import LotEngine
from backend.app.marketdata.dataset import MarketDataSnapshot
from backend.app.marketdata.models import AdjustmentBasis
from backend.app.marketdata.provider import PricePolicy, PriceResolver
from backend.app.schedulefa.engine import ScheduleFaEngine
from backend.app.schedulefa.models import ComputedFigure, FigureStatus
from backend.app.securities.master import SecurityMaster
from backend.app.securities.resolver import SecurityResolver
from backend.app.tax.periods import AssessmentYear
from backend.app.tax.rules.models import (
    CalculationPolicy,
    MultipleRatePolicy,
    PeakValuationFrequency,
)
from backend.app.validation.issues import IssueCollector
from tests.fixtures.marketdata.builder import (
    adjusted_records,
    nvda_split_action,
    unadjusted_records,
)
from tests.fixtures.vested.builder import build_vested_workbook

PERIOD_END = date(2025, 12, 31)


@pytest.fixture(scope="module")
def ledger():
    return VestedParser().parse(
        load_source(build_vested_workbook(), file_name="v.xlsx")
    ).ledger


@pytest.fixture(scope="module")
def book(ledger):
    return LotEngine().build(ledger, IssueCollector())


@pytest.fixture(scope="module")
def resolution(ledger, repo_root):
    master = SecurityMaster.from_directory(repo_root / "data" / "securities")
    return SecurityResolver(master).resolve_ledger(ledger)


@pytest.fixture(scope="module")
def rule(rule_registry):
    return rule_registry.rule_for("2026-27")


@pytest.fixture(scope="module")
def period(rule):
    return rule.schedule_fa.reporting_period.resolve(AssessmentYear.parse("2026-27"))


@pytest.fixture(scope="module")
def snapshot():
    return MarketDataSnapshot(
        unadjusted_records(),
        [nvda_split_action()],
        dataset_name="synthetic-unadjusted",
        adjustment_basis=AdjustmentBasis.UNADJUSTED,
        synthetic=True,
    )


def make_engine(
    rule,
    period,
    fx_dataset,
    snapshot,
    *,
    policy: CalculationPolicy | None = None,
    price_policy: PricePolicy | None = None,
) -> ScheduleFaEngine:
    return ScheduleFaEngine(
        rule=rule,
        period=period,
        fx=FxResolver(
            fx_dataset, multiple_rate_policy=MultipleRatePolicy.LATEST_PUBLICATION
        ),
        market_data=snapshot,
        price_resolver=PriceResolver(
            snapshot, policy=price_policy or PricePolicy(), expected_currency="USD"
        ),
        policy=policy,
    )


@pytest.fixture()
def engine(rule, period, fx_dataset_usd_2025, snapshot):
    return make_engine(rule, period, fx_dataset_usd_2025, snapshot)


@pytest.fixture()
def report(engine, ledger, book, resolution):
    return engine.build(ledger, book, resolution, IssueCollector())


def row(report, symbol):
    return next(r for r in report.table_a3 if r.symbol == symbol)


# --- the reporting period -------------------------------------------------


def test_the_period_is_the_calendar_year_not_the_financial_year(report) -> None:
    """The distinction that most often makes a Schedule FA wrong."""
    assert report.period_start == date(2025, 1, 1)
    assert report.period_end == date(2025, 12, 31)
    assert "calendar year" in report.period_description.lower()


def test_every_figure_is_labelled_when_the_rules_are_unconfirmed(report) -> None:
    assert report.rule_verified is False
    nvda = row(report, "NVDA")
    assert nvda.closing_value.status is FigureStatus.QUALIFIED
    assert any("not been verified" in c for c in nvda.closing_value.caveats)


def test_no_computed_figure_escapes_the_unverified_label(report) -> None:
    """A figure can be copied out of the report, so it carries its own label.

    Checking one field would not catch this: the peak is computed by a
    different path from the other money fields and once omitted the label.
    """
    money = [
        figure
        for table_row in list(report.table_a3) + list(report.table_a2)
        for figure in table_row.fields()
        if isinstance(figure, ComputedFigure)
    ]
    assert money
    assert not [f for f in money if f.status is FigureStatus.COMPLETE], (
        "a figure is marked COMPLETE while the rule version is unverified"
    )
    for figure in (f for f in money if f.status is FigureStatus.QUALIFIED):
        assert any("not been verified" in c for c in figure.caveats), (
            f"{figure.field_name} carries no rule-version label"
        )


def test_unverified_rules_raise_an_issue_once(engine, ledger, book, resolution) -> None:
    issues = IssueCollector()
    engine.build(ledger, book, resolution, issues)

    assert len(issues.by_code(ErrorCode.TAX_RULE_UNVERIFIED)) == 1


# --- which holdings appear ------------------------------------------------


def test_a_holding_sold_inside_the_period_is_still_reported(report) -> None:
    """Schedule FA covers interests held at any time in the period."""
    aapl = row(report, "AAPL")

    assert aapl.closed_during_period is True
    assert aapl.closing_value.status is FigureStatus.NIL
    assert aapl.closing_value.inr_amount == Decimal(0)
    assert aapl.peak_value.status in (
        FigureStatus.COMPLETE,
        FigureStatus.QUALIFIED,
    )


def test_a_closed_holding_says_why_its_closing_value_is_nil(report) -> None:
    aapl = row(report, "AAPL")
    assert "not held at the end" in aapl.closing_value.explanation
    assert "held at any time" in aapl.closing_value.explanation


def test_nil_is_not_the_same_status_as_unavailable(report) -> None:
    """A holding with no dividend and a holding with an unknown one differ."""
    voo = row(report, "VOO")
    msft = row(report, "MSFT")

    assert voo.gross_proceeds.status is FigureStatus.NIL
    assert voo.gross_proceeds.display == "0"
    assert msft.initial_value.status is FigureStatus.UNAVAILABLE
    assert msft.initial_value.display == "NOT AVAILABLE"


# --- the peak ------------------------------------------------------------


def test_the_peak_is_selected_on_rupee_value_not_dollar_value(report) -> None:
    """Every candidate date is converted before comparison.

    If the engine found the dollar peak and converted it once, the rupee peak
    would be the value on the dollar-peak date. Asserting the peak equals the
    maximum over per-date conversions is what distinguishes the two.
    """
    voo = row(report, "VOO")
    points = voo.peak_value.valuation_points

    assert len(points) > 200
    dollar_peak = max(p.value_native for p in points)
    peak_point = next(
        p
        for p in points
        if p.valuation_date.isoformat() in voo.peak_value.explanation
    )
    # The chosen date is a real valuation date, and the figure is a conversion
    # of that date's own native value rather than of the dollar maximum.
    assert peak_point.value_native <= dollar_peak
    assert voo.peak_value.native_amount == peak_point.value_native
    assert voo.peak_value.rate_date is not None


def test_the_peak_names_its_date_quantity_price_and_rate(report) -> None:
    voo = row(report, "VOO")
    figure = voo.peak_value

    assert "highest of" in figure.explanation
    assert "share(s) at USD" in figure.explanation
    assert "daily closing price" in figure.explanation
    assert figure.rate_value is not None
    assert "x" in figure.formula


def test_the_peak_considers_dates_the_holding_changed(report) -> None:
    """A peak can fall on a purchase date, so those dates are valued too."""
    nvda = row(report, "NVDA")
    dates = {p.valuation_date for p in nvda.peak_value.valuation_points}

    assert date(2025, 7, 8) in dates


def test_a_coarser_peak_frequency_is_declared_as_a_caveat(
    rule, period, fx_dataset_usd_2025, snapshot, ledger, book, resolution
) -> None:
    coarse = make_engine(
        rule,
        period,
        fx_dataset_usd_2025,
        snapshot,
        policy=CalculationPolicy(
            peak_valuation_frequency=PeakValuationFrequency.MONTH_END
        ),
    )
    report = coarse.build(ledger, book, resolution, IssueCollector())
    voo = row(report, "VOO")

    assert len(voo.peak_value.valuation_points) < 30
    assert any("may understate" in c for c in voo.peak_value.caveats)


def test_a_coarser_frequency_cannot_exceed_the_daily_peak(
    rule, period, fx_dataset_usd_2025, snapshot, ledger, book, resolution, report
) -> None:
    """Sampling fewer dates can only find a lower maximum, never a higher one."""
    coarse = make_engine(
        rule,
        period,
        fx_dataset_usd_2025,
        snapshot,
        policy=CalculationPolicy(
            peak_valuation_frequency=PeakValuationFrequency.QUARTER_END
        ),
    )
    coarse_report = coarse.build(ledger, book, resolution, IssueCollector())

    daily = row(report, "VOO").peak_value.inr_amount
    sampled = row(coarse_report, "VOO").peak_value.inr_amount
    assert daily is not None and sampled is not None
    assert sampled <= daily


# --- the split-adjustment trap -------------------------------------------


def test_adjusted_prices_against_unadjusted_quantities_are_refused(
    rule, period, fx_dataset_usd_2025, ledger, book, resolution
) -> None:
    """The mistake that silently understates a pre-split holding fourfold."""
    adjusted = MarketDataSnapshot(
        adjusted_records(),
        [nvda_split_action()],
        dataset_name="synthetic-adjusted",
        adjustment_basis=AdjustmentBasis.SPLIT_ADJUSTED,
        synthetic=True,
    )
    engine = make_engine(
        rule,
        period,
        fx_dataset_usd_2025,
        adjusted,
        price_policy=PricePolicy(quantities_are_adjusted=False),
    )
    issues = IssueCollector()
    report = engine.build(ledger, book, resolution, issues)

    assert report.blocking_reasons
    assert report.is_filable is False
    assert report.table_a3 == []


# --- initial value -------------------------------------------------------


def test_each_acquisition_is_converted_at_its_own_date(report) -> None:
    """Purchases months apart must not share one exchange rate."""
    nvda = row(report, "NVDA")
    figure = nvda.initial_value

    assert figure.status is FigureStatus.QUALIFIED
    assert "2025-02-10" in figure.formula
    assert "2025-04-15" in figure.formula
    assert "own acquisition date" in figure.explanation


def test_missing_acquisition_history_makes_initial_value_unavailable(report) -> None:
    """MSFT was sold with no purchase in the file: the cost is unknown, not zero."""
    msft = row(report, "MSFT")

    assert msft.initial_value.status is FigureStatus.UNAVAILABLE
    assert msft.initial_value.inr_amount is None
    assert "not in the uploaded files" in msft.initial_value.explanation


def test_missing_history_does_not_stop_peak_and_closing_value(report) -> None:
    """Quantity is known even when cost is not, so these still compute."""
    msft = row(report, "MSFT")

    assert msft.peak_value.available
    assert msft.peak_value.inr_amount is not None
    assert msft.closing_value.available


def test_a_peak_built_on_inferred_history_is_declared_a_lower_bound(report) -> None:
    """The shares were provably held on the sale date, and possibly earlier.

    Valuing only the dates the data proves is the honest floor. Claiming the
    holding spanned the whole period would invent an acquisition date; saying
    nothing would present a floor as if it were the answer.
    """
    msft = row(report, "MSFT")
    points = msft.peak_value.valuation_points

    assert len(points) == 1
    assert points[0].quantity == Decimal("3.00000000")
    assert any("lower bound" in c for c in msft.peak_value.caveats)
    assert msft.peak_value.status is FigureStatus.QUALIFIED


def test_missing_history_leaves_the_acquisition_date_blank(report) -> None:
    msft = row(report, "MSFT")

    assert msft.acquisition_date.value is None
    assert "will not substitute the earliest date" in msft.acquisition_date.explanation


def test_the_acquisition_date_is_the_earliest_of_several(report) -> None:
    nvda = row(report, "NVDA")

    assert nvda.acquisition_date.value == "2025-02-10"
    assert "earliest of" in nvda.acquisition_date.explanation


# --- income and proceeds --------------------------------------------------


def test_income_is_reported_gross_of_withholding_tax(report) -> None:
    nvda = row(report, "NVDA")
    figure = nvda.income_credited

    assert figure.available
    assert "gross of foreign tax withheld" in figure.explanation
    assert "is not deducted" in figure.explanation


def test_net_income_can_be_configured_and_is_lower(
    rule, period, fx_dataset_usd_2025, snapshot, ledger, book, resolution, report
) -> None:
    net_engine = make_engine(
        rule,
        period,
        fx_dataset_usd_2025,
        snapshot,
        policy=CalculationPolicy(income_is_gross_of_withholding=False),
    )
    net_report = net_engine.build(ledger, book, resolution, IssueCollector())

    gross = row(report, "NVDA").income_credited.inr_amount
    net = row(net_report, "NVDA").income_credited.inr_amount
    assert gross is not None and net is not None
    assert net < gross
    assert "net of foreign tax withheld" in (
        row(net_report, "NVDA").income_credited.explanation
    )


def test_proceeds_are_gross_and_say_so(report) -> None:
    aapl = row(report, "AAPL")
    figure = aapl.gross_proceeds

    assert figure.available
    assert "not deducted" in figure.explanation
    assert "asks for gross" in figure.explanation


def test_deducting_selling_fees_is_a_declared_choice(
    rule, period, fx_dataset_usd_2025, snapshot, ledger, book, resolution, report
) -> None:
    net_engine = make_engine(
        rule,
        period,
        fx_dataset_usd_2025,
        snapshot,
        policy=CalculationPolicy(deduct_fees_from_gross_proceeds=True),
    )
    net_report = net_engine.build(ledger, book, resolution, IssueCollector())

    gross = row(report, "AAPL").gross_proceeds.inr_amount
    net = row(net_report, "AAPL").gross_proceeds.inr_amount
    assert gross is not None and net is not None
    assert net < gross
    assert "fees are deducted" in row(net_report, "AAPL").gross_proceeds.explanation


def test_income_and_proceeds_are_converted_per_transaction_date(report) -> None:
    nvda = row(report, "NVDA")

    assert "own disposal date" in nvda.gross_proceeds.explanation or (
        nvda.gross_proceeds.status is FigureStatus.NIL
    )
    assert "date it was credited" in nvda.income_credited.explanation


# --- entity identity -----------------------------------------------------


def test_the_entity_name_is_the_legal_name_not_the_ticker(report) -> None:
    nvda = row(report, "NVDA")

    assert nvda.entity_name.value == "NVIDIA Corporation"
    assert "not the ticker symbol" in nvda.entity_name.explanation


def test_an_unnamed_entity_leaves_the_field_blank(report) -> None:
    """VOO has no legal entity name in the seed data, on purpose."""
    voo = row(report, "VOO")

    assert voo.entity_name.value is None
    assert voo.entity_name.display == "NOT AVAILABLE"
    assert voo.is_complete is False
    assert "entity_name" in voo.missing_fields()


def test_an_unconfirmed_country_code_is_not_substituted(report) -> None:
    """The ISO code is not written into a field that wants the ITR code."""
    nvda = row(report, "NVDA")

    assert nvda.country_name.value == "United States of America"
    assert nvda.country_code.value is None
    assert "not always identical" in nvda.country_code.explanation or (
        "not substituted" in nvda.country_code.explanation
    )


def test_a_row_is_not_filable_while_a_field_is_missing(report) -> None:
    assert report.is_filable is False
    problems = report.incomplete_rows()
    assert problems
    assert any("VOO" in p for p in problems)


# --- Table A2 -------------------------------------------------------------


def test_the_cash_account_reports_only_cash(report) -> None:
    """Securities value belongs in A3; adding it here double-counts."""
    account = report.table_a2[0]

    assert any("same wealth twice" in n for n in account.notes)
    assert account.peak_balance.available


def test_the_account_number_is_never_invented(report) -> None:
    account = report.table_a2[0]

    assert account.account_number.value is None
    assert "never inferred" in account.account_number.explanation or any(
        "never inferred" in c for c in account.account_number.caveats
    )


def test_the_earliest_transaction_is_not_an_account_opening_date(report) -> None:
    account = report.table_a2[0]

    assert account.account_opening_date.value is None
    assert any("not a substitute" in c for c in account.account_opening_date.caveats)


def test_user_supplied_account_details_are_used(
    engine, ledger, book, resolution
) -> None:
    report = engine.build(
        ledger,
        book,
        resolution,
        IssueCollector(),
        account_number="XXXX1234",
        account_status="Owner",
        account_opening_date=date(2024, 11, 3),
    )
    account = report.table_a2[0]

    assert account.account_number.value == "XXXX1234"
    assert account.account_opening_date.value == "2024-11-03"


def test_deposits_are_excluded_from_amounts_credited(report) -> None:
    """The holder's own funding is not an amount paid or credited to them."""
    account = report.table_a2[0]

    assert "Deposits" in account.gross_amount_credited.explanation
    assert "own money moving in" in account.gross_amount_credited.explanation


def test_the_institution_name_is_left_blank_when_unconfirmed(report) -> None:
    """App brand, introducing broker and clearing custodian are not the same."""
    account = report.table_a2[0]

    assert account.institution_name.value is None
    assert any(
        "different entities" in c for c in account.institution_name.caveats
    )


# --- traceability ---------------------------------------------------------


def test_every_computed_figure_carries_an_explanation(report) -> None:
    for table_row in report.table_a3:
        for figure in table_row.fields():
            if figure.available and figure.field_name.endswith("value"):
                assert figure.explanation, f"{table_row.symbol}.{figure.field_name}"


def test_every_unavailable_figure_carries_a_reason(report) -> None:
    for table_row in list(report.table_a3) + list(report.table_a2):
        for figure in table_row.fields():
            if not figure.available:
                assert figure.caveats, f"{figure.field_name} has no reason"


def test_the_summary_shows_the_period_the_rules_and_what_blocks(report) -> None:
    text = report.summary()

    assert "2025-01-01 to 2025-12-31" in text
    assert "NOT VERIFIED" in text
    assert "filable as it stands: False" in text
    assert "NOT AVAILABLE" in text


def test_the_policy_is_recorded_on_the_report(report) -> None:
    assert report.calculation_policy["Price Valuation Point"] == "daily closing price"


def test_the_rate_used_for_each_figure_is_recoverable(report) -> None:
    nvda = row(report, "NVDA")
    closing = nvda.closing_value

    assert closing.rate_date is not None
    assert closing.rate_value is not None
    assert "TT_BUY" in (closing.rate_type or "")


def test_the_closing_rate_comes_from_the_period_end_or_just_before(report) -> None:
    """31 December is frequently a non-publication day."""
    nvda = row(report, "NVDA")
    assert nvda.closing_value.rate_date is not None
    assert nvda.closing_value.rate_date <= PERIOD_END
    assert (PERIOD_END - nvda.closing_value.rate_date).days <= 7
