"""Raw file reading: precision preservation, date decoding and hostile files."""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

import pytest

from backend.app.core.errors import ErrorCode, ParseError
from backend.app.core.money import to_decimal
from backend.app.io.csv_reader import read_csv
from backend.app.io.filetype import FileType, detect_file_type, safe_file_name, validate_upload
from backend.app.io.loader import load_source
from backend.app.io.tabular import (
    CellKind,
    column_index,
    column_letter,
    detect_header_row,
    extract_table,
    sanitize_sheet_name,
    split_reference,
)
from backend.app.io.xlsx_reader import read_xlsx, serial_to_datetime
from tests.fixtures.builders import (
    BLANK,
    STYLE_CURRENCY,
    STYLE_DATE_BUILTIN,
    STYLE_DATETIME,
    boolean,
    build_billion_laughs_xlsx,
    build_unsafe_path_xlsx,
    build_xlsx,
    build_xxe_xlsx,
    build_zip_bomb_xlsx,
    date_serial,
    error,
    formula,
    number,
    text,
)

# --- the precision guarantee ---------------------------------------------


@pytest.mark.parametrize(
    "digits",
    [
        "0.1",
        "0.3",
        "123.456789012345678901234567890",
        "1234567890123456789.987654321",
        "0.000000000000000001",
        "12.340000000000000001",
        "99999999999999999999999",
    ],
)
def test_numeric_cells_keep_their_exact_source_digits(digits: str) -> None:
    """The reason this reader exists: no value passes through a float."""
    content = build_xlsx({"S": [[text("Amount")], [number(digits)]]})

    sheet = read_xlsx(content).sheet("S")
    cell = sheet.cell(1, 0)

    assert cell.kind is CellKind.NUMBER
    assert cell.raw_text == digits
    # Exactly equal as a Decimal, with every digit intact.
    assert to_decimal(cell.raw_text) == Decimal(digits)


def test_a_float_round_trip_would_have_lost_these_digits() -> None:
    """Demonstrates the failure mode the raw reader avoids."""
    digits = "123.456789012345678901234567890"
    content = build_xlsx({"S": [[number(digits)]]})

    preserved = to_decimal(read_xlsx(content).sheet("S").cell(0, 0).raw_text)
    via_float = Decimal(str(float(digits)))

    assert preserved == Decimal(digits)
    assert via_float != Decimal(digits)


def test_to_decimal_refuses_a_float_outright() -> None:
    with pytest.raises(Exception) as excinfo:
        to_decimal(1.1)
    assert "float is not accepted" in str(excinfo.value)


# --- date decoding --------------------------------------------------------


def test_date_formatted_cells_decode_to_calendar_dates() -> None:
    # Serial 45658 is 1 January 2025 in the 1900 date system.
    content = build_xlsx({"S": [[text("Date")], [date_serial("45658")]]})

    cell = read_xlsx(content).sheet("S").cell(1, 0)

    assert cell.kind is CellKind.DATE
    assert cell.date_value == date(2025, 1, 1)
    assert cell.display_text == "2025-01-01"
    # The serial is still available, so a misread format stays diagnosable.
    assert cell.raw_text == "45658"


def test_builtin_date_format_is_recognised() -> None:
    content = build_xlsx({"S": [[date_serial("45658", style=STYLE_DATE_BUILTIN)]]})

    assert read_xlsx(content).sheet("S").cell(0, 0).kind is CellKind.DATE


def test_datetime_serial_decodes_the_time_component() -> None:
    content = build_xlsx({"S": [[date_serial("45658.5", style=STYLE_DATETIME)]]})

    cell = read_xlsx(content).sheet("S").cell(0, 0)

    assert cell.date_value == datetime(2025, 1, 1, 12, 0)


def test_currency_format_is_not_mistaken_for_a_date() -> None:
    content = build_xlsx({"S": [[number("1234.5600", style=STYLE_CURRENCY)]]})

    cell = read_xlsx(content).sheet("S").cell(0, 0)

    assert cell.kind is CellKind.NUMBER
    assert cell.raw_text == "1234.5600"


def test_the_1900_leap_year_bug_is_handled() -> None:
    """Serial 61 is 1 March 1900, because serial 60 is a date that never existed."""
    assert serial_to_datetime(Decimal(61)) == date(1900, 3, 1)
    assert serial_to_datetime(Decimal(59)) == date(1900, 2, 28)
    with pytest.raises(ValueError):
        serial_to_datetime(Decimal(60))


def test_1904_date_system_is_decoded_with_its_own_epoch() -> None:
    content = build_xlsx({"S": [[date_serial("44196")]]}, date1904=True)

    cell = read_xlsx(content).sheet("S").cell(0, 0)

    assert cell.date_value == date(2025, 1, 1)


def test_1904_workbook_is_reported_as_a_warning() -> None:
    workbook = read_xlsx(build_xlsx({"S": [[date_serial("44196")]]}, date1904=True))

    assert any("1904 date system" in w for w in workbook.warnings)


# --- cell kinds -----------------------------------------------------------


def test_all_cell_kinds_are_classified() -> None:
    content = build_xlsx(
        {
            "S": [
                [
                    text("hello"),
                    number("42"),
                    date_serial("45658"),
                    boolean(True),
                    error("#REF!"),
                    BLANK,
                ]
            ]
        }
    )
    sheet = read_xlsx(content).sheet("S")

    assert [sheet.cell(0, column).kind for column in range(6)] == [
        CellKind.TEXT,
        CellKind.NUMBER,
        CellKind.DATE,
        CellKind.BOOLEAN,
        CellKind.ERROR,
        CellKind.EMPTY,
    ]
    # An empty cell is not stored, so the sheet's width stops at the last
    # populated column rather than at the last cell the file mentioned.
    assert sheet.column_count == 5


def test_shared_strings_are_resolved() -> None:
    from tests.fixtures.builders import Cell

    content = build_xlsx(
        {"S": [[Cell(kind="s", value="1")]]},
        shared_strings=["first", "second"],
    )

    assert read_xlsx(content).sheet("S").cell(0, 0).text == "second"


# --- formulas are never evaluated ----------------------------------------


def test_formula_cells_keep_their_cached_value_and_text() -> None:
    content = build_xlsx({"S": [[number("10")], [number("5")], [formula("A1*A2", "50")]]})

    cell = read_xlsx(content).sheet("S").cell(2, 0)

    assert cell.formula == "A1*A2"
    assert cell.raw_text == "50"
    assert cell.kind is CellKind.NUMBER


def test_a_lying_cached_value_is_taken_as_broker_data_not_recomputed() -> None:
    """The cached value is data; recomputing it would mean evaluating a formula."""
    content = build_xlsx({"S": [[formula("1+1", "999")]]})

    assert read_xlsx(content).sheet("S").cell(0, 0).raw_text == "999"


def test_formula_presence_is_reported() -> None:
    workbook = read_xlsx(build_xlsx({"S": [[formula("1+1", "2")]]}))

    assert workbook.sheets[0].formula_cell_count == 1
    assert any("no formula is evaluated" in w for w in workbook.warnings)


# --- hostile files --------------------------------------------------------


def test_external_entity_declaration_is_refused() -> None:
    with pytest.raises(ParseError) as excinfo:
        read_xlsx(build_xxe_xlsx())

    assert excinfo.value.code is ErrorCode.SOURCE_FILE_CORRUPT


def test_entity_expansion_bomb_is_refused() -> None:
    with pytest.raises(ParseError) as excinfo:
        read_xlsx(build_billion_laughs_xlsx())

    assert excinfo.value.code is ErrorCode.SOURCE_FILE_CORRUPT


def test_decompression_bomb_is_refused() -> None:
    with pytest.raises(ParseError) as excinfo:
        read_xlsx(build_zip_bomb_xlsx())

    assert excinfo.value.code is ErrorCode.SOURCE_FILE_CORRUPT
    assert "bomb" in str(excinfo.value) or "limit" in str(excinfo.value)


def test_unsafe_entry_path_is_refused() -> None:
    with pytest.raises(ParseError) as excinfo:
        read_xlsx(build_unsafe_path_xlsx())

    assert "unsafe entry path" in str(excinfo.value)


def test_macro_bearing_workbook_is_read_but_flagged() -> None:
    workbook = read_xlsx(build_xlsx({"S": [[text("a")]]}, include_macros=True))

    assert workbook.contains_macros
    assert any("macro" in w for w in workbook.warnings)


def test_external_links_are_reported_and_not_followed() -> None:
    workbook = read_xlsx(build_xlsx({"S": [[text("a")]]}, include_external_link=True))

    assert workbook.external_links
    assert any("not followed" in w for w in workbook.warnings)


def test_a_truncated_package_is_reported_as_corrupt() -> None:
    content = build_xlsx({"S": [[text("a")]]})

    with pytest.raises(ParseError) as excinfo:
        read_xlsx(content[: len(content) // 2])

    assert excinfo.value.code is ErrorCode.SOURCE_FILE_CORRUPT


# --- file-type detection --------------------------------------------------


def test_type_is_decided_by_content_not_by_name() -> None:
    xlsx = build_xlsx({"S": [[text("a")]]})

    detected = validate_upload(xlsx, file_name="statement.csv", max_bytes=10_000_000)

    assert detected.file_type is FileType.XLSX
    assert detected.extension_mismatch
    assert any("but its contents are" in w for w in detected.warnings)


def test_html_error_page_is_rejected() -> None:
    kind, warnings = detect_file_type(b"<!DOCTYPE html><html><body>Login</body></html>")

    assert kind is FileType.UNKNOWN
    assert "HTML page" in warnings[0]


def test_legacy_xls_is_rejected_with_actionable_guidance() -> None:
    ole2 = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\x00" * 512

    with pytest.raises(ParseError) as excinfo:
        validate_upload(ole2, file_name="old.xls", max_bytes=10_000_000)

    assert excinfo.value.code is ErrorCode.SOURCE_FILE_UNSUPPORTED
    assert "save it as .xlsx" in str(excinfo.value)


def test_pdf_is_rejected_for_parsing() -> None:
    with pytest.raises(ParseError) as excinfo:
        validate_upload(b"%PDF-1.7\n...", file_name="s.pdf", max_bytes=10_000_000)

    assert "cannot yet be parsed" in str(excinfo.value)


def test_oversized_upload_is_rejected() -> None:
    with pytest.raises(ParseError) as excinfo:
        validate_upload(b"a,b\n1,2\n", file_name="s.csv", max_bytes=4)

    assert excinfo.value.code is ErrorCode.SOURCE_FILE_UNSUPPORTED
    assert "upload limit" in str(excinfo.value)


def test_empty_upload_is_rejected() -> None:
    with pytest.raises(ParseError):
        validate_upload(b"", file_name="s.csv", max_bytes=1000)


def test_disallowed_extension_is_rejected() -> None:
    with pytest.raises(ParseError) as excinfo:
        validate_upload(b"a,b\n1,2\n", file_name="s.exe", max_bytes=1000)

    assert "not accepted" in str(excinfo.value)


@pytest.mark.parametrize(
    ("supplied", "expected"),
    [
        # Every path component is discarded, leaving only the base name.
        ("../../etc/passwd", "passwd"),
        (r"..\..\windows\system32\cfg", "cfg"),
        ("/absolute/path/file.xlsx", "file.xlsx"),
        ("....//....//x.csv", "x.csv"),
        ("", "upload"),
        (None, "upload"),
        ("..", "upload"),
        ("nul", "nul"),
    ],
)
def test_filenames_are_never_trusted(supplied: str | None, expected: str) -> None:
    assert safe_file_name(supplied) == expected


# --- CSV ------------------------------------------------------------------


def test_csv_numeric_text_is_preserved() -> None:
    workbook = read_csv(b"Amount\n1234.56789012345678901\n")

    cell = workbook.sheets[0].cell(1, 0)

    assert cell.kind is CellKind.NUMBER
    assert to_decimal(cell.raw_text) == Decimal("1234.56789012345678901")


def test_csv_accounting_negatives_and_thousands_are_normalized() -> None:
    workbook = read_csv(b'Amount\n"(1,234.56)"\n"$2,000.00"\n')
    sheet = workbook.sheets[0]

    assert to_decimal(sheet.cell(1, 0).raw_text) == Decimal("-1234.56")
    assert to_decimal(sheet.cell(2, 0).raw_text) == Decimal("2000.00")


def test_csv_phone_like_text_is_not_treated_as_a_number() -> None:
    workbook = read_csv(b"Ref\n1-800-FLOWERS\n")

    assert workbook.sheets[0].cell(1, 0).kind is CellKind.TEXT


def test_semicolon_delimited_file_is_detected() -> None:
    workbook = read_csv(b"Date;Ticker;Amount\n2025-01-02;NVDA;100.50\n")

    assert workbook.sheets[0].column_count == 3
    assert any("delimiter" in w for w in workbook.warnings)


def test_tab_delimited_file_is_detected() -> None:
    workbook = read_csv(b"Date\tTicker\tAmount\n2025-01-02\tNVDA\t100.50\n")

    assert workbook.sheets[0].column_count == 3


def test_empty_csv_is_rejected() -> None:
    with pytest.raises(ParseError):
        read_csv(b"   \n  \n")


# --- header detection -----------------------------------------------------


def test_header_row_is_found_below_a_title_block() -> None:
    content = build_xlsx(
        {
            "Trades": [
                [text("Vested Finance - Account Statement")],
                [text("Account: ****1234")],
                [BLANK],
                [text("Date"), text("Ticker"), text("Quantity"), text("Price")],
                [date_serial("45658"), text("NVDA"), number("10"), number("120.50")],
            ]
        }
    )
    sheet = read_xlsx(content).sheet("Trades")

    header = detect_header_row(sheet, expected_aliases=["Date", "Ticker", "Quantity"])

    assert header is not None
    assert header.row_index == 3
    assert header.labels() == ["Date", "Ticker", "Quantity", "Price"]


def test_extract_table_returns_rows_addressable_by_header() -> None:
    content = build_xlsx(
        {
            "Trades": [
                [text("Trade Date"), text("Symbol"), text("Price / Share")],
                [date_serial("45658"), text("NVDA"), number("120.5000")],
                [date_serial("45659"), text("AAPL"), number("190.2500")],
            ]
        }
    )
    sheet = read_xlsx(content).sheet("Trades")

    table = extract_table(sheet, expected_aliases=["Trade Date", "Symbol"])

    assert table is not None
    assert len(table) == 2
    first = table.rows[0]
    assert first.row_number == 2
    assert first.text("Symbol") == "NVDA"
    # Punctuation and case are ignored, so "Price/Share" finds "Price / Share".
    assert first.text("Price/Share") == "120.5000"
    assert first.raw_values()["Trade Date"] == "45658"


def test_column_matching_does_not_creatively_guess() -> None:
    """Matching is deliberately conservative.

    "Price Per Share" is not treated as "Price / Share": a mapping that
    invents word-level equivalences could silently bind a tax figure to the
    wrong column. Parsers declare explicit alias lists instead.
    """
    content = build_xlsx(
        {"S": [[text("Trade Date"), text("Price / Share")], [date_serial("45658"), number("1")]]}
    )
    table = extract_table(read_xlsx(content).sheet("S"))

    assert table is not None
    assert table.rows[0].text("Price Per Share") is None


def test_an_alias_never_matches_a_header_that_merely_contains_it() -> None:
    """Regression: "Scrip" must not resolve to "Description".

    An earlier substring fallback bound the ticker alias "Scrip" to a
    "Description" column, because "de-scrip-tion" contains it, and cash
    transfers acquired tickers such as "Additional Funding". A column that
    reads as missing is recoverable; a column silently bound to unrelated data
    produces a finished-looking, wrong figure.
    """
    content = build_xlsx(
        {"S": [[text("Date"), text("Description")], [date_serial("45658"), text("Funding")]]}
    )
    table = extract_table(read_xlsx(content).sheet("S"))

    assert table is not None
    assert table.rows[0].text("Scrip") is None
    assert table.rows[0].text("Ticker", "Symbol", "Scrip") is None
    assert table.rows[0].text("Description") == "Funding"


def test_alias_groups_accept_any_declared_spelling() -> None:
    content = build_xlsx(
        {"S": [[text("Trade Date"), text("Symbol")], [date_serial("45658"), text("N")]]}
    )
    table = extract_table(read_xlsx(content).sheet("S"))

    assert table is not None
    assert table.missing_field_groups(
        [
            ("Transaction Date", ("Transaction Date", "Trade Date")),
            ("Ticker", ("Ticker", "Symbol")),
            ("Quantity", ("Quantity", "Shares")),
        ]
    ) == ["Quantity"]


def test_missing_required_headers_are_named() -> None:
    content = build_xlsx({"S": [[text("Date"), text("Ticker")], [date_serial("45658"), text("N")]]})
    table = extract_table(read_xlsx(content).sheet("S"))

    assert table is not None
    assert table.missing_headers(["Date", "Ticker", "Quantity"]) == ["Quantity"]


def test_table_extraction_stops_at_a_trailing_totals_block() -> None:
    content = build_xlsx(
        {
            "S": [
                [text("Date"), text("Amount")],
                [date_serial("45658"), number("100")],
                [BLANK, BLANK],
                [BLANK, BLANK],
                [BLANK, BLANK],
                [BLANK, BLANK],
                [BLANK, BLANK],
                [text("Total"), number("100")],
            ]
        }
    )
    table = extract_table(read_xlsx(content).sheet("S"), stop_on_blank_rows=5)

    assert table is not None
    assert len(table) == 1


# --- sheet and column helpers --------------------------------------------


@pytest.mark.parametrize(
    ("index", "letters"), [(0, "A"), (25, "Z"), (26, "AA"), (27, "AB"), (701, "ZZ"), (702, "AAA")]
)
def test_column_letter_round_trip(index: int, letters: str) -> None:
    assert column_letter(index) == letters
    assert column_index(letters) == index


def test_split_reference() -> None:
    assert split_reference("B7") == (6, 1)
    assert split_reference("AA100") == (99, 26)
    with pytest.raises(ValueError):
        split_reference("7B")


@pytest.mark.parametrize(
    ("supplied", "expected"),
    [
        ("Trades", "Trades"),
        ("Trades/2025", "Trades_2025"),
        # 32 characters in, truncated to Excel's 31-character sheet-name limit.
        ("A[very]:long*name?with/bad\\chars", "A_very__long_name_with_bad_char"),
        ("", "Sheet"),
        ("x" * 50, "x" * 31),
    ],
)
def test_sheet_names_are_sanitized_for_output(supplied: str, expected: str) -> None:
    assert sanitize_sheet_name(supplied) == expected


# --- the loader -----------------------------------------------------------


def test_loader_profiles_every_sheet() -> None:
    content = build_xlsx(
        {
            "Trades": [
                [text("Date"), text("Ticker"), text("Quantity"), text("Amount")],
                [date_serial("45658"), text("NVDA"), number("10"), number("1205.00")],
                [date_serial("45659"), text("AAPL"), BLANK, number("1902.50")],
            ],
            "Notes": [[text("nothing here")]],
        }
    )

    loaded = load_source(content, file_name="vested.xlsx")

    assert loaded.file_type is FileType.XLSX
    assert [p.name for p in loaded.sheet_profiles] == ["Trades", "Notes"]
    trades = loaded.sheet_profiles[0]
    assert trades.data_row_count == 2
    assert trades.header_row_number == 1
    assert "Date" in trades.date_columns
    assert "Amount" in trades.numeric_columns
    assert "Quantity" in trades.columns_with_missing_values


def test_same_bytes_produce_the_same_source_file_id() -> None:
    content = build_xlsx({"S": [[text("a")]]})

    first = load_source(content, file_name="a.xlsx")
    second = load_source(content, file_name="differently_named.xlsx")

    assert first.file_hash == second.file_hash
    assert first.source_file_id == second.source_file_id


def test_different_bytes_produce_different_ids() -> None:
    first = load_source(build_xlsx({"S": [[text("a")]]}), file_name="a.xlsx")
    second = load_source(build_xlsx({"S": [[text("b")]]}), file_name="a.xlsx")

    assert first.source_file_id != second.source_file_id


def test_hidden_sheets_are_read_and_marked() -> None:
    content = build_xlsx(
        {"Visible": [[text("a")]], "Secret": [[text("b")]]}, hidden_sheets=["Secret"]
    )

    loaded = load_source(content, file_name="v.xlsx")

    assert loaded.sheet_profiles[1].hidden is True
