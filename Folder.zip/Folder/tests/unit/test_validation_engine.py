"""The worklist, the filing verdict and the resolution workflow.

The engine's job is to be trusted about one question -- "can this be filed,
and if not, what exactly do I do next?" -- so these tests are mostly about the
answers being honest rather than convenient: that acknowledgement cannot waive
a figure into existence, that a claimed fix is verified rather than believed,
and that no gap in the form is missing from the worklist.
"""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from backend.app.core.errors import (
    ERROR_CATALOG,
    ErrorCode,
    ResolutionAction,
    Severity,
    definition,
)
from backend.app.validation.engine import (
    FilingReadiness,
    ValidationEngine,
)
from backend.app.validation.issues import (
    IssueCollector,
    IssueScope,
    IssueStatus,
    issue,
)
from backend.app.validation.resolutions import (
    CarryOutcome,
    ResolutionStore,
    carry_summary,
)

NOW = datetime(2026, 2, 1, 9, 30, tzinfo=UTC)


def make(code: ErrorCode, subject: str, message: str = "something happened"):
    return issue(code, scope=IssueScope.CALCULATION, subject=subject, message=message)


@pytest.fixture()
def collector():
    return IssueCollector()


# --- the catalogue's workflow routing ------------------------------------


def test_every_code_declares_an_action_and_a_waiver_decision() -> None:
    """A code with no routing would appear in the worklist with no next step."""
    for code in ErrorCode:
        entry = definition(code)
        assert entry.action in set(ResolutionAction)
        assert isinstance(entry.waivable, bool)


def test_only_reconciliation_errors_can_be_waived() -> None:
    """The full list of guard rails a user may step around, asserted.

    This test exists to make widening that list a deliberate act. Adding a
    waivable error means a filing can proceed with that condition accepted,
    which is a policy decision and not an implementation detail.
    """
    waivable = {
        code
        for code, entry in ERROR_CATALOG.items()
        if entry.default_severity is Severity.ERROR and entry.waivable
    }
    assert waivable == {
        ErrorCode.LOT_RECONCILIATION_FAILED,
        ErrorCode.CASH_RECONCILIATION_FAILED,
    }


def test_missing_data_errors_are_never_waivable() -> None:
    """No amount of acceptance produces a figure that has no inputs."""
    for code in (
        ErrorCode.FX_RATE_MISSING,
        ErrorCode.MARKET_PRICE_MISSING,
        ErrorCode.ACQUISITION_COST_MISSING,
        ErrorCode.SECURITY_ENTITY_NAME_MISSING,
        ErrorCode.ACCOUNT_DETAILS_MISSING,
        ErrorCode.PRICE_ADJUSTMENT_BASIS_MISMATCH,
    ):
        assert definition(code).waivable is False, code


# --- blocking and waiving -------------------------------------------------


def test_an_open_error_blocks(collector) -> None:
    item = collector.add(make(ErrorCode.FX_RATE_MISSING, "USD 2025-12-31"))

    assert item.is_blocking
    assert collector.is_blocked


def test_acknowledging_an_unwaivable_error_does_not_unblock(collector) -> None:
    """Otherwise a checkbox steps around every guard rail in the platform."""
    item = collector.add(make(ErrorCode.FX_RATE_MISSING, "USD 2025-12-31"))
    accepted = item.resolve(
        status=IssueStatus.ACKNOWLEDGED, note="I accept this", user="u", at=NOW
    )

    assert accepted.is_blocking is True


def test_acknowledging_a_waivable_error_unblocks(collector) -> None:
    """The broker's stated holding may legitimately be the wrong one."""
    item = collector.add(make(ErrorCode.LOT_RECONCILIATION_FAILED, "NVDA"))
    accepted = item.resolve(
        status=IssueStatus.ACKNOWLEDGED,
        note="broker statement predates the corporate action",
        user="u",
        at=NOW,
    )

    assert item.is_blocking is True
    assert accepted.is_blocking is False


def test_a_warning_never_blocks(collector) -> None:
    item = collector.add(make(ErrorCode.MARKET_PRICE_STALE, "AAPL"))
    assert item.is_blocking is False


# --- grouping and ordering ------------------------------------------------


def test_many_occurrences_of_one_condition_are_one_task(collector) -> None:
    """Two hundred missing rates are one trip to import a dataset."""
    for day in range(1, 60):
        collector.add(
            make(
                ErrorCode.FX_RATE_MISSING,
                f"USD 2025-03-{day:02d}",
                f"no rate on 2025-03-{day:02d}",
            )
        )
    result = ValidationEngine().assess(collector)

    assert len(result.groups) == 1
    group = result.groups[0]
    assert group.count == 59
    assert group.action is ResolutionAction.IMPORT_FX_DATASET
    assert "59 occurrence(s)" in group.headline()


def test_blocking_work_comes_before_everything_else(collector) -> None:
    collector.add(make(ErrorCode.MARKET_PRICE_STALE, "AAPL"))
    collector.add(make(ErrorCode.SECONDARY_SOURCE_USED, "USD"))
    collector.add(make(ErrorCode.FX_RATE_MISSING, "USD 2025-12-31"))
    result = ValidationEngine().assess(collector)

    assert result.groups[0].code is ErrorCode.FX_RATE_MISSING
    assert result.next_action() is result.groups[0]


def test_settled_groups_sink_below_open_ones(collector) -> None:
    stale = collector.add(make(ErrorCode.MARKET_PRICE_STALE, "AAPL"))
    collector.add(make(ErrorCode.SECONDARY_SOURCE_USED, "USD"))
    collector.apply_resolutions(
        {
            stale.issue_id: stale.resolve(
                status=IssueStatus.ACKNOWLEDGED, note="fine", user="u", at=NOW
            )
        }
    )
    result = ValidationEngine().assess(collector)

    codes = [g.code for g in result.groups]
    assert codes.index(ErrorCode.SECONDARY_SOURCE_USED) < codes.index(
        ErrorCode.MARKET_PRICE_STALE
    )


def test_an_unwaivable_group_says_it_cannot_be_filed_around(collector) -> None:
    collector.add(make(ErrorCode.FX_RATE_MISSING, "USD 2025-12-31"))
    group = ValidationEngine().assess(collector).groups[0]

    assert "cannot be accepted and filed around" in group.describe()


def test_the_worklist_names_the_action_not_just_the_problem(collector) -> None:
    collector.add(make(ErrorCode.ACQUISITION_COST_MISSING, "MSFT"))
    group = ValidationEngine().assess(collector).groups[0]

    assert group.action is ResolutionAction.UPLOAD_EARLIER_STATEMENT
    assert "Upload an earlier broker statement" in group.describe()


# --- the verdict ----------------------------------------------------------


def test_a_clean_run_is_ready(collector) -> None:
    result = ValidationEngine().assess(collector)

    assert result.readiness is FilingReadiness.READY
    assert result.is_filable


def test_open_warnings_qualify_rather_than_block(collector) -> None:
    collector.add(make(ErrorCode.MARKET_PRICE_STALE, "AAPL"))
    result = ValidationEngine().assess(collector)

    assert result.readiness is FilingReadiness.READY_WITH_QUALIFICATIONS
    assert result.is_filable
    assert result.qualifications


def test_an_error_blocks_and_says_what_to_do(collector) -> None:
    collector.add(make(ErrorCode.SECURITY_ENTITY_NAME_MISSING, "VOO"))
    result = ValidationEngine().assess(collector)

    assert result.readiness is FilingReadiness.BLOCKED
    assert not result.is_filable
    assert any("VOO" in reason for reason in result.blocking_reasons)
    assert any(
        "Supply the entity's reporting details" in reason
        for reason in result.blocking_reasons
    )


# --- the resolution workflow ---------------------------------------------


def test_an_acknowledgement_requires_a_reason(collector) -> None:
    """A bare acknowledgement is indistinguishable from a mis-click later."""
    item = collector.add(make(ErrorCode.MARKET_PRICE_STALE, "AAPL"))
    store = ResolutionStore()

    with pytest.raises(ValueError, match="requires a reason"):
        store.acknowledge(item, note="   ", user="u", at=NOW)


def test_an_acknowledgement_survives_a_rerun() -> None:
    """The condition persisting is exactly what was accepted."""
    first = IssueCollector()
    item = first.add(make(ErrorCode.MARKET_PRICE_STALE, "AAPL", "carried forward 2 days"))
    store = ResolutionStore()
    store.acknowledge(item, note="weekend, expected", user="omkar", at=NOW)

    rerun = IssueCollector()
    rerun.add(make(ErrorCode.MARKET_PRICE_STALE, "AAPL", "carried forward 2 days"))
    results = store.apply(rerun)

    assert [r.outcome for r in results] == [CarryOutcome.CARRIED]
    carried = next(iter(rerun))
    assert carried.status is IssueStatus.ACKNOWLEDGED
    assert carried.resolution_note == "weekend, expected"
    assert carried.resolved_by == "omkar"


def test_a_claimed_fix_that_did_not_take_is_reopened() -> None:
    """The most dangerous thing here would be to believe the claim.

    Marking an issue fixed asserts the data changed. If the next run produces
    the same issue, the data did not change, and carrying the claim forward
    would hide a live problem behind a stale assertion.
    """
    first = IssueCollector()
    item = first.add(make(ErrorCode.FX_RATE_MISSING, "USD 2025-12-31"))
    store = ResolutionStore()
    store.mark_resolved(item, note="imported the December rates", user="omkar", at=NOW)

    rerun = IssueCollector()
    rerun.add(make(ErrorCode.FX_RATE_MISSING, "USD 2025-12-31"))
    results = store.apply(rerun)

    assert [r.outcome for r in results] == [CarryOutcome.REOPENED]
    assert next(iter(rerun)).status is IssueStatus.OPEN
    assert rerun.is_blocked
    assert "still present" in results[0].explanation


def test_a_fix_that_worked_is_recorded_as_obsolete() -> None:
    first = IssueCollector()
    item = first.add(make(ErrorCode.FX_RATE_MISSING, "USD 2025-12-31"))
    store = ResolutionStore()
    store.mark_resolved(item, note="imported the December rates", user="omkar", at=NOW)

    results = store.apply(IssueCollector())

    assert [r.outcome for r in results] == [CarryOutcome.OBSOLETE]
    assert "no longer occurs" in results[0].explanation


def test_a_reworded_issue_keeps_the_decision_but_asks_for_confirmation() -> None:
    """Neither silently dropping nor silently carrying is acceptable.

    The user accepted a specific statement. When the statement changes, the
    honest move is to keep their decision so it is not lost, and tell them it
    was made against different wording.
    """
    first = IssueCollector()
    item = first.add(
        make(ErrorCode.DUPLICATE_TRANSACTION, "NVDA", "2 identical rows on 2025-07-08")
    )
    store = ResolutionStore()
    store.acknowledge(item, note="both trades are real", user="omkar", at=NOW)

    rerun = IssueCollector()
    rerun.add(
        make(ErrorCode.DUPLICATE_TRANSACTION, "NVDA", "3 identical rows on 2025-07-08")
    )
    results = store.apply(rerun)

    assert [r.outcome for r in results] == [CarryOutcome.NEEDS_RECONFIRMATION]
    assert results[0].needs_user_attention
    assert next(iter(rerun)).status is IssueStatus.ACKNOWLEDGED
    assert "2 identical rows" in results[0].explanation
    assert "3 identical rows" in results[0].explanation


def test_a_decision_is_keyed_on_the_condition_not_the_wording() -> None:
    """Which is why rewording does not orphan it."""
    a = make(ErrorCode.DUPLICATE_TRANSACTION, "NVDA", "2 identical rows")
    b = make(ErrorCode.DUPLICATE_TRANSACTION, "NVDA", "3 identical rows")

    assert a.issue_id != b.issue_id
    assert a.resolution_key == b.resolution_key


def test_decisions_round_trip_through_json(tmp_path) -> None:
    collector = IssueCollector()
    item = collector.add(make(ErrorCode.MARKET_PRICE_STALE, "AAPL"))
    store = ResolutionStore()
    store.acknowledge(item, note="weekend", user="omkar", at=NOW)

    path = tmp_path / "resolutions.json"
    store.save(path)
    reloaded = ResolutionStore.load(path)

    assert len(reloaded) == 1
    record = reloaded.get(item.resolution_key)
    assert record is not None
    assert record.note == "weekend"
    assert record.at == NOW


def test_loading_a_missing_file_is_not_an_error(tmp_path) -> None:
    assert len(ResolutionStore.load(tmp_path / "nothing.json")) == 0


def test_the_carry_summary_accounts_for_every_stored_decision() -> None:
    collector = IssueCollector()
    stale = collector.add(make(ErrorCode.MARKET_PRICE_STALE, "AAPL"))
    missing = collector.add(make(ErrorCode.FX_RATE_MISSING, "USD"))
    store = ResolutionStore()
    store.acknowledge(stale, note="weekend", user="u", at=NOW)
    store.mark_resolved(missing, note="imported", user="u", at=NOW)

    text = carry_summary(store.apply(collector))

    assert "2 recorded decision(s) considered" in text
    assert "CARRIED" in text
    assert "REOPENED" in text


def test_no_stored_decisions_says_so() -> None:
    assert "no previously recorded decisions" in carry_summary([])
