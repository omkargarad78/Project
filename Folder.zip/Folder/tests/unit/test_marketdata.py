"""Price snapshots, resolution policy, adjustment basis and corporate actions."""

from __future__ import annotations

from datetime import date
from decimal import Decimal

import pytest

from backend.app.core.errors import ErrorCode, ParseError, Severity
from backend.app.marketdata.dataset import MarketDataSnapshot, merge_snapshots
from backend.app.marketdata.models import (
    AdjustmentBasis,
    CorporateAction,
    CorporateActionType,
    PriceRecord,
)
from backend.app.marketdata.provider import (
    CsvPriceProvider,
    ManualPriceProvider,
    MissingPricePolicy,
    PricePolicy,
    PriceResolver,
    PriceStatus,
)
from backend.app.validation.issues import IssueCollector
from tests.fixtures.marketdata.builder import (
    AAPL_GAP_END,
    AAPL_GAP_START,
    SPLIT_EX_DATE,
    aapl_prices,
    adjusted_records,
    nvda_split_action,
    nvda_split_adjusted_prices,
    nvda_unadjusted_prices,
    price_csv,
    unadjusted_records,
    voo_prices,
)


@pytest.fixture(scope="module")
def unadjusted():
    return MarketDataSnapshot(
        unadjusted_records(),
        [nvda_split_action()],
        dataset_name="synthetic unadjusted",
        synthetic=True,
    )


@pytest.fixture(scope="module")
def adjusted():
    return MarketDataSnapshot(
        adjusted_records(),
        [nvda_split_action()],
        dataset_name="synthetic split-adjusted",
        synthetic=True,
    )


# --- the adjustment-basis trap -------------------------------------------


def test_the_two_fixtures_disagree_by_the_split_ratio(unadjusted, adjusted) -> None:
    """Confirms the fixture actually reproduces the hazard being guarded."""
    before = date(2025, 3, 3)

    raw = unadjusted.price("NVDA", before).price
    restated = adjusted.price("NVDA", before).price

    assert raw == restated * Decimal(4)
    # After the split the two series agree, which is why the error is invisible
    # unless the basis is tracked explicitly.
    after = date(2025, 9, 1)
    assert unadjusted.price("NVDA", after).price == adjusted.price("NVDA", after).price


def test_adjusted_prices_with_historical_quantities_is_refused(adjusted) -> None:
    issues = IssueCollector()
    resolver = PriceResolver(
        adjusted, policy=PricePolicy(quantities_are_adjusted=False)
    )

    assert not resolver.check_basis(issues)
    issue = issues.by_code(ErrorCode.PRICE_ADJUSTMENT_BASIS_MISMATCH)[0]
    assert issue.severity is Severity.ERROR
    assert "misstates every holding that had a split" in issue.message


def test_adjusted_prices_with_adjusted_quantities_is_allowed(adjusted) -> None:
    issues = IssueCollector()
    resolver = PriceResolver(
        adjusted, policy=PricePolicy(quantities_are_adjusted=True)
    )

    assert resolver.check_basis(issues)
    assert not issues.by_code(ErrorCode.PRICE_ADJUSTMENT_BASIS_MISMATCH)


def test_unadjusted_prices_with_historical_quantities_is_allowed(unadjusted) -> None:
    issues = IssueCollector()
    resolver = PriceResolver(
        unadjusted, policy=PricePolicy(quantities_are_adjusted=False)
    )

    assert resolver.check_basis(issues)


def test_unadjusted_prices_with_adjusted_quantities_is_refused(unadjusted) -> None:
    issues = IssueCollector()
    resolver = PriceResolver(
        unadjusted, policy=PricePolicy(quantities_are_adjusted=True)
    )

    assert not resolver.check_basis(issues)


def test_an_unstated_basis_is_an_error_not_an_assumption() -> None:
    """Defaulting UNKNOWN to UNADJUSTED would be the dangerous choice."""
    snapshot = MarketDataSnapshot(
        [
            PriceRecord(
                symbol="ABC",
                price_date=date(2025, 6, 2),
                price=Decimal("10"),
                currency="USD",
            )
        ],
        dataset_name="basis not stated",
    )
    issues = IssueCollector()

    assert snapshot.adjustment_basis is AdjustmentBasis.UNKNOWN
    assert not PriceResolver(snapshot).check_basis(issues)
    assert issues.by_code(ErrorCode.PRICE_ADJUSTMENT_BASIS_UNKNOWN)


def test_a_total_return_series_is_never_valuation_safe() -> None:
    snapshot = MarketDataSnapshot(
        [
            PriceRecord(
                symbol="ABC",
                price_date=date(2025, 6, 2),
                price=Decimal("10"),
                currency="USD",
                adjustment_basis=AdjustmentBasis.TOTAL_RETURN_ADJUSTED,
            )
        ],
        dataset_name="total return",
    )
    issues = IssueCollector()

    assert not PriceResolver(snapshot).check_basis(issues)
    issue = issues.by_code(ErrorCode.PRICE_ADJUSTMENT_BASIS_MISMATCH)[0]
    assert "reinvested dividends" in issue.message


def test_mixed_bases_in_one_snapshot_are_refused() -> None:
    snapshot = MarketDataSnapshot(
        [
            *nvda_unadjusted_prices()[:5],
            *[
                r.model_copy(update={"symbol": "OTHER"})
                for r in nvda_split_adjusted_prices()[:5]
            ],
        ],
        dataset_name="mixed",
    )
    issues = IssueCollector()

    assert snapshot.mixed_adjustment_bases
    assert not PriceResolver(snapshot).check_basis(issues)


# --- missing prices are never invented -----------------------------------


def test_a_weekend_uses_the_last_traded_price(unadjusted) -> None:
    saturday = date(2025, 3, 8)
    assert saturday.weekday() == 5

    resolution = PriceResolver(unadjusted).resolve("VOO", saturday)

    assert resolution.status is PriceStatus.CARRIED_FORWARD
    assert resolution.price_date == date(2025, 3, 7)
    assert resolution.staleness_days == 1
    assert resolution.usable


def test_a_carried_forward_price_is_labelled(unadjusted) -> None:
    issues = IssueCollector()

    PriceResolver(unadjusted).resolve("VOO", date(2025, 3, 8), issues=issues)

    issue = issues.by_code(ErrorCode.MARKET_PRICE_STALE)[0]
    assert issue.severity is Severity.WARNING
    assert "consistent with a weekend or exchange holiday" in issue.message


def test_a_weekday_gap_is_distinguished_from_a_closed_market(unadjusted) -> None:
    """AAPL is missing weekdays that other securities traded on."""
    issues = IssueCollector()
    inside_gap = date(2025, 8, 12)
    assert AAPL_GAP_START <= inside_gap <= AAPL_GAP_END

    resolution = PriceResolver(unadjusted).resolve("AAPL", inside_gap, issues=issues)

    assert resolution.status is PriceStatus.CARRIED_FORWARD
    issue = issues.by_code(ErrorCode.MARKET_PRICE_STALE)[0]
    assert "a price may be missing rather than unpublished" in issue.message


def test_a_gap_beyond_the_limit_is_missing_not_carried(unadjusted) -> None:
    issues = IssueCollector()
    # The last day of the AAPL gap is 7 days past the last real price.
    resolution = PriceResolver(unadjusted).resolve(
        "AAPL", date(2025, 8, 17), issues=issues
    )

    assert resolution.status is PriceStatus.MISSING
    assert not resolution.usable
    assert issues.by_code(ErrorCode.MARKET_PRICE_MISSING)
    assert "exceeds the 4-day carry-forward limit" in resolution.explanation
    assert "the data is incomplete rather than the market being closed" in (
        resolution.explanation
    )


def test_no_price_is_ever_interpolated(unadjusted) -> None:
    """A carried-forward price equals a real quotation, never an average."""
    inside_gap = date(2025, 8, 12)
    resolution = PriceResolver(unadjusted).resolve("AAPL", inside_gap)

    before = unadjusted.price("AAPL", date(2025, 8, 8)).price
    after = unadjusted.price("AAPL", date(2025, 8, 18)).price

    assert resolution.price == before
    assert resolution.price != (before + after) / 2


def test_strict_policy_refuses_to_carry_forward(unadjusted) -> None:
    issues = IssueCollector()
    resolver = PriceResolver(
        unadjusted, policy=PricePolicy(missing_policy=MissingPricePolicy.STRICT)
    )

    resolution = resolver.resolve("VOO", date(2025, 3, 8), issues=issues)

    assert resolution.status is PriceStatus.MISSING
    assert "does not allow carrying an earlier price forward" in resolution.explanation


def test_an_uncovered_symbol_says_so_plainly(unadjusted) -> None:
    issues = IssueCollector()

    resolution = PriceResolver(unadjusted).resolve(
        "TSLA", date(2025, 6, 2), issues=issues
    )

    assert resolution.status is PriceStatus.SYMBOL_NOT_COVERED
    assert "contains no prices at all for TSLA" in resolution.explanation
    assert issues.by_code(ErrorCode.MARKET_PRICE_MISSING)


def test_a_date_before_the_snapshot_starts_is_missing(unadjusted) -> None:
    resolution = PriceResolver(unadjusted).resolve("VOO", date(2024, 6, 2))

    assert resolution.status is PriceStatus.MISSING
    assert "snapshot starts after this valuation date" in resolution.explanation


# --- currency -------------------------------------------------------------


def test_a_currency_mismatch_is_refused(unadjusted) -> None:
    issues = IssueCollector()
    resolver = PriceResolver(unadjusted, expected_currency="INR")

    resolution = resolver.resolve("VOO", date(2025, 6, 2), issues=issues)

    assert resolution.status is PriceStatus.UNUSABLE
    assert not resolution.usable
    issue = issues.by_code(ErrorCode.MARKET_PRICE_CURRENCY_MISMATCH)[0]
    assert issue.severity is Severity.ERROR
    assert "misstate the value by the whole exchange rate" in issue.message


def test_a_matching_currency_resolves(unadjusted) -> None:
    resolver = PriceResolver(unadjusted, expected_currency="USD")

    assert resolver.resolve("VOO", date(2025, 6, 2)).usable


# --- the trading calendar -------------------------------------------------


def test_trading_days_are_inferred_from_coverage(unadjusted) -> None:
    assert unadjusted.is_trading_day(date(2025, 3, 7))  # Friday
    assert not unadjusted.is_trading_day(date(2025, 3, 8))  # Saturday
    assert not unadjusted.is_trading_day(date(2025, 3, 9))  # Sunday


def test_a_day_only_one_symbol_misses_is_still_a_trading_day(unadjusted) -> None:
    """AAPL's gap does not remove those days from the calendar."""
    inside_gap = date(2025, 8, 13)

    assert unadjusted.is_trading_day(inside_gap)
    assert unadjusted.price("AAPL", inside_gap) is None
    assert unadjusted.price("VOO", inside_gap) is not None


def test_coverage_counts_trading_day_gaps(unadjusted) -> None:
    aapl = unadjusted.coverage("AAPL")
    voo = unadjusted.coverage("VOO")

    assert aapl is not None and voo is not None
    assert aapl.gap_count == 5
    assert voo.gap_count == 0


def test_missing_symbols_are_reported(unadjusted) -> None:
    assert unadjusted.missing_symbols(["NVDA", "TSLA", "AMZN"]) == ["AMZN", "TSLA"]


# --- corporate actions ----------------------------------------------------


def test_a_split_multiplies_the_share_count(unadjusted) -> None:
    factor = unadjusted.quantity_factor(
        "NVDA", from_date=date(2025, 1, 2), to_date=date(2025, 12, 31)
    )

    assert factor == Decimal(4)
    assert unadjusted.adjust_quantity(
        "NVDA", Decimal("5.25"), from_date=date(2025, 1, 2), to_date=date(2025, 12, 31)
    ) == Decimal(21)


def test_chained_ratios_do_not_shed_fractional_shares() -> None:
    """Two 1-for-3 reverse splits must return exactly the original count."""
    snapshot = MarketDataSnapshot(
        voo_prices(),
        [
            CorporateAction(
                action_id=f"CA-{index}",
                action_type=CorporateActionType.REVERSE_SPLIT,
                symbol="ABC",
                ex_date=day,
                ratio_to=Decimal(1),
                ratio_from=Decimal(3),
            )
            for index, day in enumerate((date(2025, 3, 1), date(2025, 9, 1)))
        ],
        dataset_name="chained",
    )

    restated = snapshot.adjust_quantity(
        "ABC", Decimal(900), from_date=date(2025, 1, 1), to_date=date(2025, 12, 31)
    )

    assert restated == Decimal(100)


def test_an_action_after_the_window_does_not_apply(unadjusted) -> None:
    factor = unadjusted.quantity_factor(
        "NVDA", from_date=date(2025, 1, 2), to_date=date(2025, 6, 9)
    )

    assert factor == Decimal(1)


def test_the_ex_date_itself_applies(unadjusted) -> None:
    factor = unadjusted.quantity_factor(
        "NVDA", from_date=date(2025, 6, 9), to_date=SPLIT_EX_DATE
    )

    assert factor == Decimal(4)


def test_a_reverse_split_gives_an_exact_fraction() -> None:
    action = CorporateAction(
        action_id="CA-1",
        action_type=CorporateActionType.REVERSE_SPLIT,
        symbol="ABC",
        ex_date=date(2025, 5, 1),
        ratio_to=Decimal(1),
        ratio_from=Decimal(3),
    )

    # The ratio stays unevaluated, so 300 shares give exactly 100 rather than
    # 99.9999... A rounded factor would shed shares at every adjustment.
    assert action.apply_to_quantity(Decimal(300)) == Decimal(100)
    assert action.ratio() == (Decimal(1), Decimal(3))


def test_a_quantity_changing_action_must_state_its_ratio() -> None:
    from pydantic import ValidationError

    with pytest.raises(ValidationError) as excinfo:
        CorporateAction(
            action_id="CA-1",
            action_type=CorporateActionType.SPLIT,
            symbol="ABC",
            ex_date=date(2025, 5, 1),
        )

    assert "must state both sides of its ratio" in str(excinfo.value)


def test_a_ticker_change_needs_no_ratio() -> None:
    action = CorporateAction(
        action_id="CA-2",
        action_type=CorporateActionType.TICKER_CHANGE,
        symbol="FB",
        resulting_symbol="META",
        ex_date=date(2022, 6, 9),
    )

    assert action.quantity_factor() == Decimal(1)
    assert "FB became META" in action.describe()


def test_unverified_actions_are_listed() -> None:
    snapshot = MarketDataSnapshot(
        voo_prices(),
        [nvda_split_action(verified=False)],
        dataset_name="unverified action",
    )

    assert len(snapshot.unverified_actions()) == 1
    assert "[UNVERIFIED]" in snapshot.summary()


# --- snapshot immutability and identity ----------------------------------


def test_identical_data_yields_the_same_version_id() -> None:
    first = MarketDataSnapshot(voo_prices(), dataset_name="a")
    second = MarketDataSnapshot(voo_prices(), dataset_name="b")

    assert first.version_id == second.version_id


def test_different_prices_yield_a_different_version_id() -> None:
    records = voo_prices()
    first = MarketDataSnapshot(records, dataset_name="a")
    changed = [*records[:-1], records[-1].model_copy(update={"price": Decimal("1")})]
    second = MarketDataSnapshot(changed, dataset_name="a")

    assert first.version_id != second.version_id


def test_a_corporate_action_changes_the_version_id() -> None:
    without = MarketDataSnapshot(voo_prices(), dataset_name="a")
    with_action = MarketDataSnapshot(
        voo_prices(), [nvda_split_action()], dataset_name="a"
    )

    assert without.version_id != with_action.version_id


def test_conflicting_quotations_cannot_coexist() -> None:
    record = voo_prices()[0]

    with pytest.raises(ValueError, match="conflicting prices"):
        MarketDataSnapshot(
            [record, record.model_copy(update={"price": Decimal("999")})],
            dataset_name="conflict",
        )


def test_an_identical_duplicate_record_is_accepted() -> None:
    record = voo_prices()[0]

    snapshot = MarketDataSnapshot([record, record], dataset_name="dupe")

    assert snapshot.record_count == 1


def test_merging_preserves_both_sources() -> None:
    a = MarketDataSnapshot(voo_prices(), dataset_name="a", synthetic=True)
    b = MarketDataSnapshot(aapl_prices(), dataset_name="b", synthetic=True)

    merged = merge_snapshots([a, b], dataset_name="merged")

    assert set(merged.symbols()) == {"AAPL", "VOO"}
    assert merged.synthetic


def test_merging_conflicting_sources_fails_loudly() -> None:
    a = MarketDataSnapshot(voo_prices(), dataset_name="a")
    tweaked = [voo_prices()[0].model_copy(update={"price": Decimal("1")})]
    b = MarketDataSnapshot(tweaked, dataset_name="b")

    with pytest.raises(ValueError, match="conflicting prices"):
        merge_snapshots([a, b], dataset_name="merged")


# --- precision ------------------------------------------------------------


def test_a_float_price_is_rejected_at_the_boundary() -> None:
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        PriceRecord(
            symbol="ABC", price_date=date(2025, 6, 2), price=10.5, currency="USD"
        )


def test_a_negative_price_is_rejected() -> None:
    from pydantic import ValidationError

    with pytest.raises(ValidationError, match="not a valid quotation"):
        PriceRecord(
            symbol="ABC",
            price_date=date(2025, 6, 2),
            price=Decimal("-1"),
            currency="USD",
        )


def test_every_resolved_price_is_a_decimal(unadjusted) -> None:
    report = PriceResolver(unadjusted).resolve_series(
        "VOO", [date(2025, 6, d) for d in range(2, 7)]
    )

    for resolution in report.resolutions:
        assert isinstance(resolution.price, Decimal)


# --- providers ------------------------------------------------------------


def test_the_csv_provider_reads_a_price_file() -> None:
    content = price_csv(voo_prices()[:10])

    provider = CsvPriceProvider(
        content,
        file_name="prices.csv",
        adjustment_basis=AdjustmentBasis.UNADJUSTED,
        synthetic=True,
    )
    records = provider.fetch(["VOO"], date(2025, 1, 1), date(2025, 12, 31))

    assert len(records) == 10
    assert all(r.adjustment_basis is AdjustmentBasis.UNADJUSTED for r in records)


def test_the_csv_provider_requires_a_stated_currency() -> None:
    content = b"Date,Symbol,Close\n2025-06-02,VOO,470.00\n"

    with pytest.raises(ParseError) as excinfo:
        CsvPriceProvider(
            content,
            file_name="p.csv",
            adjustment_basis=AdjustmentBasis.UNADJUSTED,
        )

    assert "will not assume one" in str(excinfo.value)


def test_a_declared_default_currency_satisfies_the_requirement() -> None:
    content = b"Date,Symbol,Close\n2025-06-02,VOO,470.00\n"

    provider = CsvPriceProvider(
        content,
        file_name="p.csv",
        adjustment_basis=AdjustmentBasis.UNADJUSTED,
        default_currency="USD",
    )

    assert provider.all_records()[0].currency == "USD"


def test_the_csv_provider_rejects_an_ambiguous_date_layout() -> None:
    content = (
        b"Date,Symbol,Close,Currency\n"
        b"01/02/2025,VOO,470.00,USD\n"
        b"03/04/2025,VOO,471.00,USD\n"
    )

    with pytest.raises(ParseError) as excinfo:
        CsvPriceProvider(
            content, file_name="p.csv", adjustment_basis=AdjustmentBasis.UNADJUSTED
        )

    assert "ambiguous" in str(excinfo.value)


def test_the_csv_provider_names_its_missing_columns() -> None:
    with pytest.raises(ParseError) as excinfo:
        CsvPriceProvider(
            b"Foo,Bar\n1,2\n",
            file_name="p.csv",
            adjustment_basis=AdjustmentBasis.UNADJUSTED,
        )

    assert "date column and a symbol column" in str(excinfo.value)


def test_a_provider_snapshot_is_frozen_and_identifiable() -> None:
    provider = ManualPriceProvider(voo_prices()[:5])

    snapshot = provider.snapshot(["VOO"], date(2025, 1, 1), date(2025, 12, 31))

    assert snapshot.record_count == 5
    assert snapshot.version_id.startswith("MDS-")


def test_a_manual_price_carries_its_own_provenance() -> None:
    provider = ManualPriceProvider()
    provider.add(
        PriceRecord(
            symbol="ABC",
            price_date=date(2025, 6, 2),
            price=Decimal("12.34"),
            currency="USD",
            adjustment_basis=AdjustmentBasis.UNADJUSTED,
            note="closing price from the exchange website",
        )
    )

    record = provider.fetch(["ABC"], date(2025, 1, 1), date(2025, 12, 31))[0]

    assert record.note == "closing price from the exchange website"


# --- reporting ------------------------------------------------------------


def test_the_resolution_report_counts_each_outcome(unadjusted) -> None:
    days = [date(2025, 3, 7), date(2025, 3, 8), date(2025, 3, 9)]

    report = PriceResolver(unadjusted).resolve_series("VOO", days)

    assert "exact: 1" in report.summary()
    assert len(report.carried_forward) == 2


def test_the_snapshot_summary_flags_synthetic_data(unadjusted) -> None:
    summary = unadjusted.summary()

    assert "SYNTHETIC TEST DATA" in summary
    assert "adjustment basis: UNADJUSTED" in summary


def test_a_resolution_describes_itself_for_the_workpaper(unadjusted) -> None:
    resolution = PriceResolver(unadjusted).resolve("VOO", date(2025, 3, 8))

    described = resolution.describe()
    assert "carried forward 1 day(s) from 2025-03-07" in described
    assert "UNADJUSTED" in described
