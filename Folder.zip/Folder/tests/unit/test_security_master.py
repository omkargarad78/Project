"""Security master storage, date-scoped resolution and the no-fabrication rules."""

from __future__ import annotations

from dataclasses import replace
from datetime import date

import pytest
from pydantic import ValidationError

from backend.app.brokers.vested.parser import VestedParser
from backend.app.core.errors import ErrorCode, Severity
from backend.app.io.loader import load_source
from backend.app.securities.master import (
    SecurityMaster,
    SecurityOverride,
    load_default_master,
)
from backend.app.securities.models import (
    Address,
    AssetClass,
    Country,
    EntityNature,
    FieldProvenance,
    Security,
    TickerAssignment,
)
from backend.app.securities.resolver import (
    SecurityResolver,
    resolve_display_name_conflicts,
    symbols_needing_attention,
)
from backend.app.tax.rules.models import VerificationStatus
from tests.fixtures.vested.builder import build_vested_workbook

US = Country(name="United States of America", iso_alpha_2="US", iso_numeric="840")


def _security(
    security_id: str,
    symbol: str,
    *,
    name: str | None = "Example Corporation",
    exchange: str | None = "XNAS",
    valid_from: date | None = None,
    valid_to: date | None = None,
    country: Country | None = US,
    address: Address | None = None,
    nature: EntityNature = EntityNature.LISTED_COMPANY,
    confirmed: bool = False,
) -> Security:
    provenance = {}
    if confirmed:
        stamp = FieldProvenance(
            verification_status=VerificationStatus.VERIFIED, confirmed_by_user=True
        )
        provenance = {"legal_entity_name": stamp, "country": stamp, "nature": stamp}
    return Security(
        security_id=security_id,
        tickers=(
            TickerAssignment(
                symbol=symbol,
                exchange=exchange,
                valid_from=valid_from,
                valid_to=valid_to,
            ),
        ),
        legal_entity_name=name,
        country=country,
        address=address,
        nature=nature,
        asset_class=AssetClass.EQUITY,
        provenance=provenance,
        synthetic=True,
    )


# --- the core rule: a ticker is not an identity --------------------------


def test_an_unknown_ticker_does_not_resolve_to_anything() -> None:
    resolver = SecurityResolver(SecurityMaster())

    result = resolver.resolve("ZZZZ", on=date(2025, 6, 1))

    assert not result.resolved
    assert result.security is None
    assert "does not infer an entity from a ticker symbol" in result.explanation


def test_no_nearest_match_is_attempted() -> None:
    """A near-miss symbol resolves to nothing, not to the near neighbour."""
    master = SecurityMaster([_security("SEC-1", "NVDA")])
    resolver = SecurityResolver(master)

    assert not resolver.resolve("NVDAA", on=date(2025, 6, 1)).resolved
    assert not resolver.resolve("NVD", on=date(2025, 6, 1)).resolved
    assert resolver.resolve("NVDA", on=date(2025, 6, 1)).resolved


def test_the_ticker_is_never_used_as_the_entity_name() -> None:
    master = SecurityMaster([_security("SEC-1", "NVDA", name=None)])
    resolver = SecurityResolver(master)

    result = resolver.resolve("NVDA", on=date(2025, 6, 1))

    assert result.resolved
    assert result.security is not None
    assert result.security.legal_entity_name is None
    assert "legal_entity_name" in result.missing_fields()
    assert not result.reportable


def test_a_broker_display_name_is_never_promoted_to_the_legal_name() -> None:
    source = load_source(build_vested_workbook(), file_name="v.xlsx")
    ledger = VestedParser().parse(source).ledger
    # VOO ships with display names but a deliberately unset legal name.
    security = load_default_master().by_id("SEC-US-VOO")

    assert security is not None
    assert security.legal_entity_name is None
    assert "Vanguard S&P 500 ETF" in security.display_names
    assert any(t.security_name == "Vanguard S&P 500 ETF" for t in ledger.transactions)


# --- date-scoped resolution ----------------------------------------------


def test_a_symbol_resolves_as_at_a_date() -> None:
    master = SecurityMaster(
        [
            _security(
                "SEC-OLD", "XYZ", valid_from=date(2010, 1, 1), valid_to=date(2019, 12, 31)
            ),
            _security("SEC-NEW", "XYZ", valid_from=date(2021, 1, 1)),
        ]
    )
    resolver = SecurityResolver(master)

    assert resolver.resolve("XYZ", on=date(2015, 6, 1)).security.security_id == "SEC-OLD"
    assert resolver.resolve("XYZ", on=date(2023, 6, 1)).security.security_id == "SEC-NEW"


def test_a_symbol_in_a_gap_between_assignments_does_not_resolve() -> None:
    master = SecurityMaster(
        [
            _security(
                "SEC-OLD", "XYZ", valid_from=date(2010, 1, 1), valid_to=date(2019, 12, 31)
            ),
            _security("SEC-NEW", "XYZ", valid_from=date(2021, 1, 1)),
        ]
    )

    result = SecurityResolver(master).resolve("XYZ", on=date(2020, 6, 1))

    assert not result.resolved
    # The explanation says the symbol exists but not then, which is actionable.
    assert "was not assigned to any security on 2020-06-01" in result.explanation
    assert len(result.out_of_period_candidates) == 2


def test_a_ticker_change_is_one_security_under_two_symbols() -> None:
    master = load_default_master()

    before = SecurityResolver(master).resolve("FB", on=date(2021, 6, 1))
    after = SecurityResolver(master).resolve("META", on=date(2024, 6, 1))

    assert before.resolved and after.resolved
    assert before.security.security_id == after.security.security_id


def test_the_retired_symbol_does_not_resolve_after_the_change() -> None:
    result = SecurityResolver(load_default_master()).resolve("FB", on=date(2024, 6, 1))

    assert not result.resolved


def test_a_security_reports_the_symbol_it_traded_under_on_a_date() -> None:
    security = load_default_master().by_id("SEC-US-META")

    assert security is not None
    assert security.symbol_on(date(2021, 6, 1)) == "FB"
    assert security.symbol_on(date(2024, 6, 1)) == "META"


# --- ambiguity ------------------------------------------------------------


def test_two_candidates_is_an_error_not_a_tie_break() -> None:
    master = SecurityMaster(
        [
            _security("SEC-US", "ABC", name="ABC Corporation", exchange="XNAS"),
            _security(
                "SEC-GB",
                "ABC",
                name="ABC plc",
                exchange="XLON",
                country=Country(name="United Kingdom", iso_alpha_2="GB"),
            ),
        ]
    )

    result = SecurityResolver(master).resolve("ABC", on=date(2025, 6, 1))

    assert not result.resolved
    assert result.ambiguous
    assert len(result.ambiguous_candidates) == 2
    assert "will not choose between them" in result.explanation
    # Both candidates are named, so the user can pick.
    assert "ABC Corporation" in result.explanation
    assert "ABC plc" in result.explanation


def test_ambiguity_is_reported_under_its_own_code(vested_ledger) -> None:
    """An ambiguous symbol raises SECURITY_AMBIGUOUS, not SECURITY_UNRESOLVED.

    The two need different remediation: one is "add the security", the other
    is "tell us which of these two you hold".
    """
    from backend.app.validation.issues import IssueCollector

    issues = IssueCollector()
    master = SecurityMaster(
        [
            _security("SEC-US", "NVDA", name="NVIDIA Corporation", exchange="XNAS"),
            _security("SEC-XX", "NVDA", name="Unrelated Listing", exchange="XLON"),
        ]
    )

    report = SecurityResolver(master).resolve_ledger(vested_ledger, issues)

    assert report.ambiguous == ["NVDA"]
    ambiguous = issues.by_code(ErrorCode.SECURITY_AMBIGUOUS)
    assert len(ambiguous) == 1
    assert ambiguous[0].severity is Severity.ERROR
    assert not issues.by_code(ErrorCode.SECURITY_UNRESOLVED) or all(
        i.subject != "NVDA" for i in issues.by_code(ErrorCode.SECURITY_UNRESOLVED)
    )


def test_overlapping_assignments_within_one_security_are_rejected() -> None:
    with pytest.raises(ValidationError):
        Security(
            security_id="SEC-BAD",
            tickers=(
                TickerAssignment(symbol="ABC", valid_from=date(2010, 1, 1)),
                TickerAssignment(symbol="ABC", valid_from=date(2015, 1, 1)),
            ),
        )


def test_an_inverted_validity_range_is_rejected() -> None:
    with pytest.raises(ValidationError):
        Security(
            security_id="SEC-BAD",
            tickers=(
                TickerAssignment(
                    symbol="ABC", valid_from=date(2020, 1, 1), valid_to=date(2010, 1, 1)
                ),
            ),
        )


# --- missing detail is named, not filled ---------------------------------


def test_a_missing_address_warns_but_does_not_block() -> None:
    master = SecurityMaster([_security("SEC-1", "NVDA", confirmed=True)])
    source = load_source(build_vested_workbook(), file_name="v.xlsx")
    result = VestedParser().parse(source)
    issues_before = len(list(result.issues))

    SecurityResolver(master).resolve_ledger(result.ledger, result.issues)

    address_issues = result.issues.by_code(ErrorCode.SECURITY_ADDRESS_MISSING)
    assert address_issues
    assert all(i.severity is Severity.WARNING for i in address_issues)
    assert len(list(result.issues)) > issues_before


def test_a_missing_entity_name_blocks() -> None:
    master = SecurityMaster([_security("SEC-1", "NVDA", name=None)])
    source = load_source(build_vested_workbook(), file_name="v.xlsx")
    result = VestedParser().parse(source)

    SecurityResolver(master).resolve_ledger(result.ledger, result.issues)

    blocking = result.issues.by_code(ErrorCode.SECURITY_ENTITY_NAME_MISSING)
    assert blocking
    assert blocking[0].severity is Severity.ERROR
    assert "will not substitute the ticker symbol" in blocking[0].message


def test_a_missing_country_blocks() -> None:
    master = SecurityMaster([_security("SEC-1", "NVDA", country=None)])
    source = load_source(build_vested_workbook(), file_name="v.xlsx")
    result = VestedParser().parse(source)

    SecurityResolver(master).resolve_ledger(result.ledger, result.issues)

    assert result.issues.by_code(ErrorCode.SECURITY_COUNTRY_MISSING)


def test_an_undetermined_nature_warns() -> None:
    master = SecurityMaster(
        [_security("SEC-1", "NVDA", nature=EntityNature.UNDETERMINED)]
    )
    source = load_source(build_vested_workbook(), file_name="v.xlsx")
    result = VestedParser().parse(source)

    SecurityResolver(master).resolve_ledger(result.ledger, result.issues)

    nature_issues = result.issues.by_code(ErrorCode.SECURITY_NATURE_MISSING)
    assert nature_issues
    assert nature_issues[0].severity is Severity.WARNING


def test_an_empty_address_object_counts_as_missing() -> None:
    security = _security("SEC-1", "NVDA", address=Address(country_name="United States"))

    # A country line alone is not an address; the form wants a street address.
    assert not security.has_address
    assert "address" in security.missing_reporting_fields()


def test_a_partial_address_is_reported_as_partial() -> None:
    security = _security(
        "SEC-1",
        "NVDA",
        address=Address(line1="2788 San Tomas Expressway", city="Santa Clara"),
    )

    assert security.has_address
    assert not security.has_zip
    assert security.missing_reporting_fields() == ("zip_code",)


def test_reportable_means_the_blocking_fields_are_present() -> None:
    complete = _security(
        "SEC-1",
        "NVDA",
        address=Address(line1="Somewhere", zip_code="95051"),
        confirmed=True,
    )
    resolver = SecurityResolver(SecurityMaster([complete]))

    result = resolver.resolve("NVDA", on=date(2025, 6, 1))

    assert result.reportable
    assert result.missing_fields() == ()


# --- the shipped dataset is honest about itself --------------------------


def test_the_shipped_master_loads() -> None:
    master = load_default_master()

    assert len(master) >= 5
    assert master.source_hash


def test_every_shipped_record_is_marked_unconfirmed() -> None:
    """Nothing ships as verified, because nothing has been checked offline."""
    for security in load_default_master().all_securities():
        assert security.verification_status is VerificationStatus.REQUIRES_CONFIRMATION


def test_no_shipped_record_invents_an_address() -> None:
    for security in load_default_master().all_securities():
        assert security.address is None


def test_the_etf_has_no_legal_entity_name_and_says_why() -> None:
    voo = load_default_master().by_id("SEC-US-VOO")

    assert voo is not None
    assert voo.legal_entity_name is None
    assert any("deliberately left unset" in note for note in voo.notes)


def test_the_custodian_legal_name_is_not_guessed() -> None:
    institution = load_default_master().institution_for_broker("vested")

    assert institution is not None
    assert institution.legal_name is None
    assert "legal_name" in institution.missing_reporting_fields()
    assert any("will not guess" in note for note in institution.notes)


def test_itr_country_codes_are_absent_until_transcribed() -> None:
    for security in load_default_master().all_securities():
        if security.country is None:
            continue
        assert security.country.itr_code is None
        assert not security.country.has_filing_code


# --- user overrides ------------------------------------------------------


def test_a_user_override_supplies_what_the_dataset_lacks() -> None:
    master = SecurityMaster([_security("SEC-1", "NVDA", name=None)])

    master.apply_overrides(
        [
            SecurityOverride(
                security_id="SEC-1",
                legal_entity_name="NVIDIA Corporation",
                address=Address(line1="2788 San Tomas Expressway", zip_code="95051"),
                reference="Form 10-K cover page, FY2025",
                confirmed_on=date(2026, 1, 15),
            )
        ]
    )
    security = master.by_id("SEC-1")

    assert security is not None
    assert security.legal_entity_name == "NVIDIA Corporation"
    assert security.has_zip


def test_an_override_is_recorded_as_user_confirmed() -> None:
    master = SecurityMaster([_security("SEC-1", "NVDA", name=None)])

    master.apply_overrides(
        [
            SecurityOverride(
                security_id="SEC-1",
                legal_entity_name="NVIDIA Corporation",
                reference="Form 10-K cover page",
            )
        ]
    )
    security = master.by_id("SEC-1")

    assert security is not None
    assert security.is_confirmed("legal_entity_name")
    provenance = security.provenance_for("legal_entity_name")
    assert provenance is not None
    assert provenance.reference == "Form 10-K cover page"


def test_an_override_leaves_untouched_fields_alone() -> None:
    master = SecurityMaster([_security("SEC-1", "NVDA", name="Original Name")])

    master.apply_overrides(
        [SecurityOverride(security_id="SEC-1", isin="US67066G1040")]
    )
    security = master.by_id("SEC-1")

    assert security is not None
    assert security.legal_entity_name == "Original Name"
    assert security.isin == "US67066G1040"


def test_an_override_for_an_unknown_security_changes_nothing() -> None:
    master = SecurityMaster([_security("SEC-1", "NVDA")])

    changed = master.apply_overrides(
        [SecurityOverride(security_id="SEC-NOPE", legal_entity_name="Ghost Inc.")]
    )

    assert changed == []
    assert len(master) == 1


def test_the_symbol_index_survives_a_replacement() -> None:
    master = SecurityMaster([_security("SEC-1", "NVDA")])

    master.apply_overrides(
        [SecurityOverride(security_id="SEC-1", legal_entity_name="New Name")]
    )

    candidates = master.candidates("NVDA", on=date(2025, 6, 1))
    assert len(candidates) == 1
    assert candidates[0].security.legal_entity_name == "New Name"


# --- ledger resolution ---------------------------------------------------


@pytest.fixture(scope="module")
def vested_ledger():
    return VestedParser().parse(
        load_source(build_vested_workbook(), file_name="v.xlsx")
    ).ledger


def test_resolving_a_ledger_covers_every_symbol(vested_ledger) -> None:
    report = SecurityResolver(load_default_master()).resolve_ledger(vested_ledger)

    assert set(report.symbol_counts) == {"AAPL", "MSFT", "NVDA", "VOO"}
    assert report.resolved_count == 4


def test_symbols_are_resolved_as_at_their_first_use(vested_ledger) -> None:
    """A symbol retired mid-history still resolves for its own era."""
    master = SecurityMaster(
        [
            _security(
                "SEC-1", "NVDA", valid_from=date(2020, 1, 1), valid_to=date(2025, 3, 1)
            )
        ]
    )

    report = SecurityResolver(master).resolve_ledger(vested_ledger)

    # NVDA is first used on 2025-02-10, inside the assignment's range.
    assert report.resolutions["NVDA"].resolved


def test_an_as_of_date_overrides_first_use(vested_ledger) -> None:
    master = SecurityMaster(
        [
            _security(
                "SEC-1", "NVDA", valid_from=date(2020, 1, 1), valid_to=date(2025, 3, 1)
            )
        ]
    )

    report = SecurityResolver(master).resolve_ledger(
        vested_ledger, as_of=date(2025, 12, 31)
    )

    assert not report.resolutions["NVDA"].resolved


def test_unresolved_symbols_are_listed_with_their_transaction_count(
    vested_ledger,
) -> None:
    from backend.app.validation.issues import IssueCollector

    issues = IssueCollector()
    master = SecurityMaster([_security("SEC-1", "NVDA")])

    report = SecurityResolver(master).resolve_ledger(vested_ledger, issues)

    assert set(report.unresolved) == {"AAPL", "MSFT", "VOO"}
    unresolved = issues.by_code(ErrorCode.SECURITY_UNRESOLVED)
    assert any("transaction(s) use this symbol" in i.message for i in unresolved)


def test_ticker_aliases_are_grouped_as_one_interest() -> None:
    from backend.app.transactions.ledger import TransactionLedger

    master = load_default_master()
    ledger = TransactionLedger()
    # Build a ledger holding the same security under both symbols.
    source = load_source(build_vested_workbook(), file_name="v.xlsx")
    base = VestedParser().parse(source).ledger.ordered()[0]
    for symbol, day in (("FB", date(2021, 6, 1)), ("META", date(2024, 6, 1))):
        ledger.add(
            replace(
                base,
                transaction_id=f"T-{symbol}",
                ticker=symbol,
                transaction_date=day,
            )
        )

    report = SecurityResolver(master).resolve_ledger(ledger)

    assert report.aliases == {"SEC-US-META": ("FB", "META")}
    assert "reported as one line" in report.summary()


def test_symbols_needing_attention_lists_everything_blocking(vested_ledger) -> None:
    report = SecurityResolver(load_default_master()).resolve_ledger(vested_ledger)

    # VOO resolves but has no legal entity name, so it still needs attention.
    assert "VOO" in symbols_needing_attention(report)


def test_the_resolution_summary_is_printable(vested_ledger) -> None:
    report = SecurityResolver(load_default_master()).resolve_ledger(vested_ledger)

    summary = report.summary()
    assert "symbols in ledger: 4" in summary
    assert "missing for reporting" in summary


# --- display-name conflicts ----------------------------------------------


def test_a_display_name_conflict_is_flagged(vested_ledger) -> None:
    from backend.app.validation.issues import IssueCollector

    issues = IssueCollector()
    master = SecurityMaster(
        [_security("SEC-1", "NVDA", name="Some Entirely Different Company")]
    )

    conflicts = resolve_display_name_conflicts(master, vested_ledger, issues)

    assert conflicts == ["NVDA"]
    issue = issues.by_code(ErrorCode.SECURITY_NAME_MISMATCH)[0]
    assert issue.severity is Severity.WARNING
    assert "the report uses the master's legal name" in issue.message


def test_a_cosmetic_name_difference_is_not_flagged(vested_ledger) -> None:
    from backend.app.validation.issues import IssueCollector

    issues = IssueCollector()
    # The file says "NVIDIA Corporation"; a trailing-period difference is noise.
    master = SecurityMaster([_security("SEC-1", "NVDA", name="NVIDIA Corp.")])

    conflicts = resolve_display_name_conflicts(master, vested_ledger, issues)

    assert conflicts == []


def test_unconfirmed_identity_warns_without_blocking(vested_ledger) -> None:
    from backend.app.validation.issues import IssueCollector

    issues = IssueCollector()
    master = SecurityMaster([_security("SEC-1", "NVDA", confirmed=False)])

    SecurityResolver(master).resolve_ledger(vested_ledger, issues)

    unconfirmed = issues.by_code(ErrorCode.SECURITY_DETAILS_UNCONFIRMED)
    assert unconfirmed
    assert unconfirmed[0].severity is Severity.WARNING
    assert (
        "the legal entity name and country have not been confirmed"
        in unconfirmed[0].message
    )


def test_a_confirmed_record_produces_no_confirmation_warning(vested_ledger) -> None:
    from backend.app.validation.issues import IssueCollector

    issues = IssueCollector()
    master = SecurityMaster([_security("SEC-1", "NVDA", confirmed=True)])

    SecurityResolver(master).resolve_ledger(vested_ledger, issues)

    assert not issues.by_code(ErrorCode.SECURITY_DETAILS_UNCONFIRMED)
