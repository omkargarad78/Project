"""Lot reconstruction, allocation methods, corporate actions and reconciliation."""

from __future__ import annotations

from datetime import date
from decimal import Decimal

import pytest

from backend.app.brokers.vested.parser import VestedParser
from backend.app.core.errors import ErrorCode, Severity
from backend.app.io.loader import load_source
from backend.app.lots.allocation import describe_method, fifo, lifo
from backend.app.lots.engine import LotEngine, reconcile, reconciliation_summary
from backend.app.lots.models import LotOrigin
from backend.app.marketdata.dataset import MarketDataSnapshot
from backend.app.tax.rules.models import CalculationPolicy, LotAllocationMethod
from backend.app.validation.issues import IssueCollector
from tests.fixtures.marketdata.builder import nvda_split_action, unadjusted_records
from tests.fixtures.vested.builder import build_vested_workbook


@pytest.fixture(scope="module")
def parsed():
    return VestedParser().parse(
        load_source(build_vested_workbook(), file_name="v.xlsx")
    )


@pytest.fixture(scope="module")
def ledger(parsed):
    return parsed.ledger


@pytest.fixture()
def book(ledger):
    return LotEngine().build(ledger, IssueCollector())


def _engine(**kwargs):
    return LotEngine(**kwargs)


# --- basic reconstruction -------------------------------------------------


def test_each_acquisition_opens_its_own_lot(book) -> None:
    nvda = book.position("NVDA")

    assert nvda is not None
    purchases = [lot for lot in nvda.lots if lot.origin is LotOrigin.PURCHASE]
    # Three distinct buys plus the duplicated row, which is flagged elsewhere
    # rather than removed here.
    assert len(purchases) == 4
    assert [lot.acquisition_date for lot in purchases] == [
        date(2025, 2, 10),
        date(2025, 4, 15),
        date(2025, 7, 8),
        date(2025, 7, 8),
    ]


def test_a_lot_keeps_its_own_cost_and_date(book) -> None:
    nvda = book.position("NVDA")
    first = next(lot for lot in nvda.lots if lot.acquisition_date == date(2025, 2, 10))

    assert first.original_quantity == Decimal("10")
    assert first.total_cost_native == Decimal("1184.00000000")
    assert first.cost_per_share == Decimal("118.40000000")
    assert first.fees_native == Decimal("0.50000000")


def test_fractional_lots_survive(book) -> None:
    nvda = book.position("NVDA")
    fractional = next(
        lot for lot in nvda.lots if lot.acquisition_date == date(2025, 4, 15)
    )

    assert fractional.original_quantity == Decimal("5.25000000")


def test_a_deposit_creates_no_lot(book) -> None:
    """Cash funding is not an acquisition."""
    assert book.position("CASH") is None
    assert set(book.symbols()) == {"AAPL", "MSFT", "NVDA", "VOO"}


def test_a_fully_disposed_holding_still_has_a_position(book) -> None:
    """AAPL was bought and sold inside the period and must not vanish."""
    aapl = book.position("AAPL")

    assert aapl is not None
    assert aapl.quantity == Decimal(0)
    assert len(aapl.disposals) == 1
    assert aapl.timeline.held_at_any_time(date(2025, 1, 1), date(2025, 12, 31))


def test_the_end_of_day_and_intraday_quantities_are_different_questions(
    book,
) -> None:
    """A holding acquired and disposed of on one date was still held that date.

    MSFT's inferred opening lot is recorded on the date of the sale that
    proved it existed, and consumed by that same sale, so its closing balance
    for the day is nil while its intra-day balance is three. Peak value needs
    the second number; closing value needs the first.
    """
    timeline = book.position("MSFT").timeline
    sale_date = book.position("MSFT").disposals[0].disposal_date

    assert timeline.quantity_on(sale_date) == Decimal(0)
    assert timeline.peak_quantity_on(sale_date) == Decimal("3.00000000")


def test_intraday_and_end_of_day_agree_on_a_quiet_date(book) -> None:
    quiet = date(2025, 9, 15)
    timeline = book.position("NVDA").timeline

    assert timeline.peak_quantity_on(quiet) == timeline.quantity_on(quiet)


def test_closing_quantities_are_reported_per_symbol(book) -> None:
    quantities = book.closing_quantities()

    # 10 + 5.25 + 4 + 4 (duplicate) - 8 sold = 15.25
    assert quantities["NVDA"] == Decimal("15.25000000")
    assert quantities["AAPL"] == Decimal(0)
    assert quantities["VOO"] == Decimal("2.50000000")


# --- missing history: the MSFT case --------------------------------------


def test_a_sale_with_no_acquisition_infers_an_opening_lot(ledger) -> None:
    issues = IssueCollector()
    book = LotEngine().build(ledger, issues)
    msft = book.position("MSFT")

    assert msft is not None
    inferred = [lot for lot in msft.lots if lot.is_inferred]
    assert len(inferred) == 1
    assert inferred[0].original_quantity == Decimal("3")
    assert msft.quantity == Decimal(0)


def test_an_inferred_lot_has_no_date_and_no_cost(ledger) -> None:
    book = LotEngine().build(ledger, IssueCollector())
    inferred = next(lot for lot in book.position("MSFT").lots if lot.is_inferred)

    assert inferred.acquisition_date is None
    assert inferred.total_cost_native is None
    assert inferred.cost_per_share is None
    assert inferred.source_transaction_id is None
    assert "lower bound" in inferred.notes[0]


def test_missing_history_blocks_with_an_explanation(ledger) -> None:
    issues = IssueCollector()
    LotEngine().build(ledger, issues)

    issue = issues.by_code(ErrorCode.MISSING_HISTORICAL_DATA)[0]
    assert issue.severity is Severity.ERROR
    assert issue.subject == "MSFT"
    assert "has not been uploaded" in issue.message
    assert "cannot be computed" in issue.message


def test_the_acquisition_date_is_never_substituted(ledger) -> None:
    issues = IssueCollector()
    LotEngine().build(ledger, issues)

    issue = issues.by_code(ErrorCode.ACQUISITION_DATE_MISSING)[0]
    assert "will not substitute the reporting period's start" in issue.message


def test_a_disposal_from_an_inferred_lot_has_no_cost_basis(ledger) -> None:
    book = LotEngine().build(ledger, IssueCollector())
    disposal = book.position("MSFT").disposals[0]

    assert disposal.uses_inferred_lots
    assert disposal.cost_basis_native is None
    assert disposal.gain_native() is None
    # Proceeds are still known; only the basis is not.
    assert disposal.gross_proceeds_native == Decimal("1238.40000000")


def test_a_partly_unknown_basis_is_unknown_not_partial() -> None:
    """A basis missing one lot is not a smaller basis."""
    from backend.app.lots.models import Disposal, LotAllocation

    disposal = Disposal(
        transaction_id="T",
        symbol="ABC",
        disposal_date=date(2025, 6, 1),
        quantity=Decimal(10),
        currency="USD",
        gross_proceeds_native=Decimal(1000),
        fees_native=None,
        allocations=(
            LotAllocation(
                lot_id="L1",
                quantity=Decimal(5),
                acquisition_date=date(2024, 1, 1),
                cost_native=Decimal(400),
                acquisition_fees_native=None,
            ),
            LotAllocation(
                lot_id="L2",
                quantity=Decimal(5),
                acquisition_date=None,
                cost_native=None,
                acquisition_fees_native=None,
                from_inferred_lot=True,
            ),
        ),
    )

    assert disposal.cost_basis_native is None
    assert disposal.gain_native() is None


def test_inference_can_be_disabled(ledger) -> None:
    issues = IssueCollector()
    book = LotEngine(infer_opening_positions=False).build(ledger, issues)
    msft = book.position("MSFT")

    assert not msft.has_inferred_lots
    assert msft.disposals[0].unmatched_quantity == Decimal("3")
    issue = issues.by_code(ErrorCode.OVERSOLD_POSITION)[0]
    assert "inference is disabled" in issue.message


def test_a_complete_history_makes_a_shortfall_contradictory(ledger) -> None:
    issues = IssueCollector()
    LotEngine(assume_complete_history=True).build(ledger, issues)

    issue = issues.by_code(ErrorCode.OVERSOLD_POSITION)[0]
    assert "marked as a complete history" in issue.message
    assert "a quantity is wrong" in issue.message


def test_inferred_symbols_are_listed(ledger) -> None:
    book = LotEngine().build(ledger, IssueCollector())

    assert book.inferred_symbols == ("MSFT",)


# --- allocation methods ---------------------------------------------------


def _method(ledger, method):
    return LotEngine(
        policy=CalculationPolicy(lot_allocation_method=method)
    ).build(ledger, IssueCollector())


def test_fifo_consumes_the_oldest_lot_first(ledger) -> None:
    book = _method(ledger, LotAllocationMethod.FIFO)
    disposal = book.position("NVDA").disposals[0]

    first = disposal.allocations[0]
    assert first.acquisition_date == date(2025, 2, 10)
    assert first.quantity == Decimal("8")


def test_lifo_consumes_the_newest_lot_first(ledger) -> None:
    book = _method(ledger, LotAllocationMethod.LIFO)
    disposal = book.position("NVDA").disposals[0]

    assert disposal.allocations[0].acquisition_date == date(2025, 7, 8)


def test_the_method_changes_the_cost_basis(ledger) -> None:
    """Which is why it is a declared methodology, not an implementation detail."""
    first_in = _method(ledger, LotAllocationMethod.FIFO)
    last_in = _method(ledger, LotAllocationMethod.LIFO)

    fifo_basis = first_in.position("NVDA").disposals[0].cost_basis_native
    lifo_basis = last_in.position("NVDA").disposals[0].cost_basis_native

    assert fifo_basis is not None and lifo_basis is not None
    assert fifo_basis != lifo_basis
    # Later NVDA lots cost more, so LIFO gives the higher basis.
    assert lifo_basis > fifo_basis


def test_the_method_does_not_change_the_quantity_held(ledger) -> None:
    """Peak and closing value depend on quantity, which allocation cannot move."""
    quantities = {
        method: _method(ledger, method).closing_quantities()
        for method in (
            LotAllocationMethod.FIFO,
            LotAllocationMethod.LIFO,
            LotAllocationMethod.HIGHEST_COST_FIRST,
            LotAllocationMethod.LOWEST_COST_FIRST,
        )
    }

    assert len({tuple(sorted(q.items())) for q in quantities.values()}) == 1


def test_highest_cost_first_picks_the_dearest_lot(ledger) -> None:
    book = _method(ledger, LotAllocationMethod.HIGHEST_COST_FIRST)
    disposal = book.position("NVDA").disposals[0]

    # The 2025-07-08 lots cost 141.20 per share, the dearest available.
    assert disposal.allocations[0].acquisition_date == date(2025, 7, 8)


def test_lowest_cost_first_picks_the_cheapest_lot(ledger) -> None:
    book = _method(ledger, LotAllocationMethod.LOWEST_COST_FIRST)
    disposal = book.position("NVDA").disposals[0]

    assert disposal.allocations[0].acquisition_date == date(2025, 2, 10)


def test_broker_specified_falls_back_and_says_so(ledger) -> None:
    issues = IssueCollector()
    LotEngine(
        policy=CalculationPolicy(
            lot_allocation_method=LotAllocationMethod.BROKER_SPECIFIED
        )
    ).build(ledger, issues)

    issue = issues.by_code(ErrorCode.SECONDARY_SOURCE_USED)[0]
    assert "does not identify which lots the broker assigned" in issue.message
    assert "first in, first out was applied" in issue.message.lower()


def test_cost_methods_put_unknown_cost_lots_last() -> None:
    from backend.app.lots.allocation import highest_cost_first, lowest_cost_first
    from backend.app.lots.models import Lot

    known = Lot(
        lot_id="L1",
        symbol="ABC",
        origin=LotOrigin.PURCHASE,
        acquisition_date=date(2025, 1, 1),
        original_quantity=Decimal(10),
        remaining_quantity=Decimal(10),
        currency="USD",
        total_cost_native=Decimal(100),
    )
    unknown = Lot(
        lot_id="L2",
        symbol="ABC",
        origin=LotOrigin.INFERRED_OPENING,
        acquisition_date=None,
        original_quantity=Decimal(10),
        remaining_quantity=Decimal(10),
        currency="USD",
        total_cost_native=None,
    )

    for strategy in (highest_cost_first, lowest_cost_first):
        assert strategy([unknown, known])[0].lot_id == "L1"


def test_fifo_treats_an_inferred_lot_as_the_oldest() -> None:
    from backend.app.lots.models import Lot

    documented = Lot(
        lot_id="L1",
        symbol="ABC",
        origin=LotOrigin.PURCHASE,
        acquisition_date=date(2025, 1, 1),
        original_quantity=Decimal(10),
        remaining_quantity=Decimal(10),
        currency="USD",
    )
    inferred = Lot(
        lot_id="L0",
        symbol="ABC",
        origin=LotOrigin.INFERRED_OPENING,
        acquisition_date=None,
        original_quantity=Decimal(5),
        remaining_quantity=Decimal(5),
        currency="USD",
    )

    # An inferred lot exists because the shares predate everything in the file.
    assert fifo([documented, inferred])[0].lot_id == "L0"
    assert lifo([documented, inferred])[0].lot_id == "L1"


def test_every_method_has_a_description() -> None:
    for method in LotAllocationMethod:
        assert describe_method(method)


def test_allocation_is_deterministic(ledger) -> None:
    first = _method(ledger, LotAllocationMethod.FIFO)
    second = _method(ledger, LotAllocationMethod.FIFO)

    def signature(book):
        return [
            (a.lot_id, a.quantity, a.cost_native)
            for d in book.all_disposals()
            for a in d.allocations
        ]

    assert signature(first) == signature(second)


# --- corporate actions ----------------------------------------------------


@pytest.fixture(scope="module")
def split_snapshot():
    return MarketDataSnapshot(
        unadjusted_records(),
        [nvda_split_action()],
        dataset_name="with split",
        synthetic=True,
    )


def test_a_split_restates_every_open_lot(ledger, split_snapshot) -> None:
    book = LotEngine(market_data=split_snapshot).build(ledger, IssueCollector())
    nvda = book.position("NVDA")

    # 10 + 5.25 held at the 10 June ex-date, quadrupled, then 4 more bought in
    # July on the new basis, less the 8 sold in September.
    assert nvda.quantity == Decimal("61.00000000")


def test_a_split_leaves_the_total_cost_unchanged(ledger, split_snapshot) -> None:
    without = LotEngine().build(ledger, IssueCollector()).position("NVDA")
    with_split = (
        LotEngine(market_data=split_snapshot)
        .build(ledger, IssueCollector())
        .position("NVDA")
    )

    first_before = next(
        lot for lot in without.lots if lot.acquisition_date == date(2025, 2, 10)
    )
    first_after = next(
        lot for lot in with_split.lots if lot.acquisition_date == date(2025, 2, 10)
    )

    assert first_after.original_quantity == first_before.original_quantity * 4
    assert first_after.total_cost_native == first_before.total_cost_native
    assert first_after.cost_per_share == first_before.cost_per_share / 4


def test_a_split_is_recorded_on_the_lot_for_audit(ledger, split_snapshot) -> None:
    book = LotEngine(market_data=split_snapshot).build(ledger, IssueCollector())
    lot = next(
        lot
        for lot in book.position("NVDA").lots
        if lot.acquisition_date == date(2025, 2, 10)
    )

    assert len(lot.adjustments) == 1
    adjustment = lot.adjustments[0]
    assert adjustment.ex_date == date(2025, 6, 10)
    assert adjustment.quantity_before == Decimal("10")
    assert adjustment.quantity_after == Decimal("40")


def test_a_lot_acquired_after_the_ex_date_is_not_restated(
    ledger, split_snapshot
) -> None:
    book = LotEngine(market_data=split_snapshot).build(ledger, IssueCollector())
    later = next(
        lot
        for lot in book.position("NVDA").lots
        if lot.acquisition_date == date(2025, 7, 8)
    )

    assert later.adjustments == ()
    assert later.original_quantity == Decimal("4")


def test_the_split_appears_in_the_timeline(ledger, split_snapshot) -> None:
    book = LotEngine(market_data=split_snapshot).build(ledger, IssueCollector())
    timeline = book.timeline("NVDA")

    assert timeline.quantity_on(date(2025, 6, 9)) == Decimal("15.25000000")
    assert timeline.quantity_on(date(2025, 6, 10)) == Decimal("61.00000000")


def test_an_unverified_action_warns(ledger) -> None:
    snapshot = MarketDataSnapshot(
        unadjusted_records(),
        [nvda_split_action(verified=False)],
        dataset_name="unverified",
    )
    issues = IssueCollector()

    LotEngine(market_data=snapshot).build(ledger, issues)

    issue = issues.by_code(ErrorCode.CORPORATE_ACTION_UNVERIFIED)[0]
    assert issue.severity is Severity.WARNING
    assert "changing the holding from" in issue.message


def test_a_security_with_no_action_is_untouched(ledger, split_snapshot) -> None:
    book = LotEngine(market_data=split_snapshot).build(ledger, IssueCollector())

    assert book.position("VOO").quantity == Decimal("2.50000000")


# --- the holding timeline -------------------------------------------------


def test_the_timeline_answers_quantity_on_any_date(book) -> None:
    timeline = book.timeline("NVDA")

    assert timeline.quantity_on(date(2025, 1, 1)) == Decimal(0)
    assert timeline.quantity_on(date(2025, 2, 10)) == Decimal("10")
    assert timeline.quantity_on(date(2025, 3, 1)) == Decimal("10")
    assert timeline.quantity_on(date(2025, 4, 15)) == Decimal("15.25000000")
    assert timeline.quantity_on(date(2025, 12, 31)) == Decimal("15.25000000")


def test_the_timeline_reports_the_first_acquisition(book) -> None:
    assert book.timeline("NVDA").first_acquisition_date() == date(2025, 2, 10)
    assert book.timeline("VOO").first_acquisition_date() == date(2025, 1, 20)


def test_an_inferred_holding_has_no_first_acquisition_date_on_record(ledger) -> None:
    book = LotEngine().build(ledger, IssueCollector())
    inferred = next(lot for lot in book.position("MSFT").lots if lot.is_inferred)

    # The timeline records when the inference was made, which is the disposal
    # date, and that is emphatically not an acquisition date.
    assert inferred.acquisition_date is None


def test_held_at_any_time_catches_a_holding_closed_mid_period(book) -> None:
    aapl = book.timeline("AAPL")

    assert aapl.closing_quantity() == Decimal(0)
    assert aapl.held_at_any_time(date(2025, 1, 1), date(2025, 12, 31))


def test_change_dates_are_where_a_peak_calculation_must_look(book) -> None:
    dates = book.timeline("NVDA").change_dates(date(2025, 1, 1), date(2025, 12, 31))

    assert dates == [
        date(2025, 2, 10),
        date(2025, 4, 15),
        date(2025, 7, 8),
        date(2025, 9, 22),
    ]


# --- reconciliation -------------------------------------------------------


def test_reconciliation_passes_when_the_broker_agrees(ledger) -> None:
    issues = IssueCollector()
    book = LotEngine().build(ledger, issues)

    results = reconcile(
        book,
        {"NVDA": Decimal("15.25"), "VOO": Decimal("2.5"), "AAPL": Decimal(0)},
        issues,
    )

    assert all(r.matches for r in results)
    assert not issues.by_code(ErrorCode.LOT_RECONCILIATION_FAILED)


def test_reconciliation_flags_a_difference(ledger) -> None:
    issues = IssueCollector()
    book = LotEngine().build(ledger, issues)

    results = reconcile(book, {"NVDA": Decimal("11.25")}, issues)

    nvda = next(r for r in results if r.symbol == "NVDA")
    assert not nvda.matches
    assert nvda.difference == Decimal("4.00000000")
    issue = issues.by_code(ErrorCode.LOT_RECONCILIATION_FAILED)[0]
    assert "a missing statement" in issue.message
    assert "duplicated row" in issue.message


def test_reconciliation_quantifies_every_defect_in_the_file(ledger) -> None:
    """The NVDA break decomposes into the two known defects, exactly.

    The broker states 11.15 shares. The ledger produces 15.25, a break of
    4.10: four shares from the duplicated buy row, and 0.1 from the
    "Fractional Share Liquidation" the parser could not map and therefore did
    not apply. Both were already flagged upstream, and reconciliation
    independently confirms how much each one moved the holding — which is the
    check earning its place rather than restating what parsing found.
    """
    with_everything = LotEngine().build(ledger, IssueCollector())
    without_duplicate = LotEngine().build(
        VestedParser()
        .parse(
            load_source(
                build_vested_workbook(include_duplicate=False), file_name="clean.xlsx"
            )
        )
        .ledger,
        IssueCollector(),
    )

    def nvda_break(book):
        return next(
            r for r in reconcile(book, {"NVDA": Decimal("11.15")}) if r.symbol == "NVDA"
        ).difference

    total_break = nvda_break(with_everything)
    residual = nvda_break(without_duplicate)

    assert total_break == Decimal("4.10000000")
    # Removing the duplicated buy accounts for exactly four of those shares.
    assert total_break - residual == Decimal("4")
    # What remains is the unmapped 0.1-share liquidation.
    assert residual == Decimal("0.10000000")


def test_a_symbol_the_broker_does_not_list_is_not_a_failure(ledger) -> None:
    book = LotEngine().build(ledger, IssueCollector())

    results = reconcile(book, {})

    assert all(r.matches for r in results)
    assert all("nothing to reconcile against" in r.explanation for r in results)


def test_a_symbol_the_broker_lists_but_we_never_saw_is_flagged(ledger) -> None:
    issues = IssueCollector()
    book = LotEngine().build(ledger, issues)

    results = reconcile(book, {"TSLA": Decimal(5)}, issues)

    tsla = next(r for r in results if r.symbol == "TSLA")
    assert not tsla.matches
    assert tsla.computed_quantity == Decimal(0)


def test_reconciliation_uses_the_brokers_own_stated_holdings(parsed) -> None:
    """End to end against the figures on the fixture's account sheet."""
    parser = VestedParser()
    source = load_source(build_vested_workbook(), file_name="v.xlsx")
    sections = parser.parse_sections(source)
    stated = parser.broker_closing_holdings(sections)

    book = LotEngine().build(parsed.ledger, IssueCollector())
    results = reconcile(book, stated)

    voo = next(r for r in results if r.symbol == "VOO")
    assert voo.matches
    # NVDA does not, because the fixture deliberately contains a duplicate row.
    nvda = next(r for r in results if r.symbol == "NVDA")
    assert not nvda.matches


def test_the_reconciliation_summary_is_printable(ledger) -> None:
    book = LotEngine().build(ledger, IssueCollector())

    text = reconciliation_summary(reconcile(book, {"NVDA": Decimal("15.25")}))

    assert "holdings reconciliation" in text
    assert "[ok ]" in text


# --- precision and determinism -------------------------------------------


def test_no_lot_quantity_or_cost_is_a_float(book) -> None:
    for lot in book.all_lots():
        assert isinstance(lot.original_quantity, Decimal)
        assert isinstance(lot.remaining_quantity, Decimal)
        assert lot.total_cost_native is None or isinstance(
            lot.total_cost_native, Decimal
        )


def test_consuming_more_than_a_lot_holds_is_refused() -> None:
    from backend.app.lots.models import Lot

    lot = Lot(
        lot_id="L1",
        symbol="ABC",
        origin=LotOrigin.PURCHASE,
        acquisition_date=date(2025, 1, 1),
        original_quantity=Decimal(10),
        remaining_quantity=Decimal(10),
        currency="USD",
    )

    with pytest.raises(ValueError, match="cannot consume"):
        lot.consume(Decimal(11))


def test_the_book_summary_is_printable(book) -> None:
    summary = book.summary()

    assert "allocation method: FIFO" in summary
    assert "first in, first out" in summary.lower()
    assert "NVDA" in summary


def test_rebuilding_produces_identical_lot_ids(ledger) -> None:
    first = LotEngine().build(ledger, IssueCollector())
    second = LotEngine().build(ledger, IssueCollector())

    assert [lot.lot_id for lot in first.all_lots()] == [
        lot.lot_id for lot in second.all_lots()
    ]
