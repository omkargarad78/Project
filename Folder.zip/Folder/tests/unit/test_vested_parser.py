"""Vested detection, schema validation, normalization and the parser report."""

from __future__ import annotations

from datetime import date
from decimal import Decimal

import pytest

from backend.app.brokers.base import Section, classify_activity
from backend.app.brokers.registry import BrokerRegistry, default_registry
from backend.app.brokers.vested.mapping import VESTED_ACTIVITY_TABLE
from backend.app.brokers.vested.parser import VestedParser
from backend.app.core.errors import ErrorCode, ParseError, Severity
from backend.app.io.loader import load_source
from backend.app.transactions.models import TransactionType
from tests.fixtures.vested.builder import (
    build_renamed_column_workbook,
    build_unrecognised_workbook,
    build_vested_workbook,
)


@pytest.fixture(scope="module")
def vested_source():
    return load_source(build_vested_workbook(), file_name="vested_statement.xlsx")


@pytest.fixture(scope="module")
def parse_result(vested_source):
    return VestedParser().parse(vested_source)


# --- detection ------------------------------------------------------------


def test_vested_export_is_detected_structurally(vested_source) -> None:
    detection = VestedParser().detect(vested_source)

    assert detection.matched
    assert detection.confidence > 0
    assert detection.matched_sections[Section.TRADES] == "Trades"
    assert detection.matched_sections[Section.INCOME] == "Income"


def test_detection_ignores_the_filename() -> None:
    """A file is recognised by structure, not by a name the uploader controls."""
    source = load_source(build_vested_workbook(), file_name="totally_unrelated.xlsx")

    assert VestedParser().detect(source).matched


def test_an_unrelated_workbook_is_not_claimed() -> None:
    source = load_source(build_unrecognised_workbook(), file_name="other.xlsx")

    assert not VestedParser().detect(source).matched


def test_registry_refuses_to_guess_for_an_unknown_format() -> None:
    source = load_source(build_unrecognised_workbook(), file_name="other.xlsx")

    with pytest.raises(ParseError) as excinfo:
        default_registry().identify(source)

    assert excinfo.value.code is ErrorCode.BROKER_UNIDENTIFIED
    assert "does not attempt a best-effort parse" in str(excinfo.value)
    # The message names what it actually saw, so the user can act on it.
    assert "Readme" in str(excinfo.value)


def test_registry_identifies_vested(vested_source) -> None:
    identification = default_registry().identify(vested_source)

    assert identification.parser.broker_id == "vested"
    assert not identification.ambiguous


def test_registry_rejects_a_duplicate_broker_registration() -> None:
    registry = BrokerRegistry([VestedParser()])

    with pytest.raises(ValueError):
        registry.register(VestedParser())


def test_unknown_broker_id_is_reported_with_the_available_list() -> None:
    with pytest.raises(ParseError) as excinfo:
        default_registry().get("interactive_brokers")

    assert "Registered brokers: vested" in str(excinfo.value)


# --- schema validation ---------------------------------------------------


def test_schema_validation_passes_on_the_expected_layout(vested_source) -> None:
    validation = VestedParser().validate(vested_source)

    assert validation.ok, validation.failure_message()
    assert not validation.missing_sections


def test_a_missing_required_column_stops_the_parse() -> None:
    source = load_source(build_renamed_column_workbook(), file_name="changed.xlsx")

    with pytest.raises(ParseError) as excinfo:
        VestedParser().parse(source)

    assert excinfo.value.code is ErrorCode.BROKER_FORMAT_CHANGED
    assert "Ticker" in str(excinfo.value)


def test_header_row_is_found_below_the_broker_title_block(vested_source) -> None:
    parsed = VestedParser().parse_trades(vested_source)

    assert parsed is not None
    # Three preamble rows precede the header in the fixture.
    assert parsed.table.header.row_index == 3
    assert "Transaction Date" in parsed.table.headers


def test_spreadsheet_date_cells_are_treated_as_unambiguous(vested_source) -> None:
    validation = VestedParser().validate(vested_source)

    resolution = validation.date_formats["TRADES.transaction_date"]
    assert resolution.resolved
    assert "serial" in (resolution.label or "")


# --- normalization: types ------------------------------------------------


def test_activity_labels_map_to_canonical_types(parse_result) -> None:
    counts = parse_result.report.type_counts

    assert counts["BUY"] == 6  # 5 distinct buys plus the duplicated row
    assert counts["SELL"] == 3
    assert counts["DIVIDEND"] == 4
    assert counts["INTEREST"] == 1
    assert counts["WITHHOLDING_TAX"] == 4
    assert counts["DEPOSIT"] == 2
    assert counts["WITHDRAWAL"] == 1
    assert counts["FEE"] == 1
    assert counts["UNKNOWN"] == 1


def test_longest_label_match_wins_over_a_substring() -> None:
    """"Sell To Cover" must not be classified as a plain "Sell"."""
    assert classify_activity("Sell To Cover", VESTED_ACTIVITY_TABLE) is TransactionType.RSU_SALE
    assert classify_activity("Sell", VESTED_ACTIVITY_TABLE) is TransactionType.SELL


def test_unmapped_activity_becomes_unknown_and_is_flagged(parse_result) -> None:
    unknown = [
        t for t in parse_result.ledger.transactions
        if t.transaction_type is TransactionType.UNKNOWN
    ]

    assert len(unknown) == 1
    assert unknown[0].raw_activity == "Fractional Share Liquidation"
    # It carries a quantity, so it blocks rather than merely warns.
    issue = parse_result.issues.by_code(ErrorCode.UNSUPPORTED_TRANSACTION)[0]
    assert issue.severity is Severity.ERROR
    assert "holdings cannot be reconstructed" in issue.message


def test_unknown_activity_affects_nothing_until_mapped(parse_result) -> None:
    unknown = next(
        t for t in parse_result.ledger.transactions
        if t.transaction_type is TransactionType.UNKNOWN
    )

    assert unknown.signed_quantity == Decimal(0)
    assert unknown.cash_delta_native == Decimal(0)


# --- normalization: gross income vs withholding tax ----------------------


def test_gross_dividend_and_withholding_tax_are_separate_transactions(parse_result) -> None:
    """The $10 / $1 / $9 case from the specification."""
    dividends = [
        t for t in parse_result.ledger.transactions
        if t.transaction_type is TransactionType.DIVIDEND
        and t.transaction_date == date(2025, 3, 20)
    ]
    taxes = [
        t for t in parse_result.ledger.transactions
        if t.transaction_type is TransactionType.WITHHOLDING_TAX
        and t.transaction_date == date(2025, 3, 20)
    ]

    assert len(dividends) == 1
    assert len(taxes) == 1
    dividend = dividends[0]
    # Gross is 10, not the 9 that hit the cash account.
    assert dividend.gross_amount_native == Decimal("10.00000000")
    assert dividend.taxes_native == Decimal("1.00000000")
    assert dividend.net_amount_native == Decimal("9.00000000")
    assert taxes[0].gross_amount_native == Decimal("1.00000000")


def test_both_transactions_trace_to_the_same_source_row(parse_result) -> None:
    same_row = [
        t for t in parse_result.ledger.transactions
        if t.source_sheet == "Income" and t.transaction_date == date(2025, 3, 20)
    ]

    assert len(same_row) == 2
    assert len({t.source_row for t in same_row}) == 1
    assert len({t.transaction_id for t in same_row}) == 2
    assert len({t.raw_data_hash for t in same_row}) == 1


def test_dividend_cash_effect_is_net_of_withholding(parse_result) -> None:
    dividend = next(
        t for t in parse_result.ledger.transactions
        if t.transaction_type is TransactionType.DIVIDEND
        and t.transaction_date == date(2025, 3, 20)
    )

    assert dividend.cash_delta_native == Decimal("9.00000000")


def test_zero_tax_income_emits_no_withholding_transaction(parse_result) -> None:
    interest_rows = [
        t for t in parse_result.ledger.transactions
        if t.source_sheet == "Income" and t.transaction_date == date(2025, 12, 5)
    ]

    assert len(interest_rows) == 1
    assert interest_rows[0].transaction_type is TransactionType.INTEREST


# --- normalization: cash vs securities -----------------------------------


def test_a_deposit_is_cash_and_not_an_acquisition(parse_result) -> None:
    deposit = next(
        t for t in parse_result.ledger.transactions
        if t.transaction_type is TransactionType.DEPOSIT
    )

    assert deposit.behaviour.is_acquisition is False
    assert deposit.signed_quantity == Decimal(0)
    assert deposit.cash_delta_native > 0
    assert deposit.ticker is None


def test_a_sale_is_a_disposal_not_an_acquisition(parse_result) -> None:
    sale = next(
        t for t in parse_result.ledger.transactions
        if t.transaction_type is TransactionType.SELL
    )

    assert sale.behaviour.is_disposal
    assert not sale.behaviour.is_acquisition
    assert sale.signed_quantity < 0


def test_buy_reduces_cash_and_increases_quantity(parse_result) -> None:
    buy = next(
        t for t in parse_result.ledger.transactions
        if t.transaction_type is TransactionType.BUY
        and t.transaction_date == date(2025, 2, 10)
    )

    assert buy.signed_quantity == Decimal("10")
    # 1184.00 plus 0.50 commission leaves the account.
    assert buy.cash_delta_native == Decimal("-1184.50000000")


# --- normalization: precision and magnitudes -----------------------------


def test_fractional_shares_are_preserved(parse_result) -> None:
    fractional = next(
        t for t in parse_result.ledger.transactions
        if t.transaction_date == date(2025, 4, 15)
        and t.transaction_type is TransactionType.BUY
    )

    assert fractional.quantity == Decimal("5.25000000")
    assert fractional.price_native == Decimal("132.75000000")


def test_amounts_are_stored_as_non_negative_magnitudes(parse_result) -> None:
    for transaction in parse_result.ledger.transactions:
        for value in (
            transaction.quantity,
            transaction.gross_amount_native,
            transaction.fees_native,
            transaction.taxes_native,
        ):
            assert value is None or value >= 0


def test_no_value_is_a_float(parse_result) -> None:
    for transaction in parse_result.ledger.transactions:
        for value in (
            transaction.quantity,
            transaction.price_native,
            transaction.gross_amount_native,
            transaction.fees_native,
            transaction.taxes_native,
            transaction.net_amount_native,
        ):
            assert value is None or isinstance(value, Decimal)


# --- provenance -----------------------------------------------------------


def test_every_transaction_traces_to_its_source_row(parse_result, vested_source) -> None:
    for transaction in parse_result.ledger.transactions:
        assert transaction.source_file_id == vested_source.source_file_id
        assert transaction.source_sheet
        assert transaction.source_row > 0
        assert transaction.raw_data_hash
        assert transaction.parser_version == "vested-parser-1.0.0"
        raw = parse_result.ledger.raw_for(transaction)
        assert raw is not None


def test_the_raw_broker_row_is_preserved_verbatim(parse_result) -> None:
    transaction = next(
        t for t in parse_result.ledger.transactions
        if t.transaction_date == date(2025, 2, 10)
        and t.transaction_type is TransactionType.BUY
    )
    raw = parse_result.ledger.raw_for(transaction)

    assert raw is not None
    # The stored price is the file's exact digit string, not a reformatted one.
    assert raw.values["Price Per Share"] == "118.4000"
    assert raw.values["Company Name"] == "NVIDIA Corporation"


def test_broker_display_name_is_kept_but_not_treated_as_the_legal_entity(
    parse_result,
) -> None:
    voo = next(t for t in parse_result.ledger.transactions if t.ticker == "VOO")

    assert voo.security_name == "Vanguard S&P 500 ETF"
    # Resolution of the legal entity is the security master's job, not the
    # parser's; the parser must not promote a display name to an entity name.
    assert voo.security_identifier is None


def test_transaction_ids_are_deterministic_across_reparses(vested_source) -> None:
    first = VestedParser().parse(vested_source)
    second = VestedParser().parse(vested_source)

    assert [t.transaction_id for t in first.ledger.ordered()] == [
        t.transaction_id for t in second.ledger.ordered()
    ]


def test_reparsing_identical_bytes_yields_an_identical_ledger() -> None:
    content = build_vested_workbook()
    first = VestedParser().parse(load_source(content, file_name="a.xlsx"))
    second = VestedParser().parse(load_source(content, file_name="b.xlsx"))

    def signature(result):
        return [
            (
                t.transaction_id,
                t.transaction_type,
                t.transaction_date,
                t.ticker,
                t.quantity,
                t.gross_amount_native,
            )
            for t in result.ledger.ordered()
        ]

    assert signature(first) == signature(second)


# --- duplicates -----------------------------------------------------------


def test_duplicate_rows_are_flagged_not_removed(parse_result) -> None:
    duplicates = parse_result.ledger.find_duplicates()

    assert len(duplicates) == 1
    group = duplicates[0]
    assert len(group.transaction_ids) == 2
    assert "broker transaction identifier" in group.reason
    # Both rows survive in the ledger.
    assert len([t for t in parse_result.ledger.transactions if t.broker_transaction_id == "T-1003"]) == 2


def test_duplicate_issue_explains_why_they_look_alike(parse_result) -> None:
    issue = parse_result.issues.by_code(ErrorCode.DUPLICATE_TRANSACTION)[0]

    assert issue.severity is Severity.WARNING
    assert "2025-07-08" in issue.message
    assert "until you confirm" in issue.message


def test_a_workbook_without_the_duplicate_reports_none() -> None:
    source = load_source(
        build_vested_workbook(include_duplicate=False), file_name="clean.xlsx"
    )

    result = VestedParser().parse(source)

    assert result.ledger.find_duplicates() == []


# --- broker-stated balances ----------------------------------------------


def test_broker_closing_balances_are_read_for_reconciliation(vested_source) -> None:
    parser = VestedParser()
    sections = parser.parse_sections(vested_source)

    assert parser.broker_closing_cash(sections) == Decimal("4699.47")
    assert parser.broker_closing_holdings(sections) == {
        "NVDA": Decimal("11.15000000"),
        "VOO": Decimal("2.50000000"),
    }


def test_account_sheet_rows_are_not_transactions(parse_result) -> None:
    assert not any(
        t.source_sheet == "My Account" for t in parse_result.ledger.transactions
    )


# --- the parser report ---------------------------------------------------


def test_parser_report_describes_every_section(parse_result) -> None:
    report = parse_result.report

    assert report.broker_id == "vested"
    assert set(report.sheet_names) == {"Trades", "Income", "Transfers", "My Account"}
    sections = {s.section: s for s in report.sections}
    assert sections[Section.TRADES].row_count == 10
    assert "Ticker" in sections[Section.TRADES].column_names
    assert "Transaction Date" in sections[Section.TRADES].date_columns
    assert sections[Section.TRADES].detected_currencies == ("USD",)


def test_parser_report_lists_transaction_categories(parse_result) -> None:
    trades = next(s for s in parse_result.report.sections if s.section is Section.TRADES)

    assert trades.transaction_categories["Buy"] == 6
    assert trades.transaction_categories["Sell"] == 3
    assert trades.unknown_categories == {"Fractional Share Liquidation": 1}


def test_parser_report_names_unmapped_activity_labels(parse_result) -> None:
    assert parse_result.report.unknown_activity_labels == ("Fractional Share Liquidation",)
    assert any("retained as UNKNOWN" in w for w in parse_result.report.warnings)


def test_parser_report_counts_duplicates(parse_result) -> None:
    assert parse_result.report.duplicate_candidate_count == 1


def test_parser_report_is_printable(parse_result) -> None:
    summary = parse_result.report.summary()

    assert "Vested Finance" in summary
    assert "normalized transactions" in summary
    assert "UNKNOWN categories" in summary


# --- ledger-level helpers ------------------------------------------------


def test_ledger_ordering_is_deterministic_and_puts_buys_before_sells(parse_result) -> None:
    ordered = parse_result.ledger.ordered()
    dates = [t.transaction_date for t in ordered]

    assert dates == sorted(dates)


def test_ledger_exposes_tickers_and_currencies(parse_result) -> None:
    assert parse_result.ledger.tickers() == ["AAPL", "MSFT", "NVDA", "VOO"]
    assert parse_result.ledger.currencies() == ["USD"]
    assert parse_result.ledger.accounts() == ["VST-0001"]


def test_ledger_date_range_covers_the_reporting_year(parse_result) -> None:
    span = parse_result.ledger.date_range()

    assert span == (date(2025, 1, 15), date(2025, 12, 5))
