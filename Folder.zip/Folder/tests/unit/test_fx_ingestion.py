"""Ingestion, dataset immutability and rate-selection behaviour."""

from __future__ import annotations

from datetime import UTC, date, datetime
from decimal import Decimal

import pytest

from backend.app.core.errors import ErrorCode, ParseError, RateError
from backend.app.fx.ingestion import (
    ColumnMapping,
    SbiRateIngestor,
    coverage_report,
    detect_date_format,
    profile_csv,
)
from backend.app.fx.models import RateStatus
from backend.app.fx.store import (
    FxDatasetStore,
    create_override_record,
    dataset_from_dict,
    dataset_to_dict,
    merge_overrides,
)
from backend.app.tax.rules.models import FxRateType, SourceTier

SYNTHETIC_SOURCE = {
    "source_id": "TEST-SYNTHETIC-FX",
    "source_name": "synthetic test fixture (not SBI data)",
    "source_tier": SourceTier.COMMUNITY_DATASET,
    "dataset_name": "synthetic-ttbr",
}


def _ingestor(**overrides: object) -> SbiRateIngestor:
    return SbiRateIngestor(**{**SYNTHETIC_SOURCE, **overrides})  # type: ignore[arg-type]


# --- profiling ------------------------------------------------------------


def test_profile_detects_columns_and_iso_dates(fx_fixture_2025_bytes: bytes) -> None:
    profile = profile_csv(fx_fixture_2025_bytes, file_name="synthetic_ttbr_2025.csv")

    assert profile.detected_date_column == "Date"
    assert profile.detected_currency_column == "Currency"
    assert profile.detected_rate_columns[FxRateType.TT_BUY] == "TT Buying Rate"
    # The selling-rate column must be recognised as a *different* rate type,
    # not folded into the buying rate.
    assert profile.detected_rate_columns[FxRateType.TT_SELL] == "TT Selling Rate"
    assert profile.detected_date_format == "%Y-%m-%d"
    assert profile.row_count > 700


def test_profile_rejects_a_file_with_no_header() -> None:
    with pytest.raises(ParseError) as excinfo:
        profile_csv(b"", file_name="empty.csv")
    assert excinfo.value.code is ErrorCode.SOURCE_FILE_CORRUPT


def test_profile_warns_when_no_tt_buying_column_is_present() -> None:
    content = b"Date,Currency,TT Selling Rate\n2025-01-02,USD,83.5\n"
    profile = profile_csv(content, file_name="selling_only.csv")

    assert not profile.has_tt_buying
    assert any("BUYING" in warning for warning in profile.warnings)


# --- date handling --------------------------------------------------------


def test_ambiguous_day_month_order_is_refused() -> None:
    fmt, label, warnings = detect_date_format(["01/02/2025", "03/04/2025"])

    assert fmt is None
    assert label is None
    assert any("ambiguous" in w for w in warnings)


def test_unambiguous_day_first_dates_are_detected() -> None:
    fmt, _label, warnings = detect_date_format(["25/02/2025", "13/04/2025"])

    assert fmt == "%d/%m/%Y"
    assert warnings == []


def test_mapping_creation_fails_on_ambiguous_dates() -> None:
    content = b"Date,Currency,TT Buying Rate\n01/02/2025,USD,83.5\n03/04/2025,USD,83.6\n"
    profile = profile_csv(content, file_name="ambiguous.csv")

    with pytest.raises(ParseError) as excinfo:
        _ingestor().ingest_csv(content, file_name="ambiguous.csv", version="t1")
    assert excinfo.value.code is ErrorCode.SCHEMA_VALIDATION_FAILED
    assert profile.detected_date_format is None


# --- rate type safety -----------------------------------------------------


def test_only_the_requested_rate_type_is_imported(fx_fixture_2025_bytes: bytes) -> None:
    report = _ingestor().ingest_csv(
        fx_fixture_2025_bytes,
        file_name="synthetic_ttbr_2025.csv",
        version="t1",
        rate_types=[FxRateType.TT_BUY],
        currencies=["USD"],
    )

    assert report.dataset is not None
    assert report.dataset.rate_types() == [FxRateType.TT_BUY]
    assert report.dataset.currencies() == ["USD"]


def test_unlabelled_rate_column_cannot_be_imported_as_tt_buying() -> None:
    content = b"Date,Currency,Rate\n2025-01-02,USD,83.5\n"

    with pytest.raises(ParseError) as excinfo:
        _ingestor().ingest_csv(content, file_name="unlabelled.csv", version="t1")

    assert excinfo.value.code is ErrorCode.SCHEMA_VALIDATION_FAILED
    assert "never inferred" in str(excinfo.value)


def test_explicit_mapping_allows_an_unlabelled_column() -> None:
    content = b"Date,Currency,Rate\n2025-01-02,USD,83.5\n"
    mapping = ColumnMapping(
        date_column="Date",
        currency_column="Currency",
        rate_columns={FxRateType.TT_BUY: "Rate"},
        date_format="%Y-%m-%d",
    )

    report = _ingestor().ingest_csv(
        content, file_name="unlabelled.csv", version="t1", mapping=mapping
    )

    assert report.records_imported == 1
    assert report.dataset is not None
    assert report.dataset.records[0].value == Decimal("83.50000000")


# --- record content and provenance ----------------------------------------


def test_imported_records_carry_full_provenance(fx_fixture_2025_bytes: bytes) -> None:
    report = _ingestor().ingest_csv(
        fx_fixture_2025_bytes,
        file_name="synthetic_ttbr_2025.csv",
        version="t1",
        rate_types=[FxRateType.TT_BUY],
        currencies=["USD"],
    )
    assert report.dataset is not None
    record = report.dataset.records[0]

    assert record.source_id == "TEST-SYNTHETIC-FX"
    assert record.source_tier is SourceTier.COMMUNITY_DATASET
    # A non-statutory source is never imported as VERIFIED.
    assert record.status is RateStatus.UNVERIFIED
    assert record.source_document_hash == report.profile.file_hash
    assert record.retrieved_at is not None
    assert record.unit == 1


def test_non_positive_rates_are_rejected_per_row() -> None:
    content = (
        b"Date,Currency,TT Buying Rate\n"
        b"2025-01-02,USD,83.5\n"
        b"2025-01-03,USD,0\n"
        b"2025-01-06,USD,-5\n"
    )
    report = _ingestor().ingest_csv(content, file_name="bad_rates.csv", version="t1")

    assert report.records_imported == 1
    assert len(report.row_errors) == 2


def test_secondary_tier_import_warns_about_authority(fx_fixture_2025_bytes: bytes) -> None:
    report = _ingestor().ingest_csv(
        fx_fixture_2025_bytes, file_name="f.csv", version="t1", currencies=["USD"]
    )

    assert any("must not be presented as an official SBI publication" in w for w in report.warnings)


def test_statutory_tier_import_is_marked_verified() -> None:
    content = b"Date,Currency,TT Buying Rate\n2025-01-02,USD,83.5\n"
    report = _ingestor(source_tier=SourceTier.STATUTORY).ingest_csv(
        content, file_name="sbi.csv", version="t1"
    )

    assert report.dataset is not None
    assert report.dataset.records[0].status is RateStatus.VERIFIED


# --- dataset versioning ---------------------------------------------------


def test_dataset_content_hash_is_order_independent() -> None:
    forward = b"Date,Currency,TT Buying Rate\n2025-01-02,USD,83.5\n2025-01-03,USD,83.6\n"
    reverse = b"Date,Currency,TT Buying Rate\n2025-01-03,USD,83.6\n2025-01-02,USD,83.5\n"

    first = _ingestor().ingest_csv(forward, file_name="a.csv", version="t1").dataset
    second = _ingestor().ingest_csv(reverse, file_name="a.csv", version="t1").dataset

    assert first is not None and second is not None
    assert first.content_hash == second.content_hash
    assert first.dataset_id == second.dataset_id


def test_dataset_round_trips_through_serialization(fx_dataset_usd_2025) -> None:
    restored = dataset_from_dict(dataset_to_dict(fx_dataset_usd_2025))

    assert restored.content_hash == fx_dataset_usd_2025.content_hash
    assert len(restored.records) == len(fx_dataset_usd_2025.records)
    assert restored.records[0].value == fx_dataset_usd_2025.records[0].value


def test_tampered_dataset_file_fails_its_integrity_check(fx_dataset_usd_2025) -> None:
    payload = dataset_to_dict(fx_dataset_usd_2025)
    payload["records"][0]["value"] = "999.0000"

    with pytest.raises(RateError) as excinfo:
        dataset_from_dict(payload)

    assert "integrity check" in str(excinfo.value)


def test_saving_the_same_version_twice_is_idempotent(tmp_path, fx_dataset_usd_2025) -> None:
    store = FxDatasetStore(tmp_path)

    first = store.save(fx_dataset_usd_2025)
    second = store.save(fx_dataset_usd_2025)

    assert first == second
    assert len(store.list()) == 1


def test_rewriting_a_version_with_different_content_is_refused(
    tmp_path, fx_dataset_usd_2025
) -> None:
    store = FxDatasetStore(tmp_path)
    store.save(fx_dataset_usd_2025)

    extra = create_override_record(
        currency="USD",
        rate_date=date(2025, 1, 1),
        rate_type=FxRateType.TT_BUY,
        value="83.1234",
        user="tester",
        reason="test",
        evidence="test evidence",
    )
    mutated = fx_dataset_usd_2025.with_records(
        [extra],
        version=fx_dataset_usd_2025.version,
        imported_at=datetime.now(UTC),
    )

    with pytest.raises(RateError) as excinfo:
        store.save(mutated)

    assert "immutable" in str(excinfo.value)


def test_store_rejects_path_traversal_in_names(tmp_path, fx_dataset_usd_2025) -> None:
    store = FxDatasetStore(tmp_path)
    hostile = fx_dataset_usd_2025.with_records(
        [],
        version="../../escaped",
        imported_at=datetime.now(UTC),
    )

    path = store.save(hostile)

    assert tmp_path in path.parents
    assert ".." not in path.name


# --- overrides ------------------------------------------------------------


def test_override_requires_reason_user_and_evidence() -> None:
    kwargs = {
        "currency": "USD",
        "rate_date": date(2025, 12, 31),
        "rate_type": FxRateType.TT_BUY,
        "value": "84.0000",
        "user": "ca@example.com",
        "reason": "SBI rate sheet for 31 Dec 2025",
        "evidence": "SBI forex card rate sheet, 31 Dec 2025",
    }
    assert create_override_record(**kwargs).status is RateStatus.MANUAL_OVERRIDE

    for missing in ("reason", "evidence", "user"):
        with pytest.raises(ValueError):
            create_override_record(**{**kwargs, missing: "  "})


def test_merged_overrides_do_not_remove_the_original_record(fx_dataset_usd_2025) -> None:
    existing = fx_dataset_usd_2025.records[0]
    override = create_override_record(
        currency=existing.currency,
        rate_date=existing.rate_date,
        rate_type=existing.rate_type,
        value="99.9999",
        user="ca@example.com",
        reason="corrected against the SBI rate sheet",
        evidence="SBI rate sheet reference",
        original_value=existing.value,
    )

    merged = merge_overrides(fx_dataset_usd_2025, [override], version="t2")

    same_key = [
        r
        for r in merged.records
        if r.rate_date == existing.rate_date and r.currency == existing.currency
    ]
    assert len(same_key) == 2
    assert merged.version == "t2"
    assert merged.dataset_id != fx_dataset_usd_2025.dataset_id


# --- coverage -------------------------------------------------------------


def test_coverage_report_separates_weekday_and_weekend_gaps(fx_dataset_usd_2025) -> None:
    report = coverage_report(
        fx_dataset_usd_2025,
        currency="USD",
        rate_type=FxRateType.TT_BUY,
        start=date(2025, 1, 1),
        end=date(2025, 12, 31),
    )

    assert report["days_in_period"] == 365
    # The fixture deliberately omits a handful of weekdays.
    assert report["weekday_gaps"] == 5
    assert report["weekend_gaps"] == 104
