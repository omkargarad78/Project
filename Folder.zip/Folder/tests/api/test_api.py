"""The HTTP surface, end to end.

The tests that matter most here are the isolation ones. A calculation bug
produces a wrong number that a reviewer can catch; an authorisation bug
hands one person's tax records to another and nobody finds out.
"""

from __future__ import annotations

from tests.api.conftest import PASSWORD, Account
from tests.fixtures.vested.builder import build_vested_workbook


def upload(account: Account, workspace_id: str, name: str = "v.xlsx"):  # noqa: ANN201
    return account.client.post(
        f"/api/v1/workspaces/{workspace_id}/files",
        headers=account.headers,
        files={"file": (name, build_vested_workbook(), "application/vnd.ms-excel")},
    )


# --- health ---------------------------------------------------------------


def test_health_checks_its_dependencies(client, api) -> None:
    body = client.get(f"{api}/health").json()

    assert body["status"] == "ok"
    assert body["database"] == "ok"
    assert body["storage"] == "ok"


def test_responses_carry_the_hardening_headers(client, api) -> None:
    headers = client.get(f"{api}/health").headers

    assert headers["X-Content-Type-Options"] == "nosniff"
    assert headers["X-Frame-Options"] == "DENY"


# --- authentication -------------------------------------------------------


def test_registering_returns_a_usable_token(alice) -> None:
    assert alice.get("/auth/me").json()["email"] == "alice@example.com"


def test_an_endpoint_refuses_an_anonymous_caller(client, api) -> None:
    response = client.get(f"{api}/workspaces")

    assert response.status_code == 401
    assert response.json()["code"] == "NOT_AUTHENTICATED"


def test_a_forged_token_is_refused(client, api) -> None:
    response = client.get(
        f"{api}/workspaces", headers={"Authorization": "Bearer not.a.token"}
    )

    assert response.status_code == 401
    assert response.json()["code"] == "INVALID_TOKEN"


def test_a_short_password_is_refused(client, api) -> None:
    response = client.post(
        f"{api}/auth/register", json={"email": "b@example.com", "password": "short"}
    )

    assert response.status_code == 422


def test_a_wrong_password_says_nothing_about_which_half_was_wrong(
    client, api, alice
) -> None:
    """The same response for a bad password and an unknown account.

    Anything else turns this endpoint into a way to find out who files
    their taxes here.
    """
    wrong = client.post(
        f"{api}/auth/login",
        json={"email": alice.email, "password": "the-wrong-password"},
    )
    unknown = client.post(
        f"{api}/auth/login",
        json={"email": "nobody@example.com", "password": "the-wrong-password"},
    )

    assert wrong.status_code == unknown.status_code == 401
    assert wrong.json() == unknown.json()


def test_registering_a_taken_email_does_not_confirm_it_is_taken(
    client, api, alice
) -> None:
    response = client.post(
        f"{api}/auth/register", json={"email": alice.email, "password": PASSWORD}
    )

    assert response.status_code == 409
    assert "cannot be registered" in response.json()["message"]
    assert alice.email not in response.json()["message"]


def test_signing_in_works_after_registering(client, api, alice) -> None:
    response = client.post(
        f"{api}/auth/login", json={"email": alice.email, "password": PASSWORD}
    )

    assert response.status_code == 200
    assert response.json()["access_token"]


# --- isolation ------------------------------------------------------------


def test_another_user_cannot_see_your_workspace(alice, mallory) -> None:
    workspace = alice.new_workspace()

    assert mallory.get(f"/workspaces/{workspace}").status_code == 404
    assert mallory.get("/workspaces").json() == []


def test_another_user_cannot_upload_into_your_workspace(alice, mallory) -> None:
    workspace = alice.new_workspace()

    assert upload(mallory, workspace).status_code == 404


def test_a_workspace_you_cannot_see_returns_404_not_403(alice, mallory) -> None:
    """403 would confirm the workspace exists, which is the leak."""
    workspace = alice.new_workspace()
    response = mallory.get(f"/workspaces/{workspace}/files")

    assert response.status_code == 404
    assert response.json()["code"] == "NOT_FOUND"


def test_a_viewer_can_read_but_not_write(alice, mallory) -> None:
    workspace = alice.new_workspace()
    assert (
        alice.post(
            f"/workspaces/{workspace}/members",
            json={"email": mallory.email, "role": "VIEWER"},
        ).status_code
        == 201
    )

    assert mallory.get(f"/workspaces/{workspace}").status_code == 200
    denied = upload(mallory, workspace)
    assert denied.status_code == 403
    assert denied.json()["code"] == "INSUFFICIENT_ROLE"


def test_a_viewer_cannot_invite_anyone(alice, mallory, client) -> None:
    workspace = alice.new_workspace()
    alice.post(
        f"/workspaces/{workspace}/members",
        json={"email": mallory.email, "role": "VIEWER"},
    )
    third = Account(client, "carol@example.com")

    response = mallory.post(
        f"/workspaces/{workspace}/members",
        json={"email": third.email, "role": "EDITOR"},
    )
    assert response.status_code == 403


def test_the_last_owner_cannot_be_removed(alice) -> None:
    """A workspace with no owner can never be administered again."""
    workspace = alice.new_workspace()
    members = alice.get(f"/workspaces/{workspace}/members").json()
    owner = next(m for m in members if m["role"] == "OWNER")

    response = alice.delete(f"/workspaces/{workspace}/members/{owner['user_id']}")
    assert response.status_code == 409
    assert response.json()["code"] == "LAST_OWNER"


# --- uploads --------------------------------------------------------------


def test_uploading_a_statement_records_its_hash(alice) -> None:
    workspace = alice.new_workspace()
    body = upload(alice, workspace).json()

    assert body["file_hash"].startswith("sha256:")
    assert body["size_bytes"] > 0


def test_the_same_bytes_uploaded_twice_are_one_file(alice) -> None:
    """Every derived identifier is built from this hash."""
    workspace = alice.new_workspace()
    first = upload(alice, workspace).json()
    second = upload(alice, workspace).json()

    assert first["id"] == second["id"]
    assert len(alice.get(f"/workspaces/{workspace}/files").json()) == 1


def test_a_file_that_is_not_a_spreadsheet_is_refused(alice) -> None:
    workspace = alice.new_workspace()
    response = alice.client.post(
        f"/api/v1/workspaces/{workspace}/files",
        headers=alice.headers,
        files={"file": ("payload.exe", b"MZ\x90\x00not a workbook", "application/exe")},
    )

    assert response.status_code == 400
    assert response.json()["code"]


def test_deleting_a_file_keeps_the_row(alice) -> None:
    """Completed runs cite it and have to stay explainable."""
    workspace = alice.new_workspace()
    file_id = upload(alice, workspace).json()["id"]

    assert alice.delete(f"/workspaces/{workspace}/files/{file_id}").status_code == 204
    assert alice.get(f"/workspaces/{workspace}/files").json() == []


# --- runs -----------------------------------------------------------------


def test_a_run_needs_a_statement_first(alice) -> None:
    workspace = alice.new_workspace()
    response = alice.post(
        f"/workspaces/{workspace}/runs",
        json={"fx_dataset": "sbi-ttbr-usd-2025", "fx_dataset_version": "1.0.0"},
    )

    assert response.status_code == 409
    assert response.json()["code"] == "NO_SOURCE_FILES"


def test_an_unknown_policy_value_is_refused_not_defaulted(alice) -> None:
    """Silently using FIFO when LIFO was asked for is a wrong answer."""
    workspace = alice.new_workspace()
    upload(alice, workspace)
    response = alice.post(
        f"/workspaces/{workspace}/runs",
        json={
            "fx_dataset": "sbi-ttbr-usd-2025",
            "fx_dataset_version": "1.0.0",
            "lot_allocation_method": "WHATEVER_IS_CHEAPEST",
        },
    )

    assert response.status_code == 422
    assert response.json()["code"] == "UNKNOWN_POLICY_VALUE"


def test_a_run_that_fails_is_recorded_rather_than_lost(alice) -> None:
    """A missing price dataset stops the run; the run still says so."""
    workspace = alice.new_workspace()
    upload(alice, workspace)
    run = alice.post(
        f"/workspaces/{workspace}/runs",
        json={
            "fx_dataset": "sbi-ttbr-usd-2025",
            "fx_dataset_version": "1.0.0",
            "market_dataset": "no-such-dataset",
        },
    ).json()

    detail = alice.get(f"/workspaces/{workspace}/runs/{run['id']}").json()
    assert detail["status"] == "FAILED"
    assert detail["error_message"]
    # The message names the failure class, never a path or a stack trace.
    assert "Traceback" not in detail["error_message"]


def test_a_failed_run_is_still_listed(alice) -> None:
    workspace = alice.new_workspace()
    upload(alice, workspace)
    alice.post(
        f"/workspaces/{workspace}/runs",
        json={
            "fx_dataset": "sbi-ttbr-usd-2025",
            "fx_dataset_version": "1.0.0",
            "market_dataset": "no-such-dataset",
        },
    )

    assert len(alice.get(f"/workspaces/{workspace}/runs").json()) == 1


def test_a_run_pins_every_input_version(alice) -> None:
    """Without these, a figure cannot be reproduced once a dataset moves."""
    workspace = alice.new_workspace()
    upload(alice, workspace)
    run = alice.post(
        f"/workspaces/{workspace}/runs",
        json={
            "fx_dataset": "sbi-ttbr-usd-2025",
            "fx_dataset_version": "1.0.0",
            "market_dataset": "no-such-dataset",
        },
    ).json()

    detail = alice.get(f"/workspaces/{workspace}/runs/{run['id']}").json()
    assert detail["fx_dataset_version"] == "1.0.0"
    assert detail["rule_version"]
    assert detail["source_file_hashes"]
    assert detail["policy"]["lot_allocation_method"] == "FIFO"


def test_another_user_cannot_read_your_run(alice, mallory) -> None:
    workspace = alice.new_workspace()
    upload(alice, workspace)
    run = alice.post(
        f"/workspaces/{workspace}/runs",
        json={
            "fx_dataset": "sbi-ttbr-usd-2025",
            "fx_dataset_version": "1.0.0",
            "market_dataset": "no-such-dataset",
        },
    ).json()

    assert mallory.get(f"/workspaces/{workspace}/runs/{run['id']}").status_code == 404
