"""An application wired to a throwaway database and storage root.

Every test gets its own SQLite database and its own storage directory, so
nothing leaks between them and none of it touches the developer's real
configuration.

The job backend is ``inline``: a run finishes before the request returns.
That is a deliberate choice for tests, because polling for a background job
makes an assertion about timing rather than about behaviour.
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool

from backend.app.api.app import API_PREFIX, create_app
from backend.app.core.config import Environment, Settings
from backend.app.db.base import Base
from backend.app.db.session import build_session_factory
from backend.app.jobs.runner import InlineJobRunner
from backend.app.storage.local import LocalBlobStore

PASSWORD = "a-sufficiently-long-password"


@pytest.fixture()
def settings(tmp_path, repo_root) -> Settings:
    return Settings(
        environment=Environment.TEST,
        secret_key="test-only-key-not-used-anywhere-else",  # noqa: S106
        database_url="sqlite+pysqlite:///:memory:",
        storage_root=tmp_path / "storage",
        data_root=repo_root / "data",
        job_backend="inline",
    )


@pytest.fixture()
def engine(settings):
    # StaticPool keeps every connection pointed at the same in-memory
    # database. Without it each connection gets its own empty one, and the
    # schema created here is invisible to the request that needs it.
    engine = create_engine(
        settings.database_url,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    yield engine
    engine.dispose()


@pytest.fixture()
def app(settings, engine):
    factory = build_session_factory(engine)
    return create_app(
        settings=settings,
        engine=engine,
        session_factory=factory,
        blob_store=LocalBlobStore(settings.storage_root),
        job_runner=InlineJobRunner(factory),
    )


@pytest.fixture()
def client(app):
    with TestClient(app) as client:
        yield client


@pytest.fixture()
def api() -> str:
    return API_PREFIX


class Account:
    """A registered user with their token, for readable tests."""

    def __init__(self, client: TestClient, email: str) -> None:
        self.client = client
        self.email = email
        response = client.post(
            f"{API_PREFIX}/auth/register",
            json={"email": email, "password": PASSWORD, "display_name": email},
        )
        assert response.status_code == 201, response.text
        self.token = response.json()["access_token"]

    @property
    def headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.token}"}

    def get(self, path: str, **kwargs):  # noqa: ANN201
        return self.client.get(f"{API_PREFIX}{path}", headers=self.headers, **kwargs)

    def post(self, path: str, **kwargs):  # noqa: ANN201
        return self.client.post(f"{API_PREFIX}{path}", headers=self.headers, **kwargs)

    def put(self, path: str, **kwargs):  # noqa: ANN201
        return self.client.put(f"{API_PREFIX}{path}", headers=self.headers, **kwargs)

    def delete(self, path: str, **kwargs):  # noqa: ANN201
        return self.client.delete(
            f"{API_PREFIX}{path}", headers=self.headers, **kwargs
        )

    def new_workspace(self, name: str = "2026-27 filing") -> str:
        response = self.post(
            "/workspaces", json={"name": name, "assessment_year": "2026-27"}
        )
        assert response.status_code == 201, response.text
        return response.json()["id"]


@pytest.fixture()
def alice(client) -> Account:
    return Account(client, "alice@example.com")


@pytest.fixture()
def mallory(client) -> Account:
    """A second, unrelated account. Used to prove isolation."""
    return Account(client, "mallory@example.com")
