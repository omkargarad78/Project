"""Developer smoke check: import every module and exercise the rule registry.

Run with ``python scripts/smoke.py``. This is a fast feedback loop during
development; the authoritative checks live in ``tests/``.
"""

from __future__ import annotations

import sys
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from backend.app.core.money import as_amount, convert, round_for_output  # noqa: E402
from backend.app.tax.rules.registry import get_rule_registry  # noqa: E402


def main() -> int:
    registry = get_rule_registry()
    years = registry.supported_assessment_years()
    print(f"registered assessment years: {years}")

    for year in years:
        rule = registry.rule_for(year)
        period = rule.tax_period()
        schema = registry.form_schema_for(year, rule.form_version)
        print(f"\n--- {year} ({rule.rule_version_id}, {rule.verification_status})")
        for key, value in period.describe().items():
            print(f"    {key}: {value}")
        print(f"    open decisions: {len(rule.open_decisions)}")
        print(f"    form tables: {[t.table_id for t in schema.tables]}")
        print(f"    A3 columns: {len(schema.table('A3').fields)}")

    inr = convert(as_amount("1234.5678"), Decimal("83.4521"))
    print(f"\nconversion check: USD 1234.5678 -> INR {round_for_output(inr)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
